import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

/** Small JDK Compiler API launcher used by run_jvm_tests.sh. */
public final class JvmTestCompiler {
    private JvmTestCompiler() {}

    public static void main(String[] args) throws IOException {
        if (args.length < 4) {
            System.err.println("Usage: JvmTestCompiler <output-dir> <classpath> <sourcepath> <source...>");
            System.exit(2);
        }
        JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) {
            System.err.println("A full JDK is required; no system Java compiler is available.");
            System.exit(2);
        }

        Path output = Paths.get(args[0]);
        Files.createDirectories(output);
        List<String> sources = new ArrayList<>(Arrays.asList(args).subList(3, args.length));
        if (sources.isEmpty()) {
            System.err.println("No Java test sources were supplied.");
            System.exit(2);
        }

        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        StringWriter compilerOutput = new StringWriter();
        List<String> options = Arrays.asList(
                "-encoding", "UTF-8",
                "--release", "11",
                "-d", output.toAbsolutePath().toString(),
                "-sourcepath", args[2],
                "-classpath", args[1]);

        try (StandardJavaFileManager manager = compiler.getStandardFileManager(
                diagnostics, Locale.ROOT, StandardCharsets.UTF_8)) {
            Iterable<? extends JavaFileObject> units =
                    manager.getJavaFileObjectsFromStrings(sources);
            Boolean ok = compiler.getTask(compilerOutput, manager, diagnostics,
                    options, null, units).call();
            if (compilerOutput.getBuffer().length() > 0)
                System.out.print(compilerOutput);
            for (Diagnostic<? extends JavaFileObject> d : diagnostics.getDiagnostics())
                System.err.println(d.toString());
            if (!Boolean.TRUE.equals(ok)) System.exit(1);
        }
        System.out.println("Java compiler API: compiled " + sources.size() + " test sources.");
    }
}

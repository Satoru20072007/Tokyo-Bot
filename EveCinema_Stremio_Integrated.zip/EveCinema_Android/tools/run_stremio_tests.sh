#!/usr/bin/env bash
# Runs every Stremio test suite WITHOUT Gradle, an Android SDK, a javac binary or any network:
#   * JVM suites  app/src/main/tests/java/com/eve/cinema/stremio/*Test.java  (real classes, real
#     HttpURLConnection against a local JDK HTTP server, no mocks of the code under test)
#   * static/structural guards  app/src/main/tests/test_stremio_wiring.py
#
# It compiles with the JDK compiler API (java.compiler / jdk.compiler modules), so a JRE that
# ships those modules is enough. org.json and android.content are provided by tiny TEST-ONLY
# shims under app/src/main/tests/shims unless ORG_JSON_JAR / ANDROID_JAR point at the real thing.
#
#   tools/run_stremio_tests.sh            # everything
#   tools/run_stremio_tests.sh Engine     # only suites whose name contains "Engine"
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MAIN="$ROOT/app/src/main"
TESTS="$MAIN/tests"
OUT="${TMPDIR:-/tmp}/stremio_jvm_tests.$$"
FILTER="${1:-}"
command -v java >/dev/null 2>&1 || { echo "FAIL: java not found"; exit 2; }
mkdir -p "$OUT/classes" "$OUT/shims"

# Shim directory: android.content always (unless a real android.jar is given), org.json only
# when no real org.json jar is available.
[ -n "${ANDROID_JAR:-}" ] || cp -R "$TESTS/shims/android" "$OUT/shims/android"
[ -n "${ORG_JSON_JAR:-}" ] || cp -R "$TESTS/shims/org" "$OUT/shims/org"
CP="."
[ -n "${ORG_JSON_JAR:-}" ] && CP="$CP:$ORG_JSON_JAR"
[ -n "${ANDROID_JAR:-}" ] && CP="$CP:$ANDROID_JAR"

cat > "$OUT/Compile.java" <<'JAVA'
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import javax.tools.*;
public final class Compile {
    public static void main(String[] a) throws Exception {
        JavaCompiler c = ToolProvider.getSystemJavaCompiler();
        if (c == null) { System.err.println("No system Java compiler (need the jdk.compiler module)"); System.exit(2); }
        DiagnosticCollector<JavaFileObject> d = new DiagnosticCollector<>();
        // Java 8 language level on purpose: stricter than the project's Java 11.
        List<String> opts = Arrays.asList("-encoding","UTF-8","-source","8","-target","8","-Xlint:-options",
                "-d",a[0],"-sourcepath",a[2],"-classpath",a[1]);
        try (StandardJavaFileManager m = c.getStandardFileManager(d, Locale.ROOT, StandardCharsets.UTF_8)) {
            List<String> src = new ArrayList<>(Arrays.asList(a).subList(3, a.length));
            boolean ok = c.getTask(null, m, d, opts, null, m.getJavaFileObjectsFromStrings(src)).call();
            for (Diagnostic<? extends JavaFileObject> x : d.getDiagnostics())
                if (x.getKind() == Diagnostic.Kind.ERROR) System.err.println(x);
            if (!ok) System.exit(1);
        }
    }
}
JAVA

SRC="$MAIN/java:$TESTS/java:$OUT/shims"
mapfile -t SUITES < <(cd "$TESTS/java/com/eve/cinema/stremio" && ls *Test.java | sed 's/\.java$//' | grep -i "$FILTER")
[ "${#SUITES[@]}" -gt 0 ] || { echo "No suites match '$FILTER'"; exit 2; }
FILES=()
for s in "${SUITES[@]}"; do FILES+=("$TESTS/java/com/eve/cinema/stremio/$s.java"); done
echo "== compiling ${#SUITES[@]} suites (Java 8 language level) =="
java "$OUT/Compile.java" "$OUT/classes" "$CP" "$SRC" "${FILES[@]}" || { echo "COMPILE FAILED"; exit 1; }

FAILED=0
for s in "${SUITES[@]}"; do
  echo "== $s =="
  timeout 240 java -cp "$OUT/classes:$CP" "com.eve.cinema.stremio.$s"
  code=$?
  [ "$code" -eq 0 ] || { echo "   exit code $code"; FAILED=$((FAILED+1)); }
done
if [ -z "$FILTER" ] && command -v python3 >/dev/null 2>&1; then
  echo "== test_stremio_wiring.py (static guards) =="
  python3 "$TESTS/test_stremio_wiring.py" 2>&1 | tail -4 || FAILED=$((FAILED+1))
  python3 "$TESTS/test_stremio_wiring.py" >/dev/null 2>&1 || FAILED=$((FAILED+1))
fi
rm -rf "$OUT"
echo "== done: ${#SUITES[@]} JVM suites, $FAILED failing =="
[ "$FAILED" -eq 0 ]

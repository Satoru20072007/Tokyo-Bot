#!/usr/bin/env python3
"""Focused wiring/security checks for the Eve Cinema Android source tree."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ALLOWLIST = ROOT / "tools/wiring_audit_allowlist.json"
failures: list[str] = []


def read(rel: str) -> str:
    path = ROOT / rel
    if not path.is_file():
        failures.append(f"missing required file: {rel}")
        return ""
    return path.read_text(encoding="utf-8", errors="replace")


def report(name: str, ok: bool, detail: str) -> None:
    print(f"{'PASS' if ok else 'FAIL'} {name}: {detail}")
    if not ok:
        failures.append(name)


def check_allowlist() -> None:
    try:
        data = json.loads(ALLOWLIST.read_text(encoding="utf-8"))
        entries = data["entries"]
        ids: set[str] = set()
        allowed_tags = {"PUBLIC_ENDPOINT", "TEST_ONLY_SYNTHETIC", "INTERNAL_IDENTIFIER"}
        for item in entries:
            if not all(item.get(k) for k in ("id", "tag", "path", "reason")):
                raise ValueError("each entry requires id, tag, path and reason")
            if item["id"] in ids:
                raise ValueError("duplicate allowlist id")
            if item["tag"] not in allowed_tags:
                raise ValueError("unknown allowlist tag")
            ids.add(item["id"])
            if not (ROOT / item["path"]).is_file():
                raise ValueError("allowlist path does not exist")
        synthetic = next(x for x in entries if x["id"] == "synthetic-redaction-example")
        sample = (ROOT / synthetic["path"]).read_text(encoding="utf-8", errors="replace")
        if synthetic.get("pattern") not in sample:
            raise ValueError("synthetic example no longer matches its documented test")
        report("tagged_allowlist", True,
               f"{len(entries)} documented entries; entries never suppress secret checks")
    except Exception as exc:
        report("tagged_allowlist", False, f"invalid or stale allowlist ({type(exc).__name__})")


def check_no_literal_secrets() -> None:
    rels = [
        "app/build.gradle.kts",
        "app/src/main/java/com/eve/cinema/Config.java",
        "app/src/main/java/com/eve/cinema/CinemaBoxCredentials.java",
    ]
    assignment = re.compile(
        r"(?im)\b(?:storePassword|keyPassword|TMDB_API_KEY|TMDB_BEARER_TOKEN|"
        r"OPENSUBTITLES_API_KEY|password|api[_-]?key|access[_-]?token)\b"
        r"\s*(?:=|,)\s*([\"'])(.*?)\1"
    )
    bad: list[str] = []
    for rel in rels:
        text = read(rel)
        for match in assignment.finditer(text):
            value = match.group(2).strip()
            if value and value.casefold() not in {"redacted", "placeholder", "test"}:
                bad.append(rel)
    report("no_embedded_credential_literals", not bad,
           "no nonempty literal credential assignments" if not bad
           else "nonempty credential-like literals found in: " + ", ".join(sorted(set(bad))))


def check_signing_ignore_rules() -> None:
    text = read(".gitignore")
    lines = {line.strip() for line in text.splitlines()}
    required = {"*.jks", "*.keystore", "local.properties", "app/google-services.json",
                "gradle.local.properties", "keystore.properties"}
    missing = sorted(required - lines)
    report("signing_and_local_secrets_ignored", not missing,
           "all six local-material ignore rules present" if not missing
           else "missing ignore rules: " + ", ".join(missing))


def check_fixture_signatures() -> None:
    fixture_root = ROOT / "app/src/main/tests/fixtures"
    bad: list[str] = []
    if not fixture_root.is_dir():
        report("fixture_signatures_redacted", False, "fixture directory missing")
        return
    names = r"Signature|Policy|Key-Pair-Id|Expires|token|JWT"
    patterns = [
        re.compile(r"(?i)[?&](?:" + names + r")=([^&\"'\s]+)"),
        re.compile(r"(?i)[\"'](?:" + names + r")[\"']\s*:\s*[\"']([^\"']+)[\"']"),
    ]
    safe = {"test_redacted", "redacted", "placeholder"}
    for path in fixture_root.rglob("*.json"):
        text = path.read_text(encoding="utf-8", errors="replace")
        if any(match.group(1).casefold() not in safe
               for pattern in patterns for match in pattern.finditer(text)):
            bad.append(path.relative_to(ROOT).as_posix())
    report("fixture_signatures_redacted", not bad,
           "all signed URL credential fields in JSON fixtures are redacted" if not bad
           else "unredacted signed URL fields in: " + ", ".join(bad))


def check_auth_preflight_and_gate() -> None:
    state = read("app/src/main/java/com/eve/cinema/providercore/ProviderResultState.java")
    adapter = read("app/src/main/java/com/eve/cinema/providercore/ProviderAdapter.java")
    controller = read("app/src/main/java/com/eve/cinema/providercore/SourceWaveController.java")
    cb = read("app/src/main/java/com/eve/cinema/providers/CinemaBoxProviderAdapter.java")
    health = read("app/src/main/java/com/eve/cinema/providercore/ProviderHealthStore.java")
    method = re.search(r"boolean countsAgainstHealth\(\)\s*\{(.*?)\n\s*\}", state, re.S)
    ok = bool(method and "case AUTH_REQUIRED" not in method.group(1)
              and "preflight(CanonicalMediaIdentity identity)" in adapter
              and "adapter.preflight(identity)" in controller
              and controller.find("adapter.preflight(identity)") < controller.find("tryAcquireProvider(id)")
              and "ProviderResultState.AUTH_REQUIRED" in cb
              and re.search(r"void reset\(String providerId\)", health))
    report("auth_required_preflight_not_outage", ok,
           "missing account is classified locally before provider circuit; health reset exists"
           if ok else "preflight, health classification or reset wiring is incomplete")


def check_labels_and_diagnostics() -> None:
    choice = read("app/src/main/java/com/eve/cinema/playback/SourceChoice.java")
    recorder = read("app/src/main/java/com/eve/cinema/DiagnosticsRecorder.java")
    redactor = read("app/src/main/java/com/eve/cinema/DiagnosticRedactor.java")
    label1 = re.search(r"LABEL_1\s*=\s*\"([^\"]+)\"", choice)
    label2 = re.search(r"LABEL_2\s*=\s*\"([^\"]+)\"", choice)
    labels_ok = bool(label1 and label2 and label1.group(1) == "مصدر 1"
                     and label2.group(1) == "مصدر 2")
    diagnostics_ok = "DiagnosticRedactor.redactText" in recorder and "redactText" in redactor
    ok = labels_ok and diagnostics_ok
    report("generic_labels_and_redacted_diagnostics", ok,
           "generic Arabic source labels and diagnostic redaction wiring verified"
           if ok else "public labels or redaction path requires review")


def check_private_diagnostic_storage() -> None:
    recorder = read("app/src/main/java/com/eve/cinema/DiagnosticsRecorder.java")
    app = read("app/src/main/java/com/eve/cinema/Applications.java")
    splash = read("app/src/main/java/com/eve/cinema/SplashActivity.java")
    manifest = read("app/src/main/AndroidManifest.xml")
    forbidden = (
        "android.permission.MANAGE_EXTERNAL_STORAGE",
        "android.permission.WRITE_EXTERNAL_STORAGE",
        "android.permission.READ_EXTERNAL_STORAGE",
    )
    ok = ("context.getNoBackupFilesDir()" in recorder
          and all(permission not in manifest for permission in forbidden)
          and "Environment.isExternalStorageManager" not in recorder + app + splash
          and "requestDiagnosticStorageAccess" not in splash
          and "/storage/emulated/0" not in recorder)
    report("private_diagnostic_storage", ok,
           "diagnostics use app-private no-backup storage without broad file permissions"
           if ok else "broad storage permission or public diagnostic path remains")


def main() -> int:
    check_allowlist()
    check_no_literal_secrets()
    check_signing_ignore_rules()
    check_fixture_signatures()
    check_auth_preflight_and_gate()
    check_labels_and_diagnostics()
    check_private_diagnostic_storage()
    failed = sum(1 for line in failures if line in {
        "tagged_allowlist", "no_embedded_credential_literals",
        "signing_and_local_secrets_ignored", "fixture_signatures_redacted",
        "auth_required_preflight_not_outage", "generic_labels_and_redacted_diagnostics",
        "private_diagnostic_storage"})
    print(f"wiring audit: {7 - failed} passed, {failed} failed")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())

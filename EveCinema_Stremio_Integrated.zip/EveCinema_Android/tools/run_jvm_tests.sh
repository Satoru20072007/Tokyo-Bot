#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

command -v java >/dev/null || { echo "FAIL: java غير متوفر" >&2; exit 2; }
command -v javac >/dev/null || { echo "FAIL: يلزم JDK كامل (javac غير متوفر)" >&2; exit 2; }
command -v python3 >/dev/null || { echo "FAIL: python3 غير متوفر" >&2; exit 2; }

CLASSPATH_EXTRA="${ORG_JSON_JAR:-}"
if [[ -z "$CLASSPATH_EXTRA" ]]; then
  CLASSPATH_EXTRA="$(find "${HOME}/.gradle/caches/modules-2/files-2.1/org.json/json" \
    -type f -name '*.jar' -print 2>/dev/null | sort -V | tail -n 1 || true)"
fi
if [[ -z "$CLASSPATH_EXTRA" ]]; then
  SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
  if [[ -n "$SDK" ]]; then
    CLASSPATH_EXTRA="$(find "$SDK/platforms" -type f -name android.jar -print 2>/dev/null | sort -V | tail -n 1 || true)"
  fi
fi
if [[ -z "$CLASSPATH_EXTRA" ]]; then
  echo "FAIL: يلزم org.json على JVM؛ عيّن ORG_JSON_JAR أو Android SDK (android.jar)." >&2
  exit 2
fi

TMP="$(mktemp -d "${TMPDIR:-/tmp}/eve-cinema-jvm.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/compiler" "$TMP/classes"

echo "== Compile test harness =="
javac --release 11 -encoding UTF-8 -d "$TMP/compiler" tools/JvmTestCompiler.java
mapfile -d '' TEST_SOURCES < <(find app/src/main/tests/java -type f -name '*.java' -print0 | sort -z)
if [[ ${#TEST_SOURCES[@]} -eq 0 ]]; then
  echo "FAIL: لم تُعثر على اختبارات Java" >&2
  exit 2
fi
SOURCEPATH="$ROOT/app/src/main/java:$ROOT/app/src/main/tests/java"
java -cp "$TMP/compiler" JvmTestCompiler "$TMP/classes" "$CLASSPATH_EXTRA" \
  "$SOURCEPATH" "${TEST_SOURCES[@]}"

JAVA_PASS=0
JAVA_FAIL=0
JAVA_MAINS=()
for source in "${TEST_SOURCES[@]}"; do
  if grep -Eq 'public[[:space:]]+static[[:space:]]+void[[:space:]]+main[[:space:]]*\(' "$source"; then
    rel="${source#app/src/main/tests/java/}"
    cls="${rel%.java}"
    cls="${cls//\//.}"
    JAVA_MAINS+=("$cls")
  fi
done
for cls in "${JAVA_MAINS[@]}"; do
  echo "== Java: $cls =="
  if java -cp "$TMP/classes:$CLASSPATH_EXTRA" "$cls"; then
    echo "PASS Java suite: $cls"
    JAVA_PASS=$((JAVA_PASS + 1))
  else
    echo "FAIL Java suite: $cls" >&2
    JAVA_FAIL=$((JAVA_FAIL + 1))
  fi
done

echo "== Python wiring suites =="
PY_STATUS=0
python3 -m unittest discover -s app/src/main/tests -p 'test_*.py' -v || PY_STATUS=$?
if [[ $PY_STATUS -eq 0 ]]; then
  echo "PASS Python test discovery"
else
  echo "FAIL Python test discovery (exit $PY_STATUS)" >&2
fi

echo "== Summary =="
echo "Java suites: $JAVA_PASS passed, $JAVA_FAIL failed; discovered ${#JAVA_MAINS[@]}"
if [[ $PY_STATUS -ne 0 || $JAVA_FAIL -ne 0 ]]; then exit 1; fi

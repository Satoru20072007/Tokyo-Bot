import java.util.Properties

plugins {
    id("com.android.application")
    id("com.google.gms.google-services")
}

val releaseSigning = mapOf(
    "eve.storeFile" to (providers.gradleProperty("eve.storeFile").orNull ?: System.getenv("EVE_STORE_FILE")),
    "eve.storePassword" to (providers.gradleProperty("eve.storePassword").orNull ?: System.getenv("EVE_STORE_PASSWORD")),
    "eve.keyAlias" to (providers.gradleProperty("eve.keyAlias").orNull ?: System.getenv("EVE_KEY_ALIAS")),
    "eve.keyPassword" to (providers.gradleProperty("eve.keyPassword").orNull ?: System.getenv("EVE_KEY_PASSWORD"))
)
val hasReleaseSigning = releaseSigning.values.all { !it.isNullOrBlank() }

// local.properties (في جذر المشروع، خارج git) يُقرأ كذلك، فيعمل بناء debug/release
// من أي بيئة (Android Studio / AndroidIDE / سطر الأوامر) بدون متغيرات بيئة.
val localProps = Properties().also { p ->
    val f = rootProject.file("local.properties")
    if (f.isFile) f.inputStream().use { p.load(it) }
}
val tmdbBearerToken = (providers.gradleProperty("eve.tmdbBearerToken").orNull
    ?: localProps.getProperty("eve.tmdbBearerToken")
    ?: System.getenv("EVE_TMDB_BEARER_TOKEN")
    ?: "").trim()
val tmdbApiKey = (providers.gradleProperty("eve.tmdbApiKey").orNull
    ?: localProps.getProperty("eve.tmdbApiKey")
    ?: System.getenv("EVE_TMDB_API_KEY")
    ?: "").trim()

// Warn (do not fail) when the TMDB token is missing.
gradle.taskGraph.whenReady {
    if (tmdbBearerToken.isBlank()) {
        println("WARNING: eve.tmdbBearerToken is empty - TMDB requests will fail with 401. Add it to local.properties.")
    }
}
fun javaStringLiteral(value: String): String =
    "\"${value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r")}\""

android {
    namespace = "com.eve.cinema"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.eve.cinema"
        minSdk = 28
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        buildConfigField("String", "TMDB_BEARER_TOKEN", javaStringLiteral(tmdbBearerToken))
        buildConfigField("String", "TMDB_API_KEY", javaStringLiteral(tmdbApiKey))

        vectorDrawables {
            useSupportLibrary = true
        }
    }

    signingConfigs {
        create("release") {
            if (hasReleaseSigning) {
                storeFile = rootProject.file(requireNotNull(releaseSigning["eve.storeFile"]))
                storePassword = requireNotNull(releaseSigning["eve.storePassword"])
                keyAlias = requireNotNull(releaseSigning["eve.keyAlias"])
                keyPassword = requireNotNull(releaseSigning["eve.keyPassword"])
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (hasReleaseSigning) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("com.google.android.material:material:1.11.0")
    implementation("com.github.bumptech.glide:glide:4.16.0")

    // AndroidX Media3 (ExoPlayer)
    val media3Version = "1.3.1"
    implementation("androidx.media3:media3-exoplayer:$media3Version")
    implementation("androidx.media3:media3-exoplayer-hls:$media3Version")
    implementation("androidx.media3:media3-exoplayer-dash:$media3Version")
    implementation("androidx.media3:media3-ui:$media3Version")
    implementation("androidx.media3:media3-common:$media3Version")
    implementation("androidx.media3:media3-datasource:$media3Version")
    implementation("androidx.media3:media3-datasource-okhttp:$media3Version")
    implementation("androidx.media3:media3-session:$media3Version")

    // Firebase
    implementation(platform("com.google.firebase:firebase-bom:33.1.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")

    // Google Sign-In
    implementation("com.google.android.gms:play-services-auth:21.2.0")
}

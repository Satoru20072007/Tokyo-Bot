package org.json;

import java.util.Map;

/** TEST-ONLY strict JSON reader/writer shared by the org.json doubles. */
final class JsonParser {
    private final String s;
    private int p;

    JsonParser(String s) { this.s = s == null ? "" : s; }

    Object parseDocument() throws JSONException {
        skipWs();
        Object v = value();
        skipWs();
        if (p != s.length()) throw new JSONException("Unexpected trailing data at " + p);
        return v;
    }

    private Object value() throws JSONException {
        if (p >= s.length()) throw new JSONException("Unexpected end of input");
        char c = s.charAt(p);
        switch (c) {
            case '{': return object();
            case '[': return array();
            case '"': return string();
            case 't': expect("true"); return Boolean.TRUE;
            case 'f': expect("false"); return Boolean.FALSE;
            case 'n': expect("null"); return JSONObject.NULL;
            default:
                if (c == '-' || (c >= '0' && c <= '9')) return number();
                throw new JSONException("Unexpected character at " + p);
        }
    }

    private JSONObject object() throws JSONException {
        JSONObject o = new JSONObject();
        p++; skipWs();
        if (peek() == '}') { p++; return o; }
        while (true) {
            skipWs();
            if (peek() != '"') throw new JSONException("Expected name at " + p);
            String k = string();
            skipWs();
            if (peek() != ':') throw new JSONException("Expected ':' at " + p);
            p++; skipWs();
            o.values.put(k, value());
            skipWs();
            char c = peek();
            if (c == ',') { p++; continue; }
            if (c == '}') { p++; return o; }
            throw new JSONException("Expected ',' or '}' at " + p);
        }
    }

    private JSONArray array() throws JSONException {
        JSONArray a = new JSONArray();
        p++; skipWs();
        if (peek() == ']') { p++; return a; }
        while (true) {
            skipWs();
            a.values.add(value());
            skipWs();
            char c = peek();
            if (c == ',') { p++; continue; }
            if (c == ']') { p++; return a; }
            throw new JSONException("Expected ',' or ']' at " + p);
        }
    }

    private String string() throws JSONException {
        StringBuilder sb = new StringBuilder();
        p++;
        while (true) {
            if (p >= s.length()) throw new JSONException("Unterminated string");
            char c = s.charAt(p++);
            if (c == '"') return sb.toString();
            if (c < 0x20) throw new JSONException("Control character in string");
            if (c != '\\') { sb.append(c); continue; }
            if (p >= s.length()) throw new JSONException("Bad escape");
            char e = s.charAt(p++);
            switch (e) {
                case '"': sb.append('"'); break;
                case '\\': sb.append('\\'); break;
                case '/': sb.append('/'); break;
                case 'b': sb.append('\b'); break;
                case 'f': sb.append('\f'); break;
                case 'n': sb.append('\n'); break;
                case 'r': sb.append('\r'); break;
                case 't': sb.append('\t'); break;
                case 'u':
                    if (p + 4 > s.length()) throw new JSONException("Bad unicode escape");
                    try { sb.append((char) Integer.parseInt(s.substring(p, p + 4), 16)); }
                    catch (NumberFormatException ex) { throw new JSONException("Bad unicode escape"); }
                    p += 4;
                    break;
                default: throw new JSONException("Bad escape");
            }
        }
    }

    private Object number() throws JSONException {
        int start = p;
        if (peek() == '-') p++;
        while (p < s.length() && Character.isDigit(s.charAt(p))) p++;
        boolean fp = false;
        if (p < s.length() && s.charAt(p) == '.') { fp = true; p++; while (p < s.length() && Character.isDigit(s.charAt(p))) p++; }
        if (p < s.length() && (s.charAt(p) == 'e' || s.charAt(p) == 'E')) {
            fp = true; p++;
            if (p < s.length() && (s.charAt(p) == '+' || s.charAt(p) == '-')) p++;
            while (p < s.length() && Character.isDigit(s.charAt(p))) p++;
        }
        String t = s.substring(start, p);
        try {
            if (!fp) {
                try { return Long.parseLong(t); } catch (NumberFormatException big) { return Double.parseDouble(t); }
            }
            return Double.parseDouble(t);
        } catch (NumberFormatException ex) { throw new JSONException("Bad number at " + start); }
    }

    private void expect(String lit) throws JSONException {
        if (!s.startsWith(lit, p)) throw new JSONException("Unexpected literal at " + p);
        p += lit.length();
    }
    private char peek() { return p < s.length() ? s.charAt(p) : '\0'; }
    private void skipWs() { while (p < s.length() && " \t\r\n".indexOf(s.charAt(p)) >= 0) p++; }

    static void write(Object v, StringBuilder sb) {
        if (v == null || v == JSONObject.NULL) sb.append("null");
        else if (v instanceof String) quote((String) v, sb);
        else if (v instanceof JSONObject || v instanceof JSONArray || v instanceof Number || v instanceof Boolean) sb.append(v);
        else if (v instanceof Map) sb.append(new JSONObject((Map<?, ?>) v));
        else quote(String.valueOf(v), sb);
    }

    static void quote(String v, StringBuilder sb) {
        sb.append('"');
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c)); else sb.append(c);
            }
        }
        sb.append('"');
    }
}

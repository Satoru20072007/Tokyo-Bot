package org.json;

/** TEST-ONLY stand-in for org.json.JSONException (the app uses the Android framework class). */
public class JSONException extends Exception {
    public JSONException(String message) { super(message); }
}

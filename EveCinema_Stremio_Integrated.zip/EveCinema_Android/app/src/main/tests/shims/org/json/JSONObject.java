package org.json;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * TEST-ONLY minimal org.json double used by tools/run_stremio_tests.sh when neither an org.json jar
 * nor android.jar is available. It mirrors the Android framework semantics the Stremio code relies
 * on (opt* coercions, JSONObject.NULL stringifying to "null") but is STRICTER when parsing
 * (no comments / single quotes / trailing garbage). It is never packaged into the app.
 */
public class JSONObject {
    public static final Object NULL = new Object() {
        @Override public boolean equals(Object o) { return o == this || o == null; }
        @Override public int hashCode() { return 0; }
        @Override public String toString() { return "null"; }
    };

    final LinkedHashMap<String, Object> values = new LinkedHashMap<>();

    public JSONObject() {}

    public JSONObject(Map<?, ?> copyFrom) {
        for (Map.Entry<?, ?> e : copyFrom.entrySet()) {
            if (e.getKey() == null) throw new NullPointerException("key == null");
            values.put((String) e.getKey(), e.getValue() == null ? NULL : e.getValue());
        }
    }

    public JSONObject(String json) throws JSONException {
        Object value = new JsonParser(json).parseDocument();
        if (!(value instanceof JSONObject)) throw new JSONException("Value is not a JSONObject");
        values.putAll(((JSONObject) value).values);
    }

    public int length() { return values.size(); }

    public JSONObject put(String name, Object value) throws JSONException {
        if (name == null) throw new JSONException("Names must be non-null");
        if (value == null) { values.remove(name); return this; }
        if (value instanceof Double && (((Double) value).isNaN() || ((Double) value).isInfinite()))
            throw new JSONException("Forbidden numeric value: " + value);
        values.put(name, value);
        return this;
    }
    public JSONObject put(String name, boolean value) throws JSONException { return put(name, (Object) value); }
    public JSONObject put(String name, int value) throws JSONException { return put(name, (Object) value); }
    public JSONObject put(String name, long value) throws JSONException { return put(name, (Object) value); }
    public JSONObject put(String name, double value) throws JSONException { return put(name, (Object) value); }

    public JSONObject putOpt(String name, Object value) throws JSONException {
        return (name == null || value == null) ? this : put(name, value);
    }

    public Object remove(String name) { return values.remove(name); }
    public boolean has(String name) { return values.containsKey(name); }
    public boolean isNull(String name) { Object o = values.get(name); return o == null || o == NULL; }
    public Object opt(String name) { return values.get(name); }

    public Object get(String name) throws JSONException {
        Object r = values.get(name);
        if (r == null) throw new JSONException("No value for " + name);
        return r;
    }

    public String optString(String name) { return optString(name, ""); }
    public String optString(String name, String fallback) {
        Object o = opt(name);
        return o == null ? fallback : (o instanceof String ? (String) o : String.valueOf(o));
    }
    public String getString(String name) throws JSONException {
        Object o = get(name);
        if (o instanceof String) return (String) o;
        throw new JSONException("Value for " + name + " is not a String");
    }

    public int optInt(String name) { return optInt(name, 0); }
    public int optInt(String name, int fallback) {
        Long l = toLong(opt(name));
        return l == null ? fallback : (int) (long) l;
    }
    public long optLong(String name) { return optLong(name, 0L); }
    public long optLong(String name, long fallback) {
        Long l = toLong(opt(name));
        return l == null ? fallback : l;
    }
    public double optDouble(String name, double fallback) {
        Object o = opt(name);
        if (o instanceof Number) return ((Number) o).doubleValue();
        if (o instanceof String) { try { return Double.parseDouble((String) o); } catch (NumberFormatException e) { return fallback; } }
        return fallback;
    }
    public boolean optBoolean(String name) { return optBoolean(name, false); }
    public boolean optBoolean(String name, boolean fallback) {
        Object o = opt(name);
        if (o instanceof Boolean) return (Boolean) o;
        if (o instanceof String) {
            String s = (String) o;
            if ("true".equalsIgnoreCase(s)) return true;
            if ("false".equalsIgnoreCase(s)) return false;
        }
        return fallback;
    }

    public JSONObject optJSONObject(String name) {
        Object o = opt(name);
        return o instanceof JSONObject ? (JSONObject) o : null;
    }
    public JSONArray optJSONArray(String name) {
        Object o = opt(name);
        return o instanceof JSONArray ? (JSONArray) o : null;
    }
    public JSONObject getJSONObject(String name) throws JSONException {
        Object o = get(name);
        if (o instanceof JSONObject) return (JSONObject) o;
        throw new JSONException("Value for " + name + " is not a JSONObject");
    }
    public JSONArray getJSONArray(String name) throws JSONException {
        Object o = get(name);
        if (o instanceof JSONArray) return (JSONArray) o;
        throw new JSONException("Value for " + name + " is not a JSONArray");
    }

    public Iterator<String> keys() { return new java.util.ArrayList<>(values.keySet()).iterator(); }
    public JSONArray names() {
        if (values.isEmpty()) return null;
        JSONArray a = new JSONArray();
        for (String k : values.keySet()) a.put(k);
        return a;
    }

    static Long toLong(Object o) {
        if (o instanceof Number) return ((Number) o).longValue();
        if (o instanceof String) {
            try { return (long) Double.parseDouble((String) o); } catch (NumberFormatException ignored) { }
        }
        return null;
    }

    @Override public String toString() {
        StringBuilder sb = new StringBuilder("{");
        boolean first = true;
        for (Map.Entry<String, Object> e : values.entrySet()) {
            if (!first) sb.append(',');
            first = false;
            JsonParser.quote(e.getKey(), sb);
            sb.append(':');
            JsonParser.write(e.getValue(), sb);
        }
        return sb.append('}').toString();
    }
}

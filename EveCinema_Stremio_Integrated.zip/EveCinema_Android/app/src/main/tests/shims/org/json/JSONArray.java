package org.json;

import java.util.ArrayList;
import java.util.List;

/** TEST-ONLY minimal org.json double (see JSONObject). */
public class JSONArray {
    final List<Object> values = new ArrayList<>();

    public JSONArray() {}

    public JSONArray(String json) throws JSONException {
        Object value = new JsonParser(json).parseDocument();
        if (!(value instanceof JSONArray)) throw new JSONException("Value is not a JSONArray");
        values.addAll(((JSONArray) value).values);
    }

    public int length() { return values.size(); }
    public JSONArray put(Object value) { values.add(value == null ? JSONObject.NULL : value); return this; }
    public JSONArray put(boolean value) { return put((Object) value); }
    public JSONArray put(int value) { return put((Object) value); }
    public JSONArray put(long value) { return put((Object) value); }
    public JSONArray put(double value) { return put((Object) value); }

    public Object opt(int index) { return (index < 0 || index >= values.size()) ? null : values.get(index); }
    public Object get(int index) throws JSONException {
        if (index < 0 || index >= values.size()) throw new JSONException("Index " + index + " out of range [0.." + values.size() + ")");
        return values.get(index);
    }
    public boolean isNull(int index) { Object o = opt(index); return o == null || o == JSONObject.NULL; }

    public String optString(int index) { return optString(index, ""); }
    public String optString(int index, String fallback) {
        Object o = opt(index);
        return o == null ? fallback : (o instanceof String ? (String) o : String.valueOf(o));
    }
    public int optInt(int index, int fallback) {
        Long l = JSONObject.toLong(opt(index));
        return l == null ? fallback : (int) (long) l;
    }
    public long optLong(int index, long fallback) {
        Long l = JSONObject.toLong(opt(index));
        return l == null ? fallback : l;
    }
    public JSONObject optJSONObject(int index) {
        Object o = opt(index);
        return o instanceof JSONObject ? (JSONObject) o : null;
    }
    public JSONArray optJSONArray(int index) {
        Object o = opt(index);
        return o instanceof JSONArray ? (JSONArray) o : null;
    }

    @Override public String toString() {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < values.size(); i++) {
            if (i > 0) sb.append(',');
            JsonParser.write(values.get(i), sb);
        }
        return sb.append(']').toString();
    }
}

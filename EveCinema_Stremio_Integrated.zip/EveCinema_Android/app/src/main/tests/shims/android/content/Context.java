package android.content;

/** TEST-ONLY compile stub of android.content.Context. */
public abstract class Context {
    public static final int MODE_PRIVATE = 0;
    public abstract SharedPreferences getSharedPreferences(String name, int mode);
    public Context getApplicationContext() { return this; }
}

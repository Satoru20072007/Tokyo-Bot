package com.eve.cinema.stremio;

import java.util.Arrays;
import java.util.Collections;

public final class StremioQualityTest {
    private static StremioQuality.Evidence ev(String name, String file, String desc, String url) {
        return StremioQuality.analyze(name, file, desc, url);
    }

    public static void main(String[] args) {
        T.section("resolution only from what the metadata states");
        StremioQuality.Evidence e = ev("Torrentio\n4k", "Movie.2010.2160p.mkv", "", "");
        T.eq(2160, e.height, "4k + 2160p agree");
        T.eq("name", e.source, "first field that states it");
        T.ok(!e.contradictory, "no contradiction");
        T.eq(1080, ev("", "", "Movie 1080p WEB-DL", "").height, "description alone");
        T.eq(720, ev("", "", "", "https://cdn.example/v/Movie.720p.mkv").height, "URL decides only when nothing else does");
        T.eq("url", ev("", "", "", "https://cdn.example/v/Movie.720p.mkv").source, "URL provenance");
        T.eq(1080, ev("", "", "1920x1080 h264", "").height, "declared WxH");
        T.eq(2160, ev("", "", "3840x1600 cinemascope", "").height, "cinemascope crop maps to 2160");
        T.eq(2160, ev("UHD", "", "", "").height, "UHD");
        for (String none : new String[]{"Movie.2010.mkv", "x264 AAC", "1080", "S01E1080", "mp4a1080p9", "", null})
            T.eq(0, ev(none, null, null, null).height, "no resolution in: " + none);

        T.section("contradictions are shown as unknown, never guessed");
        StremioQuality.Evidence c = ev("720p", "", "Movie 1080p", "");
        T.eq(0, c.height, "name says 720p, description says 1080p");
        T.ok(c.contradictory, "flagged contradictory");
        T.eq(new java.util.LinkedHashSet<>(Arrays.asList(720, 1080)), c.distinctHeights, "raw values kept for diagnostics");
        T.ok(ev("Pack 1080p 720p", "", "", "").contradictory, "one field listing several resolutions is ambiguous too");
        T.ok(!ev("1080p", "x.1080p.mkv", "FullHD 1080p", "").contradictory, "agreement across fields is fine");
        T.eq(1080, ev("1080p", "", "", "https://cdn.example/a.720p.mkv").height, "URL never contradicts a stated resolution (it is only a fallback)");

        T.section("buckets and labels");
        T.eq(StremioQuality.Bucket.Q2160, StremioQuality.bucketOf(2160), "2160");
        T.eq(StremioQuality.Bucket.Q1440, StremioQuality.bucketOf(1440), "1440");
        T.eq(StremioQuality.Bucket.Q1080, StremioQuality.bucketOf(1080), "1080");
        T.eq(StremioQuality.Bucket.Q720, StremioQuality.bucketOf(720), "720");
        T.eq(StremioQuality.Bucket.Q576, StremioQuality.bucketOf(576), "576p stays separate");
        T.eq(StremioQuality.Bucket.Q480, StremioQuality.bucketOf(480), "480p stays separate");
        T.eq(StremioQuality.Bucket.Q360, StremioQuality.bucketOf(360), "360p stays separate");
        T.eq(StremioQuality.Bucket.SD, StremioQuality.bucketOf(240), "sub-360p falls into SD");
        T.eq(StremioQuality.Bucket.UNKNOWN, StremioQuality.bucketOf(0), "unknown");
        T.eq("2160p", StremioQuality.label(2160), "2160p label");
        T.eq("1080p", StremioQuality.label(1080), "1080p label");
        T.eq(null, StremioQuality.label(0), "unknown has no label");

        T.section("option helpers");
        StremioStreamOption o = new StremioStreamOption("s1", "https://cdn.example/a.mkv", null, "m", "PROGRESSIVE", 1080,
                "name", false, -1d, null, 1, "a.mkv", 4_000_000_000L, "h", Collections.singleton("h:h"));
        T.eq("MKV", o.formatLabel(), "container from the URL extension");
        T.eq("HLS", new StremioStreamOption("s", "https://c.example/p.m3u8", null, "m", "HLS", 0, 0d, null).formatLabel(), "HLS");
        T.eq("", new StremioStreamOption("s", "https://c.example/p.avi", null, "m", "UNKNOWN", 0, 0d, null).formatLabel(), "unknown containers get no label");
        T.eq("3.7 GB", StremioStreamOption.formatSize(4_000_000_000L), "size in GB");
        T.eq("850 MB", StremioStreamOption.formatSize(850L * 1024 * 1024), "size in MB");
        T.eq("", StremioStreamOption.formatSize(-1), "unknown size");
        T.eq("12", StremioStreamOption.formatMbps(12.3), "Mbps >= 10 rounds");
        T.eq("4.2", StremioStreamOption.formatMbps(4.21), "Mbps < 10 keeps a decimal");
        StremioStreamOption p = o.withProbe(8.0, 720);
        T.ok(p.qualityHeight == 720 && "manifest".equals(p.qualitySource) && p.speedMbps == 8.0, "probe result applied with provenance");
        T.ok(o.withProbe(8.0, 0).qualityHeight == 1080, "no manifest height: text-derived value kept");
        T.ok(o.sameFileAs(p) && !o.sameFileAs(null), "same strong key = same file");
        System.exit(T.finish("StremioQualityTest"));
    }
}

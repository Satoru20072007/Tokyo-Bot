package com.eve.cinema.stremio;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;

public final class StremioChooserDataTest {
    private static StremioStreamOption opt(String id, int height, double mbps) {
        return new StremioStreamOption(id, "https://cdn.example/" + id + ".mkv", null, "m", "PROGRESSIVE", height, "name", false,
                mbps, null, 1, "", -1L, "", new LinkedHashSet<String>());
    }

    private static List<String> ids(List<StremioStreamOption> o) { List<String> r = new ArrayList<>(); for (StremioStreamOption x : o) r.add(x.id); return r; }

    public static void main(String[] args) {
        T.section("fixed quality groups, fastest measured links first");
        List<StremioStreamOption> mixed = Arrays.asList(opt("u1", 0, -1), opt("p720a", 720, -1), opt("k4", 2160, -1),
                opt("p1080a", 1080, -1), opt("sd", 480, -1), opt("p1080b", 1080, 50), opt("p720b", 720, 5), opt("q1440", 1440, -1), opt("sd2", 576, -1));
        List<StremioOptionRanker.Group> groups = StremioOptionRanker.group(mixed);
        List<StremioQuality.Bucket> order = new ArrayList<>();
        for (StremioOptionRanker.Group g : groups) order.add(g.bucket);
        T.eq(Arrays.asList(StremioQuality.Bucket.Q2160, StremioQuality.Bucket.Q1440, StremioQuality.Bucket.Q1080,
                StremioQuality.Bucket.Q720, StremioQuality.Bucket.Q576, StremioQuality.Bucket.Q480,
                StremioQuality.Bucket.UNKNOWN), order, "individual quality buckets in descending resolution order");
        T.eq(Arrays.asList("p1080b", "p1080a"), ids(groups.get(2).options), "measured speed ranks ahead of unknown speed in 1080p");
        T.eq(Arrays.asList("p720b", "p720a"), ids(groups.get(3).options), "measured speed ranks ahead of unknown speed in 720p");
        T.eq(Arrays.asList("sd2"), ids(groups.get(4).options), "576p has its own group");
        T.eq(Arrays.asList("sd"), ids(groups.get(5).options), "480p has its own group");
        T.eq(9, StremioOptionRanker.rank(mixed).size(), "rank() keeps every option");
        T.eq(0, StremioOptionRanker.group(Collections.<StremioStreamOption>emptyList()).size(), "empty input");

        T.section("fastest badge needs at least two measurements");
        T.eq(null, snapshot(opt("a", 1080, -1), opt("b", 1080, 10)).fastestId, "one measurement proves nothing");
        T.eq("b", snapshot(opt("a", 1080, 4), opt("b", 1080, 10)).fastestId, "highest measured speed");
        T.eq(null, snapshot(opt("a", 1080, -1), opt("b", 720, -1)).fastestId, "nothing measured");

        T.section("states");
        T.ok(!StremioChooserData.loading().isFinal(), "LOADING is not final");
        T.ok(StremioChooserData.empty().isFinal(), "empty() is final");
        StremioChooserData legacy = new StremioChooserData(Arrays.asList(opt("a", 1080, -1)), Collections.<StremioSubtitle>emptyList());
        T.eq(StremioChooserData.State.COMPLETE, legacy.state, "compatibility constructor = finished list");

        T.section("subtitle lists are capped but exact matches are never cut");
        List<StremioSubtitle> subs = new ArrayList<>();
        StremioStreamOption o = new StremioStreamOption("s1", "https://cdn.example/s1.mkv", null, "m", "PROGRESSIVE", 1080, "name", false,
                -1d, null, 1, "", -1L, "", new LinkedHashSet<>(Arrays.asList("h:x")));
        for (int i = 0; i < 20; i++) subs.add(new StremioSubtitle("g" + i, "https://s.example/g" + i + ".srt", "ara", Collections.<String>emptySet(), Collections.<String>emptySet(), true));
        for (int i = 0; i < 3; i++) subs.add(new StremioSubtitle("e" + i, "https://s.example/e" + i + ".srt", "ara", Collections.<String>emptySet(), Collections.singleton("h:x"), false));
        StremioChooserData d = new StremioChooserData(1L, StremioChooserData.State.COMPLETE, StremioChooserData.EmptyReason.NONE,
                Arrays.asList(o), subs, StremioChooserData.Progress.NONE);
        List<StremioSubtitle> offered = d.subtitlesFor(o);
        T.eq(StremioChooserData.MAX_SUBTITLES_PER_OPTION, offered.size(), "manual picker stays compact");
        T.eq(Arrays.asList("e0", "e1", "e2"), Arrays.asList(offered.get(0).id, offered.get(1).id, offered.get(2).id), "exact ones first");
        T.eq(23, d.allSubtitlesFor(o).size(), "automatic fallback retains every compatible candidate instead of truncating to UI limit");
        T.eq("e0", d.recommendedSubtitleFor(o).id, "automatically recommends an exact file match");
        T.eq(0, d.subtitlesFor(null).size(), "no option -> nothing");
        T.eq(Arrays.asList("s1"), ids(d.optionsFor(subs.get(20))), "options for an exact subtitle");
        System.exit(T.finish("StremioChooserDataTest"));
    }

    private static StremioChooserData snapshot(StremioStreamOption... o) {
        return new StremioChooserData(1L, StremioChooserData.State.COMPLETE, StremioChooserData.EmptyReason.NONE,
                Arrays.asList(o), Collections.<StremioSubtitle>emptyList(), StremioChooserData.Progress.NONE);
    }
}

package com.eve.cinema.stremio;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class StremioSearchEngineTest {

    private static StremioSearchEngine.Budgets budgets(int streamMs, int subMs, int maxIdentity, int maxProbes) {
        return new StremioSearchEngine.Budgets(streamMs, subMs, 5000, 20, 60, maxProbes, maxIdentity, 1, 120, 150);
    }

    private static List<StremioSearchEngine.Target> targets(String... keys) {
        List<StremioSearchEngine.Target> out = new ArrayList<>();
        for (String k : keys) out.add(Fx.target(k, "tt1375666", "tt1375666"));
        return out;
    }

    public static void main(String[] args) throws Exception {
        progressive();
        subtitleDoesNotStarveStreams();
        hardCapAndTimeouts();
        retries();
        failureClassification();
        emptyStates();
        dedupAndCaps();
        subtitleIdentity();
        identityCapAndPriority();
        embeddedSubtitles();
        probes();
        cancellation();
        serialization();
        buildTargets();
        System.exit(T.finish("StremioSearchEngineTest"));
    }

    // ───────────────────────────────────────────────────────────────────────────

    static void progressive() {
        T.section("first option is published before the slowest add-on finishes");
        Fx.FakeGateway gw = new Fx.FakeGateway();
        gw.streamScripts.put("fast", Fx.after(40, Fx.batch(Fx.cand("https://cdn.example/a.1080p.mkv", "Fast", "1080p"), Fx.cand("https://cdn.example/b.720p.mkv", "Fast", "720p"))));
        gw.streamScripts.put("mid", Fx.after(400, Fx.batch(Fx.cand("https://cdn.example/c.2160p.mkv", "Mid", "2160p"))));
        gw.streamScripts.put("slow", Fx.after(1100, Fx.batch(Fx.cand("https://cdn.example/d.480p.mp4", "Slow", "480p"))));
        StremioSearchEngine engine = StremioSearchEngine.standalone(gw, budgets(3000, 3000, 4, 0), null);
        Fx.Recorder rec = new Fx.Recorder();
        engine.start("movie", targets("fast", "mid", "slow"), rec);

        T.eq(StremioChooserData.State.LOADING, rec.snapshots.get(0).state, "first snapshot is LOADING (UI can open at once)");
        T.ok(rec.waitFor(4000, d -> d.state == StremioChooserData.State.COMPLETE), "search completes");
        long first = rec.firstTimeWithOptions();
        T.ok(first >= 0 && first < 350, "first option shown after " + first + "ms, long before the 1100ms add-on");
        boolean sawPartial = false;
        for (StremioChooserData d : rec.snapshots) if (d.state == StremioChooserData.State.PARTIAL) sawPartial = true;
        T.ok(sawPartial, "a PARTIAL snapshot exists while slower add-ons are still working");
        StremioChooserData fin = rec.last();
        T.eq(4, fin.options.size(), "all four options listed at the end");
        T.eq(Arrays.asList(2160, 1080, 720, 480), heights(fin), "ordered by quality group");
        T.ok(rec.versionsAscending && !rec.overlapped, "versions strictly ascending, listener never re-entered");
        T.eq(3, fin.progress.addonsFinished, "progress counts finished add-ons");
        engine.shutdown();
    }

    static void subtitleDoesNotStarveStreams() {
        T.section("a slow subtitle service neither delays streams nor blocks completion forever");
        Fx.FakeGateway gw = new Fx.FakeGateway();
        gw.subtitleDelayMs = 4000;
        gw.streamScripts.put("a", Fx.after(30, Fx.batch(Fx.cand("https://cdn.example/a.1080p.mkv", "A", "1080p"))));
        StremioSearchEngine engine = StremioSearchEngine.standalone(gw, budgets(2000, 700, 4, 0), null);
        Fx.Recorder rec = new Fx.Recorder();
        engine.start("movie", targets("a"), rec);
        T.ok(rec.waitFor(1000, d -> !d.options.isEmpty()), "option visible quickly");
        T.ok(rec.firstTimeWithOptions() < 400, "streams were not queued behind the 4s subtitle call");
        StremioChooserData mid = rec.last();
        T.eq(StremioChooserData.State.PARTIAL, mid.state, "still PARTIAL while subtitles are pending");
        T.ok(mid.progress.addonsFinished == mid.progress.addonsTotal && mid.progress.searching,
                "stream phase is finished, only subtitles are pending (UI can say so)");
        T.ok(rec.waitFor(3000, d -> d.state == StremioChooserData.State.COMPLETE), "subtitle budget (700ms) ends the wait");
        engine.shutdown();
    }

    static void hardCapAndTimeouts() {
        T.section("hard stream budget; timeouts are classified");
        Fx.FakeGateway gw = new Fx.FakeGateway();
        gw.streamScripts.put("ok", Fx.after(20, Fx.batch(Fx.cand("https://cdn.example/a.1080p.mkv", "A", "1080p"))));
        gw.streamScripts.put("stall", Fx.after(60_000, Fx.batch()));
        StremioSearchEngine engine = StremioSearchEngine.standalone(gw, budgets(700, 700, 4, 0), null);
        Fx.Recorder rec = new Fx.Recorder();
        long t0 = System.nanoTime();
        engine.start("movie", targets("ok", "stall"), rec);
        T.ok(rec.waitFor(3000, d -> d.state == StremioChooserData.State.COMPLETE), "completes despite a stalled add-on");
        long took = (System.nanoTime() - t0) / 1_000_000L;
        T.ok(took < 1800, "finished within the budget window (" + took + "ms)");
        T.eq(1, rec.last().progress.addonsTimedOut, "the stalled add-on is counted as timed out");
        T.eq(1, rec.last().progress.addonsFailed, "and as failed");
        engine.shutdown();

        Fx.FakeGateway allStall = new Fx.FakeGateway();
        allStall.streamScripts.put("s1", Fx.after(60_000, Fx.batch()));
        allStall.streamScripts.put("s2", Fx.after(60_000, Fx.batch()));
        StremioSearchEngine e2 = StremioSearchEngine.standalone(allStall, budgets(600, 600, 4, 0), null);
        Fx.Recorder r2 = new Fx.Recorder();
        e2.start("movie", targets("s1", "s2"), r2);
        T.ok(r2.waitFor(3000, StremioChooserData::isFinal), "all-timeout search ends");
        T.eq(StremioChooserData.State.FAILED, r2.last().state, "timeouts while the device is online -> FAILED (not offline)");
        e2.shutdown();

        StremioSearchEngine e3 = StremioSearchEngine.standalone(allStall, budgets(600, 600, 4, 0), () -> false);
        Fx.Recorder r3 = new Fx.Recorder();
        e3.start("movie", targets("s1", "s2"), r3);
        T.ok(r3.waitFor(3000, StremioChooserData::isFinal), "ends");
        T.eq(StremioChooserData.State.OFFLINE, r3.last().state, "timeouts while the device reports no connectivity -> OFFLINE");
        e3.shutdown();
    }

    static void retries() {
        T.section("bounded retry: transient only, never beyond the budget");
        Fx.FakeGateway gw = new Fx.FakeGateway();
        final StremioAddonClient.StreamBatch good = Fx.batch(Fx.cand("https://cdn.example/a.1080p.mkv", "A", "1080p"));
        gw.streamScripts.put("flaky", (call, timeout) -> { if (call == 1) throw Fx.fail(StremioException.Kind.HTTP_STATUS, 503); return good; });
        gw.streamScripts.put("gone", Fx.failing(StremioException.Kind.HTTP_STATUS, 404));
        gw.streamScripts.put("limited", Fx.failing(StremioException.Kind.HTTP_STATUS, 429));
        gw.streamScripts.put("bad", Fx.failing(StremioException.Kind.MALFORMED, 0));
        gw.streamScripts.put("down", Fx.failing(StremioException.Kind.NETWORK, 0));
        StremioSearchEngine engine = StremioSearchEngine.standalone(gw, budgets(3000, 3000, 4, 0), null);
        Fx.Recorder rec = new Fx.Recorder();
        engine.start("movie", targets("flaky", "gone", "limited", "bad", "down"), rec);
        T.ok(rec.waitFor(4000, StremioChooserData::isFinal), "finishes");
        T.eq(2, gw.streamCalls.get("flaky"), "503 retried once and recovered");
        T.eq(1, rec.last().options.size(), "recovered add-on contributed its option");
        T.eq(1, gw.streamCalls.get("gone"), "404 is final");
        T.eq(1, gw.streamCalls.get("limited"), "429 is not hammered");
        T.eq(1, gw.streamCalls.get("bad"), "malformed answer is final");
        T.eq(2, gw.streamCalls.get("down"), "network error retried once (maxRetries = 1)");
        engine.shutdown();

        Fx.FakeGateway tight = new Fx.FakeGateway();
        tight.streamScripts.put("late", (call, timeout) -> { Fx.sleep(300); throw Fx.fail(StremioException.Kind.TIMEOUT, 0); });
        StremioSearchEngine e2 = StremioSearchEngine.standalone(tight, budgets(500, 500, 4, 0), null);
        Fx.Recorder r2 = new Fx.Recorder();
        e2.start("movie", targets("late"), r2);
        T.ok(r2.waitFor(3000, StremioChooserData::isFinal), "finishes");
        T.eq(1, tight.streamCalls.get("late"), "no retry when the remaining budget could not hold another attempt");
        e2.shutdown();
    }

    static void failureClassification() {
        T.section("OFFLINE vs FAILED");
        Fx.FakeGateway net = new Fx.FakeGateway();
        net.streamScripts.put("n1", Fx.failing(StremioException.Kind.NETWORK, 0));
        net.streamScripts.put("n2", Fx.failing(StremioException.Kind.NETWORK, 0));
        StremioSearchEngine engine = StremioSearchEngine.standalone(net, budgets(3000, 3000, 4, 0), null);
        Fx.Recorder rec = new Fx.Recorder();
        engine.start("movie", targets("n1", "n2"), rec);
        T.ok(rec.waitFor(4000, StremioChooserData::isFinal), "ends");
        T.eq(StremioChooserData.State.OFFLINE, rec.last().state, "every add-on unreachable -> OFFLINE");
        engine.shutdown();

        Fx.FakeGateway mixed = new Fx.FakeGateway();
        mixed.streamScripts.put("n1", Fx.failing(StremioException.Kind.NETWORK, 0));
        mixed.streamScripts.put("h1", Fx.failing(StremioException.Kind.HTTP_STATUS, 500));
        StremioSearchEngine e2 = StremioSearchEngine.standalone(mixed, budgets(3000, 3000, 4, 0), null);
        Fx.Recorder r2 = new Fx.Recorder();
        e2.start("movie", targets("n1", "h1"), r2);
        T.ok(r2.waitFor(4000, StremioChooserData::isFinal), "ends");
        T.eq(StremioChooserData.State.FAILED, r2.last().state, "mixed failures -> FAILED");
        T.eq(StremioChooserData.EmptyReason.ALL_FAILED, r2.last().emptyReason, "reason");
        e2.shutdown();

        Fx.FakeGateway partial = new Fx.FakeGateway();
        partial.streamScripts.put("n1", Fx.failing(StremioException.Kind.NETWORK, 0));
        partial.streamScripts.put("ok", Fx.after(10, Fx.batch(Fx.cand("https://cdn.example/a.1080p.mkv", "A", "1080p"))));
        StremioSearchEngine e3 = StremioSearchEngine.standalone(partial, budgets(3000, 3000, 4, 0), null);
        Fx.Recorder r3 = new Fx.Recorder();
        e3.start("movie", targets("n1", "ok"), r3);
        T.ok(r3.waitFor(4000, StremioChooserData::isFinal), "ends");
        T.eq(StremioChooserData.State.COMPLETE, r3.last().state, "one failing add-on does not hide the other's result");
        T.eq(1, r3.last().progress.addonsFailed, "failure is still counted");
        e3.shutdown();
    }

    static void emptyStates() {
        T.section("empty states");
        Fx.FakeGateway gw = new Fx.FakeGateway();
        StremioSearchEngine engine = StremioSearchEngine.standalone(gw, budgets(2000, 2000, 4, 0), null);
        Fx.Recorder none = new Fx.Recorder();
        engine.start("movie", Collections.<StremioSearchEngine.Target>emptyList(), none);
        T.eq(1, none.snapshots.size(), "no targets: a single final snapshot, synchronously");
        T.eq(StremioChooserData.State.EMPTY, none.last().state, "EMPTY");
        T.eq(StremioChooserData.EmptyReason.NO_COMPATIBLE_ADDON, none.last().emptyReason, "no compatible add-on");

        gw.streamScripts.put("t", Fx.after(5, Fx.unsupportedOnly(7)));
        Fx.Recorder tor = new Fx.Recorder();
        engine.start("movie", targets("t"), tor);
        T.ok(tor.waitFor(3000, StremioChooserData::isFinal), "ends");
        T.eq(StremioChooserData.EmptyReason.ONLY_UNSUPPORTED, tor.last().emptyReason, "only torrent entries");
        T.eq(7, tor.last().progress.unsupportedStreams, "unsupported entries are counted, not silently dropped");

        gw.streamScripts.put("e", Fx.after(5, Fx.batch()));
        Fx.Recorder empty = new Fx.Recorder();
        engine.start("movie", targets("e"), empty);
        T.ok(empty.waitFor(3000, StremioChooserData::isFinal), "ends");
        T.eq(StremioChooserData.EmptyReason.NO_STREAMS, empty.last().emptyReason, "answered, nothing offered");
        engine.shutdown();
    }

    static void dedupAndCaps() {
        T.section("de-duplication and caps");
        Fx.FakeGateway gw = new Fx.FakeGateway();
        List<StremioAddonClient.StreamCandidate> many = new ArrayList<>();
        for (int i = 0; i < 30; i++) many.add(Fx.cand((i == 0 ? "https://CDN.example/m0.720p.mkv" : "https://cdn.example/m" + i + ".720p.mkv"), "M", "720p"));
        gw.streamScripts.put("a", Fx.after(5, Fx.batch(many.toArray(new StremioAddonClient.StreamCandidate[0]))));
        gw.streamScripts.put("b", Fx.after(150, Fx.batch(Fx.cand("https://cdn.example/m0.720p.mkv", "dup", "720p"), Fx.cand("https://cdn.example/other.1080p.mkv", "B", "1080p"))));
        StremioSearchEngine engine = StremioSearchEngine.standalone(gw, budgets(2000, 2000, 4, 0), null);
        Fx.Recorder rec = new Fx.Recorder();
        engine.start("movie", targets("a", "b"), rec);
        T.ok(rec.waitFor(3000, StremioChooserData::isFinal), "ends");
        int total = rec.last().options.size();
        T.ok(total == 21, "20 per add-on cap + 1 distinct from the second add-on (duplicate URL ignored): " + total);
        java.util.Set<String> numbers = new java.util.HashSet<>();
        for (StremioStreamOption o : rec.last().options) numbers.add(o.id);
        T.eq(total, numbers.size(), "option ids are unique");
        T.eq("https://CDN.example/m0.720p.mkv", byUrl(rec.last(), "m0.720p").url,
                "dedup comparison never rewrites the actual playback URL");
        engine.shutdown();
    }

    // ── subtitles ─────────────────────────────────────────────────────────────

    static void subtitleIdentity() {
        T.section("subtitles are tied to the file they were requested for");
        Fx.FakeGateway gw = new Fx.FakeGateway();
        gw.streamScripts.put("a", Fx.after(5, Fx.batch(
                Fx.cand("https://cdn.example/A.1080p.mkv", "A", "1080p", "Movie.2010.1080p.mkv", 4_000_000_000L, "aaaaaaaaaaaaaaaa"),
                Fx.cand("https://cdn.example/B.720p.mkv", "B", "720p", "Movie.2010.720p.mkv", 1_000_000_000L, "bbbbbbbbbbbbbbbb"),
                Fx.cand("https://cdn.example/C.480p.mkv", "C", "480p"))));
        gw.titleLevelSubtitles = Fx.subs(Fx.sub("https://subs.example/generic.srt"));
        gw.byHash.put("aaaaaaaaaaaaaaaa", Fx.subs(Fx.sub("https://subs.example/for-A.srt")));
        gw.byHash.put("bbbbbbbbbbbbbbbb", Fx.subs(Fx.sub("https://subs.example/for-B.srt")));
        StremioSearchEngine engine = StremioSearchEngine.standalone(gw, budgets(2000, 2000, 4, 0), null);
        Fx.Recorder rec = new Fx.Recorder();
        engine.start("movie", targets("a"), rec);
        T.ok(rec.waitFor(3000, StremioChooserData::isFinal), "ends");
        StremioChooserData d = rec.last();
        StremioStreamOption a = byUrl(d, "A.1080p"), b = byUrl(d, "B.720p"), c = byUrl(d, "C.480p");
        StremioSubtitle forA = subByUrl(d, "for-A"), forB = subByUrl(d, "for-B"), generic = subByUrl(d, "generic");

        T.eq(StremioChooserData.Match.EXACT, d.match(forA, a), "A's subtitle is exact for A");
        T.eq(StremioChooserData.Match.INCOMPATIBLE, d.match(forA, b), "A's subtitle is NOT offered for B");
        T.eq(StremioChooserData.Match.INCOMPATIBLE, d.match(forA, c), "nor for a stream without identity");
        T.eq(StremioChooserData.Match.EXACT, d.match(forB, b), "B's subtitle is exact for B");
        for (StremioStreamOption o : d.options)
            T.eq(StremioChooserData.Match.UNVERIFIED, d.match(generic, o), "title-level subtitle is only 'unverified' for " + o.id);
        T.eq(Arrays.asList(forA.id, generic.id), ids(d.subtitlesFor(a)), "A: exact first, then the unverified generic one");
        T.eq(Arrays.asList(forB.id, generic.id), ids(d.subtitlesFor(b)), "B: its own, then generic");
        T.eq(Collections.singletonList(generic.id), ids(d.subtitlesFor(c)), "C: only the unverified generic one");
        T.ok(d.hasExactArabic(a) && d.hasExactArabic(b) && !d.hasExactArabic(c), "exact-Arabic flag per stream");
        T.eq(2, d.countWithExactArabic(), "two streams have a proven Arabic subtitle");

        boolean askedForA = false, askedForC = false;
        for (String r : gw.subtitleRequests) {
            if (r.contains("videoHash=aaaaaaaaaaaaaaaa") && r.contains("videoSize=4000000000") && r.contains("filename=Movie.2010.1080p.mkv")) askedForA = true;
            if (r.contains("480p")) askedForC = true;
        }
        T.ok(askedForA, "the request for A carried videoHash, videoSize and filename: " + gw.subtitleRequests);
        T.ok(!askedForC, "no identity request was invented for the stream without identity");
        T.eq(1 + 2, gw.subtitleRequests.size(), "one title-level + two file-level requests");
        engine.shutdown();
    }

    static void identityCapAndPriority() {
        T.section("identity request cap: hash first, remainder reported");
        Fx.FakeGateway gw = new Fx.FakeGateway();
        gw.streamScripts.put("a", Fx.after(5, Fx.batch(
                Fx.cand("https://cdn.example/n1.mkv", "N1", "1080p", "n1.mkv", 111L, ""),
                Fx.cand("https://cdn.example/n2.mkv", "N2", "1080p", "n2.mkv", 222L, ""),
                Fx.cand("https://cdn.example/h1.mkv", "H1", "1080p", "h1.mkv", 333L, "cccccccccccccccc"))));
        gw.byHash.put("cccccccccccccccc", Fx.subs(Fx.sub("https://subs.example/for-H1.srt")));
        StremioSearchEngine engine = StremioSearchEngine.standalone(gw, budgets(2000, 2000, 1, 0), null);
        Fx.Recorder rec = new Fx.Recorder();
        engine.start("movie", targets("a"), rec);
        T.ok(rec.waitFor(3000, StremioChooserData::isFinal), "ends");
        int fileLevel = 0; boolean hashAsked = false;
        for (String r : gw.subtitleRequests) if (!r.endsWith("{}")) { fileLevel++; if (r.contains("videoHash=cccc")) hashAsked = true; }
        T.eq(1, fileLevel, "only one file-level request (cap = 1)");
        T.ok(hashAsked, "the hash-bearing file won the only slot although it arrived last in the batch");
        T.ok(rec.last().progress.identitiesUnchecked >= 2, "the two unchecked identities are reported: " + rec.last().progress.identitiesUnchecked);
        engine.shutdown();
    }

    static void embeddedSubtitles() {
        T.section("subtitles embedded in a stream belong to that stream");
        Fx.FakeGateway gw = new Fx.FakeGateway();
        StremioSubtitle embedded = Fx.sub("https://subs.example/embedded.srt");
        gw.streamScripts.put("a", Fx.after(5, Fx.batch(
                Fx.cand("https://cdn.example/X.1080p.mkv", "X", "1080p", "", -1L, "", embedded),
                Fx.cand("https://cdn.example/Y.720p.mkv", "Y", "720p"))));
        StremioSearchEngine engine = StremioSearchEngine.standalone(gw, budgets(2000, 2000, 4, 0), null);
        Fx.Recorder rec = new Fx.Recorder();
        engine.start("movie", targets("a"), rec);
        T.ok(rec.waitFor(3000, StremioChooserData::isFinal), "ends");
        StremioChooserData d = rec.last();
        StremioStreamOption x = byUrl(d, "X.1080p"), y = byUrl(d, "Y.720p");
        StremioSubtitle s = subByUrl(d, "embedded");
        T.eq(StremioChooserData.Match.EXACT, d.match(s, x), "exact for the stream that carries it");
        T.eq(StremioChooserData.Match.INCOMPATIBLE, d.match(s, y), "never offered for another stream");
        T.eq(Collections.singletonList(s.id), ids(x.attachedSubtitles), "attached list carries the registered subtitle");
        engine.shutdown();

        Fx.FakeGateway gw2 = new Fx.FakeGateway();
        gw2.streamScripts.put("a", gw.streamScripts.get("a"));
        gw2.titleLevelSubtitles = Fx.subs(Fx.sub("https://subs.example/embedded.srt"));
        StremioSearchEngine e2 = StremioSearchEngine.standalone(gw2, budgets(2000, 2000, 4, 0), null);
        Fx.Recorder r2 = new Fx.Recorder();
        e2.start("movie", targets("a"), r2);
        T.ok(r2.waitFor(3000, StremioChooserData::isFinal), "ends");
        StremioChooserData d2 = r2.last();
        T.eq(1, d2.subtitles.size(), "same URL from two answers is one subtitle");
        T.eq(StremioChooserData.Match.EXACT, d2.match(d2.subtitles.get(0), byUrl(d2, "X.1080p")), "still exact for its stream");
        T.eq(StremioChooserData.Match.UNVERIFIED, d2.match(d2.subtitles.get(0), byUrl(d2, "Y.720p")), "and merely unverified for the other");
        e2.shutdown();
    }

    // ── probes ────────────────────────────────────────────────────────────────

    static void probes() {
        T.section("speed probes rank measured links and do not delay the initial list");
        Fx.FakeGateway gw = new Fx.FakeGateway();
        gw.probeDelayMs = 150;
        List<StremioAddonClient.StreamCandidate> list = new ArrayList<>();
        for (int i = 0; i < 10; i++) list.add(Fx.cand("https://cdn.example/p" + i + ".1080p.mkv", "P", "1080p"));
        gw.streamScripts.put("a", Fx.after(5, Fx.batch(list.toArray(new StremioAddonClient.StreamCandidate[0]))));
        gw.probeResults.put("https://cdn.example/p0.1080p.mkv", Fx.probeSpeed(12.0, 0));
        gw.probeResults.put("https://cdn.example/p1.1080p.mkv", Fx.probeSpeed(30.0, 0));
        gw.probeResults.put("https://cdn.example/p2.1080p.mkv", Fx.probeDead());
        gw.probeResults.put("https://cdn.example/p3.1080p.mkv", Fx.probeBlocked());
        gw.probeResults.put("https://cdn.example/p4.1080p.mkv", Fx.probeSpeed(5.0, 720));
        StremioSearchEngine engine = StremioSearchEngine.standalone(gw, budgets(2000, 2000, 4, 6), null);
        Fx.Recorder rec = new Fx.Recorder();
        engine.start("movie", targets("a"), rec);
        T.ok(rec.waitFor(3000, StremioChooserData::isFinal), "search completes");
        long completeAt = rec.times.get(rec.snapshots.size() - 1);
        T.ok(rec.waitFor(3000, d -> !d.progress.measuring), "measurement finishes in the background");
        T.eq(6, gw.probeCalls.get(), "probe count is capped at maxProbes");
        StremioChooserData d = rec.last();
        T.eq(8, d.options.size(), "dead and blocked links removed (10 - 2)");
        T.eq(1, d.progress.deadLinks, "dead link counted");
        T.ok(d.progress.unsafeStreams >= 1, "blocked link counted as unsafe");
        T.eq("s2", d.fastestId, "fastest measured option is s2 (30 Mbps)");
        StremioStreamOption p4 = byUrl(d, "p4.1080p");
        T.eq(720, p4.qualityHeight, "HLS/DASH manifest resolution (measured) overrides the text-derived one");
        T.eq("manifest", p4.qualitySource, "provenance recorded");
        // s5 (p4) is re-classified to 720p by its own manifest and moves to its own group;
        // measured 30 Mbps then 12 Mbps links lead the 1080p group; unmeasured links stay behind.
        List<String> in1080 = new ArrayList<>();
        for (StremioStreamOption o : d.options) if (o.qualityHeight == 1080) in1080.add(o.id);
        T.eq(Arrays.asList("s2", "s1", "s6", "s7", "s8", "s9", "s10"), in1080, "measured speed ranks within a quality group");
        T.ok(completeAt < 600, "probing (150ms each) did not hold back COMPLETE: " + completeAt);
        engine.shutdown();
    }

    // ── cancellation / serialization ──────────────────────────────────────────

    static void cancellation() {
        T.section("cancel stops all callbacks");
        Fx.FakeGateway gw = new Fx.FakeGateway();
        gw.streamScripts.put("a", Fx.after(300, Fx.batch(Fx.cand("https://cdn.example/a.1080p.mkv", "A", "1080p"))));
        StremioSearchEngine engine = StremioSearchEngine.standalone(gw, budgets(2000, 2000, 4, 0), null);
        Fx.Recorder rec = new Fx.Recorder();
        StremioSearchEngine.Handle h = engine.start("movie", targets("a"), rec);
        Fx.sleep(60);
        h.cancel();
        int atCancel = rec.snapshots.size();
        Fx.sleep(700);
        T.ok(h.isCancelled(), "handle reports cancelled");
        T.eq(atCancel, rec.snapshots.size(), "no snapshot was delivered after cancel() although the add-on answered later");
        engine.shutdown();
    }

    static void serialization() {
        T.section("snapshots are serialized and ordered under heavy concurrency");
        Fx.FakeGateway gw = new Fx.FakeGateway();
        for (int i = 0; i < 8; i++) {
            String key = "k" + i;
            gw.streamScripts.put(key, Fx.after(10 + (i * 7) % 50, Fx.batch(Fx.cand("https://cdn.example/" + key + ".1080p.mkv", key, "1080p", key + ".mkv", 1000L + i, "hash000000000" + String.format("%03d", i)))));
        }
        gw.subtitleDelayMs = 20;
        gw.probeDelayMs = 10;
        StremioSearchEngine engine = StremioSearchEngine.standalone(gw, budgets(3000, 3000, 8, 6), null);
        Fx.Recorder rec = new Fx.Recorder();
        engine.start("movie", targets("k0", "k1", "k2", "k3", "k4", "k5", "k6", "k7"), rec);
        T.ok(rec.waitFor(5000, d -> d.state == StremioChooserData.State.COMPLETE && !d.progress.measuring), "completes");
        T.ok(!rec.overlapped, "listener never called concurrently");
        T.ok(rec.versionsAscending, "versions strictly ascending");
        T.eq(8, rec.last().options.size(), "all options present");
        engine.shutdown();

        Fx.FakeGateway gw2 = new Fx.FakeGateway();
        gw2.streamScripts.put("a", Fx.after(5, Fx.batch(Fx.cand("https://cdn.example/a.1080p.mkv", "A", "1080p"))));
        StremioSearchEngine e2 = StremioSearchEngine.standalone(gw2, budgets(2000, 2000, 4, 0), null);
        final java.util.concurrent.atomic.AtomicInteger calls = new java.util.concurrent.atomic.AtomicInteger();
        e2.start("movie", targets("a"), d -> { calls.incrementAndGet(); throw new IllegalStateException("UI bug"); });
        Fx.sleep(400);
        T.ok(calls.get() >= 2, "a throwing listener does not stop later snapshots (" + calls.get() + ")");
        e2.shutdown();
    }

    static void buildTargets() {
        T.section("target ids: one id per add-on and resource, IMDb first");
        StremioManifest imdbOnly = Fx.imdbAddon("com.imdb");
        StremioManifest tmdbOnly = Fx.manifest("com.tmdb", "[\"stream\"]", "[\"movie\",\"series\"]", "\"idPrefixes\":[\"tmdb:\"]");
        StremioManifest both = Fx.manifest("com.both", "[\"stream\"]", "[\"movie\"]", "\"idPrefixes\":[\"tt\",\"tmdb:\"]");
        StremioManifest neither = Fx.manifest("com.kitsu", "[\"stream\"]", "[\"movie\"]", "\"idPrefixes\":[\"kitsu:\"]");
        StremioManifest subsOnlyImdb = Fx.manifest("com.subs", "[\"subtitles\"]", "[\"movie\"]", "\"idPrefixes\":[\"tt\"]");
        StremioManifest seriesOnlyAddon = Fx.manifest("com.movies", "[\"stream\"]", "[\"movie\"]", null);
        List<StremioAddonStore.Addon> addons = Arrays.asList(
                addon("https://a.example/manifest.json", imdbOnly, true),
                addon("https://b.example/manifest.json", tmdbOnly, true),
                addon("https://c.example/manifest.json", both, true),
                addon("https://d.example/manifest.json", neither, true),
                addon("https://e.example/manifest.json", subsOnlyImdb, true),
                addon("https://f.example/manifest.json", imdbOnly, false),
                addon("https://g.example/manifest.json", seriesOnlyAddon, true));
        StremioContentRef movie = StremioContentRef.movie("27205").withImdb("tt1375666");
        List<StremioSearchEngine.Target> t = StremioSearchEngine.buildTargets(addons, movie);
        T.eq(Arrays.asList("a1", "a2", "a3", "a5", "a7"), keys(t), "disabled add-on and add-on with no usable id skipped");
        T.eq("tt1375666", t.get(0).streamId, "IMDb-only add-on gets the tt id");
        T.eq("tmdb:27205", t.get(1).streamId, "TMDB-only add-on gets the tmdb id");
        T.eq("tt1375666", t.get(2).streamId, "add-on that accepts both is asked ONCE, with the IMDb id (no blind double query)");
        T.eq(null, t.get(3).streamId, "subtitles-only add-on has no stream id");
        T.eq("tt1375666", t.get(3).subtitleId, "but gets a subtitle id");

        StremioContentRef noImdb = StremioContentRef.movie("27205");
        List<StremioSearchEngine.Target> t2 = StremioSearchEngine.buildTargets(addons, noImdb);
        T.eq(Arrays.asList("a2", "a3", "a7"), keys(t2), "without an IMDb id only add-ons that accept tmdb ids (or any id) are asked");

        T.ok(StremioSearchEngine.idUnavailable(Arrays.asList(addon("https://a.example/manifest.json", imdbOnly, true)), noImdb,
                StremioSearchEngine.buildTargets(Arrays.asList(addon("https://a.example/manifest.json", imdbOnly, true)), noImdb)),
                "tt-only add-on + no IMDb id -> the UI must say the id is missing (not 'no add-on supports this')");
        T.ok(!StremioSearchEngine.idUnavailable(addons, noImdb, t2), "some add-on can still be asked -> not 'unavailable'");
        T.ok(!StremioSearchEngine.idUnavailable(Arrays.asList(addon("https://d.example/manifest.json", neither, true)), noImdb,
                StremioSearchEngine.buildTargets(Arrays.asList(addon("https://d.example/manifest.json", neither, true)), noImdb)),
                "a kitsu-only add-on can never serve the title: that really is 'no compatible add-on'");
        T.ok(!StremioSearchEngine.idUnavailable(Arrays.asList(addon("https://a.example/manifest.json", imdbOnly, false)), noImdb,
                new ArrayList<StremioSearchEngine.Target>()), "a disabled add-on does not make the id 'needed'");
        StremioContentRef ep = StremioContentRef.episode("1399", 2, 5).withImdb("tt0944947");
        List<StremioSearchEngine.Target> t3 = StremioSearchEngine.buildTargets(addons, ep);
        T.eq("tt0944947:2:5", t3.get(0).streamId, "episode id is tt:season:episode");
        T.eq(Arrays.asList("a1", "a2"), keys(t3), "movie-only add-ons are not asked about episodes (types respected)");
        T.eq("tmdb:1399:2:5", t3.get(1).streamId, "episode tmdb id form");

        T.section("anime episode targets use each add-on's declared type");
        StremioManifest animeOnly = Fx.manifest("com.anime", "[\"stream\",\"subtitles\"]", "[\"anime\"]", "\"idPrefixes\":[\"tt\"]");
        StremioManifest seriesOnly = Fx.manifest("com.series", "[\"stream\",\"subtitles\"]", "[\"series\"]", "\"idPrefixes\":[\"tt\"]");
        List<StremioAddonStore.Addon> animeAddons = Arrays.asList(
                addon("https://anime.example/manifest.json", animeOnly, true),
                addon("https://series.example/manifest.json", seriesOnly, true));
        StremioContentRef animeRef = StremioContentRef.episode("1399", 2, 5, "anime").withImdb("tt0944947");
        List<StremioSearchEngine.Target> animeTargets = StremioSearchEngine.buildTargets(animeAddons, animeRef);
        T.eq(2, animeTargets.size(), "both anime-aware and series-only add-ons are compatible");
        T.eq("anime", animeTargets.get(0).streamType, "prefer anime endpoint when exposed");
        T.eq("anime", animeTargets.get(0).subtitleType, "anime subtitle endpoint when exposed");
        T.eq("series", animeTargets.get(1).streamType, "fallback to series endpoint for compatible provider");
        T.eq("series", animeTargets.get(1).subtitleType, "fallback subtitle endpoint follows provider declaration");
        T.eq("tt0944947:2:5", animeTargets.get(0).streamId, "anime gets standard IMDb episode id");
        T.eq("tt0944947:2:5", animeTargets.get(1).streamId, "series fallback retains the episode id");
    }

    // ── helpers ───────────────────────────────────────────────────────────────

    private static StremioAddonStore.Addon addon(String url, StremioManifest m, boolean enabled) {
        return new StremioAddonStore.Addon(url, m, enabled, 0L);
    }

    private static List<String> keys(List<StremioSearchEngine.Target> t) {
        List<String> out = new ArrayList<>();
        for (StremioSearchEngine.Target x : t) out.add(x.key);
        return out;
    }

    private static List<Integer> heights(StremioChooserData d) {
        List<Integer> out = new ArrayList<>();
        for (StremioStreamOption o : d.options) out.add(o.qualityHeight);
        return out;
    }

    private static List<String> ids(List<StremioSubtitle> subs) {
        List<String> out = new ArrayList<>();
        for (StremioSubtitle s : subs) out.add(s.id);
        return out;
    }

    private static StremioStreamOption byUrl(StremioChooserData d, String part) {
        for (StremioStreamOption o : d.options) if (o.url.contains(part)) return o;
        throw new AssertionError("no option " + part);
    }

    private static StremioSubtitle subByUrl(StremioChooserData d, String part) {
        for (StremioSubtitle s : d.subtitles) if (s.url.contains(part)) return s;
        throw new AssertionError("no subtitle " + part);
    }
}

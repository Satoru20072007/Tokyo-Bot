package com.eve.cinema.stremio;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/** Real HttpURLConnection against a JDK fake server (the policy is the test policy: http + loopback). */
public final class StremioHttpTest {
    private static final StremioHttp HTTP = new StremioHttp(StremioNetPolicy.Policy.forTests());
    private static final StremioHttp.Limits SMALL = new StremioHttp.Limits(500, 800, 2000, 4096, 3);

    private static HttpServer server(HttpHandler handler) throws IOException {
        HttpServer s = HttpServer.create(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0), 0);
        s.createContext("/", handler);
        s.setExecutor(java.util.concurrent.Executors.newCachedThreadPool());
        s.start();
        return s;
    }

    private static String url(HttpServer s, String path) { return "http://127.0.0.1:" + s.getAddress().getPort() + path; }

    private static void reply(HttpExchange ex, int code, String type, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        if (type != null) ex.getResponseHeaders().set("Content-Type", type);
        ex.sendResponseHeaders(code, bytes.length == 0 ? -1 : bytes.length);
        if (bytes.length > 0) try (OutputStream o = ex.getResponseBody()) { o.write(bytes); }
        ex.close();
    }

    public static void main(String[] args) throws Exception {
        T.section("success, raw credential path reaches the server unchanged");
        final List<String> rawPaths = new CopyOnWriteArrayList<>();
        HttpServer ok = server(ex -> {
            rawPaths.add(ex.getRequestURI().getRawPath() + (ex.getRequestURI().getRawQuery() == null ? "" : "?" + ex.getRequestURI().getRawQuery()));
            reply(ex, 200, "application/json; charset=utf-8", "{\"id\":\"x\",\"n\":1}");
        });
        String credentialPath = "/%7B%22auth_token%22%3A%22SECRET%2Bx%22%7D/manifest.json?sig=a%3D%3D";
        JSONObject json = HTTP.getJson(url(ok, credentialPath), SMALL, true);
        T.eq("x", json.optString("id"), "parsed body");
        T.eq(credentialPath, rawPaths.get(0), "server saw the exact raw path + query (no decode/re-encode)");
        for (String tricky : new String[]{
                "/%7B%22auth_token%22%3A%22TEST_TOKEN_NOT_REAL%22%7D/manifest.json",
                "/%7B%22k%22%3A%22100%25%22%7D/manifest.json",             // %25 must stay %25 (no %2525)
                "/%D8%AA%D8%B1%D8%AC%D9%85%D8%A9/a%2Fb/manifest.json",     // Unicode + escaped slash
                "/a%20b/%7E%2B/manifest.json?sig=x%3D%3D&t=%7B1%7D"}) {
            rawPaths.clear();
            HTTP.getJson(url(ok, tricky), SMALL, true);
            T.eq(tricky, rawPaths.get(0), "raw path unchanged on the wire: " + tricky);
        }

        T.section("content-type / status / malformed bodies");
        HttpServer odd = server(ex -> {
            String p = ex.getRequestURI().getPath();
            switch (p) {
                case "/html": reply(ex, 200, "text/html", "<html></html>"); break;
                case "/ct-upper": reply(ex, 200, "Application/JSON; Charset=UTF-8", "{\"a\":\"v\"}"); break;
                case "/ct-vendor": reply(ex, 200, "application/vnd.api+json", "{\"a\":\"v\"}"); break;
                case "/ct-none": reply(ex, 200, null, "{\"a\":\"v\"}"); break;
                case "/ct-text": reply(ex, 200, "text/plain", "{\"a\":\"v\"}"); break;
                case "/404": reply(ex, 404, "application/json", "{}"); break;
                case "/500": reply(ex, 500, "application/json", "{}"); break;
                case "/429": reply(ex, 429, "application/json", "{}"); break;
                case "/array": reply(ex, 200, "application/json", "[1,2]"); break;
                case "/trunc": reply(ex, 200, "application/json", "{\"a\":"); break;
                case "/bom": reply(ex, 200, "application/json", "\uFEFF{\"a\":\"b\"}"); break;
                case "/deep": {
                    StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < 20000; i++) sb.append('[');
                    reply(ex, 200, "application/json", "{\"a\":" + sb + "}");
                    break;
                }
                default: reply(ex, 200, "application/json", "{}");
            }
        });
        T.eq("v", HTTP.getJson(url(odd, "/ct-upper"), SMALL, false).optString("a"), "Content-Type matching is case-insensitive (Application/JSON; Charset=UTF-8)");
        T.eq("v", HTTP.getJson(url(odd, "/ct-vendor"), SMALL, false).optString("a"), "vendor JSON types are accepted (application/vnd.api+json)");
        T.eq("v", HTTP.getJson(url(odd, "/ct-none"), SMALL, false).optString("a"), "a missing Content-Type is tolerated");
        T.throwsKind(StremioException.Kind.NOT_JSON, "text/plain is not JSON", () -> HTTP.getJson(url(odd, "/ct-text"), SMALL, false));
        T.throwsKind(StremioException.Kind.NOT_JSON, "html answer", () -> HTTP.getJson(url(odd, "/html"), SMALL, false));
        T.throwsKind(StremioException.Kind.HTTP_STATUS, "404", () -> HTTP.getJson(url(odd, "/404"), SMALL, false));
        T.throwsKind(StremioException.Kind.HTTP_STATUS, "500", () -> HTTP.getJson(url(odd, "/500"), SMALL, false));
        try { HTTP.getJson(url(odd, "/500"), SMALL, false); } catch (StremioException e) { T.ok(e.isTransient() && e.httpStatus == 500, "500 is transient"); }
        try { HTTP.getJson(url(odd, "/404"), SMALL, false); } catch (StremioException e) { T.ok(!e.isTransient() && e.httpStatus == 404, "404 is NOT transient"); }
        try { HTTP.getJson(url(odd, "/429"), SMALL, false); } catch (StremioException e) { T.ok(!e.isTransient(), "429 is NOT retried"); }
        T.throwsKind(StremioException.Kind.MALFORMED, "array root", () -> HTTP.getJson(url(odd, "/array"), SMALL, false));
        T.throwsKind(StremioException.Kind.MALFORMED, "truncated json", () -> HTTP.getJson(url(odd, "/trunc"), SMALL, false));
        T.eq("b", HTTP.getJson(url(odd, "/bom"), SMALL, false).optString("a"), "UTF-8 BOM tolerated");
        T.throwsKind(StremioException.Kind.MALFORMED, "20 000-level nesting is refused before parsing (no StackOverflowError)",
                () -> HTTP.getJson(url(odd, "/deep"), new StremioHttp.Limits(500, 800, 4000, 1 << 20, 3), false));
        T.ok(StremioHttp.exceedsDepth("[[[[", 3) && !StremioHttp.exceedsDepth("{\"a\":[{\"b\":\"[[[[[[\"}]}", 4), "depth scan ignores brackets inside strings");

        T.section("size limits (declared and undeclared length)");
        final String big = new String(new char[10000]).replace('\0', 'a');
        HttpServer large = server(ex -> {
            if (ex.getRequestURI().getPath().equals("/declared")) reply(ex, 200, "application/json", "{\"a\":\"" + big + "\"}");
            else {   // chunked: length unknown up-front
                ex.getResponseHeaders().set("Content-Type", "application/json");
                ex.sendResponseHeaders(200, 0);
                try (OutputStream o = ex.getResponseBody()) { o.write(("{\"a\":\"" + big + "\"}").getBytes(StandardCharsets.UTF_8)); }
                ex.close();
            }
        });
        T.throwsKind(StremioException.Kind.TOO_LARGE, "Content-Length above the cap", () -> HTTP.getJson(url(large, "/declared"), SMALL, false));
        T.throwsKind(StremioException.Kind.TOO_LARGE, "chunked body above the cap", () -> HTTP.getJson(url(large, "/chunked"), SMALL, false));

        T.section("redirects");
        final AtomicInteger loopHits = new AtomicInteger();
        final HttpServer[] other = new HttpServer[1];
        other[0] = server(ex -> reply(ex, 200, "application/json", "{\"from\":\"other\"}"));
        HttpServer redirector = server(ex -> {
            String p = ex.getRequestURI().getPath();
            if (p.equals("/same")) { ex.getResponseHeaders().set("Location", "/target?x=1"); reply(ex, 302, null, ""); }
            else if (p.equals("/target")) reply(ex, 200, "application/json", "{\"from\":\"redirector\",\"q\":\"" + ex.getRequestURI().getRawQuery() + "\"}");
            else if (p.equals("/loop")) { loopHits.incrementAndGet(); ex.getResponseHeaders().set("Location", "/loop"); reply(ex, 302, null, ""); }
            else if (p.equals("/cross")) { ex.getResponseHeaders().set("Location", url(other[0], "/x")); reply(ex, 307, null, ""); }
            else if (p.equals("/nolocation")) reply(ex, 302, null, "");
            else if (p.equals("/ftp")) { ex.getResponseHeaders().set("Location", "ftp://example.com/x"); reply(ex, 302, null, ""); }
            else reply(ex, 200, "application/json", "{}");
        });
        T.eq("redirector", HTTP.getJson(url(redirector, "/same"), SMALL, true).optString("from"), "same-origin redirect followed (relative Location)");
        T.eq("x=1", HTTP.getJson(url(redirector, "/same"), SMALL, true).optString("q"), "query of the Location kept");
        T.throwsKind(StremioException.Kind.REDIRECT_REJECTED, "redirect loop stops", () -> HTTP.getJson(url(redirector, "/loop"), SMALL, false));
        T.ok(loopHits.get() <= 4, "no more than maxRedirects+1 requests were made (" + loopHits.get() + ")");
        T.throwsKind(StremioException.Kind.REDIRECT_REJECTED, "credential URL must not leave its origin", () -> HTTP.getJson(url(redirector, "/cross"), SMALL, true));
        T.eq("other", HTTP.getJson(url(redirector, "/cross"), SMALL, false).optString("from"), "public (non-credential) URL may follow a cross-origin hop");
        T.throwsKind(StremioException.Kind.REDIRECT_REJECTED, "redirect without Location", () -> HTTP.getJson(url(redirector, "/nolocation"), SMALL, false));
        T.throwsKind(StremioException.Kind.UNSAFE_URL, "redirect to a non-http scheme is rejected by the policy", () -> HTTP.getJson(url(redirector, "/ftp"), SMALL, false));
        T.ok(StremioHttp.isRedirect(301) && StremioHttp.isRedirect(308) && !StremioHttp.isRedirect(304) && !StremioHttp.isRedirect(200), "redirect status set");

        T.section("a redirect hop into a refused (private) target is rejected before it is contacted");
        final AtomicInteger deniedHits = new AtomicInteger();
        HttpServer deniedServer = server(ex -> { deniedHits.incrementAndGet(); reply(ex, 200, "application/json", "{\"leak\":1}"); });
        final String deniedAuthority = "127.0.0.1:" + deniedServer.getAddress().getPort();
        HttpServer hopper = server(ex -> { ex.getResponseHeaders().set("Location", "http://" + deniedAuthority + "/internal"); reply(ex, 302, null, ""); });
        StremioHttp guarded = new StremioHttp(StremioNetPolicy.Policy.forTestsDenying(deniedAuthority));
        T.throwsKind(StremioException.Kind.UNSAFE_URL, "public -> private redirect refused", () -> guarded.getJson(url(hopper, "/start"), SMALL, false));
        T.eq(0, deniedHits.get(), "the private target never saw a request");
        T.ok(StremioHttp.isDowngrade(URI.create("https://a.example/x"), URI.create("http://a.example/x")), "https -> http is a downgrade");
        T.ok(!StremioHttp.isDowngrade(URI.create("http://a.example/x"), URI.create("https://a.example/x")), "http -> https is not");
        T.ok(!StremioHttp.isDowngrade(URI.create("https://a.example/x"), URI.create("https://b.example/x")), "https -> https is not");
        deniedServer.stop(0); hopper.stop(0);

        T.section("each redirect hop is re-validated by DNS policy");
        final AtomicInteger privateHits = new AtomicInteger();
        HttpServer internal = server(ex -> { privateHits.incrementAndGet(); reply(ex, 200, "application/json", "{\"secret\":1}"); });
        // Public-looking name that "resolves" to loopback must be refused before any socket is opened.
        StremioNetPolicy.Policy rebinding = StremioNetPolicy.Policy.media(host -> new InetAddress[]{InetAddress.getByName("127.0.0.1")});
        StremioHttp strict = new StremioHttp(rebinding);
        T.throwsKind(StremioException.Kind.UNSAFE_URL, "name resolving to loopback is refused",
                () -> strict.getJson("http://evil.example.com:" + internal.getAddress().getPort() + "/x", SMALL, false));
        T.eq(0, privateHits.get(), "the internal server was never contacted");

        T.section("timeouts");
        HttpServer slow = server(ex -> {
            String p = ex.getRequestURI().getPath();
            try {
                if (p.equals("/stall")) { Thread.sleep(3000); reply(ex, 200, "application/json", "{}"); }
                else if (p.equals("/drip")) {
                    ex.getResponseHeaders().set("Content-Type", "application/json");
                    ex.sendResponseHeaders(200, 0);
                    OutputStream o = ex.getResponseBody();
                    o.write('{'); o.flush();
                    for (int i = 0; i < 40; i++) { Thread.sleep(150); o.write(' '); o.flush(); }
                    o.close();
                }
            } catch (Exception ignored) { /* client went away */ }
            ex.close();
        });
        long t0 = System.nanoTime();
        T.throwsKind(StremioException.Kind.TIMEOUT, "read timeout on a stalled server", () -> HTTP.getJson(url(slow, "/stall"), SMALL, false));
        T.ok((System.nanoTime() - t0) / 1_000_000 < 2500, "stall aborted well before the server answered");
        long t1 = System.nanoTime();
        T.throwsKind(StremioException.Kind.TIMEOUT, "total deadline beats a server that drips bytes forever",
                () -> HTTP.getJson(url(slow, "/drip"), new StremioHttp.Limits(500, 1000, 700, 1 << 20, 3), false));
        T.ok((System.nanoTime() - t1) / 1_000_000 < 2500, "drip aborted by the total deadline, not by the read timeout");

        T.section("connection failure and message hygiene");
        int deadPort;
        try (java.net.ServerSocket s = new java.net.ServerSocket(0, 0, InetAddress.getByName("127.0.0.1"))) { deadPort = s.getLocalPort(); }
        final String deadUrl = "http://127.0.0.1:" + deadPort + "/%7BSECRET-TOKEN%7D/manifest.json";
        T.throwsKind(StremioException.Kind.NETWORK, "closed port", () -> HTTP.getJson(deadUrl, SMALL, true));
        try { HTTP.getJson(deadUrl, SMALL, true); }
        catch (StremioException e) {
            T.ok(!e.getMessage().contains("SECRET") && !e.getMessage().contains("127.0.0.1") && !e.getMessage().contains(String.valueOf(deadPort)),
                    "exception text carries no URL, host, port or secret: " + e.getMessage());
            T.ok(e.getCause() == null, "original exception (which embeds the URL) is not attached");
        }
        T.eq("SocketTimeoutException", StremioException.safeDescription(new java.net.SocketTimeoutException("https://x/SECRET")), "safeDescription = class name only");

        T.section("resolveRedirect helper");
        T.eq(URI.create("https://h.example/b?x=%7B1%7D"), StremioHttp.resolveRedirect(URI.create("https://h.example/a/manifest.json"), "/b?x=%7B1%7D"), "absolute path");
        T.eq(URI.create("https://h.example/a/n.json"), StremioHttp.resolveRedirect(URI.create("https://h.example/a/manifest.json"), "n.json"), "relative path");
        T.throwsKind(StremioException.Kind.REDIRECT_REJECTED, "blank Location", () -> StremioHttp.resolveRedirect(URI.create("https://h.example/"), "  "));

        for (HttpServer s : new HttpServer[]{ok, odd, large, other[0], redirector, internal, slow}) s.stop(0);
        System.exit(T.finish("StremioHttpTest"));
    }
}

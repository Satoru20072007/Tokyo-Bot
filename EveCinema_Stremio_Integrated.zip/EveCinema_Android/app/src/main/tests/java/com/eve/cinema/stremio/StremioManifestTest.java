package com.eve.cinema.stremio;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

public final class StremioManifestTest {

    private static StremioManifest parse(String json) throws JSONException { return StremioManifest.parse(new JSONObject(json)); }

    private static boolean rejects(String json) {
        try { parse(json); return false; } catch (JSONException ex) { return true; }
    }

    private static final String TORRENTIO = "{\"id\":\"com.stremio.torrentio.addon\",\"version\":\"0.0.14\",\"name\":\"Torrentio\","
            + "\"description\":\"Provides torrent streams\",\"catalogs\":[],"
            + "\"resources\":[{\"name\":\"stream\",\"types\":[\"movie\",\"series\",\"anime\"],\"idPrefixes\":[\"tt\",\"kitsu\"]}],"
            + "\"types\":[\"movie\",\"series\",\"anime\",\"other\"],\"behaviorHints\":{\"configurable\":true,\"configurationRequired\":false}}";

    private static final String OPENSUBS = "{\"id\":\"org.stremio.opensubtitlesv3\",\"version\":\"1.0.0\",\"name\":\"OpenSubtitles v3\","
            + "\"description\":\"subs\",\"catalogs\":[],\"resources\":[\"subtitles\"],\"types\":[\"movie\",\"series\"],\"idPrefixes\":[\"tt\"]}";

    public static void main(String[] args) throws Exception {
        T.section("the TMDB-id problem: tt-prefix add-ons never accept tmdb: ids");
        StremioManifest tor = parse(TORRENTIO);
        T.ok(tor.supports("stream", "movie", "tt1375666"), "movie by IMDb id");
        T.ok(tor.supports("stream", "series", "tt0944947:1:2"), "episode by IMDb id");
        T.ok(tor.supports("stream", "anime", "kitsu:1234"), "kitsu id for anime");
        T.ok(!tor.supports("stream", "movie", "tmdb:27205"), "tmdb:<id> is NOT accepted (this is why the app asked add-ons in vain)");
        T.ok(!tor.supports("stream", "other", "tt1"), "resource-level types win over manifest-level types");
        T.ok(!tor.supports("subtitles", "movie", "tt1"), "resource not declared");
        StremioContentRef ref = StremioContentRef.movie("27205");
        T.ok(tor.supports("stream", "movie", ref.withImdb("tt1375666").idFor(tor, "stream")), "with the IMDb id the add-on is reachable");
        T.eq(null, ref.idFor(tor, "stream"), "without an IMDb id the add-on is not queried (no pointless request)");
        T.ok(ref.couldBeServedBy(tor, "stream"), "but it is known to be servable once the IMDb id is resolved");

        T.section("manifest-level types/idPrefixes apply to plain-string resources");
        StremioManifest subs = parse(OPENSUBS);
        T.ok(subs.supports("subtitles", "movie", "tt1375666"), "subtitles for an IMDb id");
        T.ok(!subs.supports("subtitles", "anime", "tt1"), "type not declared by the manifest is refused (was accepted before)");
        T.ok(!subs.supports("subtitles", "movie", "kitsu:1"), "global idPrefixes are honoured for string resources");
        T.eq(Arrays.asList("tt"), subs.idPrefixes, "global idPrefixes exposed");

        T.section("resource objects fall back to the manifest values only for what they omit");
        StremioManifest mixed = parse("{\"id\":\"x.y\",\"version\":\"1\",\"name\":\"N\",\"description\":\"D\",\"catalogs\":[],"
                + "\"types\":[\"movie\",\"series\"],\"idPrefixes\":[\"tt\"],\"resources\":["
                + "{\"name\":\"stream\"},{\"name\":\"subtitles\",\"types\":[\"movie\"]},{\"name\":\"meta\",\"idPrefixes\":[\"abc:\"]}]}");
        T.ok(mixed.supports("stream", "series", "tt1"), "no own values: inherits types and prefixes");
        T.ok(!mixed.supports("stream", "series", "abc:1"), "inherited prefix list still restricts");
        T.ok(mixed.supports("subtitles", "movie", "tt1") && !mixed.supports("subtitles", "series", "tt1"), "own types, inherited prefixes");
        T.ok(mixed.supports("meta", "series", "abc:1") && !mixed.supports("meta", "series", "tt1"), "own prefixes, inherited types");
        StremioManifest wide = parse("{\"id\":\"x.y\",\"version\":\"1\",\"name\":\"N\",\"description\":\"D\",\"catalogs\":[],"
                + "\"types\":[\"movie\"],\"resources\":[{\"name\":\"stream\",\"types\":[\"movie\",\"series\"]}]}");
        T.ok(wide.supports("stream", "series", "anything"), "a resource may declare a type the manifest list omits (no longer rejects the add-on)");

        T.section("validation: required fields, tolerance elsewhere");
        T.ok(!rejects(TORRENTIO.replace("\"catalogs\":[],", "")), "a missing catalogs array is tolerated (the reference client defaults it to [])");
        T.eq(0, parse(TORRENTIO.replace("\"catalogs\":[],", "")).catalogs.size(), "and yields no catalogs");
        T.ok(!rejects(TORRENTIO.replace("\"catalogs\":[],", "\"catalogs\":\"nope\",")), "a non-array catalogs value does not crash or reject");
        T.ok(rejects(TORRENTIO.replace("\"description\":\"Provides torrent streams\"", "\"description\":null")), "JSON null is not a description");
        T.ok(rejects(TORRENTIO.replace("\"id\":\"com.stremio.torrentio.addon\"", "\"id\":\"bad id\"")), "id with spaces");
        T.ok(rejects(TORRENTIO.replace("\"types\":[\"movie\",\"series\",\"anime\",\"other\"]", "\"types\":[]")), "empty types");
        T.ok(rejects(TORRENTIO.replace("\"resources\":[{\"name\":\"stream\",\"types\":[\"movie\",\"series\",\"anime\"],\"idPrefixes\":[\"tt\",\"kitsu\"]}]", "\"resources\":[]")), "no resources");
        T.ok(!rejects(TORRENTIO.replace("com.stremio.torrentio.addon", "org.example:addon@v2")), "ids with : and @ are accepted");
        StremioManifest tolerant = parse("{\"id\":\"x.y\",\"version\":\"1\",\"name\":\"N\",\"description\":\"D\","
                + "\"types\":[\"movie\"],\"resources\":[5,{\"nope\":1},\"stream\"],"
                + "\"catalogs\":[\"junk\",{\"type\":\"movie\"},{\"type\":\"other\",\"id\":\"c\",\"name\":\"C\"}]}");
        T.eq(1, tolerant.resources.size(), "unreadable resource entries are skipped, the valid one survives");
        T.eq(1, tolerant.catalogs.size(), "unreadable catalog entries are skipped; a catalog type outside `types` no longer rejects the add-on");
        T.ok(!tolerant.configurationRequired, "configurationRequired defaults to false");
        T.ok(parse(TORRENTIO.replace("\"configurationRequired\":false", "\"configurationRequired\":true")).configurationRequired, "configurationRequired read");

        T.section("catalog extras are validated, never invented");
        StremioManifest cat = parse("{\"id\":\"x.y\",\"version\":\"1\",\"name\":\"N\",\"description\":\"D\",\"types\":[\"movie\"],"
                + "\"resources\":[\"catalog\"],\"catalogs\":[{\"type\":\"movie\",\"id\":\"top\",\"name\":\"Top\",\"extra\":["
                + "{\"name\":\"search\",\"isRequired\":true},{\"name\":\"genre\",\"options\":[\"Action\",\"Comedy\"]},{\"name\":\"skip\"}]},"
                + "{\"type\":\"movie\",\"id\":\"legacy\",\"name\":\"L\",\"extraSupported\":[\"search\"],\"extraRequired\":[\"search\"]}]}");
        Map<String, String> given = new LinkedHashMap<>();
        given.put("search", "inception"); given.put("genre", "Action"); given.put("skip", "20"); given.put("junk", "1");
        Map<String, String> clean = cat.sanitizeCatalogExtras("movie", "top", given);
        T.eq(Arrays.asList("search", "genre", "skip"), Arrays.asList(clean.keySet().toArray()), "undeclared argument dropped, declared ones kept in manifest order");
        Map<String, String> wrongOption = new LinkedHashMap<>(); wrongOption.put("search", "x"); wrongOption.put("genre", "Drama");
        T.throwsKind(StremioException.Kind.UNSUPPORTED, "value outside options", () -> cat.sanitizeCatalogExtras("movie", "top", wrongOption));
        T.throwsKind(StremioException.Kind.UNSUPPORTED, "required argument without a value", () -> cat.sanitizeCatalogExtras("movie", "top", new LinkedHashMap<String, String>()));
        T.throwsKind(StremioException.Kind.UNSUPPORTED, "legacy extraRequired is honoured", () -> cat.sanitizeCatalogExtras("movie", "legacy", new LinkedHashMap<String, String>()));
        T.throwsKind(StremioException.Kind.UNSUPPORTED, "unknown catalog", () -> cat.sanitizeCatalogExtras("movie", "nope", given));
        T.ok(cat.supports("catalog", "movie", "top") && !cat.supports("catalog", "movie", "nope"), "catalog support is by catalog id");

        T.section("raw() is a defensive copy");
        JSONObject copy = tor.raw();
        copy.put("name", "tampered");
        T.eq("Torrentio", tor.raw().optString("name"), "stored manifest unaffected by a caller's edits");

        System.exit(T.finish("StremioManifestTest"));
    }
}

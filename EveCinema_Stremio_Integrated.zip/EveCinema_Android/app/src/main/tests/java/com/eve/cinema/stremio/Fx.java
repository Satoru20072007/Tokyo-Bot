package com.eve.cinema.stremio;

import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/** Shared builders and a scriptable gateway for the Stremio JVM suites. */
final class Fx {
    private Fx() {}

    static StremioManifest manifest(String id, String resourcesJson, String typesJson, String extraJson) {
        try {
            String json = "{\"id\":\"" + id + "\",\"version\":\"1.0.0\",\"name\":\"N\",\"description\":\"D\","
                    + "\"types\":" + typesJson + ",\"resources\":" + resourcesJson + ",\"catalogs\":[]"
                    + (extraJson == null || extraJson.isEmpty() ? "" : "," + extraJson) + "}";
            return StremioManifest.parse(new JSONObject(json));
        } catch (Exception ex) {
            throw new AssertionError(ex);
        }
    }

    /** Stream+subtitles add-on that accepts IMDb ids. */
    static StremioManifest imdbAddon(String id) {
        return manifest(id, "[\"stream\",\"subtitles\"]", "[\"movie\",\"series\"]", "\"idPrefixes\":[\"tt\"]");
    }

    static StremioSearchEngine.Target target(String key, String streamId, String subtitleId) {
        return new StremioSearchEngine.Target(key, "https://" + key + ".example/manifest.json",
                imdbAddon("addon." + key), streamId, subtitleId);
    }

    static StremioAddonClient.StreamCandidate cand(String url, String name, String desc) {
        return cand(url, name, desc, "", -1L, "");
    }

    static StremioAddonClient.StreamCandidate cand(String url, String name, String desc, String hintFile,
                                                   long size, String hash, StremioSubtitle... embedded) {
        List<StremioSubtitle> subs = new ArrayList<>();
        Collections.addAll(subs, embedded);
        return new StremioAddonClient.StreamCandidate(url, name, desc, hintFile, hintFile, size, hash,
                StremioAddonClient.inferType(url), Collections.<String, String>emptyMap(), subs);
    }

    static StremioAddonClient.StreamBatch batch(StremioAddonClient.StreamCandidate... c) {
        List<StremioAddonClient.StreamCandidate> list = new ArrayList<>();
        Collections.addAll(list, c);
        return new StremioAddonClient.StreamBatch(list, 0, 0, 0, 0, 0, list.size());
    }

    static StremioAddonClient.StreamBatch unsupportedOnly(int torrents) {
        return new StremioAddonClient.StreamBatch(new ArrayList<StremioAddonClient.StreamCandidate>(),
                torrents, 0, 0, 0, 0, torrents);
    }

    static StremioAddonClient.SubtitleBatch subs(StremioSubtitle... s) {
        List<StremioSubtitle> list = new ArrayList<>();
        Collections.addAll(list, s);
        return new StremioAddonClient.SubtitleBatch(list, 0, 0, 0);
    }

    static StremioSubtitle sub(String url) { return new StremioSubtitle(url, "ara"); }

    /** A scripted behaviour for one call. */
    interface Script {
        StremioAddonClient.StreamBatch streams(int call, int timeoutMs) throws IOException;
    }

    static StremioException fail(StremioException.Kind kind, int status) { return new StremioException(kind, status); }

    /** Gateway whose per-target behaviour and latency are scripted; records every request. */
    static final class FakeGateway implements StremioSearchEngine.Gateway {
        final Map<String, Script> streamScripts = new LinkedHashMap<>();
        final Map<String, Integer> streamCalls = new LinkedHashMap<>();
        final List<String> subtitleRequests = new CopyOnWriteArrayList<>();   // "key|id|extras"
        volatile int subtitleDelayMs = 0;
        volatile StremioAddonClient.SubtitleBatch titleLevelSubtitles = Fx.subs();
        final Map<String, StremioAddonClient.SubtitleBatch> byHash = new LinkedHashMap<>();
        final Map<String, StremioSpeedProbe.Result> probeResults = new LinkedHashMap<>();
        final AtomicInteger probeCalls = new AtomicInteger();
        volatile int probeDelayMs = 0;
        final Object callLock = new Object();

        @Override public StremioAddonClient.StreamBatch streams(StremioSearchEngine.Target t, String type, String id,
                                                                int timeoutMs) throws IOException {
            int call;
            synchronized (callLock) { call = streamCalls.containsKey(t.key) ? streamCalls.get(t.key) + 1 : 1; streamCalls.put(t.key, call); }
            Script script = streamScripts.get(t.key);
            if (script == null) return Fx.batch();
            return script.streams(call, timeoutMs);
        }

        @Override public StremioAddonClient.SubtitleBatch subtitles(StremioSearchEngine.Target t, String type, String id,
                                                                    Map<String, String> extras, int timeoutMs) throws IOException {
            subtitleRequests.add(t.key + "|" + id + "|" + new java.util.TreeMap<>(extras));
            sleep(Math.min(subtitleDelayMs, timeoutMs));
            if (subtitleDelayMs > timeoutMs) throw new StremioException(StremioException.Kind.TIMEOUT);
            if (extras.isEmpty()) return titleLevelSubtitles;
            StremioAddonClient.SubtitleBatch hit = byHash.get(extras.get("videoHash"));
            return hit == null ? Fx.subs() : hit;
        }

        @Override public StremioSpeedProbe.Result probe(StremioStreamOption option) {
            probeCalls.incrementAndGet();
            sleep(probeDelayMs);
            StremioSpeedProbe.Result r = probeResults.get(option.url);
            return r == null ? probeUnknown() : r;
        }
    }

    static StremioSpeedProbe.Result probeUnknown() { return new StremioSpeedProbe.Result(false, -1d, 0); }
    static StremioSpeedProbe.Result probeSpeed(double mbps, int height) { return new StremioSpeedProbe.Result(false, mbps, height); }
    static StremioSpeedProbe.Result probeDead() { return new StremioSpeedProbe.Result(true, -1d, 0); }
    static StremioSpeedProbe.Result probeBlocked() { return new StremioSpeedProbe.Result(false, true, -1d, 0); }

    /** After {@code delayMs} (capped by the request timeout like a real client) return {@code batch}. */
    static Script after(final int delayMs, final StremioAddonClient.StreamBatch batch) {
        return new Script() {
            @Override public StremioAddonClient.StreamBatch streams(int call, int timeoutMs) throws IOException {
                if (delayMs > timeoutMs) { sleep(timeoutMs); throw new StremioException(StremioException.Kind.TIMEOUT); }
                sleep(delayMs);
                return batch;
            }
        };
    }

    static Script failing(final StremioException.Kind kind, final int status) {
        return new Script() {
            @Override public StremioAddonClient.StreamBatch streams(int call, int timeoutMs) throws IOException {
                throw new StremioException(kind, status);
            }
        };
    }

    static void sleep(long ms) {
        if (ms <= 0) return;
        try { Thread.sleep(ms); } catch (InterruptedException ex) { Thread.currentThread().interrupt(); }
    }

    /** Collects snapshots with their arrival time (ms since construction). */
    static final class Recorder implements StremioSearchEngine.Listener {
        final long t0 = System.nanoTime();
        final List<StremioChooserData> snapshots = new CopyOnWriteArrayList<>();
        final List<Long> times = new CopyOnWriteArrayList<>();
        final AtomicInteger inside = new AtomicInteger();
        volatile boolean overlapped;
        volatile long lastVersion = -1;
        volatile boolean versionsAscending = true;

        @Override public void onSnapshot(StremioChooserData data) {
            if (inside.incrementAndGet() > 1) overlapped = true;
            if (data.version <= lastVersion) versionsAscending = false;
            lastVersion = data.version;
            snapshots.add(data);
            times.add((System.nanoTime() - t0) / 1_000_000L);
            inside.decrementAndGet();
        }

        StremioChooserData last() { return snapshots.isEmpty() ? null : snapshots.get(snapshots.size() - 1); }

        long firstTimeWithOptions() {
            for (int i = 0; i < snapshots.size(); i++) if (!snapshots.get(i).options.isEmpty()) return times.get(i);
            return -1;
        }

        boolean waitFor(long timeoutMs, Cond c) {
            long end = System.nanoTime() + timeoutMs * 1_000_000L;
            while (System.nanoTime() < end) {
                StremioChooserData l = last();
                if (l != null && c.ok(l)) return true;
                sleep(10);
            }
            return false;
        }

        interface Cond { boolean ok(StremioChooserData d); }
    }
}

package com.eve.cinema.stremio;

/** Minimal assertion helper shared by the Stremio JVM suites (no JUnit: matches tools/run_jvm_tests.sh). */
final class T {
    private T() {}

    interface Body { void run() throws Exception; }

    private static int passed;
    private static int failed;

    static void ok(boolean condition, String message) {
        if (condition) { passed++; return; }
        failed++;
        System.err.println("  FAIL: " + message);
    }

    static void eq(Object expected, Object actual, String message) {
        boolean same = expected == null ? actual == null : expected.equals(actual);
        if (same) { passed++; return; }
        failed++;
        System.err.println("  FAIL: " + message + "\n        expected: " + expected + "\n        actual:   " + actual);
    }

    /** Asserts that {@code body} throws a {@link StremioException} of the given kind. */
    static void throwsKind(StremioException.Kind kind, String message, Body body) {
        try {
            body.run();
        } catch (StremioException ex) {
            eq(kind, ex.kind, message);
            return;
        } catch (Throwable other) {
            failed++;
            System.err.println("  FAIL: " + message + " (unexpected " + other + ")");
            return;
        }
        failed++;
        System.err.println("  FAIL: " + message + " (nothing thrown)");
    }

    static void noThrow(String message, Body body) {
        try { body.run(); passed++; }
        catch (Throwable ex) { failed++; System.err.println("  FAIL: " + message + " threw " + ex); }
    }

    static void section(String name) { System.out.println("  - " + name); }

    static int finish(String suite) {
        System.out.println(suite + ": " + passed + " passed, " + failed + " failed");
        return failed == 0 ? 0 : 1;
    }
}

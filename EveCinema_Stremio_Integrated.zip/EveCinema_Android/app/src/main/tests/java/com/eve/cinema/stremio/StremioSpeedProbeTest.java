package com.eve.cinema.stremio;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicLong;

public final class StremioSpeedProbeTest {
    private static final java.util.Map<String, String> NO_HEADERS = Collections.<String, String>emptyMap();

    public static void main(String[] args) throws Exception {
        final AtomicLong sent = new AtomicLong();
        final AtomicLong forbiddenHits = new AtomicLong();
        HttpServer forbidden = HttpServer.create(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0), 0);
        forbidden.createContext("/", (HttpExchange ex) -> { forbiddenHits.incrementAndGet(); reply(ex, 200, "video/mp4", "x"); });
        forbidden.start();
        final int forbiddenPort = forbidden.getAddress().getPort();

        HttpServer server = HttpServer.create(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0), 0);
        server.setExecutor(java.util.concurrent.Executors.newCachedThreadPool());
        server.createContext("/", (HttpExchange ex) -> {
            String p = ex.getRequestURI().getPath();
            if (p.equals("/video.mp4")) {            // 5 MB answer: the probe must not take all of it
                ex.getResponseHeaders().set("Content-Type", "video/mp4");
                ex.sendResponseHeaders(200, 5L * 1024 * 1024);
                byte[] chunk = new byte[32 * 1024];
                try (OutputStream o = ex.getResponseBody()) {
                    for (int i = 0; i < 160; i++) { o.write(chunk); o.flush(); sent.addAndGet(chunk.length); Fx.sleep(4); }
                } catch (IOException clientClosed) { /* expected: probe stopped reading */ }
            }
            else if (p.equals("/page.mp4")) reply(ex, 200, "text/html", "<html>nope</html>");
            else if (p.equals("/gone.mp4")) reply(ex, 404, "text/plain", "gone");
            else if (p.equals("/err.mp4")) reply(ex, 500, "text/plain", "err");
            else if (p.equals("/to-forbidden.mp4")) { ex.getResponseHeaders().set("Location", "http://127.0.0.1:" + forbiddenPort + "/x.mp4"); reply(ex, 302, null, ""); }
            else if (p.equals("/master.m3u8")) reply(ex, 200, "application/vnd.apple.mpegurl",
                    "#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=800000,RESOLUTION=1920x1080\nmedia.m3u8\n");
            else if (p.equals("/media.m3u8")) reply(ex, 200, "application/vnd.apple.mpegurl",
                    "#EXTM3U\n#EXT-X-TARGETDURATION:4\n#EXTINF:4,\nseg0.ts\n#EXT-X-ENDLIST\n");
            else reply(ex, 404, "text/plain", "");
        });
        server.start();
        final int port = server.getAddress().getPort();
        StremioSpeedProbe probe = new StremioSpeedProbe(url -> !url.contains(":" + forbiddenPort + "/"));
        String base = "http://127.0.0.1:" + port;

        T.section("bounded measurement");
        long t0 = System.nanoTime();
        StremioSpeedProbe.Result r = probe.probe(base + "/video.mp4", NO_HEADERS, "PROGRESSIVE");
        T.ok(!r.dead && !r.blocked, "healthy link");
        T.ok(r.mbps > 0, "a speed was measured: " + r.mbps);
        T.ok(sent.get() < 2L * 1024 * 1024, "the 5 MB file was not downloaded (server wrote " + sent.get() + " bytes before the client stopped)");
        T.ok((System.nanoTime() - t0) / 1_000_000L < 6500, "within the per-link budget");

        T.section("dead / blocked / unknown are different outcomes");
        T.ok(probe.probe(base + "/page.mp4", NO_HEADERS, "PROGRESSIVE").dead, "an HTML page is not a video");
        T.ok(probe.probe(base + "/gone.mp4", NO_HEADERS, "PROGRESSIVE").dead, "404");
        StremioSpeedProbe.Result err = probe.probe(base + "/err.mp4", NO_HEADERS, "PROGRESSIVE");
        T.ok(!err.dead && !err.blocked && err.mbps <= 0, "a 500 proves nothing: unknown, not dead");
        StremioSpeedProbe.Result blocked = probe.probe(base + "/to-forbidden.mp4", NO_HEADERS, "PROGRESSIVE");
        T.ok(blocked.blocked && !blocked.dead, "a redirect hop to a refused target is 'blocked'");
        T.eq(0L, forbiddenHits.get(), "the refused target was never contacted");
        T.ok(new StremioSpeedProbe(url -> false).probe(base + "/video.mp4", NO_HEADERS, "PROGRESSIVE").blocked, "policy refusal of the first URL");
        T.ok(!probe.probe("http://127.0.0.1:1/never.mp4", NO_HEADERS, "PROGRESSIVE").dead, "connection refused is unknown (never throws)");

        T.section("HLS: resolution comes from the playlist itself");
        StremioSpeedProbe.Result hls = probe.probe(base + "/master.m3u8", NO_HEADERS, "HLS");
        T.eq(1080, hls.manifestHeight, "RESOLUTION=1920x1080 in the master playlist");
        T.ok(!hls.dead, "playlist is alive");
        server.stop(0); forbidden.stop(0);
        System.exit(T.finish("StremioSpeedProbeTest"));
    }

    private static void reply(HttpExchange ex, int code, String type, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        if (type != null) ex.getResponseHeaders().set("Content-Type", type);
        ex.sendResponseHeaders(code, bytes.length == 0 ? -1 : bytes.length);
        if (bytes.length > 0) try (OutputStream o = ex.getResponseBody()) { o.write(bytes); }
        ex.close();
    }
}

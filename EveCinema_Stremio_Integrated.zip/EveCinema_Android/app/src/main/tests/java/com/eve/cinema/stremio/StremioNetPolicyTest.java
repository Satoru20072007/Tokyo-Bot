package com.eve.cinema.stremio;

import java.net.InetAddress;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;

public final class StremioNetPolicyTest {

    private static boolean pub4(String ip) throws Exception {
        return StremioNetPolicy.isPublicAddress(InetAddress.getByName(ip));
    }

    private static byte[] v6(int... bytes) {
        byte[] out = new byte[16];
        for (int i = 0; i < bytes.length; i++) out[i] = (byte) bytes[i];
        return out;
    }

    private static boolean syntaxOk(StremioNetPolicy.Policy policy, String url) {
        try { policy.checkSyntax(URI.create(url)); return true; }
        catch (StremioException ex) { return false; }
        catch (IllegalArgumentException ex) { return false; }
    }

    public static void main(String[] args) throws Exception {
        T.section("IPv4 classification");
        for (String ip : new String[]{"8.8.8.8", "1.1.1.1", "93.184.216.34", "172.15.0.1", "172.32.0.1",
                "100.63.255.255", "100.128.0.1", "198.17.255.255", "198.20.0.1", "11.0.0.1", "223.255.255.254"})
            T.ok(pub4(ip), ip + " must be public");
        for (String ip : new String[]{"0.0.0.0", "0.1.2.3", "10.0.0.1", "10.255.255.255", "127.0.0.1", "127.8.9.10",
                "172.16.0.1", "172.31.255.255", "192.168.0.1", "192.168.255.255", "100.64.0.1", "100.127.255.255",
                "169.254.169.254", "192.0.0.5", "192.0.2.1", "198.18.0.1", "198.19.255.255", "198.51.100.7",
                "203.0.113.9", "192.88.99.1", "224.0.0.1", "239.255.255.250", "240.0.0.1", "255.255.255.255"})
            T.ok(!pub4(ip), ip + " must NOT be public");

        T.section("IPv6 classification");
        T.ok(!StremioNetPolicy.isPublicIpv6(v6()), ":: unspecified");
        T.ok(!StremioNetPolicy.isPublicIpv6(v6(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1)), "::1 loopback");
        T.ok(!StremioNetPolicy.isPublicIpv6(v6(0xfe,0x80,0,0,0,0,0,0,0,0,0,0,0,0,0,1)), "fe80::1 link-local");
        T.ok(!StremioNetPolicy.isPublicIpv6(v6(0xfc,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1)), "fc00::1 ULA");
        T.ok(!StremioNetPolicy.isPublicIpv6(v6(0xfd,0x12,0x34,0x56,0,0,0,0,0,0,0,0,0,0,0,1)), "fd12:3456:: ULA");
        T.ok(!StremioNetPolicy.isPublicIpv6(v6(0xff,0x02,0,0,0,0,0,0,0,0,0,0,0,0,0,1)), "ff02::1 multicast");
        T.ok(!StremioNetPolicy.isPublicIpv6(v6(0,0,0,0,0,0,0,0,0,0,0xff,0xff,127,0,0,1)), "::ffff:127.0.0.1 mapped loopback");
        T.ok(!StremioNetPolicy.isPublicIpv6(v6(0,0,0,0,0,0,0,0,0,0,0xff,0xff,192,168,1,1)), "::ffff:192.168.1.1 mapped private");
        T.ok(StremioNetPolicy.isPublicIpv6(v6(0,0,0,0,0,0,0,0,0,0,0xff,0xff,8,8,8,8)), "::ffff:8.8.8.8 mapped public");
        T.ok(!StremioNetPolicy.isPublicIpv6(v6(0x20,0x01,0x0d,0xb8,0,0,0,0,0,0,0,0,0,0,0,1)), "2001:db8:: documentation");
        T.ok(!StremioNetPolicy.isPublicIpv6(v6(0x20,0x01,0,0,0,0,0,0,0,0,0,0,0,0,0,1)), "2001:: Teredo");
        T.ok(!StremioNetPolicy.isPublicIpv6(v6(0x01,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1)), "100:: discard prefix (outside 2000::/3)");
        T.ok(StremioNetPolicy.isPublicIpv6(v6(0x26,0x06,0x47,0x00,0x47,0,0,0,0,0,0,0,0,0,0x11,0x11)), "2606:4700:4700::1111 public");
        T.ok(StremioNetPolicy.isPublicIpv6(v6(0x20,0x01,0x48,0x60,0x48,0x60,0,0,0,0,0,0,0,0,0x88,0x88)), "2001:4860:4860::8888 public");
        T.ok(StremioNetPolicy.isPublicIpv6(v6(0,0x64,0xff,0x9b,0,0,0,0,0,0,0,0,8,8,8,8)), "NAT64 of 8.8.8.8 is allowed (IPv6-only mobile networks)");
        T.ok(!StremioNetPolicy.isPublicIpv6(v6(0,0x64,0xff,0x9b,0,0,0,0,0,0,0,0,127,0,0,1)), "NAT64 of 127.0.0.1 is rejected");
        T.ok(!StremioNetPolicy.isPublicIpv6(v6(0x20,0x02,0xc0,0xa8,0x01,0x01,0,0,0,0,0,0,0,0,0,1)), "6to4 of 192.168.1.1 rejected");
        T.ok(StremioNetPolicy.isPublicIpv6(v6(0x20,0x02,0x08,0x08,0x08,0x08,0,0,0,0,0,0,0,0,0,1)), "6to4 of 8.8.8.8 allowed");

        T.section("URL syntax (addon policy: public https only)");
        StremioNetPolicy.Policy addon = StremioNetPolicy.Policy.addon();
        for (String ok : new String[]{"https://private-addon.example/x/manifest.json", "https://EXAMPLE.com/manifest.json",
                "https://torrentio.strem.fun/manifest.json", "https://1.2.3.4/manifest.json",
                "https://addon.example.com:8443/x/manifest.json", "https://xn--mgbh0fb.example/manifest.json"})
            T.ok(syntaxOk(addon, ok), "accepted: " + ok);
        for (String bad : new String[]{"http://example.com/manifest.json", "ftp://example.com/manifest.json",
                "stremio://example.com/manifest.json", "file:///etc/passwd", "https://user:pw@example.com/m.json",
                "https://example.com/m.json#frag", "https://localhost/m.json", "https://foo.localhost/m.json",
                "https://localhost./m.json", "https://a.local/m.json", "https://a.internal./m.json",
                "https://nas/m.json", "https://router.lan/m.json", "https://127.0.0.1/m.json",
                "https://2130706433/m.json", "https://0x7f.0.0.1/m.json", "https://127.1/m.json",
                "https://017.0.0.1/m.json", "https://[::1]/m.json", "https://[fd00::1]/m.json",
                "https://10.0.0.5/m.json", "https://192.168.1.1:8443/m.json",
                "https://169.254.169.254/latest/meta-data/", "https://100.64.0.1/m.json",
                "https://example.com:0/m.json", "https://example.com:99999/m.json",
                "https://host_with_underscore.com/m.json", "https:///no-host", "//example.com/m.json"})
            T.ok(!syntaxOk(addon, bad), "rejected: " + bad);

        T.section("Media policy allows http but still no private hosts");
        StremioNetPolicy.Policy media = StremioNetPolicy.Policy.media();
        T.ok(syntaxOk(media, "http://cdn.example.com/video.mp4"), "http media accepted");
        T.ok(!syntaxOk(media, "http://192.168.1.10/video.mp4"), "private http media rejected");
        T.ok(!syntaxOk(media, "http://localhost:8080/v.m3u8"), "localhost media rejected");
        T.ok(!syntaxOk(media, "rtsp://cdn.example.com/v"), "rtsp rejected");

        T.section("DNS check (resolver double)");
        final List<String> asked = new ArrayList<>();
        StremioNetPolicy.Resolver resolver = host -> {
            asked.add(host);
            switch (host) {
                case "good.example.com": return new InetAddress[]{InetAddress.getByName("8.8.8.8")};
                case "mixed.example.com": return new InetAddress[]{InetAddress.getByName("8.8.8.8"), InetAddress.getByName("10.0.0.1")};
                case "v6.example.com": return new InetAddress[]{InetAddress.getByName("::1")};
                case "cgnat.example.com": return new InetAddress[]{InetAddress.getByName("100.64.0.5")};
                case "empty.example.com": return new InetAddress[0];
                default: throw new UnknownHostException(host);
            }
        };
        StremioNetPolicy.Policy withDns = StremioNetPolicy.Policy.addon(resolver);
        T.noThrow("public resolution passes", () -> withDns.check(URI.create("https://Good.Example.COM./a/manifest.json")));
        T.eq("good.example.com", asked.get(0), "resolver receives the normalized (lower-case, no trailing dot) host");
        T.throwsKind(StremioException.Kind.UNSAFE_URL, "one private address in the answer set rejects the host",
                () -> withDns.check(URI.create("https://mixed.example.com/m.json")));
        T.throwsKind(StremioException.Kind.UNSAFE_URL, "IPv6 loopback answer rejected",
                () -> withDns.check(URI.create("https://v6.example.com/m.json")));
        T.throwsKind(StremioException.Kind.UNSAFE_URL, "CGNAT answer rejected",
                () -> withDns.check(URI.create("https://cgnat.example.com/m.json")));
        T.throwsKind(StremioException.Kind.NETWORK, "empty answer is a network failure",
                () -> withDns.check(URI.create("https://empty.example.com/m.json")));
        T.throwsKind(StremioException.Kind.NETWORK, "unknown host is a network failure, not a policy hit",
                () -> withDns.check(URI.create("https://nope.example.com/m.json")));
        int before = asked.size();
        T.throwsKind(StremioException.Kind.UNSAFE_URL, "syntax failures never reach DNS",
                () -> withDns.check(URI.create("https://localhost/m.json")));
        T.eq(before, asked.size(), "no lookup for a syntactically rejected host");

        T.section("Log redaction never exposes path/query secrets");
        String secretUrl = "https://private-addon.example/%7B%22auth_token%22%3A%22TEST_TOKEN_NOT_REAL%22%7D/manifest.json?token=abc";
        String red = StremioNetPolicy.redactUrlForLogs(secretUrl);
        T.eq("https://private-addon.example/…/manifest.json?…", red, "manifest redaction");
        T.ok(!red.contains("TEST_TOKEN_NOT_REAL") && !red.contains("abc") && !red.contains("auth_token"), "no secret text");
        String streamRed = StremioNetPolicy.redactUrlForLogs("https://t.example/cfgSECRET/stream/movie/tt1375666.json");
        T.eq("https://t.example/…/stream/movie/…", streamRed, "stream resource redaction");
        T.eq("[invalid-url]", StremioNetPolicy.redactUrlForLogs("not a url"), "invalid input");
        T.eq("[none]", StremioNetPolicy.redactUrlForLogs(null), "null input");

        System.exit(T.finish("StremioNetPolicyTest"));
    }
}

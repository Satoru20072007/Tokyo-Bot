package com.eve.cinema.stremio;

import java.net.URI;
import java.util.LinkedHashMap;
import java.util.Map;

public final class StremioUrlsTest {

    private static String norm(String in) throws StremioException { return StremioUrls.normalizeManifestUrl(in); }

    public static void main(String[] args) throws Exception {
        T.section("normalizeManifestUrl: shapes users paste");
        T.eq("https://torrentio.strem.fun/manifest.json", norm("https://torrentio.strem.fun/manifest.json"), "canonical stays");
        T.eq("https://torrentio.strem.fun/manifest.json", norm("  https://Torrentio.Strem.Fun  "), "trim + host lower-case + manifest appended");
        T.eq("https://h.example/manifest.json", norm("https://h.example/"), "root slash");
        T.eq("https://h.example/a/b/manifest.json", norm("https://h.example/a/b/"), "base with trailing slash");
        T.eq("https://h.example/a/manifest.json", norm("https://h.example/a/manifest.json/"), "manifest followed by slash");
        T.eq("https://h.example/a/manifest.json", norm("https://h.example/a/configure"), "configure page maps to the manifest next to it");
        T.eq("https://h.example/manifest.json", norm("https://h.example/configure/"), "root configure page");
        T.eq("https://h.example/a/MANIFEST.JSON", norm("https://h.example/a/MANIFEST.JSON"), "file name matched case-insensitively, case kept");
        T.eq("https://h.example:8443/a/manifest.json?x=1&y=2", norm("https://h.example:8443/a/manifest.json?x=1&y=2"), "port and query kept");
        T.eq("https://h.example/manifest.json?k=v", norm("https://h.example?k=v"), "query without path");

        T.section("credential path is preserved byte for byte");
        String credentialUrl = "https://private-addon.example/%7B%22auth_token%22%3A%22TEST_TOKEN_NOT_REAL%22%2C%22lang%22%3A%22ar%22%7D/manifest.json";
        T.eq(credentialUrl, norm(credentialUrl), "percent-encoded credential path unchanged (no double encoding)");
        T.ok(!norm(credentialUrl).contains("%25"), "no %25 introduced");
        String plusPath = "https://h.example/a%2Bb%20c/x%2Fy/manifest.json";
        T.eq(plusPath, norm(plusPath), "%2B %20 %2F kept as given");
        T.eq("https://h.example/%7B%22a%22:%22b%20c%22%7D/manifest.json",
                norm("https://h.example/{\"a\":\"b c\"}/manifest.json"),
                "decoded JSON path pasted from an address bar: only illegal characters (braces, quotes, space) are encoded; ':' is a legal path character");
        T.eq("https://h.example/%D8%AA%D8%B1%D8%AC%D9%85%D8%A9/manifest.json", norm("https://h.example/ترجمة/manifest.json"), "Unicode path -> UTF-8 percent-encoding");
        T.eq("https://h.example/100%25/manifest.json", norm("https://h.example/100%/manifest.json"), "lone % is escaped");
        T.eq("https://h.example/a/manifest.json?sig=abc%3D%3D&e=1", norm("https://h.example/a/manifest.json?sig=abc%3D%3D&e=1"), "signed query untouched");
        T.eq("https://h.example/a//b/manifest.json", norm("https://h.example/a//b/manifest.json"), "empty segments are not collapsed");

        T.section("rejections");
        for (String bad : new String[]{null, "", "   ", "http://h.example/manifest.json", "stremio://h.example/manifest.json",
                "ftp://h.example/manifest.json", "h.example/manifest.json", "//h.example/manifest.json",
                "https://h.example/a#frag", "https://u:p@h.example/manifest.json", "https://localhost/manifest.json",
                "https://127.0.0.1/manifest.json", "https://10.1.1.1/manifest.json", "https://nas/manifest.json"}) {
            final String url = bad;
            T.throwsKind(StremioException.Kind.UNSAFE_URL, "rejected: " + bad, () -> norm(url));
        }
        StringBuilder longUrl = new StringBuilder("https://h.example/");
        for (int i = 0; i < 5000; i++) longUrl.append('a');
        T.throwsKind(StremioException.Kind.UNSAFE_URL, "over-long URL", () -> norm(longUrl.toString()));

        T.section("test policy allows a loopback http fixture");
        T.eq("http://127.0.0.1:8080/x/manifest.json",
                StremioUrls.normalizeManifestUrl("http://127.0.0.1:8080/x", StremioNetPolicy.Policy.forTests()), "http fixture");

        T.section("resourceUrl");
        StremioNetPolicy.Policy p = StremioNetPolicy.Policy.addon();
        String base = "https://h.example/%7Bcfg%7D/manifest.json";
        T.eq("https://h.example/%7Bcfg%7D/stream/movie/tt1375666.json",
                StremioUrls.resourceUrl(base, "stream", "movie", "tt1375666", null, p), "movie stream");
        T.eq("https://h.example/%7Bcfg%7D/stream/series/tt0944947%3A1%3A2.json",
                StremioUrls.resourceUrl(base, "stream", "series", "tt0944947:1:2", null, p), "episode id colons are encoded");
        Map<String, String> extras = new LinkedHashMap<>();
        extras.put("videoHash", "8e245d9679d31e12");
        extras.put("videoSize", "1234567890");
        extras.put("filename", "My Movie (2010) [1080p].mkv");
        T.eq("https://h.example/%7Bcfg%7D/subtitles/movie/tt1375666/videoHash=8e245d9679d31e12&videoSize=1234567890&filename=My%20Movie%20%282010%29%20%5B1080p%5D.mkv.json",
                StremioUrls.resourceUrl(base, "subtitles", "movie", "tt1375666", extras, p), "subtitle extras encoded");
        Map<String, String> nasty = new LinkedHashMap<>();
        nasty.put("filename", "a&b=c/d?e#f.mkv");
        String nastyUrl = StremioUrls.resourceUrl(base, "subtitles", "movie", "tt1", nasty, p);
        T.eq("https://h.example/%7Bcfg%7D/subtitles/movie/tt1/filename=a%26b%3Dc%2Fd%3Fe%23f.mkv.json", nastyUrl, "separators inside values are escaped");
        T.eq("https://h.example/a/stream/movie/tt1.json?token=zz",
                StremioUrls.resourceUrl("https://h.example/a/manifest.json?token=zz", "stream", "movie", "tt1", null, p), "manifest query is forwarded");
        T.throwsKind(StremioException.Kind.UNSUPPORTED, "unknown resource", () -> StremioUrls.resourceUrl(base, "addon_catalog", "movie", "x", null, p));
        T.throwsKind(StremioException.Kind.UNSUPPORTED, "empty id", () -> StremioUrls.resourceUrl(base, "stream", "movie", "", null, p));
        T.ok(URI.create(nastyUrl).getRawPath().endsWith(".json"), "result is a valid URI");

        T.section("credential detection and origins");
        T.ok(!StremioUrls.carriesCredential("https://torrentio.strem.fun/manifest.json"), "plain manifest is public");
        T.ok(StremioUrls.carriesCredential("https://h.example/abc/manifest.json"), "config segment may hold a secret");
        T.ok(StremioUrls.carriesCredential("https://h.example/manifest.json?token=1"), "query may hold a secret");
        T.ok(StremioUrls.sameOrigin(URI.create("https://A.example/x"), URI.create("https://a.example:443/y")), "default port equals explicit 443");
        T.ok(!StremioUrls.sameOrigin(URI.create("https://a.example/x"), URI.create("https://b.example/x")), "host differs");
        T.ok(!StremioUrls.sameOrigin(URI.create("https://a.example/x"), URI.create("http://a.example/x")), "scheme differs");
        T.ok(!StremioUrls.sameOrigin(URI.create("https://a.example/x"), URI.create("https://a.example:8443/x")), "port differs");

        T.section("stream dedup key");
        String canonical = StremioUrls.streamDedupKey("https://CDN.example/video.m3u8?token=x&expires=4");
        T.eq("https://cdn.example/video.m3u8?expires=4&token=x", canonical,
                "comparison key normalizes host and query order");
        T.eq(canonical, StremioUrls.streamDedupKey("https://cdn.example/video.m3u8?expires=4&token=x&utm_source=app"),
                "tracking parameters do not create duplicate rows");
        T.ok(!canonical.equals(StremioUrls.streamDedupKey("https://cdn.example/video.m3u8?token=y&expires=4")),
                "different signed token remains a different source");

        System.exit(T.finish("StremioUrlsTest"));
    }
}

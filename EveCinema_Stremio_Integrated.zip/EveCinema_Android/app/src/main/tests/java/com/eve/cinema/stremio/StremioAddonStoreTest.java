package com.eve.cinema.stremio;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;

public final class StremioAddonStoreTest {
    private static String url(int i) { return "https://addon" + i + ".example.com/cfg/manifest.json"; }
    private static StremioManifest manifest(String id) { return Fx.imdbAddon(id); }

    public static void main(String[] args) throws Exception {
        persistence();
        duplicates();
        failuresNeverDelete();
        damagedAndRejected();
        limitsAndConcurrency();
        System.exit(T.finish("StremioAddonStoreTest"));
    }

    static void persistence() throws Exception {
        T.section("add-ons survive an app restart (new store instance, same preferences)");
        FakePrefs prefs = new FakePrefs();
        StremioAddonStore first = new StremioAddonStore(prefs);
        T.eq(StremioAddonStore.AddResult.ADDED, first.addOrUpdateDetailed(url(1), manifest("a.one"), 1000L), "added");
        first.setEnabled("a.one", false);
        StremioAddonStore afterRestart = new StremioAddonStore(prefs);
        T.eq(1, afterRestart.list().size(), "still there");
        StremioAddonStore.Addon a = afterRestart.find("a.one");
        T.eq(url(1), a.manifestUrl, "URL kept");
        T.ok(!a.enabled && !a.usable(), "the user's 'disabled' choice persisted");
        T.eq(1000L, a.lastSuccessMs, "check time kept");
        T.eq("a.one", a.manifest.id, "manifest re-parsed from the stored copy");
    }

    static void duplicates() throws Exception {
        T.section("duplicates: no second record, and an overwrite is reported, not silent");
        FakePrefs prefs = new FakePrefs();
        StremioAddonStore s = new StremioAddonStore(prefs);
        s.addOrUpdate(url(1), manifest("a.one"), 1L);
        s.setEnabled("a.one", false);
        T.eq(StremioAddonStore.AddResult.UPDATED_SAME_URL, s.addOrUpdateDetailed(url(1), manifest("a.one"), 2L), "same URL again");
        T.eq(1, s.list().size(), "no duplicate record");
        T.ok(!s.find("a.one").enabled, "re-adding does not silently re-enable what the user disabled");
        T.eq(StremioAddonStore.AddResult.UPDATED_SAME_URL, s.addOrUpdateDetailed("https://ADDON1.example.com/cfg", manifest("a.one"), 3L), "different spelling of the same URL");
        T.eq(1, s.list().size(), "still one record");
        T.eq(StremioAddonStore.AddResult.REPLACED_SAME_ID, s.addOrUpdateDetailed(url(2), manifest("a.one"), 4L), "same add-on id behind another URL");
        T.eq(url(2), s.find("a.one").manifestUrl, "the new configuration replaces the old one");
        T.eq(1, s.list().size(), "and there is still exactly one record");
        T.ok(s.addOrUpdate(url(3), manifest("a.one"), 5L), "the compatibility method reports 'replaced'");
        T.ok(!s.addOrUpdate(url(9), manifest("b.two"), 6L), "and 'not replaced' for a new add-on");
    }

    static void failuresNeverDelete() throws Exception {
        T.section("a failed refresh records the failure and nothing else");
        FakePrefs prefs = new FakePrefs();
        StremioAddonStore s = new StremioAddonStore(prefs);
        s.addOrUpdate(url(1), manifest("a.one"), 100L);
        T.ok(s.recordFailure("a.one", StremioException.Kind.NETWORK, 200L), "failure recorded");
        StremioAddonStore.Addon a = s.find("a.one");
        T.ok(a != null && a.manifestUrl.equals(url(1)) && a.manifest.id.equals("a.one"), "manifest and URL untouched");
        T.ok(a.enabled && a.usable(), "still enabled and usable (cached manifest keeps working)");
        T.ok(a.lastRefreshFailed() && "NETWORK".equals(a.lastFailureKind), "failure kind visible to the UI");
        T.eq(100L, a.lastSuccessMs, "last SUCCESS time kept");
        T.eq(200L, a.lastCheckedMs, "last attempt time updated");
        T.ok(s.update("a.one", url(1), manifest("a.one"), 300L), "a later success");
        a = s.find("a.one");
        T.ok(!a.lastRefreshFailed() && a.lastFailureKind.isEmpty(), "clears the failure state");
        T.ok(!s.recordFailure("missing", StremioException.Kind.TIMEOUT, 1L), "unknown id is ignored");
        T.ok(s.remove("a.one") && s.list().isEmpty(), "only an explicit remove deletes");
    }

    static void damagedAndRejected() throws Exception {
        T.section("damaged or no-longer-accepted entries are not destroyed by a save");
        FakePrefs prefs = new FakePrefs();
        StremioAddonStore s = new StremioAddonStore(prefs);
        s.addOrUpdate(url(1), manifest("good.one"), 1L);
        JSONArray array = new JSONArray(prefs.getString("addons_v1", "[]"));
        JSONObject broken = new JSONObject();
        broken.put("manifestUrl", "https://broken.example.com/manifest.json");
        broken.put("manifest", new JSONObject("{\"id\":\"???\"}"));
        broken.put("enabled", true);
        array.put(broken);
        JSONObject oldHttp = new JSONObject();
        oldHttp.put("manifestUrl", "http://old.example.com/manifest.json");
        oldHttp.put("manifest", manifest("old.http").raw());
        oldHttp.put("enabled", true);
        oldHttp.put("lastCheckedMs", 77L);
        array.put(oldHttp);
        prefs.edit().putString("addons_v1", array.toString()).apply();

        List<StremioAddonStore.Addon> list = new StremioAddonStore(prefs).list();
        T.eq(2, list.size(), "readable entries listed (the corrupt manifest is not)");
        StremioAddonStore.Addon rejected = null;
        for (StremioAddonStore.Addon a : list) if (a.manifest.id.equals("old.http")) rejected = a;
        T.ok(rejected != null && rejected.urlRejected && !rejected.usable(), "http URL is flagged, visible, and never queried");
        T.eq("http://old.example.com/manifest.json", rejected.manifestUrl, "its stored URL text is kept as it was");
        T.eq(77L, rejected.lastSuccessMs, "records without lastSuccessMs fall back to lastCheckedMs");

        s.setEnabled("good.one", false);   // an unrelated write
        String saved = prefs.getString("addons_v1", "");
        T.ok(saved.contains("broken.example.com"), "the unreadable record survived the save");
        T.ok(saved.contains("old.example.com"), "so did the rejected one");
        T.ok(s.remove("old.http"), "the user can still remove the rejected one");
        T.ok(!prefs.getString("addons_v1", "").contains("old.example.com"), "and it is gone after an explicit remove");
        prefs.edit().putString("addons_v1", "not json at all").apply();
        T.eq(0, new StremioAddonStore(prefs).list().size(), "unreadable list -> empty list, no crash");
        T.noThrow("preferences/context are required", () -> { try { new StremioAddonStore((android.content.SharedPreferences) null); } catch (IllegalArgumentException ok) { return; } throw new AssertionError("accepted null"); });
    }

    static void limitsAndConcurrency() throws Exception {
        T.section("limit and concurrent writers on separate store instances");
        FakePrefs prefs = new FakePrefs();
        StremioAddonStore s = new StremioAddonStore(prefs);
        for (int i = 0; i < 50; i++) s.addOrUpdate(url(i), manifest("m." + i), i);
        try { s.addOrUpdate(url(99), manifest("m.99"), 1L); T.ok(false, "51st accepted"); }
        catch (IllegalStateException expected) { T.ok(true, "51st add-on refused"); }
        T.eq(50, s.list().size(), "the 50 are intact");

        final FakePrefs shared = new FakePrefs();
        final int threads = 8, each = 6;
        final CountDownLatch go = new CountDownLatch(1);
        final AtomicInteger errors = new AtomicInteger();
        List<Thread> workers = new ArrayList<>();
        for (int t = 0; t < threads; t++) {
            final int id = t;
            Thread th = new Thread(() -> {
                try {
                    StremioAddonStore mine = new StremioAddonStore(shared);   // each screen creates its own instance
                    go.await();
                    for (int i = 0; i < each; i++) {
                        mine.addOrUpdate(url(id * 100 + i), manifest("w." + id + "." + i), 1L);
                        mine.setEnabled("w." + id + "." + i, i % 2 == 0);
                    }
                } catch (Throwable ex) { errors.incrementAndGet(); }
            });
            workers.add(th); th.start();
        }
        go.countDown();
        for (Thread th : workers) th.join();
        T.eq(0, errors.get(), "no worker failed");
        List<StremioAddonStore.Addon> all = new StremioAddonStore(shared).list();
        T.eq(threads * each, all.size(), "no lost update across store instances");
        int enabled = 0;
        for (StremioAddonStore.Addon a : all) if (a.enabled) enabled++;
        T.eq(threads * each / 2, enabled, "every enable/disable toggle landed");
    }
}

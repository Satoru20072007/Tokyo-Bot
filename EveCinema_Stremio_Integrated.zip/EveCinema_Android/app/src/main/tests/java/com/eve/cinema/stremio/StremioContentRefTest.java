package com.eve.cinema.stremio;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class StremioContentRefTest {
    public static void main(String[] args) {
        T.section("content ref");
        StremioContentRef m = StremioContentRef.movie("27205");
        T.eq("tmdb:27205", m.tmdbVideoId(), "tmdb form");
        T.eq(null, m.imdbVideoId(), "no IMDb id yet");
        T.eq(Arrays.asList("tmdb:27205"), m.candidateIds(), "only the honest id exists");
        StremioContentRef mi = m.withImdb("tt1375666");
        T.eq(Arrays.asList("tt1375666", "tmdb:27205"), mi.candidateIds(), "IMDb preferred");
        T.eq(null, m.withImdb("garbage").imdbId, "malformed IMDb ids are ignored");
        T.eq(null, m.withImdb("tt12").imdbId, "too short");
        T.eq(null, m.withImdb(null).imdbId, "null");
        StremioContentRef ep = StremioContentRef.episode("1399", 1, 2).withImdb("tt0944947");
        T.eq("tt0944947:1:2", ep.imdbVideoId(), "episode id");
        T.eq("tmdb:1399:1:2", ep.tmdbVideoId(), "episode tmdb id");
        T.eq("series", ep.type, "series type");
        StremioContentRef anime = StremioContentRef.episode("1399", 1, 2, "anime").withImdb("tt0944947");
        T.eq("anime", anime.type, "anime uses the explicit Stremio anime type");
        T.ok(anime.isEpisode() && anime.isAnime(), "anime episode is recognized as an episode and as anime");
        T.eq("tt0944947:1:2", anime.imdbVideoId(), "anime IMDb episode id shape");
        T.eq("tmdb:1399:1:2", anime.tmdbVideoId(), "anime TMDB episode id shape");
        T.eq("tt0944947:0:3", StremioContentRef.episode("1399", 0, 3).withImdb("tt0944947").imdbVideoId(), "specials (season 0)");
        for (String bad : new String[]{null, "", "abc", "12 3", "-5", "1234567890123"}) {
            try { StremioContentRef.movie(bad); T.ok(false, "accepted bad tmdb id " + bad); }
            catch (IllegalArgumentException expected) { T.ok(true, "rejected " + bad); }
        }
        try { StremioContentRef.episode("1", 1, 0); T.ok(false, "episode 0 accepted"); } catch (IllegalArgumentException ok) { T.ok(true, "episode 0 rejected"); }

        T.section("availability check before the IMDb id is known");
        StremioManifest imdb = Fx.imdbAddon("a.b");
        StremioManifest tmdb = Fx.manifest("c.d", "[\"stream\"]", "[\"movie\"]", "\"idPrefixes\":[\"tmdb:\"]");
        StremioManifest kitsu = Fx.manifest("e.f", "[\"stream\"]", "[\"movie\"]", "\"idPrefixes\":[\"kitsu:\"]");
        T.ok(m.couldBeServedBy(imdb, "stream"), "tt-add-on can serve once IMDb is resolved");
        T.ok(m.couldBeServedBy(tmdb, "stream"), "tmdb-add-on can serve right away");
        T.ok(!m.couldBeServedBy(kitsu, "stream"), "kitsu-only add-on can never serve a TMDB title");
        T.ok(ep.couldBeServedBy(imdb, "stream"), "episodes too");
        StremioManifest seriesOnly = Fx.manifest("series.only", "[\"stream\"]", "[\"series\"]", "\"idPrefixes\":[\"tt\"]");
        T.ok(anime.couldBeServedBy(seriesOnly, "stream"), "anime may fall back to an add-on exposing series only");
        T.ok(!StremioContentRef.episode("1", 1, 1).couldBeServedBy(Fx.manifest("g.h", "[\"stream\"]", "[\"movie\"]", null), "stream"), "movie-only add-on cannot serve an episode");

        T.section("TMDB -> IMDb resolver");
        final List<String> urls = new ArrayList<>();
        final int[] mode = {0};   // 0 ok, 1 io failure, 2 no imdb, 3 garbage
        StremioIdResolver r = new StremioIdResolver((url, timeout) -> {
            urls.add(url);
            if (mode[0] == 1) throw new IOException("boom https://api.example/secret-token");
            if (mode[0] == 2) return "{\"id\":1,\"imdb_id\":null}";
            if (mode[0] == 3) return "<html>";
            return "{\"id\":27205,\"imdb_id\":\"tt1375666\",\"wikidata_id\":\"Q25188\"}";
        }, "https://api.themoviedb.org/3/");
        T.eq("tt1375666", r.resolveImdb("movie", "27205", 1000), "movie");
        T.eq("https://api.themoviedb.org/3/movie/27205/external_ids", urls.get(0), "movie endpoint");
        T.eq("tt1375666", r.resolveImdb("movie", "27205", 1000), "second call");
        T.eq(1, urls.size(), "answered from the cache (one HTTP call)");
        T.eq("tt1375666", r.resolveImdb("series", "1399", 1000), "series");
        T.eq("https://api.themoviedb.org/3/tv/1399/external_ids", urls.get(1), "tv endpoint for series");
        T.eq("tt1375666", r.resolveImdb("anime", "1400", 1000), "anime IMDb resolution");
        T.eq("https://api.themoviedb.org/3/tv/1400/external_ids", urls.get(2), "anime uses TV external ids");
        mode[0] = 1;
        T.eq(null, r.resolveImdb("movie", "111", 1000), "network failure -> null, never throws");
        mode[0] = 0;
        T.eq("tt1375666", r.resolveImdb("movie", "111", 1000), "a failure is NOT cached: the next call succeeds");
        mode[0] = 2;
        T.eq(null, r.resolveImdb("movie", "222", 1000), "TMDB has no IMDb id");
        mode[0] = 0;
        int calls = urls.size();
        T.eq(null, r.resolveImdb("movie", "222", 1000), "a definitive 'none' is cached");
        T.eq(calls, urls.size(), "no refetch for a definitive none");
        mode[0] = 3;
        T.eq(null, r.resolveImdb("movie", "333", 1000), "garbage body -> null");
        calls = urls.size();
        T.eq(null, r.resolveImdb("movie", "../etc", 1000), "non-numeric id never reaches the network");
        T.eq(null, r.resolveImdb("movie", null, 1000), "null id");
        T.eq(calls, urls.size(), "no HTTP call for invalid ids");
        System.exit(T.finish("StremioContentRefTest"));
    }
}

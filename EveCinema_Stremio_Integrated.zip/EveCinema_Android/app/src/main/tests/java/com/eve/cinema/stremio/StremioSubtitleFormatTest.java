package com.eve.cinema.stremio;

import com.eve.cinema.playback.SubtitleParser;

import java.util.List;

/**
 * Regression test for what the SHARED in-app subtitle parser (not modified by this work) really
 * reads. It is the evidence behind the chooser's rule "hide .ass/.ssa, trust content for the rest".
 */
public final class StremioSubtitleFormatTest {
    private static final String SRT = "1\r\n00:00:01,000 --> 00:00:03,500\r\nمرحبا بالعالم\r\n\r\n2\r\n00:00:04,000 --> 00:00:06,000\r\nسطر ثانٍ\r\n";
    private static final String VTT = "\uFEFFWEBVTT\n\nNOTE comment\n\n00:01.000 --> 00:03.000 align:start\n<i>مرحبا</i>\n\n00:00:04.000 --> 00:00:06.250\nسطر\n";
    private static final String ASS = "[Script Info]\nTitle: x\n\n[V4+ Styles]\nFormat: Name, Fontname\nStyle: Default,Arial\n\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\nDialogue: 0,0:00:01.00,0:00:03.00,Default,,0,0,0,,مرحبا\n";

    public static void main(String[] args) {
        T.section("SRT and WebVTT are read (content-sniffed, CRLF and BOM tolerated)");
        List<SubtitleParser.Cue> srt = SubtitleParser.parse(SRT);
        T.eq(2, srt.size(), "SRT cues");
        T.eq(1000L, srt.get(0).startMs, "SRT comma milliseconds");
        T.eq("مرحبا بالعالم", srt.get(0).text, "Arabic text kept");
        T.eq(SubtitleParser.Format.SRT, SubtitleParser.detect(SRT), "detected as SRT");
        List<SubtitleParser.Cue> vtt = SubtitleParser.parse(VTT);
        T.eq(2, vtt.size(), "VTT cues (NOTE block ignored, cue settings ignored)");
        T.eq(1000L, vtt.get(0).startMs, "VTT optional hours");
        T.eq("مرحبا", vtt.get(0).text, "markup stripped");
        T.eq(SubtitleParser.Format.VTT, SubtitleParser.detect(VTT), "detected as VTT despite the BOM");

        T.section("ASS/SSA and garbage yield no cues and never throw");
        T.eq(0, SubtitleParser.parse(ASS).size(), "ASS/SSA is NOT supported by the in-app parser");
        T.eq(0, SubtitleParser.parse("").size(), "empty");
        T.eq(0, SubtitleParser.parse(null).size(), "null");
        T.eq(0, SubtitleParser.parse("<html><body>Not a subtitle</body></html>").size(), "HTML error page");
        T.eq(0, SubtitleParser.parse("1\n00:00:xx --> broken\ntext").size(), "malformed timing line");
        T.noThrow("binary-ish content is survivable", () -> SubtitleParser.parse(new String(new char[5000]).replace('\0', '\u0001')));

        T.section("the chooser's own extension rule agrees with that reality");
        T.ok(StremioSubtitle.hasUnsupportedFormatExtension("https://s.example/a.ass") && StremioSubtitle.hasUnsupportedFormatExtension("https://s.example/a.SSA?x=1"), ".ass/.ssa hidden");
        T.ok(!StremioSubtitle.hasUnsupportedFormatExtension("https://s.example/a.srt") && !StremioSubtitle.hasUnsupportedFormatExtension("https://s.example/a.vtt") && !StremioSubtitle.hasUnsupportedFormatExtension("https://s.example/download/123"), "srt/vtt/extension-less stay");
        System.exit(T.finish("StremioSubtitleFormatTest"));
    }
}

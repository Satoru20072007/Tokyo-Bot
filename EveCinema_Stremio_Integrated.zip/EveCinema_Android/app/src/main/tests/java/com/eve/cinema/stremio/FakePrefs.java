package com.eve.cinema.stremio;

import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/** In-memory SharedPreferences double (complete API shape, so it also compiles against android.jar). */
final class FakePrefs implements SharedPreferences {
    final Map<String, Object> values = new HashMap<>();

    public Map<String, ?> getAll() { synchronized (values) { return new HashMap<>(values); } }
    public String getString(String key, String def) { synchronized (values) { Object v = values.get(key); return v instanceof String ? (String) v : def; } }
    public Set<String> getStringSet(String key, Set<String> def) { return def; }
    public int getInt(String key, int def) { return def; }
    public long getLong(String key, long def) { return def; }
    public float getFloat(String key, float def) { return def; }
    public boolean getBoolean(String key, boolean def) { return def; }
    public boolean contains(String key) { synchronized (values) { return values.containsKey(key); } }
    public void registerOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener l) { }
    public void unregisterOnSharedPreferenceChangeListener(OnSharedPreferenceChangeListener l) { }

    public Editor edit() {
        return new Editor() {
            private final Map<String, Object> pending = new HashMap<>();
            private boolean clear;
            public Editor putString(String key, String value) { pending.put(key, value); return this; }
            public Editor putStringSet(String key, Set<String> v) { return this; }
            public Editor putInt(String key, int v) { return this; }
            public Editor putLong(String key, long v) { return this; }
            public Editor putFloat(String key, float v) { return this; }
            public Editor putBoolean(String key, boolean v) { return this; }
            public Editor remove(String key) { pending.put(key, null); return this; }
            public Editor clear() { clear = true; return this; }
            public boolean commit() {
                synchronized (values) {
                    if (clear) values.clear();
                    for (Map.Entry<String, Object> e : pending.entrySet()) {
                        if (e.getValue() == null) values.remove(e.getKey()); else values.put(e.getKey(), e.getValue());
                    }
                }
                return true;
            }
            public void apply() { commit(); }
        };
    }
}

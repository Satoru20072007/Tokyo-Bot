package com.eve.cinema.stremio;

import java.util.ArrayList;
import java.util.List;

public final class StremioSourceResolverTest {
    private static StremioAddonStore.Addon addon(String url, StremioManifest m, boolean enabled) {
        return new StremioAddonStore.Addon(url, m, enabled, 0L);
    }

    public static void main(String[] args) {
        T.section("'is a Stremio source available?' understands every id scheme the app can produce");
        StremioManifest imdbOnly = Fx.imdbAddon("a.imdb");                                         // like Torrentio/Comet
        StremioManifest tmdbOnly = Fx.manifest("b.tmdb", "[\"stream\"]", "[\"movie\"]", "\"idPrefixes\":[\"tmdb:\"]");
        StremioManifest kitsuOnly = Fx.manifest("c.kitsu", "[\"stream\"]", "[\"movie\"]", "\"idPrefixes\":[\"kitsu:\"]");
        StremioManifest movieOnly = Fx.manifest("d.movie", "[\"stream\"]", "[\"movie\"]", "\"idPrefixes\":[\"tt\"]");
        StremioManifest needsConfig = Fx.manifest("e.cfg", "[\"stream\"]", "[\"movie\"]", "\"idPrefixes\":[\"tt\"],\"behaviorHints\":{\"configurationRequired\":true}");

        T.ok(StremioSourceResolver.anyUsableStreamAddon(list(addon("https://a.example.com/manifest.json", imdbOnly, true)), "movie", "tmdb:"),
                "a tt-prefix add-on authorizes playback (the bare 'tmdb:' probe used by the policy used to return false for it)");
        T.ok(StremioSourceResolver.anyUsableStreamAddon(list(addon("https://a.example.com/manifest.json", imdbOnly, true)), "movie", "tmdb:27205"), "movie with a TMDB id");
        T.ok(StremioSourceResolver.anyUsableStreamAddon(list(addon("https://a.example.com/manifest.json", imdbOnly, true)), "series", "tmdb:1399:2:5"), "episode with a TMDB id");
        StremioManifest animeOnly = Fx.manifest("anime.only", "[\"stream\"]", "[\"anime\"]", "\"idPrefixes\":[\"tt\"]");
        T.ok(StremioSourceResolver.anyUsableStreamAddon(list(addon("https://anime.example/manifest.json", animeOnly, true)), "anime", "tmdb:1399:2:5"), "anime-only add-on is surfaced for anime episodes");
        T.ok(StremioSourceResolver.anyUsableStreamAddon(list(addon("https://a.example.com/manifest.json", imdbOnly, true)), "anime", "tmdb:1399:2:5"), "series-only add-on can serve as anime fallback");
        T.ok(StremioSourceResolver.anyUsableStreamAddon(list(addon("https://b.example.com/manifest.json", tmdbOnly, true)), "movie", "tmdb:27205"), "a tmdb-prefix add-on still works");
        T.ok(!StremioSourceResolver.anyUsableStreamAddon(list(addon("https://c.example.com/manifest.json", kitsuOnly, true)), "movie", "tmdb:27205"), "kitsu-only add-on cannot serve a TMDB title");
        T.ok(!StremioSourceResolver.anyUsableStreamAddon(list(addon("https://d.example.com/manifest.json", movieOnly, true)), "series", "tmdb:1:1:1"), "movie-only add-on does not serve episodes");
        T.ok(!StremioSourceResolver.anyUsableStreamAddon(list(addon("https://a.example.com/manifest.json", imdbOnly, false)), "movie", "tmdb:1"), "a disabled add-on does not count");
        T.ok(!StremioSourceResolver.anyUsableStreamAddon(list(addon("https://e.example.com/manifest.json", needsConfig, true)), "movie", "tmdb:1"), "an add-on that needs configuration does not count");
        T.ok(!StremioSourceResolver.anyUsableStreamAddon(list(rejected("http://old.example.com/manifest.json", imdbOnly)), "movie", "tmdb:1"), "an add-on whose stored URL is no longer accepted does not count");
        T.ok(!StremioSourceResolver.anyUsableStreamAddon(new ArrayList<StremioAddonStore.Addon>(), "movie", "tmdb:1"), "no add-ons");
        T.ok(!StremioSourceResolver.anyUsableStreamAddon(null, "movie", "tmdb:1") && !StremioSourceResolver.anyUsableStreamAddon(list(), null, "x") && !StremioSourceResolver.anyUsableStreamAddon(list(), "movie", ""), "null/empty input");

        T.section("capability probe ids");
        T.eq("tt0000001", StremioSourceResolver.imdbCapabilityProbe("movie", "tmdb:"), "bare prefix");
        T.eq("tt0000001", StremioSourceResolver.imdbCapabilityProbe("movie", "tmdb:123"), "movie id");
        T.eq("tt0000001:2:5", StremioSourceResolver.imdbCapabilityProbe("series", "tmdb:123:2:5"), "episode id keeps season/episode");
        T.eq(null, StremioSourceResolver.imdbCapabilityProbe("movie", "tt1375666"), "an IMDb id needs no probe");
        System.exit(T.finish("StremioSourceResolverTest"));
    }

    private static StremioAddonStore.Addon rejected(String url, StremioManifest m) {
        return new StremioAddonStore.Addon(url, m, true, 0L, 0L, 0L, "", true);
    }

    private static List<StremioAddonStore.Addon> list(StremioAddonStore.Addon... a) {
        List<StremioAddonStore.Addon> out = new ArrayList<>();
        java.util.Collections.addAll(out, a);
        return out;
    }
}

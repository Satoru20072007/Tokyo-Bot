package com.eve.cinema.stremio;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class StremioSelectionTest {
    private static StremioStreamOption opt(String id, int h, String... keys) {
        return new StremioStreamOption(id, "https://cdn.example/" + id + ".mkv", null, "m", "PROGRESSIVE", h, "name", false,
                -1d, null, 1, "", -1L, "", new LinkedHashSet<>(Arrays.asList(keys)));
    }
    private static StremioSubtitle sub(String id, boolean generic, String key) {
        Set<String> keys = key == null ? Collections.<String>emptySet() : Collections.singleton(key);
        return new StremioSubtitle(id, "https://subs.example/" + id + ".srt", "ara", Collections.<String>emptySet(), keys, generic);
    }
    private static StremioChooserData data(List<StremioStreamOption> o, StremioSubtitle... s) {
        return new StremioChooserData(1L, StremioChooserData.State.COMPLETE, StremioChooserData.EmptyReason.NONE, o, Arrays.asList(s), StremioChooserData.Progress.NONE);
    }
    private static List<String> ids(List<StremioSubtitle> l) { List<String> r = new ArrayList<>(); for (StremioSubtitle s : l) r.add(s.id); return r; }

    public static void main(String[] args) {
        StremioStreamOption a = opt("a", 1080, "h:aaa"), b = opt("b", 720, "h:bbb"), c = opt("c", 480);
        StremioSubtitle forA = sub("t1", false, "h:aaa"), forB = sub("t2", false, "h:bbb"), gen = sub("t3", true, null);
        StremioChooserData d = data(Arrays.asList(a, b, c), forA, forB, gen);

        T.section("nothing is chosen on the user's behalf");
        StremioSelection s = new StremioSelection();
        T.eq(null, s.optionId(), "no stream pre-selected");
        T.eq(StremioSelection.SubtitleMode.UNSET, s.subtitleMode(), "no subtitle decision pre-made");
        T.ok(!s.canPlay(d), "Play is disabled until a stream is chosen");
        T.eq(null, s.option(d), "option lookup");
        s.selectSubtitle("t1");
        T.eq(null, s.optionId(), "choosing a subtitle does not choose a stream");
        T.ok(!s.canPlay(d), "still cannot play");
        s.selectOption("a");
        T.eq(StremioSelection.SubtitleMode.SUBTITLE, s.subtitleMode(), "choosing a stream does not touch the subtitle choice");
        T.ok(s.canPlay(d) && !s.conflict(d), "exact pair plays");
        T.eq("t1", s.subtitle(d).id, "chosen subtitle");

        T.section("conflicts must be resolved explicitly");
        s.selectOption("b");
        T.ok(s.conflict(d) && !s.canPlay(d), "A's subtitle with stream B blocks Play");
        T.ok(s.dimOption(d, b) && !s.dimOption(d, a), "incompatible streams are dimmed, compatible are not");
        s.selectSubtitle("t3");
        T.ok(!s.conflict(d) && s.canPlay(d), "an unverified subtitle never conflicts (it carries a warning instead)");
        s.selectNoSubtitle();
        T.ok(s.canPlay(d) && s.subtitle(d) == null, "'no subtitle' is an explicit, playable choice");
        T.eq(StremioSelection.SubtitleMode.NONE, s.subtitleMode(), "recorded as NONE");

        T.section("hint when a proven subtitle exists but the user has not decided");
        StremioSelection h = new StremioSelection();
        h.selectOption("a");
        T.ok(h.needsSubtitleHint(d), "undecided + exact subtitle exists -> hint");
        h.selectNoSubtitle();
        T.ok(!h.needsSubtitleHint(d), "decided -> no hint");
        StremioSelection h2 = new StremioSelection();
        h2.selectOption("c");
        T.ok(!h2.needsSubtitleHint(d), "no exact subtitle for the stream -> no hint");

        T.section("display order");
        StremioSelection o = new StremioSelection();
        T.eq(Arrays.asList("t1", "t2", "t3"), ids(o.displayOrder(d)), "no stream chosen: file-bound before generic, stable order inside");
        o.selectOption("b");
        T.eq(Arrays.asList("t2", "t3", "t1"), ids(o.displayOrder(d)), "stream B chosen: exact, then unverified, then bound-elsewhere (still visible)");
        StremioSubtitle name = new StremioSubtitle("t4", "https://subs.example/t4.srt", "Arabic", Collections.<String>emptySet(), Collections.<String>emptySet(), true);
        StremioSubtitle code = new StremioSubtitle("t5", "https://subs.example/t5.srt", "ara", Collections.<String>emptySet(), Collections.<String>emptySet(), true);
        List<StremioSubtitle> byConfidence = new StremioSelection().displayOrder(data(Arrays.asList(a), name, code));
        T.eq(Arrays.asList("t5", "t4"), ids(byConfidence), "language-code evidence ranks above language-name evidence");

        T.section("reconcile when the list changes under the user");
        StremioSelection r = new StremioSelection();
        r.selectOption("a"); r.selectSubtitle("t1");
        StremioSelection.Change none = r.reconcile(d);
        T.ok(!none.optionLost && !none.subtitleLost, "unchanged data keeps the selection");
        StremioChooserData shrunk = data(Arrays.asList(b, c), forB, gen);
        StremioSelection.Change lost = r.reconcile(shrunk);
        T.ok(lost.optionLost && lost.subtitleLost, "removed stream and subtitle are reported");
        T.eq(null, r.optionId(), "stream cleared (never silently replaced by another)");
        T.eq(StremioSelection.SubtitleMode.UNSET, r.subtitleMode(), "subtitle choice back to undecided");
        StremioSelection keep = new StremioSelection();
        keep.selectOption("b"); keep.selectNoSubtitle();
        keep.reconcile(shrunk);
        T.eq("b", keep.optionId(), "selection survives growth/reordering (held by id)");
        T.eq(StremioSelection.SubtitleMode.NONE, keep.subtitleMode(), "explicit 'none' survives");
        System.exit(T.finish("StremioSelectionTest"));
    }
}

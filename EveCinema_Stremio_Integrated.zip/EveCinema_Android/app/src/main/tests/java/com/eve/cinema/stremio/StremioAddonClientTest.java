package com.eve.cinema.stremio;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public final class StremioAddonClientTest {
    private static final StremioNetPolicy.Policy MEDIA = StremioNetPolicy.Policy.media();

    private static StremioAddonClient.StreamBatch streams(String json) throws Exception {
        return StremioAddonClient.parseStreams(new JSONObject(json), "https://addon.example/cfg/manifest.json", MEDIA);
    }

    public static void main(String[] args) throws Exception {
        parsingStreams();
        parsingSubtitles();
        headers();
        extrasPerResource();
        endToEnd();
        System.exit(T.finish("StremioAddonClientTest"));
    }

    static void parsingStreams() throws Exception {
        T.section("stream objects: playable vs unsupported, behaviorHints read per the protocol");
        String body = "{\"streams\":["
                + "{\"name\":\"Direct\",\"description\":\"Movie 1080p\",\"url\":\"https://cdn.example.com/v/a.mkv\","
                +   "\"behaviorHints\":{\"filename\":\"Movie.2010.1080p.mkv\",\"videoSize\":4294967296,\"videoHash\":\"8E245D9679D31E12\",\"notWebReady\":true}},"
                + "{\"name\":\"Legacy\",\"title\":\"title text\",\"filename\":\"legacy.720p.mp4\",\"url\":\"https://cdn.example.com/v/b.mp4\"},"
                + "{\"name\":\"Torrent\",\"infoHash\":\"0123456789abcdef0123456789abcdef01234567\",\"fileIdx\":1},"
                + "{\"name\":\"Ext\",\"externalUrl\":\"https://example.com/watch\"},"
                + "{\"name\":\"Frame\",\"playerFrameUrl\":\"https://example.com/embed\"},"
                + "{\"name\":\"YT\",\"ytId\":\"abc\"},"
                + "{\"name\":\"Weird\"},"
                + "{\"name\":\"Private\",\"url\":\"http://192.168.1.5/x.mp4\"},"
                + "{\"name\":\"NullFields\",\"description\":null,\"url\":\"https://cdn.example.com/v/c.m3u8\",\"behaviorHints\":{\"filename\":null,\"videoSize\":null}},"
                + "\"junk\",42]}";
        StremioAddonClient.StreamBatch b = streams(body);
        T.eq(3, b.playable.size(), "three playable streams");
        T.eq(1, b.torrentOnly, "torrent-only counted");
        T.eq(2, b.externalOnly, "externalUrl + playerFrameUrl counted");
        T.eq(1, b.youtubeOnly, "ytId counted");
        T.eq(1, b.otherUnsupported, "stream with nothing playable counted");
        T.eq(1, b.unsafeUrl, "private-address url counted, not offered");
        T.eq(5, b.unsupportedTotal(), "torrent + external + frame + yt + other");

        StremioAddonClient.StreamCandidate a = b.playable.get(0);
        T.eq("Movie.2010.1080p.mkv", a.hintFilename, "behaviorHints.filename");
        T.eq(4294967296L, a.videoSize, "behaviorHints.videoSize (larger than int)");
        T.eq("8E245D9679D31E12", a.videoHash, "behaviorHints.videoHash");
        T.eq("PROGRESSIVE", a.streamType, "mkv is a progressive file");
        T.ok(a.identity().isStrong() && a.identity().strongKeys.contains("h:8e245d9679d31e12"), "hash identity is lower-cased");
        StremioAddonClient.StreamCandidate legacy = b.playable.get(1);
        T.eq("legacy.720p.mp4", legacy.filename, "a legacy top-level filename still helps display/quality");
        T.eq("", legacy.hintFilename, "but it is not an identity (not from behaviorHints)");
        T.ok(!legacy.identity().isStrong(), "so it can never prove a subtitle match");
        T.eq("title text", legacy.description, "title is used when description is absent");
        StremioAddonClient.StreamCandidate nulls = b.playable.get(2);
        T.eq("", nulls.description, "JSON null is empty text, not the string \"null\"");
        T.eq(-1L, nulls.videoSize, "JSON null size is unknown");
        T.eq("HLS", nulls.streamType, "m3u8");

        StringBuilder many = new StringBuilder("{\"streams\":[");
        for (int i = 0; i < 400; i++) many.append(i == 0 ? "" : ",").append("{\"url\":\"https://cdn.example.com/x").append(i).append(".mp4\"}");
        T.eq(100, streams(many + "]}").playable.size(), "playable entries per answer are bounded");
        StringBuilder longUrl = new StringBuilder("https://cdn.example.com/");
        for (int i = 0; i < 5000; i++) longUrl.append('a');
        StremioAddonClient.StreamBatch tooLong = streams("{\"streams\":[{\"url\":\"" + longUrl + "\"}]}");
        T.eq(0, tooLong.playable.size(), "an over-long URL is refused, not cut into a different URL");
        T.eq(1, tooLong.unsafeUrl, "and counted");
        T.eq(0, streams("{}").playable.size(), "missing streams array");
        T.eq(0, StremioAddonClient.parseStreams(null, "https://a.example/manifest.json", MEDIA).playable.size(), "null body");
    }

    static void parsingSubtitles() throws Exception {
        T.section("subtitle objects: Arabic by the add-on's own language field only");
        String body = "[{\"id\":\"1\",\"url\":\"https://subs.example/a.srt\",\"lang\":\"ara\"},"
                + "{\"id\":\"2\",\"url\":\"https://subs.example/b.vtt\",\"lang\":\"ar\"},"
                + "{\"id\":\"3\",\"url\":\"https://subs.example/c.srt\",\"lang\":\"Arabic\"},"
                + "{\"id\":\"4\",\"url\":\"https://subs.example/d.srt\",\"lang\":\"ar-SA\"},"
                + "{\"id\":\"5\",\"url\":\"https://subs.example/e.srt\",\"lang\":\"eng\"},"
                + "{\"id\":\"6\",\"url\":\"https://subs.example/\u0639\u0631\u0628\u064a.srt\",\"lang\":\"eng\"},"
                + "{\"id\":\"7\",\"url\":\"https://subs.example/f.ass\",\"lang\":\"ara\"},"
                + "{\"id\":\"8\",\"url\":\"https://subs.example/g.SSA\",\"lang\":\"ara\"},"
                + "{\"id\":\"9\",\"url\":\"http://10.0.0.5/h.srt\",\"lang\":\"ara\"},"
                + "{\"id\":\"10\",\"url\":\"https://subs.example/a.srt\",\"lang\":\"ara\"},"
                + "{\"id\":\"11\",\"url\":\"https://subs.example/noext/123\",\"lang\":\"ara\"},"
                + "{\"id\":\"12\",\"lang\":\"ara\"},{\"id\":\"13\",\"url\":\"https://subs.example/n.srt\",\"lang\":null},\"junk\"]";
        StremioAddonClient.SubtitleBatch b = StremioAddonClient.parseSubtitleArray(new JSONArray(body), MEDIA);
        T.eq(5, b.arabic.size(), "a, b, c, d and the extension-less URL (de-duplicated by URL)");
        T.eq(2, b.ignoredFormat, ".ass/.ssa ignored: the in-app parser reads SRT/VTT only");
        T.eq(1, b.unsafeUrl, "private-address subtitle URL refused (an entry with no url at all is just skipped)");
        T.ok(b.nonArabic >= 3, "non-Arabic (including an Arabic-looking file name with lang=eng and lang=null) not accepted: " + b.nonArabic);
        T.eq(StremioSubtitle.LANGUAGE_BY_CODE, b.arabic.get(0).languageConfidence, "\"ara\" is a language CODE");
        T.eq(StremioSubtitle.LANGUAGE_BY_CODE, b.arabic.get(3).languageConfidence, "\"ar-SA\" is a language CODE");
        T.eq(StremioSubtitle.LANGUAGE_BY_NAME, b.arabic.get(2).languageConfidence, "\"Arabic\" is recognised by NAME only (lower confidence)");
        T.ok(StremioSubtitle.hasUnsupportedFormatExtension("https://x.example/a.ASS") && !StremioSubtitle.hasUnsupportedFormatExtension("https://x.example/a.srt"), "extension check");
        T.eq(0, StremioAddonClient.parseSubtitleArray(null, MEDIA).arabic.size(), "null array");
        StringBuilder manyArabic = new StringBuilder("[");
        for (int i = 0; i < 205; i++) {
            if (i > 0) manyArabic.append(',');
            manyArabic.append("{\"id\":\"").append(i)
                    .append("\",\"url\":\"https://subs.example/ar_").append(i)
                    .append(".srt\",\"lang\":\"ara\"}");
        }
        manyArabic.append(']');
        StremioAddonClient.SubtitleBatch bounded = StremioAddonClient.parseSubtitleArray(
                new JSONArray(manyArabic.toString()), MEDIA);
        T.eq(200, bounded.arabic.size(), "Arabic subtitle candidates allow up to 200 per bounded response");
        T.ok(bounded.arabic.get(199).url.endsWith("ar_199.srt"), "200th Arabic candidate kept; excess entries are bounded");
    }

    static void headers() throws Exception {
        T.section("forwarded request headers");
        JSONObject h = new JSONObject("{\"user-agent\":\"UA\",\"REFERER\":\"https://r.example/\",\"Cookie\":\"c=1\",\"Authorization\":\"Bearer x\",\"X-Evil\":\"1\",\"Origin\":\"o\\r\\nX: y\"}");
        Map<String, String> same = StremioAddonClient.safeHeaders(h, "https://addon.example/v.mkv", "https://addon.example/manifest.json");
        T.eq("UA", same.get("User-Agent"), "header names are matched case-insensitively");
        T.eq("https://r.example/", same.get("Referer"), "Referer");
        T.eq("c=1", same.get("Cookie"), "Cookie to the add-on's own host over https");
        T.ok(same.containsKey("Authorization") && !same.containsKey("X-Evil"), "allow-list only");
        T.ok(!same.containsKey("Origin"), "values with CR/LF are dropped");
        Map<String, String> other = StremioAddonClient.safeHeaders(h, "https://cdn.other.example/v.mkv", "https://addon.example/manifest.json");
        T.ok(!other.containsKey("Cookie") && !other.containsKey("Authorization"), "no credentials to another host");
        Map<String, String> plain = StremioAddonClient.safeHeaders(h, "http://addon.example/v.mkv", "https://addon.example/manifest.json");
        T.ok(!plain.containsKey("Cookie") && !plain.containsKey("Authorization"), "no credentials over plain http");
    }

    static void extrasPerResource() throws Exception {
        T.section("extras are filtered per resource");
        StremioManifest m = Fx.imdbAddon("x.y");
        Map<String, String> all = new LinkedHashMap<>();
        all.put("videoHash", " abc "); all.put("videoSize", "123"); all.put("filename", "f.mkv"); all.put("genre", "x"); all.put("videoSize2", "9");
        T.eq(0, StremioAddonClient.sanitizeExtras(m, "stream", "movie", "tt1", all).size(), "stream requests carry no extras");
        T.eq(0, StremioAddonClient.sanitizeExtras(m, "meta", "movie", "tt1", all).size(), "meta requests carry no extras");
        Map<String, String> sub = StremioAddonClient.sanitizeExtras(m, "subtitles", "movie", "tt1", all);
        T.eq("[videoHash, videoSize, filename]", sub.keySet().toString(), "subtitles: only the three protocol-defined arguments, protocol order");
        T.eq("abc", sub.get("videoHash"), "values trimmed");
        Map<String, String> blank = new LinkedHashMap<>(); blank.put("videoHash", "  "); blank.put("filename", "");
        T.eq(0, StremioAddonClient.sanitizeExtras(m, "subtitles", "movie", "tt1", blank).size(), "blank values are not sent");
    }

    static void endToEnd() throws Exception {
        T.section("client against a fake add-on (real HTTP, credential path)");
        final List<String> hits = new CopyOnWriteArrayList<>();
        HttpServer server = HttpServer.create(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0), 0);
        server.createContext("/", (HttpExchange ex) -> {
            String raw = ex.getRequestURI().getRawPath();
            hits.add(raw);
            String json;
            if (raw.endsWith("/manifest.json")) json = "{\"id\":\"fake.addon\",\"version\":\"1.0.0\",\"name\":\"Fake\",\"description\":\"D\",\"catalogs\":[],"
                    + "\"resources\":[\"stream\",\"subtitles\"],\"types\":[\"movie\",\"series\"],\"idPrefixes\":[\"tt\"]}";
            else if (raw.contains("/stream/")) json = "{\"streams\":[{\"name\":\"S\",\"url\":\"https://cdn.example.com/a.1080p.mkv\",\"behaviorHints\":{\"videoHash\":\"8e245d9679d31e12\"}},{\"infoHash\":\"abc\"}]}";
            else json = "{\"subtitles\":[{\"id\":\"1\",\"url\":\"https://subs.example/a.srt\",\"lang\":\"ara\"},{\"id\":\"2\",\"url\":\"https://subs.example/b.srt\",\"lang\":\"eng\"}]}";
            byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
            ex.getResponseHeaders().set("Content-Type", "application/json");
            ex.sendResponseHeaders(200, bytes.length);
            try (OutputStream o = ex.getResponseBody()) { o.write(bytes); }
            ex.close();
        });
        server.start();
        String base = "http://127.0.0.1:" + server.getAddress().getPort() + "/%7B%22tok%22%3A%22SECRET%2B1%22%7D/manifest.json";
        StremioAddonClient client = new StremioAddonClient(StremioNetPolicy.Policy.forTests(), MEDIA);

        StremioManifest manifest = StremioManifest.parse(client.fetchManifest(base));
        T.eq("/%7B%22tok%22%3A%22SECRET%2B1%22%7D/manifest.json", hits.get(0), "manifest requested at the exact credential path");

        StremioAddonClient.StreamBatch sb = client.fetchStreams(base, manifest, "movie", "tt1375666", 3000);
        T.eq("/%7B%22tok%22%3A%22SECRET%2B1%22%7D/stream/movie/tt1375666.json", hits.get(1), "stream request keeps the credential path and adds no extras");
        T.eq(1, sb.playable.size(), "one playable stream");
        T.eq(1, sb.torrentOnly, "and one torrent-only entry reported");

        Map<String, String> extras = new LinkedHashMap<>();
        extras.put("videoHash", "8e245d9679d31e12"); extras.put("videoSize", "4294967296"); extras.put("filename", "Movie (2010).mkv");
        StremioAddonClient.SubtitleBatch sub = client.fetchSubtitles(base, manifest, "movie", "tt1375666", extras, 3000);
        T.eq("/%7B%22tok%22%3A%22SECRET%2B1%22%7D/subtitles/movie/tt1375666/videoHash=8e245d9679d31e12&videoSize=4294967296&filename=Movie%20%282010%29.mkv.json", hits.get(2), "subtitle request carries the file identity");
        T.eq(1, sub.arabic.size(), "Arabic subtitle kept");
        T.eq(1, sub.nonArabic, "English one counted, not offered");

        int before = hits.size();
        T.throwsKind(StremioException.Kind.UNSUPPORTED, "an id the manifest does not accept is refused before any request",
                () -> client.fetchStreams(base, manifest, "movie", "tmdb:27205", 3000));
        T.throwsKind(StremioException.Kind.UNSUPPORTED, "so is a type it does not declare",
                () -> client.fetchStreams(base, manifest, "anime", "tt1", 3000));
        StremioManifest needsConfig = StremioManifest.parse(new JSONObject("{\"id\":\"c.c\",\"version\":\"1\",\"name\":\"C\",\"description\":\"D\",\"catalogs\":[],\"resources\":[\"stream\"],\"types\":[\"movie\"],\"behaviorHints\":{\"configurationRequired\":true}}"));
        T.throwsKind(StremioException.Kind.CONFIG_REQUIRED, "an add-on that needs configuration is not queried",
                () -> client.fetchStreams(base, needsConfig, "movie", "tt1", 3000));
        T.eq(before, hits.size(), "none of the refused requests reached the network");
        server.stop(0);

        T.section("production client refuses a non-https manifest");
        T.throwsKind(StremioException.Kind.UNSAFE_URL, "http manifest", () -> new StremioAddonClient().fetchManifest("http://addon.example/manifest.json"));
        T.throwsKind(StremioException.Kind.UNSAFE_URL, "loopback manifest", () -> new StremioAddonClient().fetchManifest("https://127.0.0.1/manifest.json"));
        // Public IP literals need no DNS, so these are deterministic offline.
        T.ok(StremioAddonClient.isSafePublicMediaUrl("http://8.8.8.8/a.mp4") && !StremioAddonClient.isSafePublicMediaUrl("http://127.0.0.1/a.mp4"), "static media check kept for the player");
        T.ok(StremioAddonClient.isSafePublicHttpsUrl("https://1.1.1.1/x") && !StremioAddonClient.isSafePublicHttpsUrl("http://1.1.1.1/x"), "static https check kept for the player");
    }
}

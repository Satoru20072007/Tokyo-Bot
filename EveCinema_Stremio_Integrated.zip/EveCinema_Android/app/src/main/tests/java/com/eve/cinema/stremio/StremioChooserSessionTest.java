package com.eve.cinema.stremio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class StremioChooserSessionTest {

    private static StremioChooserData snap(long version, StremioChooserData.State state, StremioStreamOption... options) {
        return new StremioChooserData(version, state, StremioChooserData.EmptyReason.NONE, java.util.Arrays.asList(options),
                Collections.<StremioSubtitle>emptyList(), StremioChooserData.Progress.NONE);
    }

    private static StremioStreamOption opt(String id, int height) {
        return new StremioStreamOption(id, "https://cdn.example/" + id + ".mkv", null, "m", "PROGRESSIVE", height, -1d, null);
    }

    public static void main(String[] args) {
        T.section("entry lifecycle");
        StremioChooserSession.clear();
        StremioChooserSession.Entry e = StremioChooserSession.begin("movie|tmdb:1", "T", "movie", "1", 0, 0);
        T.eq(StremioChooserData.State.LOADING, e.data().state, "a new session starts LOADING");
        final List<Long> seen = new ArrayList<>();
        e.addListener(d -> seen.add(d.version));
        int epoch = e.epoch();
        e.update(snap(1, StremioChooserData.State.LOADING), epoch);
        e.update(snap(2, StremioChooserData.State.PARTIAL, opt("s1", 1080)), epoch);
        e.update(snap(2, StremioChooserData.State.PARTIAL), epoch);
        e.update(snap(1, StremioChooserData.State.LOADING), epoch);
        T.eq(java.util.Arrays.asList(1L, 2L), seen, "listeners see each version once; stale/duplicate versions are dropped");
        T.eq(1, e.data().options.size(), "latest snapshot kept");

        T.section("a restarted search supersedes the old one");
        StremioSearchEngine.Handle old = new StremioSearchEngine.Handle();
        e.attach(old, epoch);
        int second = e.restart();
        T.ok(second > epoch, "epoch advanced");
        T.ok(old.isCancelled(), "the previous search was cancelled");
        T.eq(StremioChooserData.State.LOADING, e.data().state, "data reset to LOADING for the retry");
        e.update(snap(50, StremioChooserData.State.COMPLETE, opt("late", 720)), epoch);
        T.eq(0, e.data().options.size(), "a callback from the superseded search is ignored");
        e.update(snap(1, StremioChooserData.State.PARTIAL, opt("fresh", 720)), second);
        T.eq("fresh", e.data().options.get(0).id, "versions restart per search");
        StremioSearchEngine.Handle stale = new StremioSearchEngine.Handle();
        e.attach(stale, epoch);
        T.ok(stale.isCancelled(), "attaching a handle of a superseded search cancels it at once");

        T.section("failed options, reopen hand-off, TTL");
        StremioChooserSession.markFailed("movie|tmdb:1", "fresh");
        StremioChooserSession.markFailed("movie|tmdb:1", "does-not-exist");
        T.eq(Collections.singleton("fresh"), StremioChooserSession.failedIds("movie|tmdb:1"), "only real options can be marked");
        e.update(snap(2, StremioChooserData.State.COMPLETE, opt("fresh", 720), opt("other", 1080)), second);
        T.eq(Collections.singleton("fresh"), StremioChooserSession.failedIds("movie|tmdb:1"), "failure marks survive later snapshots");
        T.eq(null, StremioChooserSession.get("movie|tmdb:12"), "keys match exactly (tmdb:1 is not tmdb:12)");
        StremioChooserSession.requestReopen("movie|tmdb:1");
        T.eq(null, StremioChooserSession.takeReopenKey("movie|tmdb:12"), "another title's prefix does not consume it");
        T.eq("movie|tmdb:1", StremioChooserSession.takeReopenKey("movie|tmdb:1"), "reopen request consumed once");
        T.eq(null, StremioChooserSession.takeReopenKey("movie|tmdb:1"), "and only once");
        StremioChooserSession.clockSkewMs = StremioChooserSession.TTL_MS + 1000;
        T.eq(null, StremioChooserSession.get("movie|tmdb:1"), "an expired session is gone (signed links go stale)");
        StremioChooserSession.requestReopen("movie|tmdb:1");
        T.eq(null, StremioChooserSession.takeReopenKey("movie|tmdb:1"), "and cannot be reopened");
        StremioChooserSession.clockSkewMs = 0;

        T.section("begin() cancels the previous session's search");
        StremioChooserSession.Entry a = StremioChooserSession.begin("movie|tmdb:2", "A", "movie", "2", 0, 0);
        StremioSearchEngine.Handle ha = new StremioSearchEngine.Handle();
        a.attach(ha, a.epoch());
        StremioChooserSession.begin("movie|tmdb:3", "B", "movie", "3", 0, 0);
        T.ok(ha.isCancelled(), "opening another title stops the first title's search");
        T.eq("movie|tmdb:123", StremioChooserSession.movieKey("123"), "key format unchanged");
        T.eq("series|tmdb:5:2:7", StremioChooserSession.episodeKey("5", 2, 7), "episode key format unchanged");

        T.section("episode keys are reopened by the show's prefix");
        StremioChooserSession.Entry ep = StremioChooserSession.begin("series|tmdb:5:2:7", "S", "series", "5", 2, 7);
        StremioChooserSession.requestReopen("series|tmdb:5:2:7");
        T.eq(null, StremioChooserSession.takeReopenKey("series|tmdb:50"), "show 50 is not show 5");
        T.eq("series|tmdb:5:2:7", StremioChooserSession.takeReopenKey("series|tmdb:5"), "show prefix matches its episode key");

        T.section("stopping a search settles an unfinished snapshot (no stuck spinner after reopen)");
        int cur = ep.epoch();
        StremioSearchEngine.Handle h = new StremioSearchEngine.Handle();
        ep.attach(h, cur);
        ep.update(snap(3, StremioChooserData.State.PARTIAL, opt("p1", 1080)), cur);
        final List<StremioChooserData.State> states = new ArrayList<>();
        ep.addListener(d -> states.add(d.state));
        ep.cancelSearch();
        T.ok(h.isCancelled(), "engine handle cancelled");
        T.eq(StremioChooserData.State.COMPLETE, ep.data().state, "PARTIAL with options settles to COMPLETE");
        T.ok(!ep.data().progress.searching && !ep.data().progress.measuring, "no more 'searching'/'measuring'");
        T.eq(1, ep.data().options.size(), "options kept for the player's panels");
        T.eq(Collections.singletonList(StremioChooserData.State.COMPLETE), states, "listeners told");
        ep.cancelSearch();
        T.eq(1, states.size(), "a second cancel is a no-op");
        StremioChooserSession.Entry empty = StremioChooserSession.begin("movie|tmdb:9", "E", "movie", "9", 0, 0);
        empty.attach(new StremioSearchEngine.Handle(), empty.epoch());
        empty.cancelSearch();
        T.eq(StremioChooserData.State.EMPTY, empty.data().state, "LOADING with nothing settles to EMPTY");
        StremioChooserSession.clear();
        System.exit(T.finish("StremioChooserSessionTest"));
    }
}

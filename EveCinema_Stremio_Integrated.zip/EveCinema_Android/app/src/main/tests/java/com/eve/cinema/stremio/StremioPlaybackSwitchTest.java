package com.eve.cinema.stremio;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

public final class StremioPlaybackSwitchTest {
    private static StremioStreamOption opt(String id, String... keys) {
        return new StremioStreamOption(id, "https://cdn.example/" + id + ".mkv", null, "m", "PROGRESSIVE", 1080, "name", false,
                -1d, null, 1, "", -1L, "", new LinkedHashSet<>(Arrays.asList(keys)));
    }

    private static StremioSubtitle sub(String id, boolean generic, Set<String> options, Set<String> keys) {
        return new StremioSubtitle(id, "https://subs.example/" + id + ".srt", "ara", options, keys, generic);
    }

    private static StremioChooserData data(StremioSubtitle... subs) {
        return new StremioChooserData(1L, StremioChooserData.State.COMPLETE, StremioChooserData.EmptyReason.NONE,
                Arrays.asList(opt("a", "h:aaa"), opt("b", "h:bbb"), opt("a2", "h:aaa"), opt("c")), Arrays.asList(subs),
                StremioChooserData.Progress.NONE);
    }

    public static void main(String[] args) {
        Set<String> none = Collections.emptySet();
        StremioSubtitle forA = sub("t1", false, none, Collections.singleton("h:aaa"));
        StremioSubtitle forB = sub("t2", false, none, Collections.singleton("h:bbb"));
        StremioSubtitle generic = sub("t3", true, none, none);
        StremioChooserData d = data(forA, forB, generic);
        StremioStreamOption a = d.find("a"), b = d.find("b"), a2 = d.find("a2"), c = d.find("c");

        T.section("position and play intent are carried over");
        StremioPlaybackSwitch.Plan p = StremioPlaybackSwitch.plan(d, a, b, null, 754_321L, true);
        T.eq(754_321L, p.positionMs, "position");
        T.ok(p.playWhenReady, "was playing -> keeps playing");
        T.ok(!StremioPlaybackSwitch.plan(d, a, b, null, 10L, false).playWhenReady, "was paused -> stays paused");
        T.eq(0L, StremioPlaybackSwitch.plan(d, a, b, null, -5L, true).positionMs, "negative position clamps to 0");
        T.eq(StremioPlaybackSwitch.SubtitleDecision.NONE, p.subtitle, "no subtitle active -> nothing to decide");

        T.section("a subtitle follows only when it is proven for the new file");
        T.eq(StremioPlaybackSwitch.SubtitleDecision.KEEP, StremioPlaybackSwitch.decideSubtitle(d, a, a2, forA), "same file from another add-on (shared hash)");
        T.eq(StremioPlaybackSwitch.SubtitleDecision.DROP, StremioPlaybackSwitch.decideSubtitle(d, a, b, forA), "different file: A's subtitle is dropped");
        T.eq(StremioPlaybackSwitch.SubtitleDecision.KEEP, StremioPlaybackSwitch.decideSubtitle(d, a, b, forB), "but a subtitle exact for the NEW file may be kept");
        T.eq(StremioPlaybackSwitch.SubtitleDecision.DROP, StremioPlaybackSwitch.decideSubtitle(d, a, b, generic), "an 'unverified' subtitle accepted for one release is not assumed for another");
        T.eq(StremioPlaybackSwitch.SubtitleDecision.DROP, StremioPlaybackSwitch.decideSubtitle(d, a, c, forA), "target without any identity: cannot be proven");
        T.eq(StremioPlaybackSwitch.SubtitleDecision.DROP, StremioPlaybackSwitch.decideSubtitle(d, c, c, generic), "even the same identity-less stream is not 'provably the same file'");
        T.eq(StremioPlaybackSwitch.SubtitleDecision.DROP, StremioPlaybackSwitch.decideSubtitle(d, a, null, forA), "no target");
        System.exit(T.finish("StremioPlaybackSwitchTest"));
    }
}

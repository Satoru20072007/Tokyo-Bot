#!/usr/bin/env python3
"""Static / structural checks for the Stremio work.

These are NOT behaviour tests (the behaviour is covered by the JVM suites under tests/java).
They guard things a compiler on a phone would only tell you late: every referenced resource
exists, both locales carry the same keys, XML is well-formed, nothing in scope was touched that
must stay untouched, and a few "must never come back" patterns are absent.
"""
import hashlib, os, re, sys, unittest
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..', '..', '..'))     # .../EveCinema_Android
MAIN = os.path.join(ROOT, 'app', 'src', 'main')
JAVA = os.path.join(MAIN, 'java', 'com', 'eve', 'cinema')
STREMIO = os.path.join(JAVA, 'stremio')
RES = os.path.join(MAIN, 'res')


def read(path):
    with open(path, encoding='utf-8') as f:
        return f.read()


def strip_comments(java):
    java = re.sub(r'/\*.*?\*/', '', java, flags=re.S)
    return re.sub(r'//[^\n]*', '', java)


def method_body(java, signature_fragment):
    """Text of the first method whose declaration contains signature_fragment (brace matched)."""
    i = java.index(signature_fragment)
    start = java.index('{', i)
    depth = 0
    for j in range(start, len(java)):
        if java[j] == '{': depth += 1
        elif java[j] == '}':
            depth -= 1
            if depth == 0: return java[start:j + 1]
    raise AssertionError('unbalanced braces after ' + signature_fragment)


def string_keys(path):
    return {e.get('name') for e in ET.parse(path).getroot() if e.tag == 'string'}


class ResourceTests(unittest.TestCase):
    def test_every_xml_resource_is_well_formed(self):
        bad = []
        for dirpath, _, files in os.walk(RES):
            for f in files:
                if f.endswith('.xml'):
                    try: ET.parse(os.path.join(dirpath, f))
                    except ET.ParseError as e: bad.append((os.path.join(dirpath, f), str(e)))
        self.assertEqual([], bad)

    def test_new_strings_exist_in_both_locales_with_same_placeholders(self):
        default = ET.parse(os.path.join(RES, 'values', 'strings.xml')).getroot()
        arabic = ET.parse(os.path.join(RES, 'values-ar', 'strings.xml')).getroot()
        d = {e.get('name'): (e.text or '') for e in default if e.tag == 'string'}
        a = {e.get('name'): (e.text or '') for e in arabic if e.tag == 'string'}
        keys = [k for k in d if k.startswith(('watch_', 'stremio_'))]
        self.assertTrue(len(keys) > 40)
        missing = [k for k in keys if k not in a]
        self.assertEqual([], missing, 'keys missing from values-ar')
        ph = lambda s: sorted(re.findall(r'%\d\$[sd]', s))
        mismatched = [k for k in keys if ph(d[k]) != ph(a[k])]
        self.assertEqual([], mismatched, 'format placeholders differ between locales')

    def test_every_resource_referenced_by_touched_files_exists(self):
        names = {}
        for dirpath, _, files in os.walk(RES):
            parts = os.path.basename(dirpath).split('-')[0]
            for f in files:
                n = os.path.splitext(f)[0]
                if parts in ('drawable', 'anim', 'layout', 'xml', 'color'): names.setdefault(parts, set()).add(n)
                if f.endswith('.xml') and parts == 'values':
                    for e in ET.parse(os.path.join(dirpath, f)).getroot():
                        if e.get('name'): names.setdefault(e.tag, set()).add(e.get('name').replace('.', '_'))
        touched = [os.path.join(JAVA, n) for n in ('WatchChooserSheet.java', 'PlayerActivity.java', 'SettingsActivity.java', 'DetailActivity.java', 'EpisodesActivity.java')]
        generated = {'default_web_client_id'}     # produced by the google-services Gradle plugin, not by res/
        missing = []
        for path in touched:
            for kind, name in re.findall(r'\bR\.(string|color|drawable|style|anim|dimen|layout)\.([A-Za-z0-9_]+)', read(path)):
                if name not in generated and name.replace('.', '_') not in names.get(kind, set()):
                    missing.append((os.path.basename(path), kind, name))
        self.assertEqual([], missing)


class ScopeGuardTests(unittest.TestCase):
    def test_protected_files_are_byte_identical_to_the_baseline(self):
        manifest = os.path.join(HERE, 'stremio_data', 'stremio_protected_files.sha256')
        different, checked = [], 0
        for line in read(manifest).splitlines():
            digest, rel = line.split(None, 1)
            rel = rel.strip()
            path = os.path.join(ROOT, rel)
            checked += 1
            if not os.path.exists(path): different.append((rel, 'missing')); continue
            with open(path, 'rb') as f:
                if hashlib.sha256(f.read()).hexdigest() != digest: different.append((rel, 'changed'))
        self.assertGreater(checked, 15)
        self.assertEqual([], different, '%d protected files checked' % checked)


class NeverComeBackTests(unittest.TestCase):
    """Static pattern guards (labelled static on purpose)."""

    def stremio_sources(self):
        return {f: strip_comments(read(os.path.join(STREMIO, f))) for f in os.listdir(STREMIO) if f.endswith('.java')}

    def test_stremio_package_never_logs(self):
        offenders = [f for f, src in self.stremio_sources().items()
                     if re.search(r'\bLog\.|System\.(out|err)|printStackTrace|DiagnosticsRecorder', src)]
        self.assertEqual([], offenders)

    def test_stremio_package_is_independent_of_cinemabox(self):
        offenders = [f for f, src in self.stremio_sources().items() if re.search(r'cinemabox', src, re.I)]
        self.assertEqual([], offenders)

    def test_session_is_memory_only_and_store_keeps_no_stream_links(self):
        session = strip_comments(read(os.path.join(STREMIO, 'StremioChooserSession.java')))
        self.assertNotIn('SharedPreferences', session)
        self.assertNotIn('android.content', session)
        store = strip_comments(read(os.path.join(STREMIO, 'StremioAddonStore.java')))
        self.assertNotRegex(store, r'(?i)streamUrl|\.headers|StremioStreamOption')

    def test_private_manifest_credentials_are_confined_to_bootstrap(self):
        # These URLs were explicitly supplied for this private build and can contain per-user
        # credentials. Keep them in one narrowly scoped bootstrap class; never copy them into logs,
        # UI strings, reports, tests, or other sources. Do not publish an APK containing these URLs.
        pattern = re.compile(r'pengu', re.I)
        hits = []
        for base in (JAVA, os.path.join(MAIN, 'tests'), RES):
            for dirpath, _, files in os.walk(base):
                for f in files:
                    if f.endswith(('.java', '.xml', '.py', '.md', '.sh')):
                        path = os.path.join(dirpath, f)
                        if pattern.search(read(path)) and not path.endswith('test_stremio_wiring.py'):
                            hits.append(path)
        bootstrap = os.path.join(STREMIO, 'StremioAddonBootstrap.java')
        self.assertEqual([bootstrap], sorted(hits), 'private endpoint must remain confined to bootstrap')
        source = strip_comments(read(bootstrap))
        self.assertNotRegex(source, r'(?i)Log\.|System\.(out|err)|printStackTrace')

    def test_chooser_sheet_never_preselects_and_uses_design_tokens(self):
        sheet = strip_comments(read(os.path.join(JAVA, 'WatchChooserSheet.java')))
        self.assertNotRegex(sheet, r'\.get\(0\)', 'no automatic first-item selection')
        self.assertNotRegex(sheet, r'0x[Ff]{2}[0-9A-Fa-f]{6}|Color\.parseColor', 'colours must come from resources')
        self.assertIn('MIN_TOUCH_DP = 48', sheet)
        self.assertIn('setOnApplyWindowInsetsListener', sheet)
        self.assertIn('LAYOUT_DIRECTION_RTL', sheet)
        self.assertIn('TextUtils.TruncateAt', sheet)
        self.assertNotRegex(sheet, r'(?i)hdr|codec|bitrate|dolby|atmos', 'no invented media facts')
        self.assertNotRegex(sheet, r'manifest\.name|\.manifest\b', 'add-on names are not shown as brands')

    def test_failed_link_never_switches_by_itself(self):
        player = strip_comments(read(os.path.join(JAVA, 'PlayerActivity.java')))
        body = method_body(player, 'private void failStremioLink(')
        self.assertNotRegex(body, r'startStremioPlayback\(|switchStremioSource\(|startExtraction\(')
        switch = method_body(player, 'private void switchStremioSource(')
        self.assertIn('stremioUrl = option.url;', switch, 'the exact link the user picked is the one played')
        self.assertIn('StremioPlaybackSwitch.plan(', switch)

    def test_player_hooks_are_gated_to_stremio_sessions(self):
        player = strip_comments(read(os.path.join(JAVA, 'PlayerActivity.java')))
        self.assertIn('if (isStremioPlayback()) {\n            showStremioQualityPanel();', player.replace('\r', ''))
        self.assertRegex(player, r'if \(isStremioPlayback\(\)\) \{ showStremioSubtitlePanel\(\);')
        self.assertRegex(player, r'if \(isStremioPlayback\(\)\) available = true;')

    def test_changed_screens_use_the_progressive_session_api(self):
        for name in ('DetailActivity.java', 'EpisodesActivity.java'):
            src = strip_comments(read(os.path.join(JAVA, name)))
            self.assertIn('StremioChooserSession.begin(', src)
            self.assertIn('StremioChooserLoader.start(', src)
            self.assertIn('WatchChooserSheet.forChoose(', src)
            self.assertNotIn('StremioChooserLoader.load(', src)


if __name__ == '__main__':
    unittest.main(verbosity=2)

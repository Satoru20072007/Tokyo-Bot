package com.eve.cinema.providers;

import android.content.Context;
import com.eve.cinema.moviebox.MovieBoxBridge;
import com.eve.cinema.playback.ProbeOutcome;
import com.eve.cinema.providercore.CanonicalMediaIdentity;
import com.eve.cinema.providercore.ProviderAdapter;
import com.eve.cinema.providercore.ProviderIds;
import com.eve.cinema.providercore.ProviderResultState;
import com.eve.cinema.providercore.NormalizedCandidate;
import java.util.Collections;
import java.util.List;

/**
 * MovieBoxProviderAdapter — Adapter رفيع يغلّف MovieBoxBridge الموجود.
 *
 * القرار الحالي: EXPERIMENTAL (ورقة القرار §2.5 في تقرير التنفيذ) — يعمل ضمن
 * المسار الحالي كما كان، ويبقى المصدر الوحيد للأنمي (P7). لا يحتوي هذا
 * الملف أي تجاوز لحماية المحتوى؛ رفض placeholder يبقى في MovieBoxParser
 * ويُربط بالمحقق عبر EveProviders.
 */
public final class MovieBoxProviderAdapter implements ProviderAdapter {

    private final Context appContext;

    public MovieBoxProviderAdapter(Context appContext) {
        this.appContext = appContext;
    }

    @Override public String id() { return ProviderIds.MOVIEBOX; }

    @Override public Capabilities capabilities() {
        return new Capabilities(true, true, true, true, true, false);
    }

    @Override public ProbeResult probe(CanonicalMediaIdentity identity) {
        long t0 = System.currentTimeMillis();
        if (!com.eve.cinema.PlaybackAuthorizationPolicy.isProviderEnabled(id()))
            return new ProbeResult(ProviderResultState.UNKNOWN, null, 0L);
        MovieBoxBridge.SubjectProbe probe = MovieBoxBridge.get(appContext)
                .matchSubjectOutcome(
                        identity.titleOriginal(),
                        firstAlias(identity),
                        identity.releaseYear(),
                        identity.mediaType() == CanonicalMediaIdentity.MediaType.SERIES);
        return new ProbeResult(toState(probe == null ? null : probe.outcome), null,
                System.currentTimeMillis() - t0);
    }

    @Override public List<NormalizedCandidate> candidates(CanonicalMediaIdentity identity) {
        // مرحلة الروابط: مسار التشغيل الحالي (resolveMovie/resolveEpisode) يبقى
        // هو المعتمد حتى تُربط الجودات بمستوى المرشحين بعد اختبار الجهاز.
        return Collections.emptyList();
    }

    @Override public NormalizedCandidate refresh(NormalizedCandidate stale) throws ProviderException {
        throw new ProviderException(ProviderResultState.FAILED,
                "link-level refresh not wired for moviebox yet");
    }

    private static String firstAlias(CanonicalMediaIdentity identity) {
        List<String> aliases = identity.titleAliases();
        return aliases == null || aliases.isEmpty() ? null : aliases.get(0);
    }

    static ProviderResultState toState(ProbeOutcome outcome) {
        if (outcome == null) return ProviderResultState.FAILED;
        switch (outcome) {
            case VERIFIED:             return ProviderResultState.VERIFIED_PLAYABLE;
            case NOT_FOUND_DEFINITIVE: return ProviderResultState.NO_MATCH;
            case REJECTED_BY_IDENTITY: return ProviderResultState.NO_MATCH;
            case UNRESOLVED_TRANSIENT:
            default:                   return ProviderResultState.FAILED;
        }
    }
}

/*
 * Derived from MovieBox-Tui (Rust) — upstream dual-licensed MIT / Apache-2.0.
 * Upstream copyright retained. See NOTICE at the project root for the full
 * license texts and attribution scope.
 */
package com.eve.cinema.moviebox;

/*
 * Ported from MovieBox-Tui (src/providers/moviebox/adapt.rs and the
 * release/source helpers in src/providers/models.rs).
 * MovieBox-Tui is dual-licensed MIT / Apache-2.0; see NOTICE.
 */

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.eve.cinema.moviebox.MovieBoxModels.Playback;
import com.eve.cinema.moviebox.MovieBoxModels.SeasonInfo;
import com.eve.cinema.moviebox.MovieBoxModels.StreamSource;
import com.eve.cinema.moviebox.MovieBoxModels.SubjectItem;
import com.eve.cinema.moviebox.MovieBoxModels.SubtitleOption;
import com.eve.cinema.moviebox.MovieBoxModels.DubOption;
import com.eve.cinema.playback.LanguageMatcher;

/**
 * Pure JSON → model mapping for the MovieBox BFF API. All methods are static
 * and side-effect free so they can be unit-tested on the JVM.
 */
public final class MovieBoxParser {

    /** Referer required by the MovieBox CDN edge (mod.rs STREAM_REFERER). */
    public static final String STREAM_REFERER = "https://sportslive.wine";

    private MovieBoxParser() {}

    // ── Generic helpers ──────────────────────────────────────

    /** First 4-digit run starting with 1 or 2 (models.rs extract_4digit_year). */
    public static String extract4DigitYear(String raw) {
        if (raw == null) return "";
        for (int i = 0; i + 4 <= raw.length(); i++) {
            char c0 = raw.charAt(i);
            if (c0 != '1' && c0 != '2') continue;
            boolean all = true;
            for (int j = 1; j < 4; j++) {
                if (!Character.isDigit(raw.charAt(i + j))) { all = false; break; }
            }
            if (all) return raw.substring(i, i + 4);
        }
        return "";
    }

    static String optId(JSONObject obj, String... keys) {
        for (String k : keys) {
            Object v = obj.opt(k);
            if (v instanceof Number) return String.valueOf(((Number) v).longValue());
            if (v instanceof String && !((String) v).isEmpty()) return (String) v;
        }
        return null;
    }

    static long optLongLoose(JSONObject obj, String key, long def) {
        Object v = obj.opt(key);
        if (v instanceof Number) return ((Number) v).longValue();
        if (v instanceof String) {
            try { return Long.parseLong(((String) v).trim()); }
            catch (NumberFormatException ignored) {}
        }
        return def;
    }

    static Integer optIntLooseOrNull(JSONObject obj, String key) {
        Object v = obj.opt(key);
        if (v instanceof Number) return ((Number) v).intValue();
        if (v instanceof String) {
            try { return Integer.valueOf(((String) v).trim()); }
            catch (NumberFormatException ignored) {}
        }
        return null;
    }

    // ── Search ───────────────────────────────────────────────

    public static SubjectItem subjectToItem(JSONObject s) {
        if (s == null) return null;
        String id = optId(s, "subjectId", "id");
        if (id == null || id.isEmpty()) return null;

        SubjectItem item = new SubjectItem();
        item.subjectId = id;
        item.title = s.optString("title", s.optString("name", "Unknown"));

        long stype = optLongLoose(s, "subjectType", Long.MIN_VALUE);
        if (stype == Long.MIN_VALUE) stype = optLongLoose(s, "stype", 1);
        item.isSeries = (stype == 2);

        String dateRaw = s.optString("releaseDate", null);
        if (dateRaw == null) dateRaw = s.optString("year", null);
        if (dateRaw == null) dateRaw = s.optString("releaseInfo", null);
        item.year = dateRaw != null ? extract4DigitYear(dateRaw) : "";

        String poster = null;
        JSONObject cover = s.optJSONObject("cover");
        if (cover != null) poster = cover.optString("url", null);
        if (poster == null || poster.isEmpty()) poster = s.optString("coverUrl", null);
        if (poster == null || poster.isEmpty()) poster = s.optString("poster", null);
        if (poster == null || poster.isEmpty()) poster = s.optString("pic", null);
        item.posterUrl = poster;

        Object season = s.opt("season");
        if (season instanceof Number) item.seasonCount = ((Number) season).intValue();
        return item;
    }

    /**
     * Search v2 response: data.results[0].subjects[] (wrapped) or
     * data.list[] / list[] fallbacks (adapt.rs moviebox_search_json_to_catalog).
     * The client already unwraps the outer "data" envelope; this method
     * tolerates both wrapped and unwrapped payloads.
     */
    public static List<SubjectItem> searchToItems(JSONObject payload) {
        List<SubjectItem> out = new ArrayList<>();
        JSONArray subjects = null;

        JSONObject data = payload.optJSONObject("data");
        JSONArray results = null;
        if (data != null) results = data.optJSONArray("results");
        if (results == null) results = payload.optJSONArray("results");
        if (results != null && results.length() > 0) {
            JSONObject first = results.optJSONObject(0);
            if (first != null) subjects = first.optJSONArray("subjects");
        }
        if (subjects == null) {
            if (data != null) subjects = data.optJSONArray("list");
            if (subjects == null) subjects = payload.optJSONArray("list");
        }
        if (subjects == null) return out;

        for (int i = 0; i < subjects.length(); i++) {
            SubjectItem item = subjectToItem(subjects.optJSONObject(i));
            if (item != null) out.add(item);
        }
        return out;
    }

    // ── Details / seasons ────────────────────────────────────

    /** Returns the inner subject object (data.subject | subject | payload). */
    public static JSONObject detailsSubject(JSONObject payload) {
        JSONObject data = payload.optJSONObject("data");
        if (data != null) {
            JSONObject subject = data.optJSONObject("subject");
            if (subject != null) return subject;
        }
        JSONObject subject = payload.optJSONObject("subject");
        return subject != null ? subject : payload;
    }

    public static boolean detailsIsSeries(JSONObject subject) {
        long stype = optLongLoose(subject, "subjectType", Long.MIN_VALUE);
        if (stype == Long.MIN_VALUE) stype = optLongLoose(subject, "stype", 1);
        return stype == 2;
    }

    /**
     * Seasons attached to the details payload by the client's season-info merge.
     * Accepts subject.seasons as either {"seasons":[...]} or a bare [...].
     * Each entry: {"se":N,"episodeNumbers":[..]} or {"se":N,"maxEp":M}.
     */
    public static List<SeasonInfo> parseSeasons(JSONObject subject) {
        List<SeasonInfo> out = new ArrayList<>();
        Object node = subject.opt("seasons");
        JSONArray arr = null;
        if (node instanceof JSONObject) arr = ((JSONObject) node).optJSONArray("seasons");
        if (arr == null && node instanceof JSONArray) arr = (JSONArray) node;
        if (arr == null) return out;

        for (int i = 0; i < arr.length(); i++) {
            JSONObject s = arr.optJSONObject(i);
            if (s == null) continue;
            SeasonInfo info = new SeasonInfo();
            info.seasonNumber = (int) optLongLoose(s, "se", 1);
            JSONArray eps = s.optJSONArray("episodeNumbers");
            if (eps != null) {
                for (int j = 0; j < eps.length(); j++) {
                    int ep = eps.optInt(j, -1);
                    if (ep > 0) info.episodes.add(ep);
                }
            } else {
                long maxEp = optLongLoose(s, "maxEp", 0);
                for (int ep = 1; ep <= maxEp; ep++) info.episodes.add(ep);
            }
            out.add(info);
        }
        return out;
    }

    // ── Deprecation / notice URLs ────────────────────────────

    /** adapt.rs is_deprecation_notice_url — these are "app update" notice videos. */
    public static boolean isDeprecationNoticeUrl(String url) {
        if (url == null) return false;
        String lower = url.toLowerCase(java.util.Locale.US);
        return lower.contains("1c7de0bd3393702d9191801f15f88f8d")
                || lower.contains("9a0461bc39da389663bf3dbb17091d3f")
                || lower.contains("b164fbfb4347792950bdfbfb563d39d9")
                || lower.contains("/notice.mp4")
                || (lower.contains("macdn.aoneroom.com") && lower.contains("/other/"));
    }

    // ── DASH manifest derivation (CloudFront / Edge-Cache) ───

    static String toDashMpd(String urlStr) {
        if (urlStr == null) return null;
        String candidate = urlStr.trim();
        if (isDeprecationNoticeUrl(candidate)) return null;
        if (!(candidate.startsWith("http://") || candidate.startsWith("https://")))
            return null;
        try {
            java.net.URI parsed = new java.net.URI(candidate);
            if (parsed.getHost() == null || parsed.getHost().isEmpty()) return null;
        } catch (java.net.URISyntaxException malformed) {
            return null;
        }

        // Only build DASH manifests from a DASH directory. Treating any URL as a
        // directory creates plausible-looking but invalid index.mpd URLs (notably
        // on the provider's dummy /other/ path).
        int fragmentAt = candidate.indexOf('#');
        String fragment = fragmentAt >= 0 ? candidate.substring(fragmentAt) : "";
        String withoutFragment = fragmentAt >= 0 ? candidate.substring(0, fragmentAt) : candidate;
        int queryAt = withoutFragment.indexOf('?');
        String query = queryAt >= 0 ? withoutFragment.substring(queryAt) : "";
        String path = queryAt >= 0 ? withoutFragment.substring(0, queryAt) : withoutFragment;
        String lowerPath = path.toLowerCase(java.util.Locale.ROOT);
        if (lowerPath.endsWith(".mpd")) return path + query + fragment;

        while (path.endsWith("*") || path.endsWith("/"))
            path = path.substring(0, path.length() - 1);
        lowerPath = path.toLowerCase(java.util.Locale.ROOT);
        if (path.isEmpty() || !lowerPath.contains("/dash/")) return null;
        return path + "/index.mpd" + query + fragment;
    }

    /**
     * Derives an index.mpd manifest URL from a signCookie string.
     * Supports:
     *  - Edge-Cache-Cookie=urlprefix=<base64url(url)>:sign=..:t=..
     *  - CloudFront-Policy=<base64(JSON{"Statement":[{"Resource":...}]})>
     * Returns null when nothing usable is present.
     */
    public static String resolveDashManifestFromPolicy(String signCookie) {
        if (signCookie == null || signCookie.trim().isEmpty()) return null;
        for (String part : signCookie.split(";")) {
            String trimmed = part.trim();
            String lower = trimmed.toLowerCase(java.util.Locale.ROOT);

            int idx = lower.indexOf("urlprefix=");
            if (idx >= 0) {
                String prefixPart = trimmed.substring(idx + "urlprefix=".length());
                int tokenEnd = prefixPart.length();
                for (int i = 0; i < prefixPart.length(); i++) {
                    char c = prefixPart.charAt(i);
                    if (c == ':' || c == ';' || Character.isWhitespace(c)) {
                        tokenEnd = i;
                        break;
                    }
                }
                String b64Token = stripQuotes(prefixPart.substring(0, tokenEnd).trim());
                String decodedUrl = decodeUtf8Base64(b64Token);
                String mpd = toDashMpd(decodedUrl);
                if (mpd != null) return mpd;
                // Some proxies percent-escape cookie separators/values. Decode only
                // %XX bytes; do not use URLDecoder because '+' is valid Base64 data.
                String percentDecoded = percentDecode(b64Token);
                if (!b64Token.equals(percentDecoded)) {
                    mpd = toDashMpd(decodeUtf8Base64(percentDecoded));
                    if (mpd != null) return mpd;
                }
            }

            int policyAt = lower.indexOf("cloudfront-policy=");
            if (policyAt >= 0) {
                String policyPart = trimmed.substring(policyAt + "CloudFront-Policy=".length()).trim();
                int tokenEnd = policyPart.length();
                for (int i = 0; i < policyPart.length(); i++) {
                    char c = policyPart.charAt(i);
                    if (c == ';' || Character.isWhitespace(c)) {
                        tokenEnd = i;
                        break;
                    }
                }
                String policyClean = stripQuotes(policyPart.substring(0, tokenEnd).trim());
                // CloudFront field encoding: '-'→'+', '_'→'=', '~'→'/'.
                StringBuilder norm = new StringBuilder(policyClean.length());
                for (int i = 0; i < policyClean.length(); i++) {
                    char c = policyClean.charAt(i);
                    if (c == '-') norm.append('+');
                    else if (c == '_') norm.append('=');
                    else if (c == '~') norm.append('/');
                    else norm.append(c);
                }
                byte[] decoded = MovieBoxBase64.decode(norm.toString());
                if (decoded == null) continue;
                try {
                    JSONObject json = new JSONObject(new String(decoded,
                            java.nio.charset.StandardCharsets.UTF_8));
                    JSONArray statements = json.optJSONArray("Statement");
                    if (statements == null) continue;
                    for (int i = 0; i < statements.length(); i++) {
                        JSONObject statement = statements.optJSONObject(i);
                        if (statement == null) continue;
                        String resource = statement.optString("Resource", null);
                        String mpd = toDashMpd(resource);
                        if (mpd != null) return mpd;
                    }
                } catch (Exception ignored) {}
            }
        }
        return null;
    }

    private static String decodeUtf8Base64(String token) {
        if (token == null || token.isEmpty()) return null;
        byte[] decoded = MovieBoxBase64.decode(token);
        if (decoded == null) return null;
        try {
            java.nio.charset.CharsetDecoder decoder = java.nio.charset.StandardCharsets.UTF_8
                    .newDecoder()
                    .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                    .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT);
            return decoder.decode(java.nio.ByteBuffer.wrap(decoded)).toString();
        } catch (java.nio.charset.CharacterCodingException invalidUtf8) {
            return null;
        }
    }

    private static String stripQuotes(String value) {
        if (value == null || value.length() < 2) return value;
        if ((value.charAt(0) == '"' && value.charAt(value.length() - 1) == '"')
                || (value.charAt(0) == '\'' && value.charAt(value.length() - 1) == '\''))
            return value.substring(1, value.length() - 1);
        return value;
    }

    private static String percentDecode(String value) {
        if (value == null || value.indexOf('%') < 0) return value;
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream(value.length());
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c == '%' && i + 2 < value.length()) {
                int hi = Character.digit(value.charAt(i + 1), 16);
                int lo = Character.digit(value.charAt(i + 2), 16);
                if (hi >= 0 && lo >= 0) {
                    out.write((hi << 4) | lo);
                    i += 2;
                    continue;
                }
            }
            byte[] bytes = String.valueOf(c).getBytes(java.nio.charset.StandardCharsets.UTF_8);
            out.write(bytes, 0, bytes.length);
        }
        return new String(out.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
    }

    // ── play-info/v2 → streams ───────────────────────────────

    /**
     * adapt.rs moviebox_play_info_json_to_releases, adapted to Eve's model:
     * one StreamSource per API stream (not per advertised resolution — the
     * same URL is never duplicated as fake qualities).
     */
    public static List<StreamSource> playInfoToStreams(JSONObject payload, int season,
                                                       int episode, String userAgent) {
        List<StreamSource> out = new ArrayList<>();
        JSONObject data = payload.optJSONObject("data");
        if (data == null) data = payload;

        JSONArray streams = data.optJSONArray("streams");
        if (streams == null) {
            com.eve.cinema.playback.ResolutionTrace.record("mb.playinfo", "NO_STREAM_ARRAY",
                    "data has no streams array");
            return out;
        }
        int policyCandidates = 0;
        int policyResolvedCount = 0;
        int noticeUrls = 0;
        int directUrls = 0;

        for (int i = 0; i < streams.length(); i++) {
            JSONObject stream = streams.optJSONObject(i);
            if (stream == null) continue;

            String streamId = optId(stream, "id");
            String format = stream.optString("format", "MP4");
            String codec = stream.optString("codecName", null);
            if (codec == null || codec.isEmpty()) codec = stream.optString("codec", null);
            long sizeBytes = optLongLoose(stream, "size", 0);

            String resolutionsStr = stream.optString("resolutions", null);
            if (resolutionsStr == null) resolutionsStr = data.optString("displayResolutions", null);
            if (resolutionsStr == null) resolutionsStr = ""; // unknown stays unknown

            String signCookie = stream.optString("signCookie", "");
            String streamUrl = stream.optString("url", "");

            boolean policyPresent = signCookie.contains("urlprefix=")
                    || signCookie.contains("CloudFront-Policy=");
            if (policyPresent) policyCandidates++;
            String playableUrl = resolveDashManifestFromPolicy(signCookie);
            boolean policyResolved = playableUrl != null;
            if (policyResolved) policyResolvedCount++;
            boolean noticeUrl = isDeprecationNoticeUrl(streamUrl);
            if (noticeUrl) noticeUrls++;
            if (playableUrl == null) {
                if (!noticeUrl && isValidHttpUrl(streamUrl)) {
                    playableUrl = streamUrl;
                    directUrls++;
                }
            }
            if (playableUrl == null) continue; // notice/placeholder — not playable

            StreamSource src = new StreamSource();
            src.streamId = streamId;
            src.url = playableUrl;
            src.codec = codec;
            src.format = format;
            src.sizeBytes = sizeBytes;
            // If the API URL is the known short update-video placeholder, its
            // duration belongs to that placeholder, not the resolved DASH media.
            // Leave runtime unknown until corroborated by active resource metadata.
            src.durationSeconds = noticeUrl && policyResolved
                    ? 0 : optLongLoose(stream, "duration", 0);
            Integer responseSeason = optIntLooseOrNull(stream, "se");
            Integer responseEpisode = optIntLooseOrNull(stream, "ep");
            src.season = responseSeason != null ? responseSeason : season;
            src.episode = responseEpisode != null ? responseEpisode : episode;
            src.numberingFromResponse = responseSeason != null && responseEpisode != null
                    && responseSeason == season && responseEpisode == episode;

            src.headers.put("Referer", STREAM_REFERER);
            src.headers.put("User-Agent", userAgent);
            if (!signCookie.isEmpty()) {
                // trim trailing ';', split ';', trim parts, rejoin with "; "
                String[] parts = signCookie.split(";");
                StringBuilder clean = new StringBuilder();
                for (String p : parts) {
                    String t = p.trim();
                    if (t.isEmpty()) continue;
                    if (clean.length() > 0) clean.append("; ");
                    clean.append(t);
                }
                if (clean.length() > 0) src.headers.put("Cookie", clean.toString());
            }

            Set<Integer> parsed = new LinkedHashSet<>();
            for (String r : resolutionsStr.split(",")) {
                try {
                    int v = Integer.parseInt(r.trim());
                    if (v > 0) parsed.add(v);
                } catch (NumberFormatException ignored) {}
            }
            List<Integer> resList = new ArrayList<>(parsed);
            resList.sort(Comparator.reverseOrder());
            src.resolutions = resList;

            out.add(src);
        }
        com.eve.cinema.playback.ResolutionTrace.record("mb.playinfo",
                out.isEmpty() ? "NO_PLAYABLE_STREAMS" : "PLAYABLE_STREAMS",
                "streams=" + streams.length() + " policy=" + policyCandidates
                        + " policyResolved=" + policyResolvedCount + " notices=" + noticeUrls
                        + " direct=" + directUrls + " output=" + out.size());
        return out;
    }

    private static boolean isValidHttpUrl(String value) {
        if (value == null) return false;
        try {
            java.net.URI uri = new java.net.URI(value.trim());
            String scheme = uri.getScheme();
            return uri.getHost() != null && !uri.getHost().isEmpty()
                    && ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme));
        } catch (java.net.URISyntaxException malformed) {
            return false;
        }
    }

    /**
     * Returns a runtime only when every exact-identity row in the active subject
     * agrees on the same positive duration. This is used only when play-info's
     * duration came from a known dummy notice URL; it never widens runtime tolerance.
     * A disagreement or lack of identity evidence returns 0 (unknown).
     */
    public static long unanimousActiveResourceDuration(List<JSONObject> rows, String expectedTitle,
            boolean series, int wantedSeason, int wantedEpisode) {
        if (rows == null || rows.isEmpty() || expectedTitle == null
                || expectedTitle.trim().isEmpty()) return 0;
        long consensus = 0;
        int matched = 0;
        for (JSONObject row : rows) {
            if (row == null) continue;
            String title = row.optString("title", "");
            if (MovieBoxSubtitleReleaseResolver.isTrailerLabel(title)) continue;
            if (series) {
                Integer rowSeason = optIntLooseOrNull(row, "se");
                Integer rowEpisode = optIntLooseOrNull(row, "ep");
                if (rowSeason == null || rowEpisode == null
                        || rowSeason != wantedSeason || rowEpisode != wantedEpisode) continue;
            } else if (!MovieBoxSubtitleReleaseResolver.sameIdentity(
                    expectedTitle, false, title, false)) {
                continue;
            }
            long duration = optLongLoose(row, "duration", 0);
            if (duration <= 0 || duration > 12L * 60L * 60L) return 0;
            if (consensus != 0 && consensus != duration) return 0;
            consensus = duration;
            matched++;
        }
        return matched > 0 ? consensus : 0;
    }

    // ── resource endpoint → direct-file candidates ───────────

    /**
     * adapt.rs moviebox_resource_json_to_releases, reduced to what Eve can
     * actually play: items whose link is a direct media URL (no resolver
     * pages) and not a deprecation notice.
     */
    public static List<StreamSource> resourceToStreams(JSONObject payload,
                                                       int wantSeason, int wantEpisode,
                                                       String userAgent) {
        List<StreamSource> out = new ArrayList<>();
        JSONArray items = payload.optJSONArray("list");
        if (items == null && payload.optJSONArray("data") != null)
            items = payload.optJSONArray("data");
        if (items == null) return out;

        Set<String> seen = new HashSet<>();
        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            if (item == null) continue;

            String link = item.optString("resourceLink", null);
            if (link == null || link.isEmpty()) link = item.optString("url", null);
            if (!isDirectPlayableResourceItem(item)) continue;

            Integer se = optIntLooseOrNull(item, "se");
            Integer ep = optIntLooseOrNull(item, "ep");
            boolean movieQuery = (wantSeason == 0 && wantEpisode == 0);
            boolean matches = movieQuery
                    || (se != null && ep != null && se == wantSeason && ep == wantEpisode)
                    || (se == null && ep == null);
            if (!matches) continue;

            // Full URL: signed query strings distinguish genuinely different files.
            if (!seen.add(link)) continue;

            StreamSource src = new StreamSource();
            src.streamId = optId(item, "resourceId", "id");
            src.url = link;
            src.codec = item.optString("codecName", null);
            if (src.codec == null || src.codec.isEmpty()) src.codec = item.optString("codec", null);
            src.format = "MP4";
            src.sizeBytes = optLongLoose(item, "size", 0);
            src.durationSeconds = optLongLoose(item, "duration", 0);
            src.season = se != null ? se : wantSeason;
            src.episode = ep != null ? ep : wantEpisode;
            src.numberingFromResponse = se != null && ep != null
                    && se == wantSeason && ep == wantEpisode;
            long res = optLongLoose(item, "resolution", 0);
            if (res <= 0) res = optLongLoose(item, "resolutions", 0);
            if (res > 0) src.resolutions.add((int) res);
            src.headers.put("Referer", STREAM_REFERER);
            src.headers.put("User-Agent", userAgent);
            out.add(src);
        }
        return out;
    }

    /** True only when this row contains a direct media URL Eve can play. */
    public static boolean isDirectPlayableResourceItem(JSONObject item) {
        if (item == null) return false;
        String link = item.optString("resourceLink", null);
        if (link == null || link.isEmpty()) link = item.optString("url", null);
        if (link == null || link.isEmpty() || isDeprecationNoticeUrl(link)
                || !link.startsWith("http")) return false;
        String lower = link.toLowerCase(java.util.Locale.US).split("\\?")[0];
        return lower.endsWith(".mp4") || lower.endsWith(".m3u8")
                || lower.endsWith(".mpd") || lower.endsWith(".mkv")
                || lower.endsWith(".webm");
    }

    /**
     * Checks that a resource URL is a real direct-media candidate. Known update-video
     * placeholders and malformed URLs are always rejected, even if title/runtime metadata
     * happens to match. Caption lookup is separate and uses resourceId metadata instead.
     */
    public static boolean isDirectMediaResourceItem(JSONObject item) {
        if (item == null) return false;
        String link = item.optString("resourceLink", null);
        if (link == null || link.isEmpty()) link = item.optString("url", null);
        if (link == null || isDeprecationNoticeUrl(link) || !isValidHttpUrl(link)) return false;
        String lower = link.toLowerCase(java.util.Locale.US).split("\\?")[0];
        if (lower.endsWith("/notice.mp4")) return false;
        return lower.endsWith(".mp4") || lower.endsWith(".m3u8")
                || lower.endsWith(".mpd") || lower.endsWith(".mkv")
                || lower.endsWith(".webm");
    }

    // ── /resource items → real upload resourceId ─────────────

    /**
     * Raw resource rows from a /resource payload (top-level "list" or "data"
     * array, or data.list). Never treats page index or array position as a
     * season identity.
     */
    public static JSONArray resourceItems(JSONObject payload) {
        if (payload == null) return null;
        JSONArray items = payload.optJSONArray("list");
        if (items != null) return items;
        JSONObject data = payload.optJSONObject("data");
        if (data != null) {
            items = data.optJSONArray("list");
            if (items != null) return items;
        }
        items = payload.optJSONArray("data");
        return items;
    }

    /**
     * Port of MovieBox-Tui service.rs find_matching_resource_item: the item
     * whose se/ep explicitly equal the requested season/episode (int or string
     * JSON values). Movies (se=0, ep=0) match the first item. No match → null;
     * a series request NEVER falls back to an arbitrary row.
     */
    public static JSONObject findMatchingResourceItem(JSONArray items, int season, int episode) {
        if (items == null) return null;
        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            if (item == null) continue;
            if (season == 0 && episode == 0) return item;
            Integer se = optIntLooseOrNull(item, "se");
            Integer ep = optIntLooseOrNull(item, "ep");
            if (se != null && ep != null && se == season && ep == episode) return item;
        }
        return null;
    }

    /** The genuine upload resourceId of a /resource row (number or string). */
    public static String resourceIdOf(JSONObject item) {
        return item == null ? null : optId(item, "resourceId", "id");
    }

    /**
     * Resource ids advertised by a subject's resourceDetectors. Parent detector
     * ids are accepted for movies or when their episode mapping is explicit; for
     * series, resolution rows must match the requested season/episode exactly.
     * Duplicate ids are removed while preserving provider order.
     */
    public static List<String> resourceDetectorIds(JSONObject details, int season, int episode) {
        List<String> out = new ArrayList<>();
        if (details == null) return out;
        JSONArray detectors = details.optJSONArray("resourceDetectors");
        if (detectors == null) return out;
        Set<String> seen = new HashSet<>();
        for (int i = 0; i < detectors.length(); i++) {
            JSONObject detector = detectors.optJSONObject(i);
            if (detector == null) continue;
            if (resourceMatchesEpisode(detector, season, episode)) {
                String id = resourceIdOf(detector);
                if (id != null && !id.isEmpty() && seen.add(id)) out.add(id);
            }
            JSONArray resolutions = detector.optJSONArray("resolutionList");
            if (resolutions == null) continue;
            for (int j = 0; j < resolutions.length(); j++) {
                JSONObject row = resolutions.optJSONObject(j);
                if (row == null || !resourceMatchesEpisode(row, season, episode)) continue;
                String id = resourceIdOf(row);
                if (id != null && !id.isEmpty() && seen.add(id)) out.add(id);
            }
        }
        return out;
    }

    /** Exact logical episode match; movie rows may omit numbering or report 0/0. */
    public static boolean resourceMatchesEpisode(JSONObject item, int season, int episode) {
        if (item == null) return false;
        Integer se = optIntLooseOrNull(item, "se");
        Integer ep = optIntLooseOrNull(item, "ep");
        if (season == 0 && episode == 0)
            return (se == null || se.intValue() == 0) && (ep == null || ep.intValue() == 0);
        return se != null && ep != null && se.intValue() == season && ep.intValue() == episode;
    }

    /** Provider continuation hint; callers still impose a finite page cap. */
    public static boolean resourceHasMore(JSONObject payload) {
        if (payload == null) return false;
        JSONObject data = payload.optJSONObject("data");
        JSONObject pager = data == null ? payload.optJSONObject("pager")
                : data.optJSONObject("pager");
        return pager != null && pager.optBoolean("hasMore", false);
    }

    // ── Subtitles (get-ext-captions) ─────────────────────────

    /** adapt.rs captions_json_to_options — filters placeholders and dupes. */
    public static List<SubtitleOption> captionsToOptions(JSONObject payload) {
        List<SubtitleOption> out = new ArrayList<>();
        JSONArray captions = payload.optJSONArray("extCaptions");
        if (captions == null) {
            JSONObject data = payload.optJSONObject("data");
            if (data != null) captions = data.optJSONArray("extCaptions");
        }
        if (captions == null) return out;

        Set<String> seenUrls = new HashSet<>();
        for (int i = 0; i < captions.length(); i++) {
            JSONObject cap = captions.optJSONObject(i);
            if (cap == null) continue;

            String url = cap.optString("url", "");
            if (url.isEmpty() || url.contains("aa348f2541d13ffe")) continue;

            long size = optLongLoose(cap, "size", 0);
            if (size > 0 && size <= 50) continue;

            String name = cap.optString("lanName", "").trim();
            if (name.isEmpty()) name = cap.optString("lan", "").trim();
            if (name.isEmpty()) name = "Unknown";
            if (name.equalsIgnoreCase("in") && size <= 100) continue;

            if (!seenUrls.add(url)) continue;

            SubtitleOption opt = new SubtitleOption();
            opt.name = name;
            opt.url = url;
            String code = LanguageMatcher.normalize(cap.optString("lan", ""));
            if (code == null) code = LanguageMatcher.normalize(name);
            opt.languageCode = code;
            out.add(opt);
        }
        return out;
    }

    // ── Dubs (adapt.rs subject.dubs → AudioTrackOption) ──────

    public static List<DubOption> parseDubs(JSONObject subject) {
        List<DubOption> out = new ArrayList<>();
        if (subject == null) return out;
        JSONArray arr = subject.optJSONArray("dubs");
        if (arr == null) return out;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject d = arr.optJSONObject(i);
            if (d == null) continue;
            DubOption dub = new DubOption();
            dub.subjectId = optId(d, "subjectId", "id");
            if (dub.subjectId == null || dub.subjectId.isEmpty()) continue;
            dub.language = d.optString("lanName", d.optString("language", d.optString("lang", "")));
            dub.label = d.optString("title", d.optString("name", dub.language));
            // Preserved verbatim; the classifier uses observed 0/1 only as corroboration
            // with language and labels, and rejects contradictory combinations.
            dub.lanCode = rawScalar(d, "lanCode");
            dub.rawType = rawScalar(d, "type");
            out.add(dub);
        }
        return out;
    }

    /** A scalar field as the provider sent it (numbers rendered as text); null when absent. */
    static String rawScalar(JSONObject obj, String key) {
        Object v = obj.opt(key);
        if (v == null || v == JSONObject.NULL) return null;
        if (v instanceof Number) {
            Number n = (Number) v;
            return n.doubleValue() == n.longValue() ? String.valueOf(n.longValue()) : n.toString();
        }
        return String.valueOf(v);
    }

    // ── Sorting (mod.rs episode_streams ordering) ────────────

    public static void sortStreamsBestFirst(List<StreamSource> streams) {
        Collections.sort(streams, (a, b) -> {
            int cmp = Integer.compare(b.topResolution(), a.topResolution());
            if (cmp != 0) return cmp;
            return Long.compare(b.sizeBytes, a.sizeBytes);
        });
    }
}

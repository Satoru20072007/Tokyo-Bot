package com.eve.cinema.moviebox;

import java.util.Locale;
import java.util.regex.Pattern;

import com.eve.cinema.playback.LanguageMatcher;

/**
 * Classifies what a MovieBox release/version LABEL claims, keeping three signals apart:
 * Arabic audio (dub), Arabic subtitles, and "original / other language".
 *
 * Everything here is a HINT derived from labels and the provider's {@code lanCode}.
 * It never proves audio: ARABIC_DUB means "the metadata says Arabic dub", and the audio
 * itself still has to be confirmed from the manifest (see ModeEvidence / ManifestProber).
 *
 * Observed MovieBox responses pair {@code type=1} with Arabic-sub release entries and
 * {@code type=0} with audio/original entries. This is corroborating provider evidence only:
 * type 0 alone never proves an Arabic dub (it also labels Original Audio), and conflicts
 * between type and language/label metadata are rejected.
 *
 * Safe-default rule: any missing or conflicting evidence yields ARABIC_AMBIGUOUS (or
 * UNKNOWN), never ARABIC_DUB. A subtitle version can therefore not be classified as a dub
 * silently. Pure Java — unit-tested on the JVM.
 */
public final class MovieBoxReleaseClassifier {

    public enum Kind {
        /** Arabic language signal + an explicit dub marker, no conflicting evidence. */
        ARABIC_DUB,
        /** Arabic language signal + an explicit subtitle marker, no conflicting evidence. */
        ARABIC_SUBTITLE,
        /** Arabic is involved but audio-vs-subtitle is unproven or the evidence conflicts. */
        ARABIC_AMBIGUOUS,
        /** Original audio or another language; no Arabic signal. */
        OTHER,
        /** Nothing usable. */
        UNKNOWN
    }

    public static final class Result {
        public final Kind kind;
        /** Short diagnostic explanation of why this kind was chosen. */
        public final String reason;

        Result(Kind kind, String reason) {
            this.kind = kind;
            this.reason = reason;
        }

        @Override public String toString() { return kind + " (" + reason + ")"; }
    }

    private static final Pattern DUB_WORD = Pattern.compile(
            "(?<![\\p{L}\\p{N}])(?:dubs?|dubbed|dubbing)(?![\\p{L}\\p{N}])");
    // "audio" only counts as a dub marker when the text is not an "original audio" label.
    private static final Pattern AUDIO_WORD = Pattern.compile(
            "(?<![\\p{L}\\p{N}])audio(?![\\p{L}\\p{N}])");
    private static final Pattern SUB_WORD = Pattern.compile(
            "(?<![\\p{L}\\p{N}])(?:subs?|subbed|subtitles?|subtitled)(?![\\p{L}\\p{N}])");
    private static final Pattern ARABIC_WORD = Pattern.compile(
            "(?<![\\p{L}\\p{N}])arabic(?![\\p{L}\\p{N}])");
    private static final Pattern ORIGINAL_WORD = Pattern.compile(
            "(?<![\\p{L}\\p{N}])original(?![\\p{L}\\p{N}])");
    private static final Pattern TOKEN_SPLIT = Pattern.compile("[^\\p{L}\\p{N}]+");
    private static final Pattern ARABIC_MARKS = Pattern.compile("[\\u064B-\\u065F\\u0670\\u0640]");

    private MovieBoxReleaseClassifier() {}

    private static final class Signals {
        boolean arabic, other, original, dub, audioWord, sub;
    }

    /** Classifies a single label (no provider language code). */
    public static Result classifyText(String text) {
        return classify(null, text);
    }

    /**
     * Classifies a release from its provider {@code lanCode} (may be null) and any number of
     * label strings (language name, title, ...). Evidence from all inputs is pooled, so a
     * conflict between them (e.g. lanCode "en" with an Arabic marker) is reported as
     * ARABIC_AMBIGUOUS rather than resolved in favour of a dub.
     */
    public static Result classify(String lanCode, String... texts) {
        Signals s = new Signals();
        String code = LanguageMatcher.normalize(lanCode);
        if (code != null) {
            if (LanguageMatcher.AR.equals(code)) s.arabic = true; else s.other = true;
        }
        if (texts != null) {
            for (String t : texts) collect(t, s);
        }
        boolean dubMarker = s.dub || (s.audioWord && !s.original);

        if (!s.arabic) {
            if (s.other || s.original) return new Result(Kind.OTHER, "non-Arabic or original signal");
            return new Result(Kind.UNKNOWN, "no language signal");
        }
        if (s.other)
            return new Result(Kind.ARABIC_AMBIGUOUS, "Arabic and other-language signals conflict");
        if (dubMarker && s.sub)
            return new Result(Kind.ARABIC_AMBIGUOUS, "both dub and subtitle markers");
        if (dubMarker) return new Result(Kind.ARABIC_DUB, "Arabic + dub marker");
        if (s.sub) return new Result(Kind.ARABIC_SUBTITLE, "Arabic + subtitle marker");
        return new Result(Kind.ARABIC_AMBIGUOUS, "Arabic signal without a dub/subtitle marker");
    }

    /**
     * Classifies a MovieBox {@code subject.dubs} entry using its preserved raw {@code type}.
     * Observed type 1 may disambiguate a bare Arabic release as subtitle; type 0 never turns
     * a bare Arabic label into a dub because Original Audio also uses type 0. A contradictory
     * type/label pair stays ambiguous instead of being silently reinterpreted.
     */
    public static Result classifyProviderRelease(String lanCode, String rawType,
                                                 String... texts) {
        Result labelled = classify(lanCode, texts);
        String type = rawType == null ? "" : rawType.trim();
        if ("1".equals(type)) {
            if (labelled.kind == Kind.ARABIC_DUB)
                return new Result(Kind.ARABIC_AMBIGUOUS,
                        "provider subtitle type conflicts with dub label");
            if (labelled.kind == Kind.ARABIC_SUBTITLE) return labelled;
            if (labelled.kind == Kind.ARABIC_AMBIGUOUS
                    && "Arabic signal without a dub/subtitle marker".equals(labelled.reason))
                return new Result(Kind.ARABIC_SUBTITLE,
                        "Arabic signal + observed MovieBox subtitle type");
            return labelled;
        }
        if ("0".equals(type) && labelled.kind == Kind.ARABIC_SUBTITLE)
            return new Result(Kind.ARABIC_AMBIGUOUS,
                    "provider audio type conflicts with subtitle label");
        return labelled;
    }

    private static void collect(String raw, Signals s) {
        if (raw == null) return;
        String text = normalize(raw);
        if (text.isEmpty()) return;

        if (text.contains("عرب") || ARABIC_WORD.matcher(text).find()) s.arabic = true;
        if (text.contains("دبلج") || DUB_WORD.matcher(text).find()) s.dub = true;
        if (AUDIO_WORD.matcher(text).find()) s.audioWord = true;
        if (text.contains("ترجم") || SUB_WORD.matcher(text).find()) s.sub = true;
        if (ORIGINAL_WORD.matcher(text).find() || text.contains("اصلي")) s.original = true;

        for (String token : TOKEN_SPLIT.split(text)) {
            // Names only (4+ letters): short tokens such as "it", "no", "he" are common
            // words and would be false language hits.
            if (token.length() < 4) continue;
            String code = MovieBoxTitleCleaner.languageToCode(token);
            if (code != null && !LanguageMatcher.AR.equals(code)) { s.other = true; break; }
        }
    }

    private static String normalize(String raw) {
        String lower = raw.trim().toLowerCase(Locale.ROOT);
        lower = ARABIC_MARKS.matcher(lower).replaceAll("");
        return lower.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا');
    }
}

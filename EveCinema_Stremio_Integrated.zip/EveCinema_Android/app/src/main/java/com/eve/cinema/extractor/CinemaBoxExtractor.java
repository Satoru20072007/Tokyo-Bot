package com.eve.cinema.extractor;

import com.eve.cinema.DiagnosticsRecorder;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * CinemaBoxExtractor — النسخة النهائية المُختبرة
 * ══════════════════════════════════════════════════════════
 *
 * ✅ getDynamicShow(showId):
 *    يُعيد JSONObject الكامل لـ /shows/shows/dynamic/{id}
 *
 *    بنية الرد للأفلام (مُثبتة بالـ curl):
 *    {
 *      "sections": [ trailer, related, comments ],
 *      "post_info": {
 *          "episode_id": 1052574,   ← هنا يقع episode_id للأفلام
 *          "id": 40840,
 *          "type": "MOVIE",
 *          ...
 *      }
 *    }
 *
 * ✅ getSections(showId) تُعيد sections فقط (للمسلسلات)
 * ══════════════════════════════════════════════════════════
 */
public class CinemaBoxExtractor {

    private static final String BASE_URL    = "https://cinema.albox.co/api/v4/";
    private static final String BACKUP_URL  = "https://pucinema.albox.co/api/v4/";
    private static final String APP_VERSION = "4.6.0";
    private static final int    TIMEOUT_MS  = 8_000;
    private static final int    RETRY_COUNT = 1;

    private String jwtToken  = null;
    private String activeUrl = BASE_URL;

    // ══════════════════════════════════════════════════════
    //  نماذج البيانات
    // ══════════════════════════════════════════════════════

    public static class VideoStream {
        public final String quality;
        public final String url;

        VideoStream(String quality, String url) {
            this.quality = quality;
            this.url     = url;
        }

        public boolean isHls() { return url.contains(".m3u8"); }

        @Override public String toString() { return quality + " → " + url; }
    }

    public static class SubtitleTrack {
        public final String language;
        public final String vttUrl;
        public final String srtUrl;

        SubtitleTrack(String language, String vttUrl, String srtUrl) {
            this.language = language;
            this.vttUrl   = vttUrl;
            this.srtUrl   = srtUrl;
        }
    }

    public static class ShowResult {
        public final int    id;
        public final String title;
        public final String type;
        public final String imageUrl;
        public final int    year;

        ShowResult(int id, String title, String type, String imageUrl, int year) {
            this.id       = id;
            this.title    = title;
            this.type     = type;
            this.imageUrl = imageUrl;
            this.year     = year;
        }
    }

    public static class MediaResult {
        public final int               episodeId;
        public final String            showTitle;
        public final String            showType;
        public final int               showId;
        public final int               episodeNumber;
        public final int               seasonNumber;
        public final int               seasonId;
        public final String            imageUrl;
        public final long              lengthMs;
        public final List<VideoStream> videos;
        public final List<SubtitleTrack> subtitles;
        public final long              introStart;
        public final long              introEnd;
        public final long              outroStart;
        public final long              outroEnd;

        MediaResult(int episodeId, String showTitle, String showType,
                    int showId, int episodeNumber, int seasonNumber, int seasonId,
                    String imageUrl, long lengthMs,
                    List<VideoStream> videos, List<SubtitleTrack> subtitles,
                    long introStart, long introEnd, long outroStart, long outroEnd) {
            this.episodeId     = episodeId;
            this.showTitle     = showTitle;
            this.showType      = showType;
            this.showId        = showId;
            this.episodeNumber = episodeNumber;
            this.seasonNumber  = seasonNumber;
            this.seasonId      = seasonId;
            this.imageUrl      = imageUrl;
            this.lengthMs      = lengthMs;
            this.videos        = videos;
            this.subtitles     = subtitles;
            this.introStart    = introStart;
            this.introEnd      = introEnd;
            this.outroStart    = outroStart;
            this.outroEnd      = outroEnd;
        }

        public VideoStream getBestQuality() {
            if (videos == null || videos.isEmpty()) return null;
            String[] order = {"1080p", "720p", "480p", "360p"};
            for (String q : order)
                for (VideoStream v : videos)
                    if (q.equalsIgnoreCase(v.quality)) return v;
            return videos.get(0);
        }

        public VideoStream getQuality(String quality) {
            if (videos == null) return null;
            for (VideoStream v : videos)
                if (quality.equalsIgnoreCase(v.quality)) return v;
            return getBestQuality();
        }
    }

    // ══════════════════════════════════════════════════════
    //  1. تسجيل الدخول
    // ══════════════════════════════════════════════════════

    public boolean login(String usernameOrEmail, String password) throws Exception {
        JSONObject body = new JSONObject();
        body.put("username_or_email", usernameOrEmail);
        body.put("password", password);

        JSONObject response = postJson("auth/login", body.toString());

        if (response.has("jwt")) {
            jwtToken = response.getString("jwt");
            return true;
        }
        return false;
    }

    public boolean isLoggedIn() { return jwtToken != null; }
    public void   setToken(String token) { this.jwtToken = token; }
    public String getToken() { return jwtToken; }

    // ══════════════════════════════════════════════════════
    //  2. البحث
    // ══════════════════════════════════════════════════════

    public List<ShowResult> search(String query) throws Exception {
        String encoded = java.net.URLEncoder.encode(query, "UTF-8");
        JSONObject response = getJson("search?q=" + encoded);

        List<ShowResult> results = new ArrayList<>();
        JSONArray arr = response.optJSONArray("results");
        if (arr == null) return results;

        for (int i = 0; i < arr.length(); i++) {
            JSONObject item = arr.getJSONObject(i);
            String imageUrl = "";
            if (item.has("style"))
                imageUrl = item.getJSONObject("style").optString("image", "");

            results.add(new ShowResult(
                item.optInt("id"),
                item.optString("title"),
                item.optString("type"),
                imageUrl,
                item.optInt("year")
            ));
        }
        return results;
    }

    // ══════════════════════════════════════════════════════
    //  3. ✅ getDynamicShow — يُعيد JSONObject الكامل
    //
    //  للأفلام: episode_id موجود داخل post_info (مُثبت بالـ curl)
    //  للمسلسلات: الحلقات موجودة داخل sections
    //
    //  المستدعي (CinemaBoxBridge) يقرر من أين يقرأ حسب النوع:
    //  - فيلم:    dynamicShow.getJSONObject("post_info").optInt("episode_id")
    //  - مسلسل:   dynamicShow.optJSONArray("sections")
    // ══════════════════════════════════════════════════════

    public JSONObject getDynamicShow(int showId) throws Exception {
        return getJson("shows/shows/dynamic/" + showId);
    }

    // ══════════════════════════════════════════════════════
    //  4. getDynamicShowWithSeason — يُعيد sections لموسم محدد
    //
    //  مُثبت بالـ curl:
    //  /shows/shows/dynamic/{show_id}?season_id={season_id}
    //  → Section[episodes] يتغير حسب الموسم المطلوب
    // ══════════════════════════════════════════════════════

    public JSONObject getDynamicShowWithSeason(int showId, int seasonId) throws Exception {
        return getJson("shows/shows/dynamic/" + showId + "?season_id=" + seasonId);
    }

    // ══════════════════════════════════════════════════════
    //  5. getSections — يُعيد sections (للمسلسلات، موسم افتراضي)
    // ══════════════════════════════════════════════════════

    public JSONArray getSections(int showId) throws Exception {
        return getDynamicShow(showId).optJSONArray("sections");
    }

    // ══════════════════════════════════════════════════════
    //  6. getSeasonIds — يُعيد قائمة season IDs مرتبة
    //
    //  من Section نوعه "Seasons" (card_type=seasonPoster)
    //  الترتيب = ترتيب المواسم: [0]=S1, [1]=S2, ...
    // ══════════════════════════════════════════════════════

    public List<Integer> getSeasonIds(int showId) throws Exception {
        List<Integer> ids = new ArrayList<>();
        JSONArray sections = getSections(showId);
        if (sections == null) return ids;

        for (int i = 0; i < sections.length(); i++) {
            JSONObject sec  = sections.getJSONObject(i);
            JSONArray  data = sec.optJSONArray("data");
            if (data == null || data.length() == 0) continue;

            // تحقق أن الـ section يحتوي مواسم
            JSONObject probe    = data.optJSONObject(0);
            if (probe == null) continue;
            String     cardType = probe.optString("card_type", "").toLowerCase();
            String     type     = probe.optString("type", "").toLowerCase();
            if (!cardType.equals("seasonposter") && !type.equals("season")) continue;

            for (int j = 0; j < data.length(); j++) {
                int seasonId = data.getJSONObject(j).optInt("id", -1);
                if (seasonId != -1) ids.add(seasonId);
            }
            break; // وجدنا الـ Seasons section
        }
        return ids;
    }

    public List<Integer> getEpisodeIds(int showId) throws Exception {
        List<Integer> ids = new ArrayList<>();
        JSONArray sections = getSections(showId);
        if (sections == null) return ids;

        for (int i = 0; i < sections.length(); i++) {
            JSONObject section = sections.getJSONObject(i);
            JSONArray data = section.optJSONArray("data");
            if (data == null) continue;

            for (int j = 0; j < data.length(); j++) {
                JSONObject item = data.getJSONObject(j);
                if ("episode".equals(item.optString("type")))
                    ids.add(item.optInt("id"));
            }
        }
        return ids;
    }

    // ══════════════════════════════════════════════════════
    //  5. رابط البث
    //  /shows/episodes/player/{episode_id}
    // ══════════════════════════════════════════════════════

    public MediaResult getStream(int episodeId) throws Exception {
        JSONObject data = getJson("shows/episodes/player/" + episodeId);

        List<VideoStream> videos = new ArrayList<>();
        JSONArray videosArr = data.optJSONArray("videos");
        if (videosArr != null) {
            for (int i = 0; i < videosArr.length(); i++) {
                JSONObject v = videosArr.getJSONObject(i);
                String url     = v.optString("url", "");
                String quality = v.optString("quality", "auto");
                if (!url.isEmpty())
                    videos.add(new VideoStream(quality, url));
            }
        }

        List<SubtitleTrack> subtitles = new ArrayList<>();
        JSONArray subsArr = data.optJSONArray("subtitles");
        if (subsArr != null) {
            for (int i = 0; i < subsArr.length(); i++) {
                JSONObject s = subsArr.getJSONObject(i);
                subtitles.add(new SubtitleTrack(
                    s.optString("language", ""),
                    s.optString("vtt", ""),
                    s.optString("srt", "")
                ));
            }
        }

        long introStart = 0, introEnd = 0, outroStart = 0, outroEnd = 0;
        JSONObject pa = data.optJSONObject("parental_access");
        if (pa != null) {
            JSONObject intro = pa.optJSONObject("intro");
            JSONObject outro = pa.optJSONObject("outro");
            if (intro != null) { introStart = intro.optLong("start"); introEnd = intro.optLong("end"); }
            if (outro != null) { outroStart = outro.optLong("start"); outroEnd = outro.optLong("end"); }
        }

        return new MediaResult(
            data.optInt("id", episodeId),
            data.optString("show_title", ""),
            data.optString("show_type", ""),
            data.optInt("show_id"),
            data.optInt("episode_number"),
            data.optInt("season_number"),
            data.optInt("season_id"),
            data.optString("image", ""),
            data.optLong("length"),
            videos, subtitles,
            introStart, introEnd, outroStart, outroEnd
        );
    }

    // ══════════════════════════════════════════════════════
    //  HTTP Client
    // ══════════════════════════════════════════════════════

    private JSONObject getJson(String endpoint) throws Exception {
        return requestWithRetry("GET", endpoint, null);
    }

    private JSONObject postJson(String endpoint, String body) throws Exception {
        return requestWithRetry("POST", endpoint, body);
    }

    private JSONObject requestWithRetry(String method, String endpoint, String body)
            throws Exception {
        Exception lastEx = null;
        for (int attempt = 0; attempt <= RETRY_COUNT; attempt++) {
            try {
                return request(method, endpoint, body);
            } catch (java.net.SocketTimeoutException e) {
                lastEx = new Exception("انتهت مهلة الاتصال — تحقق من الشبكة");
            } catch (Exception e) {
                throw e;
            }
        }
        throw lastEx;
    }

    private JSONObject request(String method, String endpoint, String body)
            throws Exception {
        HttpURLConnection conn = null;
        final String diagnosticUrl = activeUrl + endpoint;
        final long diagnosticStart = android.os.SystemClock.elapsedRealtime();
        int diagnosticStatus = -1;
        String diagnosticResponse = null;
        try {
            conn = (HttpURLConnection) new URL(diagnosticUrl).openConnection();
            conn.setRequestMethod(method);
            conn.setConnectTimeout(TIMEOUT_MS);
            conn.setReadTimeout(TIMEOUT_MS);
            conn.setRequestProperty("Accept",           "application/json");
            conn.setRequestProperty("Content-Type",     "application/json");
            conn.setRequestProperty("App-Version",      APP_VERSION);
            conn.setRequestProperty("Accept-Language",  "en,ar;q=0.5");
            conn.setRequestProperty("Device-Id",        getDeviceId());
            conn.setRequestProperty("Device-Model",     Build.MODEL);
            conn.setRequestProperty("Device-OS-Version",Build.VERSION.RELEASE);
            conn.setRequestProperty("Device-Store",     "google");
            conn.setRequestProperty("X-Hide-Sensitive-Content", "false");
            conn.setRequestProperty("User-Agent",
                System.getProperty("http.agent", "okhttp/4.9.0"));
            if (jwtToken != null)
                conn.setRequestProperty("Authorization", jwtToken);

            DiagnosticsRecorder.headers("CinemaBox", "provider_request", method, diagnosticUrl, conn.getRequestProperties());
            if (body != null) {
                conn.setDoOutput(true);
                byte[] bytes = body.getBytes("UTF-8");
                conn.setRequestProperty("Content-Length", String.valueOf(bytes.length));
                conn.getOutputStream().write(bytes);
            }

            int code = conn.getResponseCode();
            diagnosticStatus = code;

            if (code == 503 && activeUrl.equals(BASE_URL)) {
                activeUrl = BACKUP_URL;
                conn.disconnect();
                return request(method, endpoint, body);
            }

            InputStream is = (code >= 200 && code < 300)
                             ? conn.getInputStream() : conn.getErrorStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();

            diagnosticResponse = sb.toString();
            DiagnosticsRecorder.network("CinemaBox", "provider_request", method, diagnosticUrl, code,
                    android.os.SystemClock.elapsedRealtime() - diagnosticStart, body, diagnosticResponse, null, false);
            if (code == 401) throw new Exception("انتهت صلاحية الجلسة — أعد تسجيل الدخول");
            if (code == 403) throw new Exception("المحتوى غير متاح في منطقتك");
            if (code == 404) throw new Exception("المحتوى غير موجود");
            if (code >= 400) throw new Exception("خطأ " + code);

            return new JSONObject(diagnosticResponse);
        } catch (Exception e) {
            DiagnosticsRecorder.network("CinemaBox", "provider_request", method, diagnosticUrl, diagnosticStatus,
                    android.os.SystemClock.elapsedRealtime() - diagnosticStart, body, diagnosticResponse, e, false);
            throw e;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private String getDeviceId() {
        return "eve_" + Build.SERIAL.hashCode();
    }
}

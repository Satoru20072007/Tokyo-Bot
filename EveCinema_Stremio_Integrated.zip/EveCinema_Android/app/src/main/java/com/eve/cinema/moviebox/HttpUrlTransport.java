package com.eve.cinema.moviebox;

import com.eve.cinema.DiagnosticsRecorder;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;
import java.net.HttpURLConnection;
import java.net.NoRouteToHostException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLHandshakeException;

public final class HttpUrlTransport implements Transport {

    private static final int MAX_BODY_BYTES = 4 * 1024 * 1024;

    @Override public Response execute(String method, String url, Map<String, String> headers,
                                      String body, int connectTimeoutMs, int readTimeoutMs)
            throws TransportException {
        HttpURLConnection connection = null;
        long diagnosticStart = android.os.SystemClock.elapsedRealtime();
        int diagnosticStatus = -1;
        String diagnosticResponse = null;
        TransportException.Phase phase = TransportException.Phase.BEFORE_SEND;
        try {
            byte[] requestBody = body == null ? null
                    : body.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            if (requestBody != null && requestBody.length > MAX_BODY_BYTES) {
                throw new TransportException("Request body exceeds 4 MB",
                        TransportException.Phase.BEFORE_SEND,
                        MovieBoxHostSelector.FailureKind.BAD_RESPONSE);
            }
            connection = (HttpURLConnection) new URL(url).openConnection();
            connection.setRequestMethod(method);
            connection.setConnectTimeout(connectTimeoutMs);
            connection.setReadTimeout(readTimeoutMs);
            connection.setInstanceFollowRedirects(false);
            if (headers != null) {
                DiagnosticsRecorder.headers("MovieBox", "http", method, url, headers);
                for (Map.Entry<String, String> header : headers.entrySet()) {
                    connection.setRequestProperty(header.getKey(), header.getValue());
                }
            }
            if (requestBody != null) {
                connection.setDoOutput(true);
                connection.setFixedLengthStreamingMode(requestBody.length);
            }
            connection.connect();

            if (requestBody != null) {
                OutputStream requestStream = connection.getOutputStream();
                phase = TransportException.Phase.AFTER_SEND;
                try (OutputStream output = requestStream) {
                    output.write(requestBody);
                    output.flush();
                }
            } else {
                phase = TransportException.Phase.AFTER_SEND;
            }
            int status = connection.getResponseCode();
            diagnosticStatus = status;
            InputStream input = status >= 200 && status < 400
                    ? connection.getInputStream() : connection.getErrorStream();
            String responseBody = input == null ? "" : readBody(input);
            diagnosticResponse = responseBody;
            DiagnosticsRecorder.network("MovieBox", "http", method, url, status,
                    android.os.SystemClock.elapsedRealtime() - diagnosticStart, body, responseBody, null, false);
            return new Response(status, responseBody, responseHeaders(connection));
        } catch (TransportException e) {
            DiagnosticsRecorder.network("MovieBox", "http", method, url, diagnosticStatus,
                    android.os.SystemClock.elapsedRealtime() - diagnosticStart, body, diagnosticResponse, e, false);
            throw e;
        } catch (IOException e) {
            DiagnosticsRecorder.network("MovieBox", "http", method, url, diagnosticStatus,
                    android.os.SystemClock.elapsedRealtime() - diagnosticStart, body, diagnosticResponse, e, false);
            throw classify(e, phase);
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static String readBody(InputStream input) throws IOException {
        try (InputStream in = input; ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int read;
            int total = 0;
            while ((read = in.read(buffer)) != -1) {
                total += read;
                if (total > MAX_BODY_BYTES) {
                    throw new TransportException("Response body exceeds 4 MB",
                            TransportException.Phase.AFTER_SEND,
                            MovieBoxHostSelector.FailureKind.BAD_RESPONSE);
                }
                output.write(buffer, 0, read);
            }
            return new String(output.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
        }
    }

    private static Map<String, List<String>> responseHeaders(HttpURLConnection connection) {
        Map<String, List<String>> result = new LinkedHashMap<>();
        for (Map.Entry<String, List<String>> entry : connection.getHeaderFields().entrySet()) {
            if (entry.getKey() == null) continue;
            List<String> values = entry.getValue();
            result.put(entry.getKey(), values == null ? new ArrayList<String>()
                    : new ArrayList<>(values));
        }
        return result;
    }

    private static TransportException classify(IOException error,
                                                TransportException.Phase phase) {
        MovieBoxHostSelector.FailureKind kind;
        if (hasCause(error, UnknownHostException.class)) {
            kind = MovieBoxHostSelector.FailureKind.DNS;
        } else if (hasCause(error, SocketTimeoutException.class)) {
            kind = MovieBoxHostSelector.FailureKind.TIMEOUT;
        } else if (hasCause(error, ConnectException.class)
                || hasCause(error, NoRouteToHostException.class)
                || hasCause(error, SSLHandshakeException.class)) {
            kind = MovieBoxHostSelector.FailureKind.CONNECT;
        } else {
            kind = MovieBoxHostSelector.FailureKind.CONNECT;
        }
        return new TransportException(error.getMessage(), phase, kind, error);
    }

    private static boolean hasCause(Throwable error, Class<? extends Throwable> type) {
        for (Throwable current = error; current != null; current = current.getCause()) {
            if (type.isInstance(current)) return true;
        }
        return false;
    }
}

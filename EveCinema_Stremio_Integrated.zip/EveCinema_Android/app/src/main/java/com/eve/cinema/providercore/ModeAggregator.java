package com.eve.cinema.providercore;

import com.eve.cinema.playback.PlaybackMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;

/**
 * Aggregates verified candidates into user-safe mode/quality summaries while
 * keeping provider identifiers and playback links behind internal picks.
 */
public final class ModeAggregator {
    private ModeAggregator() {}

    /** Internal launch decision for one exact mode and quality. */
    public static final class ProviderPick {
        private final PlaybackMode mode;
        private final int quality;
        private final NormalizedCandidate primary;
        private final List<NormalizedCandidate> alternates;

        private ProviderPick(PlaybackMode mode, int quality, NormalizedCandidate primary,
                             List<NormalizedCandidate> alternates) {
            this.mode = mode;
            this.quality = quality;
            this.primary = primary;
            this.alternates = Collections.unmodifiableList(new ArrayList<>(alternates));
        }

        public PlaybackMode mode() { return mode; }
        public int quality() { return quality; }
        /** Internal only: caller must not pass this object or its data to UI/diagnostics. */
        public NormalizedCandidate candidateForLaunch() { return primary; }
        /** Internal same-mode/same-quality alternates, stable provider order. */
        public List<NormalizedCandidate> alternates() { return alternates; }
    }

    public static final class Result {
        private final PlaybackProfileBuilder.PlaybackProfile profile;

        private Result(PlaybackProfileBuilder.PlaybackProfile profile) {
            this.profile = profile;
        }

        /** Safe presentation surface: only Arabic mode and quality values. */
        public List<PlaybackProfileBuilder.QualitySummary> uiSummaries() {
            return profile.uiSummaries();
        }

        public List<PlaybackMode> availableModes() {
            return Collections.unmodifiableList(profile.availableModes());
        }

        /** Highest listed non-AUTO quality; AUTO is used only if it is the sole option. */
        public int defaultQuality(PlaybackMode mode) {
            PlaybackProfileBuilder.ModeProfile modeProfile = profile.forMode(mode);
            if (modeProfile == null) return -1;
            List<Integer> qualities = modeProfile.qualities();
            for (int i = qualities.size() - 1; i >= 0; i--)
                if (qualities.get(i) != NormalizedCandidate.QUALITY_AUTO) return qualities.get(i);
            return qualities.contains(NormalizedCandidate.QUALITY_AUTO)
                    ? NormalizedCandidate.QUALITY_AUTO : -1;
        }

        /** Exact lookup only; never falls across Arabic mode or quality. */
        public ProviderPick pick(PlaybackMode mode, int quality) {
            PlaybackProfileBuilder.ModeProfile modeProfile = profile.forMode(mode);
            if (modeProfile == null) return null;
            List<NormalizedCandidate> candidates = modeProfile.candidatesFor(quality);
            if (candidates.isEmpty()) return null;
            NormalizedCandidate primary = candidates.get(0);
            List<NormalizedCandidate> alternates = new ArrayList<>();
            for (int i = 1; i < candidates.size(); i++) alternates.add(candidates.get(i));
            return new ProviderPick(mode, quality, primary, alternates);
        }
    }

    /**
     * Provider order is the deterministic tie-breaker while measured ranking
     * weights remain disabled. Anime policy remains MovieBox-only.
     */
    public static Result aggregate(String mediaKey, boolean anime,
                                   List<ProviderModeEvidence> providerEvidence) {
        List<NormalizedCandidate> accepted = new ArrayList<>();
        if (mediaKey != null && !mediaKey.trim().isEmpty() && providerEvidence != null) {
            for (ProviderModeEvidence evidence : providerEvidence) {
                if (evidence == null || !mediaKey.equals(evidence.mediaKey())) continue;
                if (anime && !ProviderIds.MOVIEBOX.equals(evidence.providerId())) continue;
                for (PlaybackMode mode : PlaybackMode.values()) {
                    if (!isArabicMode(mode)) continue;
                    for (NormalizedCandidate candidate : evidence.verifiedCandidatesFor(mode)) {
                        if (mediaKey.equals(candidate.mediaKey())
                                && evidence.providerId().equals(candidate.providerId())
                                && CandidateRanker.passesHardGates(candidate, null))
                            accepted.add(candidate);
                    }
                }
            }
        }
        // The six-weight formula is experimental; preserve deterministic provider
        // and adapter order until Tuning.RANKER_WEIGHTS_ENABLED is explicitly enabled.
        if (Tuning.RANKER_WEIGHTS_ENABLED && !accepted.isEmpty()) {
            List<CandidateRanker.Scored> ranked = CandidateRanker.rank(accepted, null);
            accepted.clear();
            for (CandidateRanker.Scored scored : ranked) accepted.add(scored.candidate);
        }
        PlaybackProfileBuilder.PlaybackProfile profile =
                PlaybackProfileBuilder.build(mediaKey, accepted);
        return new Result(profile);
    }

    private static boolean isArabicMode(PlaybackMode mode) {
        return mode == PlaybackMode.ARABIC_DUB
                || mode == PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE
                || mode == PlaybackMode.ARABIC_SUBTITLE;
    }
}

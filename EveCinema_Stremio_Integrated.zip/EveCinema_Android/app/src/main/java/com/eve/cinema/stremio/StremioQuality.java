package com.eve.cinema.stremio;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Extracts a video height only from evidence present in the stream's own metadata
 * (name, filename, description, URL, or a resolution declared by the manifest).
 * Never guesses: returns {@link #UNKNOWN} when nothing states a resolution.
 */
public final class StremioQuality {
    public static final int UNKNOWN = 0;

    private static final Pattern HEIGHT = Pattern.compile(
            "(?<![A-Za-z0-9])(2160|1440|1080|720|576|480|360)[pi](?![A-Za-z0-9])",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern FOUR_K = Pattern.compile(
            "(?<![A-Za-z0-9])(4k|uhd)(?![A-Za-z0-9])", Pattern.CASE_INSENSITIVE);
    private static final Pattern WIDTH_X_HEIGHT = Pattern.compile(
            "(?<![0-9])([0-9]{3,4})\\s*[x\u00D7]\\s*([0-9]{3,4})(?![0-9])");

    private StremioQuality() {}

    /** First text that states a resolution wins; later texts are only consulted if earlier ones do not. */
    public static int fromTexts(String... texts) {
        if (texts == null) return UNKNOWN;
        for (String text : texts) {
            int height = fromText(text);
            if (height != UNKNOWN) return height;
        }
        return UNKNOWN;
    }

    public static int fromText(String text) {
        if (text == null || text.isEmpty()) return UNKNOWN;
        Matcher m = HEIGHT.matcher(text);
        if (m.find()) return Integer.parseInt(m.group(1));
        if (FOUR_K.matcher(text).find()) return 2160;
        Matcher wh = WIDTH_X_HEIGHT.matcher(text);
        if (wh.find()) {
            return fromDimensions(Integer.parseInt(wh.group(1)), Integer.parseInt(wh.group(2)));
        }
        return UNKNOWN;
    }

    /** Maps a declared WxH (cinemascope crops included) to its conventional "Np" bucket. */
    public static int fromDimensions(int width, int height) {
        return Math.max(bucketForWidth(width), bucketForHeight(height));
    }

    private static int bucketForWidth(int w) {
        if (w >= 3000) return 2160;
        if (w >= 2200) return 1440;
        if (w >= 1600) return 1080;
        if (w >= 1100) return 720;
        if (w >= 900) return 576;
        if (w >= 700) return 480;
        if (w >= 500) return 360;
        return UNKNOWN;
    }

    private static int bucketForHeight(int h) {
        if (h >= 2000) return 2160;
        if (h >= 1300) return 1440;
        if (h >= 1000) return 1080;
        if (h >= 650) return 720;
        if (h >= 530) return 576;
        if (h >= 420) return 480;
        if (h >= 300) return 360;
        return UNKNOWN;
    }

    /** Fixed, ordered quality groups shown by the chooser (best first). */
    public enum Bucket {
        Q2160("2160p"), Q1440("1440p"), Q1080("1080p"), Q720("720p"),
        Q576("576p"), Q480("480p"), Q360("360p"), SD("SD"), UNKNOWN(null);
        /** Short label, or null for {@link #UNKNOWN} (the UI supplies the localized text). */
        public final String label;
        Bucket(String label) { this.label = label; }
    }

    public static Bucket bucketOf(int height) {
        if (height >= 2160) return Bucket.Q2160;
        if (height >= 1440) return Bucket.Q1440;
        if (height >= 1080) return Bucket.Q1080;
        if (height >= 720) return Bucket.Q720;
        if (height >= 576) return Bucket.Q576;
        if (height >= 480) return Bucket.Q480;
        if (height >= 360) return Bucket.Q360;
        if (height > 0) return Bucket.SD;
        return Bucket.UNKNOWN;
    }

    /** What the metadata says about the resolution, and how far that can be trusted. */
    public static final class Evidence {
        public static final Evidence NONE = new Evidence(UNKNOWN, "", false, Collections.<Integer>emptySet());
        public final int height;
        /** Which field stated it: name, filename, description, url or manifest; "" when unknown. */
        public final String source;
        /** Two fields disagree (or one field lists several resolutions): the quality is shown as unknown. */
        public final boolean contradictory;
        public final Set<Integer> distinctHeights;
        Evidence(int height, String source, boolean contradictory, Set<Integer> distinct) {
            this.height = height;
            this.source = source;
            this.contradictory = contradictory;
            this.distinctHeights = Collections.unmodifiableSet(distinct);
        }
    }

    /**
     * Combines the add-on's own fields. Name, filename and description must agree; when they state
     * different resolutions (or one of them lists several) the answer is UNKNOWN with
     * {@code contradictory = true} instead of picking the highest value by guesswork. The URL is a
     * weaker hint: it only decides when no other field states anything.
     */
    public static Evidence analyze(String name, String filename, String description, String url) {
        String[] labels = {"name", "filename", "description"};
        String[] texts = {name, filename, description};
        Set<Integer> union = new LinkedHashSet<>();
        String firstSource = "";
        boolean multiInOneField = false;
        for (int i = 0; i < texts.length; i++) {
            Set<Integer> found = heightsIn(texts[i]);
            if (found.size() > 1) multiInOneField = true;
            if (!found.isEmpty() && firstSource.isEmpty()) firstSource = labels[i];
            union.addAll(found);
        }
        if (union.size() > 1 || multiInOneField) return new Evidence(UNKNOWN, "", true, union);
        if (union.size() == 1) return new Evidence(union.iterator().next(), firstSource, false, union);
        Set<Integer> fromUrl = heightsIn(url);
        if (fromUrl.size() == 1) return new Evidence(fromUrl.iterator().next(), "url", false, fromUrl);
        return Evidence.NONE;
    }

    /** Every distinct resolution a text states (4K/UHD count as 2160). */
    static Set<Integer> heightsIn(String text) {
        Set<Integer> out = new LinkedHashSet<>();
        if (text == null || text.isEmpty()) return out;
        Matcher m = HEIGHT.matcher(text);
        while (m.find()) out.add(Integer.parseInt(m.group(1)));
        if (FOUR_K.matcher(text).find()) out.add(2160);
        Matcher wh = WIDTH_X_HEIGHT.matcher(text);
        while (wh.find()) {
            int h = fromDimensions(Integer.parseInt(wh.group(1)), Integer.parseInt(wh.group(2)));
            if (h != UNKNOWN) out.add(h);
        }
        return out;
    }

    /** User-facing label, or null when the height is unknown (caller shows "unknown quality"). */
    public static String label(int height) {
        if (height <= 0) return null;
        return height + "p";
    }
}

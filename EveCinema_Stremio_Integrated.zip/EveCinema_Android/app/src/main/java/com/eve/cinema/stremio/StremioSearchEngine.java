package com.eve.cinema.stremio;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Progressive "find streams and Arabic subtitles" search.
 *
 * <ul>
 *   <li>Every add-on runs in parallel; each answer is published as an immutable
 *       {@link StremioChooserData} snapshot as soon as it arrives, so the first valid option can be
 *       shown while slower add-ons are still working (state LOADING → PARTIAL → COMPLETE).</li>
 *   <li>Streams, subtitles and speed probes use SEPARATE pools: a slow subtitle service can never
 *       starve stream requests.</li>
 *   <li>Hard time budgets (see {@link Budgets}); one bounded retry for transient failures only; a
 *       retry never runs when it could not finish inside the budget.</li>
 *   <li>Subtitles are requested twice over: a title-level request (answers are "unverified") and, for
 *       the strongest file identities found among the streams, file-specific requests carrying
 *       videoHash / videoSize / filename (answers are bound to that file). The number of
 *       file-specific requests is capped and the unchecked remainder is reported, not hidden.</li>
 *   <li>The engine never selects a stream. Speed checks are bounded by the 60-option cap; the
 *       chooser renders the five fastest measured links per quality and keeps unknowns explicit.</li>
 *   <li>Subtitles are ranked separately against the chosen file; later file-specific results can
 *       still arrive while playback is starting.</li>
 *   <li>{@link Handle#cancel()} stops publishing at once; a cancelled search can never call back.</li>
 * </ul>
 */
public final class StremioSearchEngine {

    /** Network seam (production: {@link StremioAddonGateway}; tests: scripted fakes). */
    public interface Gateway {
        StremioAddonClient.StreamBatch streams(Target target, String type, String id, int timeoutMs) throws IOException;
        StremioAddonClient.SubtitleBatch subtitles(Target target, String type, String id,
                                                   Map<String, String> extras, int timeoutMs) throws IOException;
        /** Never throws. */
        StremioSpeedProbe.Result probe(StremioStreamOption option);
    }

    public interface Connectivity { boolean isOnline(); }

    public interface Listener {
        /** Called from worker threads, one snapshot at a time, in version order. Must return quickly. */
        void onSnapshot(StremioChooserData data);
    }

    /** One add-on and the ids to ask it for. A null id means "not queried for that resource". */
    public static final class Target {
        public final String key;
        public final String manifestUrl;
        public final StremioManifest manifest;
        public final String streamId;
        public final String subtitleId;
        public final String streamType;
        public final String subtitleType;

        public Target(String key, String manifestUrl, StremioManifest manifest, String streamId, String subtitleId) {
            this(key, manifestUrl, manifest, streamId, subtitleId, null, null);
        }

        public Target(String key, String manifestUrl, StremioManifest manifest, String streamId, String subtitleId,
                      String streamType, String subtitleType) {
            this.key = key; this.manifestUrl = manifestUrl; this.manifest = manifest;
            this.streamId = streamId; this.subtitleId = subtitleId;
            this.streamType = streamType; this.subtitleType = subtitleType;
        }
    }

    /** All timing and size limits in one place so they can be tested and tuned. */
    public static final class Budgets {
        /** Hard cap for the stream phase (the first-result target is the user's patience, not a limit). */
        public final int streamBudgetMs;
        public final int subtitleBudgetMs;
        public final int requestTimeoutMs;
        public final int maxStreamsPerAddon;
        public final int maxOptions;
        public final int maxProbes;
        /** Distinct file identities that get their own subtitle request. */
        public final int maxIdentityRequests;
        public final int maxRetries;
        public final int retryBackoffMs;
        /** An attempt is not started with less than this left. */
        public final int minAttemptMs;

        public Budgets(int streamBudgetMs, int subtitleBudgetMs, int requestTimeoutMs, int maxStreamsPerAddon,
                       int maxOptions, int maxProbes, int maxIdentityRequests, int maxRetries,
                       int retryBackoffMs, int minAttemptMs) {
            this.streamBudgetMs = streamBudgetMs; this.subtitleBudgetMs = subtitleBudgetMs;
            this.requestTimeoutMs = requestTimeoutMs; this.maxStreamsPerAddon = maxStreamsPerAddon;
            this.maxOptions = maxOptions; this.maxProbes = maxProbes;
            this.maxIdentityRequests = maxIdentityRequests; this.maxRetries = maxRetries;
            this.retryBackoffMs = retryBackoffMs; this.minAttemptMs = minAttemptMs;
        }

        public static Budgets defaults() {
            // Probe every accepted option up to the existing 60-option cap. The UI renders only
            // the five highest measured speeds per quality; checks are background-only and bounded.
            return new Budgets(10_000, 15_000, 12_000, 20, 60, 60, 4, 1, 350, 600);
        }
    }

    public static final class Handle {
        private volatile boolean cancelled;
        private final List<Future<?>> futures = new CopyOnWriteArrayList<Future<?>>();
        public boolean isCancelled() { return cancelled; }
        public void cancel() {
            cancelled = true;
            for (Future<?> f : futures) f.cancel(true);
        }
        void track(Future<?> f) { futures.add(f); if (cancelled) f.cancel(true); }
    }

    // ───────────────────────────── construction ─────────────────────────────

    private final Gateway gateway;
    private final Budgets budgets;
    private final Connectivity connectivity;
    private final ThreadPoolExecutor streamPool, subtitlePool, probePool;
    private final ScheduledExecutorService timer;
    private final boolean ownsPools;

    public StremioSearchEngine(Gateway gateway, Budgets budgets, Connectivity connectivity,
                               ThreadPoolExecutor streamPool, ThreadPoolExecutor subtitlePool,
                               ThreadPoolExecutor probePool, ScheduledExecutorService timer, boolean ownsPools) {
        this.gateway = gateway; this.budgets = budgets; this.connectivity = connectivity;
        this.streamPool = streamPool; this.subtitlePool = subtitlePool; this.probePool = probePool;
        this.timer = timer; this.ownsPools = ownsPools;
    }

    private static final class Shared {
        static final ThreadPoolExecutor STREAMS = pool("stremio-stream", 6);
        static final ThreadPoolExecutor SUBTITLES = pool("stremio-subtitle", 4);
        static final ThreadPoolExecutor PROBES = pool("stremio-probe", 3);
        static final ScheduledExecutorService TIMER = timer("stremio-timer");
    }

    /** Production engine on the process-wide pools (daemon threads that retire when idle). */
    public static StremioSearchEngine production(Gateway gateway, Connectivity connectivity) {
        return new StremioSearchEngine(gateway, Budgets.defaults(), connectivity, Shared.STREAMS,
                Shared.SUBTITLES, Shared.PROBES, Shared.TIMER, false);
    }

    /** Engine with private pools (tests); call {@link #shutdown()} when done. */
    public static StremioSearchEngine standalone(Gateway gateway, Budgets budgets, Connectivity connectivity) {
        return new StremioSearchEngine(gateway, budgets, connectivity, pool("t-stream", 6), pool("t-sub", 4),
                pool("t-probe", 3), timer("t-timer"), true);
    }

    public void shutdown() {
        if (!ownsPools) return;
        streamPool.shutdownNow(); subtitlePool.shutdownNow(); probePool.shutdownNow(); timer.shutdownNow();
    }

    private static ThreadPoolExecutor pool(final String name, int size) {
        final AtomicInteger n = new AtomicInteger();
        ThreadPoolExecutor p = new ThreadPoolExecutor(size, size, 30L, TimeUnit.SECONDS,
                new LinkedBlockingQueue<Runnable>(), new ThreadFactory() {
            @Override public Thread newThread(Runnable r) {
                Thread t = new Thread(r, name + "-" + n.incrementAndGet());
                t.setDaemon(true);
                return t;
            }
        });
        p.allowCoreThreadTimeOut(true);
        return p;
    }

    private static ScheduledExecutorService timer(final String name) {
        ScheduledThreadPoolExecutor t = new ScheduledThreadPoolExecutor(1, new ThreadFactory() {
            @Override public Thread newThread(Runnable r) {
                Thread th = new Thread(r, name);
                th.setDaemon(true);
                return th;
            }
        });
        t.setRemoveOnCancelPolicy(true);
        return t;
    }

    // ───────────────────────────── targets ─────────────────────────────

    /**
     * Which add-ons to ask and with which id. A disabled / configuration-required / policy-rejected
     * add-on is skipped; one id per resource per add-on (IMDb preferred, TMDB only when the
     * manifest accepts nothing else): never a blind second query.
     */
    public static List<Target> buildTargets(List<StremioAddonStore.Addon> addons, StremioContentRef ref) {
        List<Target> targets = new ArrayList<>();
        int index = 0;
        for (StremioAddonStore.Addon addon : addons) {
            index++;
            if (!addon.usable()) continue;
            String streamType = supportedType(addon.manifest, StremioManifest.STREAM, ref.type, ref);
            String subtitleType = supportedType(addon.manifest, StremioManifest.SUBTITLES, ref.type, ref);
            String streamId = streamType == null ? null : ref.idFor(addon.manifest, StremioManifest.STREAM, streamType);
            String subtitleId = subtitleType == null ? null : ref.idFor(addon.manifest, StremioManifest.SUBTITLES, subtitleType);
            if (streamId == null) streamType = null;
            if (subtitleId == null) subtitleType = null;
            if (streamId == null && subtitleId == null) continue;
            targets.add(new Target("a" + index, addon.manifestUrl, addon.manifest,
                    streamId, subtitleId, streamType, subtitleType));
        }
        return Collections.unmodifiableList(targets);
    }

    private static String supportedType(StremioManifest manifest, String resource, String preferred,
                                        StremioContentRef ref) {
        // Use the specific anime type when declared; otherwise allow that add-on's series endpoint.
        if (ref.idFor(manifest, resource, preferred) != null) return preferred;
        if (ref.isAnime() && ref.idFor(manifest, resource, StremioContentRef.SERIES) != null)
            return StremioContentRef.SERIES;
        return null;
    }

    /**
     * True when nothing can be asked ONLY because the IMDb id is missing: there are no targets,
     * the title has no IMDb id, and at least one usable add-on could serve it with one. The UI
     * must then say that (a retry may fix it), not claim that no add-on supports the title.
     */
    public static boolean idUnavailable(List<StremioAddonStore.Addon> addons, StremioContentRef ref,
                                        List<Target> targets) {
        if (!targets.isEmpty() || ref.imdbId != null) return false;
        for (StremioAddonStore.Addon addon : addons) {
            if (!addon.usable()) continue;
            if (ref.couldBeServedBy(addon.manifest, StremioManifest.STREAM)) return true;
        }
        return false;
    }

    // ───────────────────────────── running a search ─────────────────────────────

    public Handle start(String type, List<Target> targets, Listener listener) {
        Handle handle = new Handle();
        new Run(handle, type, targets, listener).begin();
        return handle;
    }

    private static final class Token { final AtomicBoolean done = new AtomicBoolean(); }

    private static final class IdentityRequest {
        final Set<String> keys; final Map<String, String> extras; final boolean hasHash;
        IdentityRequest(Set<String> keys, Map<String, String> extras) {
            this.keys = keys; this.extras = extras; this.hasHash = extras.containsKey("videoHash");
        }
    }

    private final class Run {
        final Handle handle; final String type; final Listener listener;
        final List<Target> streamTargets = new ArrayList<>();
        final List<Target> subtitleTargets = new ArrayList<>();
        final long startNanos = System.nanoTime();
        final Object lock = new Object();
        final Object publishLock = new Object();

        // guarded by lock ----------------------------------------------------
        final List<StremioStreamOption> options = new ArrayList<>();
        final Set<String> seenUrls = new HashSet<>();
        final Map<String, String> optionByDedupKey = new java.util.HashMap<>();
        final LinkedHashMap<String, StremioSubtitle> subtitlesByUrl = new LinkedHashMap<>();
        final Set<String> streamTargetDone = new HashSet<>();
        final List<StremioException.Kind> streamFailureKinds = new ArrayList<>();
        final List<Token> subtitleTokens = new ArrayList<>();
        final Set<String> identityRequested = new HashSet<>();
        final Set<String> identitySeen = new LinkedHashSet<>();
        final Set<String> probed = new HashSet<>();
        int nextOption = 1, nextSubtitle = 1;
        int streamPending, subtitlePending, probePending;
        int streamFinished, streamFailed, streamTimedOut;
        int unsupported, unsafe, dead, ignoredFormats, subtitleReqTotal, subtitleReqDone;
        int probesIssued, identityIssued;
        boolean subtitleExpired;
        long version;

        Run(Handle handle, String type, List<Target> targets, Listener listener) {
            this.handle = handle; this.type = type; this.listener = listener;
            for (Target t : targets) {
                if (t.streamId != null) streamTargets.add(t);
                if (t.subtitleId != null) subtitleTargets.add(t);
            }
        }

        void begin() {
            synchronized (lock) {
                streamPending = streamTargets.size();
                if (!streamTargets.isEmpty()) {
                    for (Target t : subtitleTargets) { subtitlePending++; subtitleReqTotal++; subtitleTokens.add(new Token()); }
                }
            }
            publish();
            if (streamTargets.isEmpty()) return;
            for (final Target t : streamTargets) handle.track(streamPool.submit(new Runnable() {
                @Override public void run() { runStream(t); }
            }));
            int i = 0;
            for (final Target t : subtitleTargets) {
                final Token token;
                synchronized (lock) { token = subtitleTokens.get(i++); }
                handle.track(subtitlePool.submit(new Runnable() {
                    @Override public void run() { runSubtitle(t, token, null, null); }
                }));
            }
            handle.track(timer.schedule(new Runnable() {
                @Override public void run() { expireStreams(); }
            }, budgets.streamBudgetMs + 250L, TimeUnit.MILLISECONDS));
            handle.track(timer.schedule(new Runnable() {
                @Override public void run() { expireSubtitles(); }
            }, budgets.subtitleBudgetMs + 250L, TimeUnit.MILLISECONDS));
        }

        // ── streams ──────────────────────────────────────────────────────────

        void runStream(Target t) {
            int attempt = 0;
            long deadline = startNanos + budgets.streamBudgetMs * 1_000_000L;
            while (!handle.cancelled) {
                int remaining = msUntil(deadline);
                if (remaining < budgets.minAttemptMs) { finishStream(t, StremioException.Kind.TIMEOUT); return; }
                try {
                    StremioAddonClient.StreamBatch batch =
                            gateway.streams(t, t.streamType == null ? type : t.streamType,
                                    t.streamId, Math.min(remaining, budgets.requestTimeoutMs));
                    onStreamBatch(t, batch);
                    return;
                } catch (IOException ex) {
                    StremioException failure = StremioException.from(ex);
                    if (failure.kind == StremioException.Kind.CANCELLED || handle.cancelled) return;
                    if (failure.isTransient() && attempt < budgets.maxRetries
                            && msUntil(deadline) > budgets.minAttemptMs + budgets.retryBackoffMs) {
                        attempt++;
                        if (!pause(budgets.retryBackoffMs)) return;
                        continue;
                    }
                    finishStream(t, failure.kind);
                    return;
                } catch (RuntimeException ex) {
                    finishStream(t, StremioException.Kind.MALFORMED);
                    return;
                }
            }
        }

        void finishStream(Target t, StremioException.Kind kind) {
            synchronized (lock) {
                if (streamTargetDone.add(t.key)) {
                    streamPending--; streamFinished++; streamFailed++;
                    if (kind == StremioException.Kind.TIMEOUT) streamTimedOut++;
                    streamFailureKinds.add(kind);
                }
            }
            publish();
        }

        void onStreamBatch(Target t, StremioAddonClient.StreamBatch batch) {
            List<IdentityRequest> newIdentities = new ArrayList<>();
            synchronized (lock) {
                if (streamTargetDone.add(t.key)) { streamPending--; streamFinished++; }
                unsupported += batch.unsupportedTotal();
                unsafe += batch.unsafeUrl;
                int taken = 0;
                for (StremioAddonClient.StreamCandidate c : batch.playable) {
                    if (taken >= budgets.maxStreamsPerAddon || options.size() >= budgets.maxOptions) break;
                    String dedupKey = StremioUrls.streamDedupKey(c.url);
                    if (!seenUrls.add(dedupKey)) {
                        // Another add-on may repeat the exact stream while attaching a better Arabic subtitle.
                        String existingOptionId = optionByDedupKey.get(dedupKey);
                        if (existingOptionId != null) {
                            StremioFileIdentity duplicateIdentity = c.identity();
                            for (StremioSubtitle embedded : c.arabicSubtitles) {
                                Set<String> ids = new LinkedHashSet<>(); ids.add(existingOptionId);
                                register(new StremioSubtitle("", embedded.url, embedded.language, ids,
                                        duplicateIdentity.strongKeys, false));
                            }
                        }
                        continue;
                    }
                    taken++;
                    int number = nextOption++;
                    String optionId = "s" + number;
                    optionByDedupKey.put(dedupKey, optionId);
                    StremioFileIdentity identity = c.identity();
                    StremioQuality.Evidence ev = StremioQuality.analyze(c.name, c.filename, c.description, c.url);
                    List<StremioSubtitle> attached = new ArrayList<>();
                    for (StremioSubtitle embedded : c.arabicSubtitles) {
                        Set<String> ids = new LinkedHashSet<>(); ids.add(optionId);
                        attached.add(register(new StremioSubtitle("", embedded.url, embedded.language, ids,
                                identity.strongKeys, false)));
                    }
                    options.add(new StremioStreamOption(optionId, c.url, c.headers, t.manifestUrl, c.streamType,
                            ev.height, ev.source, ev.contradictory, StremioStreamOption.SPEED_UNKNOWN, attached,
                            number, c.filename, c.videoSize, c.videoHash, identity.strongKeys));
                    if (identity.isStrong()) {
                        identitySeen.addAll(identity.strongKeys);
                        boolean fresh = true;
                        for (String key : identity.strongKeys) if (identityRequested.contains(key)) fresh = false;
                        if (fresh) {
                            Map<String, String> extras = new LinkedHashMap<>();
                            if (!c.videoHash.isEmpty()) extras.put("videoHash", c.videoHash);
                            if (c.videoSize > 0) extras.put("videoSize", String.valueOf(c.videoSize));
                            if (!c.hintFilename.isEmpty()) extras.put("filename", c.hintFilename);
                            newIdentities.add(new IdentityRequest(identity.strongKeys, extras));
                        }
                    }
                }
            }
            scheduleIdentityRequests(newIdentities);
            scheduleProbes();
            publish();
        }

        // ── subtitles ────────────────────────────────────────────────────────

        /** Adds or merges by URL (caller holds the lock). */
        StremioSubtitle register(StremioSubtitle incoming) {
            StremioSubtitle existing = subtitlesByUrl.get(incoming.url);
            if (existing != null) {
                StremioSubtitle merged = existing.mergedWith(incoming);
                subtitlesByUrl.put(incoming.url, merged);
                return merged;
            }
            if (subtitlesByUrl.size() >= StremioAddonClient.MAX_ARABIC_SUBTITLES) return incoming;
            StremioSubtitle stored = incoming.withId("t" + nextSubtitle++);
            subtitlesByUrl.put(stored.url, stored);
            return stored;
        }

        void scheduleIdentityRequests(List<IdentityRequest> candidates) {
            if (candidates.isEmpty() || subtitleTargets.isEmpty()) return;
            Collections.sort(candidates, new Comparator<IdentityRequest>() {
                @Override public int compare(IdentityRequest a, IdentityRequest b) {
                    return a.hasHash == b.hasHash ? 0 : (a.hasHash ? -1 : 1);   // stable: hash first
                }
            });
            for (final IdentityRequest request : candidates) {
                final List<Token> tokens = new ArrayList<>();
                synchronized (lock) {
                    if (subtitleExpired || identityIssued >= budgets.maxIdentityRequests) continue;
                    identityRequested.addAll(request.keys);
                    identityIssued++;
                    for (int i = 0; i < subtitleTargets.size(); i++) {
                        Token token = new Token();
                        tokens.add(token); subtitleTokens.add(token);
                        subtitlePending++; subtitleReqTotal++;
                    }
                }
                for (int i = 0; i < subtitleTargets.size(); i++) {
                    final Target t = subtitleTargets.get(i);
                    final Token token = tokens.get(i);
                    handle.track(subtitlePool.submit(new Runnable() {
                        @Override public void run() { runSubtitle(t, token, request.extras, request.keys); }
                    }));
                }
            }
        }

        void runSubtitle(Target t, Token token, Map<String, String> extras, Set<String> fileKeys) {
            int attempt = 0;
            long deadline = startNanos + budgets.subtitleBudgetMs * 1_000_000L;
            try {
                while (!handle.cancelled) {
                    int remaining = msUntil(deadline);
                    if (remaining < budgets.minAttemptMs) return;
                    try {
                        StremioAddonClient.SubtitleBatch batch = gateway.subtitles(t,
                                t.subtitleType == null ? type : t.subtitleType, t.subtitleId,
                                extras == null ? Collections.<String, String>emptyMap() : extras,
                                Math.min(remaining, budgets.requestTimeoutMs));
                        onSubtitleBatch(batch, fileKeys);
                        return;
                    } catch (IOException ex) {
                        StremioException failure = StremioException.from(ex);
                        if (failure.kind == StremioException.Kind.CANCELLED || handle.cancelled) return;
                        if (failure.isTransient() && attempt < budgets.maxRetries
                                && msUntil(deadline) > budgets.minAttemptMs + budgets.retryBackoffMs) {
                            attempt++;
                            if (!pause(budgets.retryBackoffMs)) return;
                            continue;
                        }
                        return;   // a failed subtitle service never fails the search
                    } catch (RuntimeException ex) {
                        return;
                    }
                }
            } finally {
                synchronized (lock) {
                    if (token.done.compareAndSet(false, true)) { subtitlePending--; subtitleReqDone++; }
                }
                publish();
            }
        }

        void onSubtitleBatch(StremioAddonClient.SubtitleBatch batch, Set<String> fileKeys) {
            synchronized (lock) {
                ignoredFormats += batch.ignoredFormat;
                for (StremioSubtitle s : batch.arabic) {
                    StremioSubtitle incoming = fileKeys == null
                            ? new StremioSubtitle("", s.url, s.language, Collections.<String>emptySet(),
                                    Collections.<String>emptySet(), true)
                            : new StremioSubtitle("", s.url, s.language, Collections.<String>emptySet(),
                                    fileKeys, false);
                    register(incoming);
                }
            }
        }

        // ── probes (speed enrichment; never blocks the list) ───────────────────

        void scheduleProbes() {
            final List<StremioStreamOption> picks = new ArrayList<>();
            synchronized (lock) {
                if (probesIssued >= budgets.maxProbes) return;
                // Measure every accepted option up to the hard global cap. Measuring only the first
                // five from a tier would falsely present those five as the fastest when later links
                // may be quicker. The bounded worker pool keeps these checks off the UI thread.
                for (StremioStreamOption option : options) {
                    if (probesIssued >= budgets.maxProbes) break;
                    if (probed.contains(option.id)) continue;
                    probed.add(option.id);
                    probesIssued++;
                    probePending++;
                    picks.add(option);
                }
            }
            for (final StremioStreamOption option : picks) {
                handle.track(probePool.submit(new Runnable() {
                    @Override public void run() { runProbe(option); }
                }));
            }
        }

        void runProbe(StremioStreamOption candidate) {
            StremioSpeedProbe.Result result;
            try { result = gateway.probe(candidate); }
            catch (RuntimeException ex) { result = null; }
            if (handle.cancelled) return;
            synchronized (lock) {
                probePending--;
                int index = -1;
                for (int i = 0; i < options.size(); i++) if (options.get(i).id.equals(candidate.id)) { index = i; break; }
                if (index >= 0 && result != null) {
                    if (result.dead) { options.remove(index); dead++; }
                    else if (result.blocked) { options.remove(index); unsafe++; }
                    else options.set(index, options.get(index).withProbe(result.mbps, result.manifestHeight));
                }
            }
            // A new batch may have arrived while this probe ran; schedule any remaining accepted
            // options (the global cap is 60, matching the searcher's option cap).
            scheduleProbes();
            publish();
        }

        // ── budgets ──────────────────────────────────────────────────────────

        void expireStreams() {
            synchronized (lock) {
                for (Target t : streamTargets) {
                    if (streamTargetDone.add(t.key)) {
                        streamPending--; streamFinished++; streamFailed++; streamTimedOut++;
                        streamFailureKinds.add(StremioException.Kind.TIMEOUT);
                    }
                }
            }
            publish();
        }

        void expireSubtitles() {
            synchronized (lock) {
                subtitleExpired = true;
                for (Token token : subtitleTokens) {
                    if (token.done.compareAndSet(false, true)) { subtitlePending--; subtitleReqDone++; }
                }
            }
            publish();
        }

        // ── snapshots ────────────────────────────────────────────────────────

        void publish() {
            if (handle.cancelled) return;
            synchronized (publishLock) {
                if (handle.cancelled) return;
                StremioChooserData snapshot;
                synchronized (lock) { snapshot = snapshotLocked(); }
                try { listener.onSnapshot(snapshot); } catch (RuntimeException ignored) { /* UI bug must not kill the search */ }
            }
        }

        StremioChooserData snapshotLocked() {
            List<StremioStreamOption> ranked = StremioOptionRanker.rank(options);
            boolean searching = streamPending > 0 || subtitlePending > 0;
            StremioChooserData.State state;
            StremioChooserData.EmptyReason reason = StremioChooserData.EmptyReason.NONE;
            if (!ranked.isEmpty()) {
                state = searching ? StremioChooserData.State.PARTIAL : StremioChooserData.State.COMPLETE;
            } else if (searching) {
                state = StremioChooserData.State.LOADING;
            } else if (streamTargets.isEmpty()) {
                state = StremioChooserData.State.EMPTY;
                reason = StremioChooserData.EmptyReason.NO_COMPATIBLE_ADDON;
            } else if (streamFailed >= streamTargets.size()) {
                boolean networkOnly = true, networkOrTimeout = true;
                for (StremioException.Kind k : streamFailureKinds) {
                    if (k != StremioException.Kind.NETWORK) networkOnly = false;
                    if (k != StremioException.Kind.NETWORK && k != StremioException.Kind.TIMEOUT) networkOrTimeout = false;
                }
                boolean deviceOffline = connectivity != null && !connectivity.isOnline();
                state = (networkOnly || (deviceOffline && networkOrTimeout))
                        ? StremioChooserData.State.OFFLINE : StremioChooserData.State.FAILED;
                reason = StremioChooserData.EmptyReason.ALL_FAILED;
            } else if (unsupported > 0) {
                state = StremioChooserData.State.EMPTY;
                reason = StremioChooserData.EmptyReason.ONLY_UNSUPPORTED;
            } else {
                state = StremioChooserData.State.EMPTY;
                reason = StremioChooserData.EmptyReason.NO_STREAMS;
            }
            StremioChooserData.Progress progress = new StremioChooserData.Progress(
                    streamTargets.size(), streamFinished, streamFailed, streamTimedOut, unsupported, unsafe,
                    dead, ignoredFormats, subtitleReqTotal, subtitleReqDone,
                    Math.max(0, identitySeen.size() - identityRequested.size()), searching, probePending > 0);
            return new StremioChooserData(++version, state, reason, ranked,
                    new ArrayList<>(subtitlesByUrl.values()), progress);
        }
    }

    private static int msUntil(long deadlineNanos) {
        long ms = (deadlineNanos - System.nanoTime()) / 1_000_000L;
        return (int) Math.max(0L, Math.min(ms, Integer.MAX_VALUE));
    }

    /** Sleeps; false when interrupted (the search was cancelled). */
    private static boolean pause(int ms) {
        try { Thread.sleep(ms); return true; } catch (InterruptedException ex) { Thread.currentThread().interrupt(); return false; }
    }
}

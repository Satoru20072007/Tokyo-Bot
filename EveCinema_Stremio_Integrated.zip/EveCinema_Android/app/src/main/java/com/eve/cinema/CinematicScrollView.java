package com.eve.cinema;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;

import android.view.animation.DecelerateInterpolator;
import android.os.Handler;

/**
 * CinematicScrollView  v4  —  Performance Edition
 *
 * PERFORMANCE FIXES vs v3:
 *
 * [1] HARDWARE LAYER REMOVED from the HSV container.
 *     17 LAYER_TYPE_HARDWARE rows simultaneously = ~17 full-size GPU textures.
 *     On a mid-range device (2-3 GB RAM, Mali-G52 / Adreno 610 tier) this
 *     causes texture-upload stalls on every frame where a child scale/alpha
 *     changes (which is every frame during fling).
 *     Hardware layers are only a win when the view content is STATIC between
 *     frames. Our children change every frame, so the layer is re-uploaded
 *     each frame → slower, not faster.
 *
 * [2] ELEVATION REMOVED from the per-frame path.
 *     setElevation() on API 21+ triggers shadow recomputation + full
 *     invalidate of the child and its parent clip region. Running this every
 *     scroll frame for every visible card is a guaranteed frame-drop source.
 *     FIX: elevation is written ONCE during runSettle(), only on the single
 *     card that became the new focus. Cost: 1 elevation write per fling-stop.
 *
 * [3] PROCESS WINDOW narrowed from 2.8× to 1.5× card-widths beyond viewport.
 *     Old value processed ~7 cards per frame; new value processes ~4 max.
 *
 * [4] SCALE RANGE tightened: 0.92 → 1.00 (8% delta, was 28%).
 *     Smaller scale deltas = fewer pixels redrawn per setScaleX call.
 *
 * [5] ALPHA DISABLED by default (USE_ALPHA = false).
 *     Alpha compositing on many Views forces each to be composited as an
 *     independent layer ("isolation layer" in Skia). With 17 rows × ~6
 *     visible cards each, that's ~100 extra compositing operations per frame.
 *     FIX: toggle USE_ALPHA = true only if targeting flagship devices.
 *
 * [6] CARD WIDTH CACHED after first measurement; refreshed only when
 *     childCount changes. Eliminates getWidth() JNI call in the hot loop.
 *
 * [7] SETTLE iterates only ±3 cards around the closest card, not all children.
 */
public class CinematicScrollView extends HorizontalScrollView {

    // ── Tuning ──────────────────────────────────────────────────────
    private static final float   SCALE_FOCUSED  = 1.00f;
    private static final float   SCALE_SIDE     = 0.95f;
    private static final float   ALPHA_FOCUSED  = 1.00f;
    private static final float   ALPHA_SIDE     = 0.70f;
    private static final boolean USE_ALPHA      = false;   // flip to true for flagships
    private static final long    SETTLE_DELAY   = 55L;
    private static final long    SETTLE_ANIM    = 220L;
    private static final float   SKIP_SCALE     = 0.003f;
    private static final float   SKIP_ALPHA     = 0.012f;

    private static final DecelerateInterpolator INTERPOLATOR = new DecelerateInterpolator(2.2f);

    // ── Fields ──────────────────────────────────────────────────────
    private LinearLayout innerRow;
    private float        density;

    private int  cachedCardWidth  = 0;
    private int  cachedChildCount = 0;
    private int  lastFocusedIdx   = -1;

    private final Handler settleHandler = new Handler();
    private       Runnable settleRunnable;

    public interface OnNearEndListener { void onNearEnd(); }
    private OnNearEndListener nearEndListener;

    // ── Constructors ────────────────────────────────────────────────
    public CinematicScrollView(Context c)                        { super(c);       init(c); }
    public CinematicScrollView(Context c, AttributeSet a)        { super(c, a);    init(c); }
    public CinematicScrollView(Context c, AttributeSet a, int s) { super(c, a, s); init(c); }

    private void init(Context ctx) {
        density = ctx.getResources().getDisplayMetrics().density;
        setClipChildren(false);
        setClipToPadding(false);
        setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        setOverScrollMode(View.OVER_SCROLL_NEVER);
        // NO hardware layer — see fix [1]
    }

    // ── Public API ──────────────────────────────────────────────────
    public void setInnerRow(LinearLayout row) {
        this.innerRow     = row;
        cachedCardWidth   = 0;
        cachedChildCount  = 0;
        lastFocusedIdx    = -1;
        if (row != null) {
            row.setClipChildren(false);
            row.setClipToPadding(false);
            row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        }
        settleRunnable = this::runSettle;
        post(() -> { refreshCardCache(); applyInstant(); });
    }

    public void setOnNearEndListener(OnNearEndListener l) { this.nearEndListener = l; }

    /** Call after appending new cards to the row. */
    public void refreshFocus() {
        post(() -> { refreshCardCache(); applyInstant(); });
    }

    // ── Core scroll callback ─────────────────────────────────────────
    @Override
    protected void onScrollChanged(int scrollX, int scrollY, int oldX, int oldY) {
        super.onScrollChanged(scrollX, scrollY, oldX, oldY);

        applyInstant();

        settleHandler.removeCallbacks(settleRunnable);
        settleHandler.postDelayed(settleRunnable, SETTLE_DELAY);

        if (nearEndListener != null && innerRow != null && cachedCardWidth > 0) {
            int maxScroll = innerRow.getWidth() - getWidth();
            if (maxScroll > 0 && (maxScroll - scrollX) < dpToPx(200))
                nearEndListener.onNearEnd();
        }
    }

    // ── INSTANT — runs every scroll frame ───────────────────────────
    // Target: complete in < 0.5 ms on Snapdragon 680 / Helio G85 tier.
    private void applyInstant() {
        if (innerRow == null) return;
        final int scrollX = getScrollX();
        final int hsvW    = getWidth();
        if (hsvW == 0) return;

        final int count = innerRow.getChildCount();
        if (count != cachedChildCount) refreshCardCache();
        if (count == 0 || cachedCardWidth == 0) return;

        final float center      = scrollX + hsvW * 0.5f;
        // Process window: viewport half-width + 1.5 card widths
        final float processWin  = hsvW * 0.5f + cachedCardWidth * 1.5f;
        final float scaleRange  = SCALE_FOCUSED - SCALE_SIDE;
        final float alphaRange  = USE_ALPHA ? (ALPHA_FOCUSED - ALPHA_SIDE) : 0f;
        final float cardWf      = (float) cachedCardWidth;

        for (int i = 0; i < count; i++) {
            final View child = innerRow.getChildAt(i);
            if (child == null) continue;

            // Use cached width — no JNI call
            final float childCenter = child.getLeft() + cardWf * 0.5f;
            final float dist        = Math.abs(center - childCenter);

            if (dist > processWin) {
                // Distant card: snap once and ignore every subsequent frame
                if (child.getScaleX() != SCALE_SIDE) {
                    child.setScaleX(SCALE_SIDE);
                    child.setScaleY(SCALE_SIDE);
                    if (USE_ALPHA) child.setAlpha(ALPHA_SIDE);
                }
                continue;
            }

            // Quadratic easing over one card-width
            final float t           = Math.min(dist / cardWf, 1f);
            final float easedT      = t * t;
            final float targetScale = SCALE_FOCUSED - easedT * scaleRange;

            if (Math.abs(child.getScaleX() - targetScale) > SKIP_SCALE) {
                child.setScaleX(targetScale);
                child.setScaleY(targetScale);
            }
            if (USE_ALPHA) {
                final float targetAlpha = ALPHA_FOCUSED - easedT * alphaRange;
                if (Math.abs(child.getAlpha() - targetAlpha) > SKIP_ALPHA)
                    child.setAlpha(targetAlpha);
            }
            // No elevation here — see fix [2]
        }
    }

    // ── SETTLE — runs once after fling stops ────────────────────────
    // Animates only ±3 cards around the closest card to center.
    private void runSettle() {
        if (innerRow == null) return;
        final int scrollX = getScrollX();
        final int hsvW    = getWidth();
        if (hsvW == 0 || cachedCardWidth == 0) return;

        final float center     = scrollX + hsvW * 0.5f;
        final int   count      = innerRow.getChildCount();
        final float scaleRange = SCALE_FOCUSED - SCALE_SIDE;
        final float alphaRange = ALPHA_FOCUSED - ALPHA_SIDE;
        final float cardWf     = (float) cachedCardWidth;

        // Find closest card to center
        int   closestIdx  = 0;
        float closestDist = Float.MAX_VALUE;
        for (int i = 0; i < count; i++) {
            View child = innerRow.getChildAt(i);
            if (child == null) continue;
            float d = Math.abs(center - (child.getLeft() + cardWf * 0.5f));
            if (d < closestDist) { closestDist = d; closestIdx = i; }
        }

        // Update elevation on focus change — at most 2 setElevation calls per fling-stop
        if (android.os.Build.VERSION.SDK_INT >= 21 && closestIdx != lastFocusedIdx) {
            if (lastFocusedIdx >= 0 && lastFocusedIdx < count) {
                View prev = innerRow.getChildAt(lastFocusedIdx);
                if (prev != null) prev.setElevation(0f);
            }
            View nowFocused = innerRow.getChildAt(closestIdx);
            if (nowFocused != null) nowFocused.setElevation(dpToPx(5));
            lastFocusedIdx = closestIdx;
        }

        // Animate only ±3 window — max 7 card animators
        final int from = Math.max(0, closestIdx - 3);
        final int to   = Math.min(count - 1, closestIdx + 3);

        for (int i = from; i <= to; i++) {
            final View child = innerRow.getChildAt(i);
            if (child == null) continue;

            final float d      = Math.abs(center - (child.getLeft() + cardWf * 0.5f));
            final float t      = Math.min(d / cardWf, 1f);
            final float easedT = t * t;
            final float tgtScale = SCALE_FOCUSED - easedT * scaleRange;

            final boolean doScale = Math.abs(child.getScaleX() - tgtScale) > SKIP_SCALE;
            final boolean doAlpha = USE_ALPHA &&
                Math.abs(child.getAlpha() - (ALPHA_FOCUSED - easedT * alphaRange)) > SKIP_ALPHA;

            if (doScale || doAlpha) {
                child.animate().cancel();
                android.view.ViewPropertyAnimator va = child.animate()
                    .scaleX(tgtScale).scaleY(tgtScale)
                    .setDuration(SETTLE_ANIM)
                    .setInterpolator(INTERPOLATOR);
                if (doAlpha) va.alpha(ALPHA_FOCUSED - easedT * alphaRange);
                va.start();
            }
        }
    }

    // ── Internal helpers ─────────────────────────────────────────────
    private void refreshCardCache() {
        if (innerRow == null) { cachedCardWidth = 0; cachedChildCount = 0; return; }
        final int count = innerRow.getChildCount();
        cachedChildCount = count;
        cachedCardWidth  = 0;
        if (count > 0) {
            View first = innerRow.getChildAt(0);
            if (first != null && first.getWidth() > 0)
                cachedCardWidth = first.getWidth();
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        settleHandler.removeCallbacksAndMessages(null);
    }

    private int dpToPx(float dp) { return (int)(dp * density); }
}

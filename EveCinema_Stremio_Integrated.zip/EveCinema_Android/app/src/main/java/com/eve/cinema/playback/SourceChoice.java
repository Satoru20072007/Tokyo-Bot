package com.eve.cinema.playback;

import com.eve.cinema.providercore.ProviderDecision;
import com.eve.cinema.providercore.ProviderIds;

/**
 * The details-page source selector model.
 *
 * <p>Stable internal ids (persisted selections, caches and diagnostics rely on them):
 * 1 = MovieBox, 2 = CinemaBox, 3 = enabled Stremio stream add-ons.
 *
 * <p>What the user sees follows priority, not id: Stremio is "مصدر 1" and is listed (and
 * selected) first; CinemaBox is "مصدر 2". MovieBox ("مصدر 3") is switched off by
 * {@link ProviderDecision}; if that decision is ever reverted it reappears last.
 *
 * <p>Anime: Stremio is the primary source. CinemaBox never serves anime (P7).
 */
public final class SourceChoice {

    public static final int SOURCE_MOVIEBOX  = 1;
    public static final int SOURCE_CINEMABOX = 2;
    public static final int SOURCE_STREMIO   = 3;

    public static final String LABEL_STREMIO   = "مصدر 1";
    public static final String LABEL_CINEMABOX = "مصدر 2";
    public static final String LABEL_MOVIEBOX  = "مصدر 3";

    private SourceChoice() {}

    public static String label(int sourceId) {
        if (sourceId == SOURCE_STREMIO) return LABEL_STREMIO;
        if (sourceId == SOURCE_CINEMABOX) return LABEL_CINEMABOX;
        if (sourceId == SOURCE_MOVIEBOX) return LABEL_MOVIEBOX;
        return "";
    }

    public static boolean isValid(int sourceId) {
        return sourceId == SOURCE_MOVIEBOX || sourceId == SOURCE_CINEMABOX
                || sourceId == SOURCE_STREMIO;
    }

    public static final class Decision {
        public final int[] choices;
        public final int selected;
        public final boolean showDropdown;
        public final boolean noSource;

        Decision(int[] choices, int selected, boolean showDropdown, boolean noSource) {
            this.choices = choices;
            this.selected = selected;
            this.showDropdown = showDropdown;
            this.noSource = noSource;
        }

        public boolean exposes(int sourceId) {
            for (int c : choices) if (c == sourceId) return true;
            return false;
        }
    }

    /** Backward-compatible overload used by callers that do not probe Stremio. */
    public static Decision compute(boolean movieboxAvailable,
                                   boolean cinemaBoxAvailable,
                                   boolean isAnime) {
        return compute(movieboxAvailable, cinemaBoxAvailable, false, isAnime);
    }

    /** A provider switched off in {@link ProviderDecision} is never offered, whatever a stale probe says. */
    private static boolean enabled(String providerId) {
        return ProviderDecision.currentFor(providerId).allowsTraffic();
    }

    /**
     * Returns eligible sources in display order: Stremio, CinemaBox, MovieBox. The first entry is the
     * default selection. Stremio is offered for anime too; CinemaBox never is.
     */
    public static Decision compute(boolean movieboxAvailable,
                                   boolean cinemaBoxAvailable,
                                   boolean stremioAvailable,
                                   boolean isAnime) {
        boolean st = stremioAvailable;
        boolean cb = cinemaBoxAvailable && !isAnime && enabled(ProviderIds.CINEMABOX);
        boolean mb = movieboxAvailable && enabled(ProviderIds.MOVIEBOX);
        int count = (st ? 1 : 0) + (cb ? 1 : 0) + (mb ? 1 : 0);
        if (count == 0) return new Decision(new int[0], 0, false, true);
        int[] choices = new int[count];
        int index = 0;
        if (st) choices[index++] = SOURCE_STREMIO;
        if (cb) choices[index++] = SOURCE_CINEMABOX;
        if (mb) choices[index] = SOURCE_MOVIEBOX;
        return new Decision(choices, choices[0], count > 1, false);
    }

    public static int coerceSelection(Decision d, int wanted) {
        if (d == null) return 0;
        if (isValid(wanted) && d.exposes(wanted)) return wanted;
        return d.selected;
    }
}

package com.eve.cinema.playback;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * SRT / WebVTT parser. Format is detected from content (not the URL). Handles
 * UTF-8 BOM, CRLF/CR line endings, comma/dot milliseconds, optional hours,
 * VTT cue settings, NOTE/STYLE/REGION blocks, HTML/ASS tags and common entities.
 * ASS/SSA files are not supported by this parser.
 */
public final class SubtitleParser {

    public static final class Cue {
        public final long startMs;
        /** Exclusive end time: the cue is inactive when playback reaches this value. */
        public final long endMs;
        public final String text;

        public Cue(long startMs, long endMs, String text) {
            this.startMs = startMs;
            this.endMs = endMs;
            this.text = text;
        }
    }

    public enum Format { SRT, VTT }

    // Anchored to the full timing line so malformed prefixes cannot be ignored and
    // timestamps longer than 99 hours are not accidentally matched from a suffix.
    private static final String TIMESTAMP = "(?:(\\d+):)?(\\d{1,2}):([0-5]?\\d)[.,](\\d{1,3})";
    private static final Pattern TIME = Pattern.compile(
            "^\\s*" + TIMESTAMP + "\\s*-->\\s*" + TIMESTAMP + "(?:[ \\t]+.*)?\\s*$");
    private static final Pattern TAG = Pattern.compile("<[^>]*>|\\{\\\\[^}]*\\}");
    private static final Pattern ENTITY = Pattern.compile("&(?:amp|lt|gt|nbsp|quot|#39|lrm|rlm);");

    private SubtitleParser() {}

    public static String normalizeText(String content) {
        if (content == null) return "";
        if (!content.isEmpty() && content.charAt(0) == '\uFEFF') content = content.substring(1);
        return content.replace("\r\n", "\n").replace('\r', '\n');
    }

    public static Format detect(String content) {
        String c = normalizeText(content).trim();
        return c.startsWith("WEBVTT") ? Format.VTT : Format.SRT;
    }

    /** Parses and returns valid cues sorted by start time. Never returns null. */
    public static List<Cue> parse(String content) {
        String c = normalizeText(content);
        boolean vtt = c.trim().startsWith("WEBVTT");
        List<Cue> out = new ArrayList<>();
        String[] blocks = c.split("\n[ \\t]*\n+");
        for (String block : blocks) {
            String b = block.trim();
            if (b.isEmpty()) continue;
            if (vtt && (b.startsWith("WEBVTT") && !b.contains("-->"))) continue;
            if (vtt && (b.startsWith("NOTE") || b.startsWith("STYLE") || b.startsWith("REGION")))
                continue;
            String[] lines = b.split("\n");
            int ts = -1;
            for (int i = 0; i < lines.length; i++) {
                if (lines[i].contains("-->")) { ts = i; break; }
            }
            if (ts < 0) continue;
            Matcher m = TIME.matcher(lines[ts]);
            if (!m.matches()) continue;
            final long start;
            final long end;
            try {
                start = toMs(m.group(1), m.group(2), m.group(3), m.group(4));
                end = toMs(m.group(5), m.group(6), m.group(7), m.group(8));
            } catch (ArithmeticException | NumberFormatException invalidTime) {
                continue;
            }
            if (start < 0 || end <= start) continue;
            StringBuilder text = new StringBuilder();
            for (int i = ts + 1; i < lines.length; i++) {
                String line = cleanLine(lines[i]);
                if (line.isEmpty()) continue;
                if (text.length() > 0) text.append('\n');
                text.append(line);
            }
            if (text.length() == 0) continue;
            out.add(new Cue(start, end, text.toString()));
        }
        Collections.sort(out, (x, y) -> Long.compare(x.startMs, y.startMs));
        return out;
    }

    static String cleanLine(String line) {
        String s = TAG.matcher(line).replaceAll("");
        return decodeEntitiesOnce(s).trim();
    }

    /** Decode entities only from the original text; never recursively reinterpret output. */
    private static String decodeEntitiesOnce(String text) {
        Matcher matcher = ENTITY.matcher(text);
        StringBuffer out = new StringBuffer(text.length());
        while (matcher.find()) {
            String value;
            switch (matcher.group()) {
                case "&amp;": value = "&"; break;
                case "&lt;": value = "<"; break;
                case "&gt;": value = ">"; break;
                case "&nbsp;": value = " "; break;
                case "&quot;": value = "\""; break;
                case "&#39;": value = "'"; break;
                case "&lrm;": value = "\u200E"; break;
                case "&rlm;": value = "\u200F"; break;
                default: value = matcher.group();
            }
            matcher.appendReplacement(out, Matcher.quoteReplacement(value));
        }
        matcher.appendTail(out);
        return out.toString();
    }

    private static long toMs(String h, String m, String s, String ms) {
        long hours = h == null ? 0 : Long.parseLong(h);
        long minutes = Long.parseLong(m);
        long seconds = Long.parseLong(s);
        if (seconds > 59 || (h != null && minutes > 59))
            throw new NumberFormatException("timestamp component out of range");
        String msPadded = (ms + "00").substring(0, 3);
        long totalSeconds = Math.addExact(Math.addExact(Math.multiplyExact(hours, 3600L),
                Math.multiplyExact(minutes, 60L)), seconds);
        return Math.addExact(Math.multiplyExact(totalSeconds, 1000L), Long.parseLong(msPadded));
    }
}

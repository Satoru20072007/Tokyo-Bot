package com.eve.cinema.moviebox;

/** Conservative ownership policy for a subtitle option attached to a selected stream. */
public final class MovieBoxCaptionResourcePolicy {
    private MovieBoxCaptionResourcePolicy() {}

    /**
     * Captions must stay within the subject that owns the active video release. A sibling can
     * have the same title and runtime while representing a different cut or audio mix; those
     * fields do not prove subtitle timing/content compatibility. Same-release alternate rows
     * still require verified metadata, and metadata is not proof of cue synchronization.
     */
    public static boolean belongsTo(String expectedSubject, String playbackSubject,
            String streamId, String captionSubject, String captionResourceId,
            boolean sameEpisode, boolean documentedSibling,
            boolean resourceIdentityVerified) {
        if (!sameEpisode || empty(captionSubject) || empty(playbackSubject)
                || !playbackSubject.equals(captionSubject)) return false;
        if (!empty(expectedSubject) && !playbackSubject.equals(expectedSubject)) return false;
        if (!empty(streamId) && streamId.equals(captionResourceId)) return true;
        return resourceIdentityVerified;
    }

    private static boolean empty(String value) { return value == null || value.isEmpty(); }
}

package com.eve.cinema;

import android.app.AlarmManager;
import android.app.Activity;
import android.app.Application;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;

public class Applications extends Application {
	private Thread.UncaughtExceptionHandler uncaughtExceptionHandler;
	@Override
	public void onCreate() {
		super.onCreate();
		DiagnosticsRecorder.initialize(this);
		// المحطة 0: تثبيت حساب CinemaBox من المخزن المشفر في الحامل — قبل أي فحص مصادر.
		CinemaBoxCredentialStore.loadIntoRuntime(this);
        com.eve.cinema.stremio.StremioAddonBootstrap.startAsync(this);
		registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
			@Override public void onActivityCreated(Activity activity, Bundle state) { }
			@Override public void onActivityStarted(Activity activity) { }
			@Override public void onActivityResumed(Activity activity) {
				DiagnosticsRecorder.initialize(getApplicationContext());
			}
			@Override public void onActivityPaused(Activity activity) { }
			@Override public void onActivityStopped(Activity activity) { }
			@Override public void onActivitySaveInstanceState(Activity activity, Bundle state) { }
			@Override public void onActivityDestroyed(Activity activity) { }
		});
		// WP2: route resolution traces to Logcat (tag "EveTrace") for device runs.
		com.eve.cinema.playback.ResolutionTrace.setSink(
				(tag, line) -> {
	                    if (!DiagnosticsRecorder.isRecordingEnabled()) return;
	                    String safeLine = DiagnosticRedactor.redactText(line);
	                    android.util.Log.d(tag, safeLine);
	                    DiagnosticsRecorder.event("playback_resolution", tag, "trace", DiagnosticsRecorder.details("traceLine", safeLine));
	                });
		this.uncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
		Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
			@Override
			public void uncaughtException(Thread thread, Throwable ex) {
				DiagnosticsRecorder.event("application", "uncaught_exception", "failed", DiagnosticsRecorder.details("thread", thread.getName(), "exception", getStackTrace(ex)));
                DiagnosticsRecorder.flushForCrash();
				Intent intent = new Intent(getApplicationContext(), DebugActivity.class);
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
				intent.putExtra("error", getStackTrace(ex));
				PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 11111, intent, PendingIntent.FLAG_ONE_SHOT);
				AlarmManager am = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
				am.set(AlarmManager.ELAPSED_REALTIME_WAKEUP, 1000, pendingIntent);
				android.os.Process.killProcess(android.os.Process.myPid());
				System.exit(2);
				uncaughtExceptionHandler.uncaughtException(thread, ex);
			}
		});
	}
	private String getStackTrace(Throwable th){
		final Writer result = new StringWriter();
		final PrintWriter printWriter = new PrintWriter(result);
		Throwable cause = th;
		while(cause != null){
			cause.printStackTrace(printWriter);
			cause = cause.getCause();
		}
		final String stacktraceAsString = result.toString();
		printWriter.close();
		return stacktraceAsString;
	}
}

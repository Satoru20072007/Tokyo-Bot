package com.eve.cinema;

import android.os.Handler;
import android.os.Looper;

import com.eve.cinema.playback.SubtitleFetcher;
import com.eve.cinema.playback.SubtitleParser;
import com.eve.cinema.playback.SubtitleTimeline;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * SubtitleManager — single owner of external subtitles (Media3 text tracks are
 * disabled in PlayerActivity, so the overlay and Media3 never render together).
 * Network + parsing run on a background executor; results are applied on the
 * main thread only if their generation is still current. Provider headers are
 * passed per load and signed URLs are used verbatim.
 */
public class SubtitleManager {

    public interface Listener {
        void onLoaded(int cueCount);
        void onFailed(String reason);
    }

    private final CinemaSubtitleView view;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private final SubtitleFetcher fetcher = new SubtitleFetcher();
    private final AtomicInteger generation = new AtomicInteger();

    /** Published as one immutable unit so lookup data cannot drift from its cues. */
    private volatile SubtitleTimeline timeline = new SubtitleTimeline(Collections.emptyList());
    private volatile boolean enabled = false;
    private volatile long offsetMs = 0L;

    public SubtitleManager(CinemaSubtitleView view) {
        this.view = view;
    }

    public void load(String url) {
        load(url, SubtitleFetcher.cinemaBoxHeaders(), null);
    }

    public void load(final String url, final Map<String, String> headers, final Listener listener) {
        loadUsing(url, headers, listener, fetcher);
    }

    /** Stremio-only path: bounded timeout, revalidate every redirect, and never log signed subtitle URLs. */
    public void loadStremio(final String url, final Map<String, String> headers, final Listener listener) {
        SubtitleFetcher safeFetcher = new SubtitleFetcher(6000, null, false,
                target -> com.eve.cinema.stremio.StremioAddonClient.isSafePublicMediaUrl(target.toString()));
        loadUsing(url, headers, listener, safeFetcher);
    }

    private void loadUsing(final String url, final Map<String, String> headers, final Listener listener,
                           final SubtitleFetcher activeFetcher) {
        final int gen = generation.incrementAndGet();
        offsetMs = 0L; // an adjustment belongs to the selected subtitle, not the next track
        timeline = new SubtitleTimeline(Collections.emptyList());
        if (view != null) view.hide();
        try {
            exec.execute(() -> {
                SubtitleFetcher.Cancellation cancel = () -> generation.get() != gen;
                try {
                    String content = activeFetcher.fetch(url, headers, cancel);
                    List<SubtitleParser.Cue> parsed = SubtitleParser.parse(content);
                    if (parsed.isEmpty()) throw new SubtitleFetcher.SubtitleException(
                            "لا توجد أسطر ترجمة صالحة في الملف", 0);
                    final SubtitleTimeline parsedTimeline = new SubtitleTimeline(parsed);
                    handler.post(() -> {
                        if (generation.get() != gen) return;
                        timeline = parsedTimeline;
                        if (listener != null) listener.onLoaded(parsedTimeline.size());
                    });
                } catch (SubtitleFetcher.SubtitleException e) {
                    if (e.httpStatus == -1) return; // superseded by a newer load
                    final String reason = e.getMessage();
                    handler.post(() -> {
                        if (generation.get() != gen) return;
                        if (listener != null) listener.onFailed(reason);
                    });
                } catch (RuntimeException e) {
                    final String reason = "تعذّر تحليل الترجمة: " + e.getClass().getSimpleName();
                    handler.post(() -> {
                        if (generation.get() != gen) return;
                        if (listener != null) listener.onFailed(reason);
                    });
                }
            });
        } catch (java.util.concurrent.RejectedExecutionException ignored) {
            // released
        }
    }

    /** Cancels in-flight loading and resets the overlay and alignment for a new item. */
    public void clear() {
        generation.incrementAndGet();
        timeline = new SubtitleTimeline(Collections.emptyList());
        offsetMs = 0L;
        if (view != null) view.hide();
    }

    public boolean hasCues() { return timeline.size() > 0; }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        if (!enabled && view != null) view.hide();
    }

    public long getOffsetMs() { return offsetMs; }

    /**
     * Positive values advance subtitle display; negative values delay it.
     * The product exposes this only as a user adjustment, not as automatic proof of sync.
     */
    public void setOffsetMs(long offsetMs) {
        this.offsetMs = offsetMs;
    }

    /** Main thread, called from the progress loop and after seeks. */
    public void tick(long posMs) {
        SubtitleTimeline snapshot = timeline;
        if (!enabled || snapshot.size() == 0 || view == null) return;
        SubtitleParser.Cue active = snapshot.cueAt(saturatedAdd(posMs, offsetMs));
        if (active != null) view.show(active.text);
        else view.hide();
    }

    public void release() {
        generation.incrementAndGet();
        timeline = new SubtitleTimeline(Collections.emptyList());
        offsetMs = 0L;
        if (view != null) view.hide();
        exec.shutdownNow();
    }

    private static long saturatedAdd(long a, long b) {
        if (b > 0 && a > Long.MAX_VALUE - b) return Long.MAX_VALUE;
        if (b < 0 && a < Long.MIN_VALUE - b) return Long.MIN_VALUE;
        return a + b;
    }
}

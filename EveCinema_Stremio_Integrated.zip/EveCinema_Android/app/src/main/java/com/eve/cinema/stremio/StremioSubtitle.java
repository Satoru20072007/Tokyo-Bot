package com.eve.cinema.stremio;

import com.eve.cinema.playback.LanguageMatcher;

import java.net.URI;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;

/**
 * One Arabic subtitle file offered by an add-on, together with the proof of WHICH video file it was
 * offered for. The player cannot tell whether a subtitle is in sync, so the chooser never claims it:
 * it only distinguishes three levels (see {@code StremioChooserData.Match}):
 *
 * <ul>
 *   <li><b>exact</b>: the add-on attached it to that very stream, or returned it for a request that
 *       carried that file's {@code videoHash} / {@code videoSize} + {@code filename};</li>
 *   <li><b>unverified</b>: a title-level answer (no file identity was sent), possibly a different release;</li>
 *   <li><b>incompatible</b>: bound to another file and never seen as a generic answer.</li>
 * </ul>
 */
public final class StremioSubtitle {
    public static final int LANGUAGE_UNKNOWN = 0;
    /** Recognised from a language NAME such as "Arabic". */
    public static final int LANGUAGE_BY_NAME = 1;
    /** Recognised from an ISO-style CODE such as "ar" / "ara" / "ar-SA". */
    public static final int LANGUAGE_BY_CODE = 2;

    /** Stable id inside one search session ("" until the engine assigns one). */
    public final String id;
    public final String url;
    /** Raw language value as declared by the add-on (e.g. "ara", "ar", "Arabic"). */
    public final String language;
    public final int languageConfidence;
    /** Stream option ids this subtitle was attached to by the add-on. */
    public final Set<String> boundOptionIds;
    /** Strong file keys (see {@link StremioFileIdentity}) this subtitle was requested/attached for. */
    public final Set<String> boundFileKeys;
    /** True when a title-level request (no file identity) also returned it. */
    public final boolean generic;

    public StremioSubtitle(String url, String language) {
        this("", url, language, Collections.<String>emptySet(), Collections.<String>emptySet(), true);
    }

    public StremioSubtitle(String id, String url, String language, Set<String> boundOptionIds,
                           Set<String> boundFileKeys, boolean generic) {
        this.id = id == null ? "" : id;
        this.url = url == null ? "" : url;
        this.language = language == null ? "" : language;
        this.languageConfidence = languageConfidenceOf(this.language);
        this.boundOptionIds = Collections.unmodifiableSet(new LinkedHashSet<>(boundOptionIds));
        this.boundFileKeys = Collections.unmodifiableSet(new LinkedHashSet<>(boundFileKeys));
        this.generic = generic;
    }

    public StremioSubtitle withId(String newId) {
        return new StremioSubtitle(newId, url, language, boundOptionIds, boundFileKeys, generic);
    }

    /** Same URL seen again: keep the union of everything the add-ons said about it. */
    public StremioSubtitle mergedWith(StremioSubtitle other) {
        Set<String> options = new LinkedHashSet<>(boundOptionIds);
        options.addAll(other.boundOptionIds);
        Set<String> keys = new LinkedHashSet<>(boundFileKeys);
        keys.addAll(other.boundFileKeys);
        return new StremioSubtitle(id.isEmpty() ? other.id : id, url,
                languageConfidence >= other.languageConfidence ? language : other.language,
                options, keys, generic || other.generic);
    }

    /** Subtitles attached to / requested for specific files. */
    public StremioSubtitle boundTo(Set<String> optionIds, Set<String> fileKeys) {
        return new StremioSubtitle(id, url, language, optionIds, fileKeys, false);
    }

    public static int languageConfidenceOf(String language) {
        if (language == null || !LanguageMatcher.isArabic(language)) return LANGUAGE_UNKNOWN;
        String l = language.trim().toLowerCase(Locale.ROOT);
        if (l.equals("ar") || l.equals("ara") || l.equals("arb") || l.startsWith("ar-") || l.startsWith("ar_"))
            return LANGUAGE_BY_CODE;
        return LANGUAGE_BY_NAME;
    }

    /**
     * The in-app parser reads SRT and WebVTT only (content-sniffed). A URL that openly names an
     * ASS/SSA file can never be shown, so it is filtered out up front; extension-less URLs are
     * judged when they are downloaded.
     */
    public static boolean hasUnsupportedFormatExtension(String url) {
        try {
            String path = URI.create(url).getPath();
            if (path == null) return false;
            String p = path.toLowerCase(Locale.ROOT);
            return p.endsWith(".ass") || p.endsWith(".ssa");
        } catch (RuntimeException ex) {
            return false;
        }
    }

    @Override public boolean equals(Object other) {
        return other instanceof StremioSubtitle && ((StremioSubtitle) other).url.equals(url);
    }

    @Override public int hashCode() { return url.hashCode(); }
}

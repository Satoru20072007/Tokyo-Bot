package com.eve.cinema.playback;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Builds the quality menu only from real renditions (Media3 video tracks parsed
 * from the DASH/HLS manifest). Heights are never invented; tracks with an
 * unknown height are not listed as a fake resolution.
 */
public final class QualityPlanner {

    private QualityPlanner() {}

    public static final class VideoTrack {
        public final int groupIndex;
        public final int trackIndex;
        public final int height;
        public final int bitrate;
        public final boolean supported;
        public VideoTrack(int groupIndex, int trackIndex, int height, int bitrate, boolean supported) {
            this.groupIndex = groupIndex; this.trackIndex = trackIndex;
            this.height = height; this.bitrate = bitrate; this.supported = supported;
        }
    }

    /** One menu entry per distinct real height (highest bitrate kept), sorted desc. */
    public static List<VideoTrack> options(List<VideoTrack> tracks) {
        Map<Integer, VideoTrack> best = new LinkedHashMap<>();
        if (tracks != null) {
            for (VideoTrack t : tracks) {
                if (t == null || !t.supported || t.height <= 0) continue;
                VideoTrack prev = best.get(t.height);
                if (prev == null || t.bitrate > prev.bitrate) best.put(t.height, t);
            }
        }
        List<VideoTrack> out = new ArrayList<>(best.values());
        Collections.sort(out, (a, b) -> Integer.compare(b.height, a.height));
        return out;
    }

    public static String label(int height) {
        return height > 0 ? height + "p" : "غير معروفة";
    }

    public static String badgeLabel(boolean adaptive, boolean autoMode, int requestedHeight,
                                    int actualHeight, String autoText, String unknownText) {
        if (!adaptive) return requestedHeight > 0 ? label(requestedHeight) : unknownText;
        if (actualHeight <= 0) return autoText;
        if (autoMode) return autoText + " • " + label(actualHeight);
        return label(actualHeight);
    }

    /** Exact match of a preferred height among real options, else null (→ Auto). */
    public static VideoTrack match(List<VideoTrack> options, int preferredHeight) {
        if (options == null || preferredHeight <= 0) return null;
        for (VideoTrack t : options) if (t.height == preferredHeight) return t;
        return null;
    }
}

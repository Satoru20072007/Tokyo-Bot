package com.eve.cinema.moviebox;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.telephony.TelephonyManager;

import org.json.JSONObject;

import java.security.SecureRandom;
import java.util.Locale;
import java.util.TimeZone;

public final class MovieBoxIdentity {

    private static final String PREFS = "eve_moviebox_identity";
    private static final String INSTALL_ID_KEY = "install_id";
    private static final String PACKAGE_NAME = "com.community.oneroom";
    private static final String VERSION_NAME = "4.0.01.0813.03";
    private static final int VERSION_CODE = 50020120;
    private static final String CRONET_VERSION = "135.0.7012.3";
    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    public enum CarrierSource {
        SIM,
        COUNTRY_FALLBACK,
        NONE
    }

    public final String userAgent;
    public final String clientInfo;
    public final boolean hasCarrierCode;
    public final CarrierSource carrierSource;
    public final String spCode;

    private MovieBoxIdentity(String userAgent, String clientInfo, String spCode,
                             CarrierSource carrierSource) {
        this.userAgent = userAgent;
        this.clientInfo = clientInfo;
        this.spCode = spCode;
        this.carrierSource = carrierSource;
        this.hasCarrierCode = !spCode.isEmpty();
    }

    public static MovieBoxIdentity build(String brand, String model, String osRelease,
                                         String buildId, String simOperator, String countryIso,
                                         String timezoneId, String languageTag, String netType,
                                         String installId) {
        String brandValue = value(brand);
        String modelValue = value(model);
        String releaseValue = value(osRelease);
        String buildValue = value(buildId);
        String country = countryCode(countryIso);
        String language = language(languageTag);
        String timezone = value(timezoneId);
        String network = networkType(netType);
        String id = value(installId);

        String simCode = value(simOperator);
        String spCode;
        CarrierSource source;
        if (simCode.matches("\\d{5,6}")) {
            spCode = simCode;
            source = CarrierSource.SIM;
        } else {
            spCode = MovieBoxCarrierCodes.forCountry(country);
            source = spCode.isEmpty() ? CarrierSource.NONE : CarrierSource.COUNTRY_FALLBACK;
        }

        String languageRegion = country.isEmpty() ? language : language + "_" + country;
        String userAgent = "com.community.oneroom/" + VERSION_CODE
                + " (Linux; U; Android " + releaseValue + "; " + languageRegion + "; "
                + printableAscii(modelValue) + "; Build/" + printableAscii(buildValue)
                + "; Cronet/" + CRONET_VERSION + ")";

        String clientInfo = "{\"package_name\":" + JSONObject.quote(PACKAGE_NAME)
                + ",\"version_name\":" + JSONObject.quote(VERSION_NAME)
                + ",\"version_code\":" + VERSION_CODE
                + ",\"os\":\"android\""
                + ",\"os_version\":" + JSONObject.quote(releaseValue)
                + ",\"install_ch\":\"ps\""
                + ",\"device_id\":" + JSONObject.quote(id)
                + ",\"install_store\":\"ps\""
                + ",\"gaid\":\"\""
                + ",\"brand\":" + JSONObject.quote(brandValue)
                + ",\"model\":" + JSONObject.quote(modelValue)
                + ",\"system_language\":" + JSONObject.quote(language)
                + ",\"net\":" + JSONObject.quote(network)
                + ",\"region\":" + JSONObject.quote(country)
                + ",\"timezone\":" + JSONObject.quote(timezone)
                + ",\"sp_code\":" + JSONObject.quote(spCode)
                + ",\"X-Play-Mode\":\"2\"}";
        return new MovieBoxIdentity(userAgent, clientInfo, spCode, source);
    }

    public static MovieBoxIdentity fromDevice(Context context) {
        Context appContext = context.getApplicationContext();
        String installId = installId(appContext);
        String simOperator = "";
        String simCountry = "";
        String networkCountry = "";

        TelephonyManager telephony = (TelephonyManager) appContext.getSystemService(
                Context.TELEPHONY_SERVICE);
        if (telephony != null) {
            try {
                simOperator = value(telephony.getSimOperator());
            } catch (SecurityException ignored) {}
            if (!simOperator.matches("\\d{5,6}")) {
                try {
                    if (telephony.getPhoneType() != TelephonyManager.PHONE_TYPE_NONE) {
                        simOperator = value(telephony.getNetworkOperator());
                    }
                } catch (SecurityException ignored) {}
            }
            try {
                simCountry = value(telephony.getSimCountryIso());
            } catch (SecurityException ignored) {}
            if (countryCode(simCountry).isEmpty()) {
                try {
                    networkCountry = value(telephony.getNetworkCountryIso());
                } catch (SecurityException ignored) {}
            }
        }

        String timezone = TimeZone.getDefault().getID();
        String country = countryForDevice(simCountry, networkCountry, timezone,
                Locale.getDefault().getCountry());
        return build(Build.BRAND, Build.MODEL, Build.VERSION.RELEASE, Build.ID,
                simOperator, country, timezone,
                Locale.getDefault().toLanguageTag(), deviceNetworkType(appContext), installId);
    }

    static String countryForDevice(String simCountry, String networkCountry,
                                   String timezoneId, String localeCountry) {
        String country = countryCode(simCountry);
        if (!country.isEmpty()) return country;
        country = countryCode(networkCountry);
        if (!country.isEmpty()) return country;
        country = MovieBoxCarrierCodes.countryForTimezone(timezoneId);
        return country.isEmpty() ? countryCode(localeCountry) : country;
    }

    private static String installId(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String id = prefs.getString(INSTALL_ID_KEY, "");
        if (id != null && id.matches("[0-9a-f]{32}")) return id;
        StringBuilder generated = new StringBuilder(32);
        synchronized (SECURE_RANDOM) {
            for (int i = 0; i < 32; i++) {
                generated.append(Character.forDigit(SECURE_RANDOM.nextInt(16), 16));
            }
        }
        id = generated.toString();
        prefs.edit().putString(INSTALL_ID_KEY, id).apply();
        return id;
    }

    private static String deviceNetworkType(Context context) {
        ConnectivityManager manager = (ConnectivityManager) context.getSystemService(
                Context.CONNECTIVITY_SERVICE);
        if (manager == null) return "NETWORK_UNKNOWN";
        Network active = manager.getActiveNetwork();
        NetworkCapabilities capabilities = active == null ? null
                : manager.getNetworkCapabilities(active);
        if (capabilities == null) return "NETWORK_UNKNOWN";
        if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "NETWORK_WIFI";
        if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
            return "NETWORK_MOBILE";
        }
        if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) {
            return "NETWORK_ETHERNET";
        }
        return "NETWORK_UNKNOWN";
    }

    private static String networkType(String value) {
        if ("NETWORK_WIFI".equals(value) || "NETWORK_MOBILE".equals(value)
                || "NETWORK_ETHERNET".equals(value)) return value;
        return "NETWORK_UNKNOWN";
    }

    private static String countryCode(String value) {
        String country = value(value).toUpperCase(Locale.US);
        return country.matches("[A-Z]{2}") ? country : "";
    }

    private static String language(String languageTag) {
        String tag = value(languageTag).trim();
        if (tag.isEmpty()) return "";
        int end = tag.length();
        int dash = tag.indexOf('-');
        int underscore = tag.indexOf('_');
        if (dash >= 0) end = Math.min(end, dash);
        if (underscore >= 0) end = Math.min(end, underscore);
        return tag.substring(0, end).toLowerCase(Locale.US);
    }

    private static String printableAscii(String value) {
        StringBuilder result = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c >= 0x20 && c <= 0x7e) result.append(c);
        }
        return result.toString();
    }

    private static String value(String value) {
        return value == null ? "" : value;
    }
}

package com.eve.cinema;

import com.eve.cinema.extractor.CinemaBoxExtractor;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * CinemaBoxCache — الحل الجذري لبطء الفتح
 * ══════════════════════════════════════════════════════════
 *
 * الفكرة:
 *  بدل إجراء البحث كاملاً عند الضغط على "مشاهدة"،
 *  نبدأ Pre-fetch فور فتح صفحة التفاصيل في الخلفية.
 *  لما يضغط المستخدم → النتيجة جاهزة فوراً أو تقريباً.
 *
 * كيف يعمل:
 *  1. DetailActivity تستدعي prefetchMovie() مباشرة في onCreate
 *  2. EpisodesActivity تستدعي prefetchShow() في onCreate
 *  3. عند الضغط → getMovie() / getTvEpisode() يعود فوراً من الكاش
 *     أو ينتظر انتهاء الـ prefetch (بدل بدء بحث جديد)
 *
 * النتيجة:
 *  - الضغط الأول: انتظار بسيط (فقط ما تبقى من وقت الـ prefetch)
 *  - الضغط الثاني وما بعده: فوري 0ms
 * ══════════════════════════════════════════════════════════
 */
public class CinemaBoxCache {

    // ── Singleton ─────────────────────────────────────────
    private static CinemaBoxCache INSTANCE;

    public static synchronized CinemaBoxCache get() {
        if (INSTANCE == null) INSTANCE = new CinemaBoxCache();
        return INSTANCE;
    }

    // ── Thread pool (max 2 خيوط متوازية) ─────────────────
    private final ExecutorService pool = Executors.newFixedThreadPool(2);

    // ── Cache: key → Future<ResolveResult> ───────────────
    // Future يسمح لنا بالانتظار على نتيجة جارية دون بدء طلب جديد
    private final ConcurrentHashMap<String, Future<CinemaBoxBridge.ResolveResult>>
        cache = new ConcurrentHashMap<>();

    // ── مفاتيح الكاش ──────────────────────────────────────

    private static String movieKey(String title, int year) {
        return "M|" + title.toLowerCase().trim() + "|" + year;
    }

    private static String episodeKey(String title, int year, int season, int episode) {
        return "E|" + title.toLowerCase().trim() + "|" + year + "|" + season + "|" + episode;
    }

    private static String showKey(String title, int year) {
        return "S|" + title.toLowerCase().trim() + "|" + year;
    }

    // ══════════════════════════════════════════════════════
    //  PRE-FETCH (يُستدعى في onCreate — لا ينتظر)
    // ══════════════════════════════════════════════════════

    /**
     * يبدأ Prefetch لفيلم في الخلفية فوراً.
     * آمن للاستدعاء أكثر من مرة — لا يُكرر البحث.
     */
    public void prefetchMovie(final String title, final String originalTitle, final int year) {
        final String key = movieKey(title, year);
        if (cache.containsKey(key)) return; // جاهز أو جارٍ

        Future<CinemaBoxBridge.ResolveResult> future = pool.submit(() ->
            CinemaBoxBridge.resolveMovie(title, originalTitle, year)
        );
        cache.put(key, future);
    }

    /**
     * يبدأ Prefetch لمسلسل (showId فقط) في الخلفية.
     * يُستخدم في EpisodesActivity — لا نعرف الحلقة بعد.
     */
    public void prefetchShowId(final String title, final String originalTitle, final int year) {
        final String key = showKey(title, year);
        if (cache.containsKey(key)) return;

        Future<CinemaBoxBridge.ResolveResult> future = pool.submit(() -> {
            // نحل الحلقة الأولى فقط لنحصل على showId
            return CinemaBoxBridge.resolveTvEpisode(title, originalTitle, year, 1, 1);
        });
        cache.put(key, future);
    }

    /**
     * يبدأ Prefetch لحلقة محددة في الخلفية.
     * يُستدعى عندما يفتح المستخدم قائمة الحلقات.
     */
    public void prefetchEpisode(final String title, final String originalTitle,
                                 final int year, final int season, final int episode) {
        final String key = episodeKey(title, year, season, episode);
        if (cache.containsKey(key)) return;

        Future<CinemaBoxBridge.ResolveResult> future = pool.submit(() ->
            CinemaBoxBridge.resolveTvEpisode(title, originalTitle, year, season, episode)
        );
        cache.put(key, future);
    }

    // ══════════════════════════════════════════════════════
    //  GET (يُستدعى عند الضغط — ينتظر النتيجة الجارية)
    // ══════════════════════════════════════════════════════

    /**
     * يُعيد نتيجة الفيلم.
     * - إذا كان الـ prefetch انتهى → فوري.
     * - إذا كان لا يزال جارياً → ينتظر انتهاءه (لا يبدأ بحثاً جديداً).
     * - إذا لم يُبدأ أصلاً → يبدأ ويُكمل.
     */
    public CinemaBoxBridge.ResolveResult getMovie(String title, String originalTitle,
                                                   int year) throws Exception {
        final String key = movieKey(title, year);
        Future<CinemaBoxBridge.ResolveResult> future = cache.get(key);

        if (future == null) {
            // لم يُبدأ الـ prefetch — نبدأ الآن ونُكمل
            prefetchMovie(title, originalTitle, year);
            future = cache.get(key);
        }

        try {
            return future.get(); // ينتظر إن كان جارياً
        } catch (Exception e) {
            cache.remove(key); // احذف النتيجة الفاشلة لإتاحة إعادة المحاولة
            Throwable cause = e.getCause();
            throw new Exception(cause != null ? cause.getMessage() : e.getMessage());
        }
    }

    /**
     * يُعيد نتيجة حلقة محددة.
     */
    public CinemaBoxBridge.ResolveResult getEpisode(String title, String originalTitle,
                                                      int year, int season,
                                                      int episode) throws Exception {
        final String key = episodeKey(title, year, season, episode);
        Future<CinemaBoxBridge.ResolveResult> future = cache.get(key);

        if (future == null) {
            prefetchEpisode(title, originalTitle, year, season, episode);
            future = cache.get(key);
        }

        try {
            return future.get();
        } catch (Exception e) {
            cache.remove(key);
            Throwable cause = e.getCause();
            throw new Exception(cause != null ? cause.getMessage() : e.getMessage());
        }
    }

    // ══════════════════════════════════════════════════════
    //  إلغاء التخزين المؤقت (عند تسجيل خروج أو تغيير المحتوى)
    // ══════════════════════════════════════════════════════

    public void clearAll() {
        for (Future<?> f : cache.values()) f.cancel(false);
        cache.clear();
    }

    /**
     * Bug 10 FIX: remove() now also removes all episode keys for the
     * given title+year, preventing stale failed-episode futures from
     * causing cache misses when a corrected title is used.
     */
    public void remove(String title, int year) {
        String prefix = "E|" + title.toLowerCase().trim() + "|" + year + "|";
        cache.remove(movieKey(title, year));
        cache.remove(showKey(title, year));
        for (String key : new java.util.ArrayList<>(cache.keySet())) {
            if (key.startsWith(prefix)) cache.remove(key);
        }
    }
}

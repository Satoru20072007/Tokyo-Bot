package com.eve.cinema.stremio;

import java.io.IOException;
import java.util.Map;

/** Production {@link StremioSearchEngine.Gateway}: real add-on client and the bounded speed probe. */
public final class StremioAddonGateway implements StremioSearchEngine.Gateway {
    private final StremioAddonClient client;
    private final StremioSpeedProbe prober;

    public StremioAddonGateway() {
        this(new StremioAddonClient(), StremioSpeedProbe.forProduction());
    }

    public StremioAddonGateway(StremioAddonClient client, StremioSpeedProbe prober) {
        this.client = client;
        this.prober = prober;
    }

    @Override public StremioAddonClient.StreamBatch streams(StremioSearchEngine.Target target, String type,
                                                            String id, int timeoutMs) throws IOException {
        return client.fetchStreams(target.manifestUrl, target.manifest, type, id, timeoutMs);
    }

    @Override public StremioAddonClient.SubtitleBatch subtitles(StremioSearchEngine.Target target, String type,
                                                                String id, Map<String, String> extras,
                                                                int timeoutMs) throws IOException {
        return client.fetchSubtitles(target.manifestUrl, target.manifest, type, id, extras, timeoutMs);
    }

    @Override public StremioSpeedProbe.Result probe(StremioStreamOption option) {
        return prober.probe(option.url, option.headers, option.streamType);
    }
}

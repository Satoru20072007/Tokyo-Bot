package com.eve.cinema;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Map;

/**
 * LoginActivity — كود + Google
 * ─────────────────────────────────────────────────────────────────────────────
 * Anti-spam: cooldown 1500ms بعد كل محاولة
 * Firebase-first: Firebase هو المصدر الأساسي، UserSession مجرد cache
 * Offline: fallback local عند فشل الشبكة
 * Cinematic loading overlay قبل الانتقال للرئيسية
 * ─────────────────────────────────────────────────────────────────────────────
 */
public class LoginActivity extends Activity {

    public static final String EXTRA_GOOGLE_ONLY = "google_only";
    private static final int   RC_GOOGLE          = 9001;
    private static final long  COOLDOWN_MS        = 1500L;

    // ── Colors ──
    private static final int C_BG        = 0xFF08080F;
    private static final int C_PURPLE    = 0xFF9B6FC4;
    private static final int C_PURPLE_DK = 0xFF7A5099;
    private static final int C_TEXT_MUT  = 0xFF6B6B88;

    // ── Views ──
    private EditText    codeInput;
    private TextView    loginBtn;
    private TextView    errorView;
    private ProgressBar progress;

    // ── State ──
    private boolean  googleOnlyMode  = false;
    private boolean  isLoading       = false;
    private boolean  navigationDone  = false;
    private long     lastAttemptTime = 0L;

    // ── Services ──
    private UserSession        session;
    private GoogleSignInClient googleSignInClient;
    private FirebaseAuth       firebaseAuth;
    private FirebaseFirestore  firestore;

    // ═════════════════════════════════════════════════════
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        MiuiBarFix.apply(this);

        session      = new UserSession(this);
        firebaseAuth = FirebaseAuth.getInstance();
        firestore    = FirebaseFirestore.getInstance();

        GoogleSignInOptions gso = new GoogleSignInOptions
                .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .requestProfile()
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, gso);

        googleOnlyMode = getIntent().getBooleanExtra(EXTRA_GOOGLE_ONLY, false);

        if (googleOnlyMode) buildGoogleOnlyUI();
        else                buildNormalUI();
    }

    // ═════════════════════════════════════════════════════
    //  ① NORMAL UI — code input
    // ═════════════════════════════════════════════════════
    private void buildNormalUI() {
        setContentView(R.layout.activity_login);

        codeInput = (EditText)    findViewById(R.id.login_code_input);
        loginBtn  = (TextView)    findViewById(R.id.login_btn);
        errorView = (TextView)    findViewById(R.id.login_error);
        progress  = (ProgressBar) findViewById(R.id.login_progress);

        // fade-in
        View root = findViewById(android.R.id.content);
        if (root != null) {
            root.setAlpha(0f);
            root.animate().alpha(1f).setDuration(400)
                .setInterpolator(new DecelerateInterpolator()).start();
        }

        loginBtn.setOnClickListener(v -> attemptLogin());

        TextView getCodeBtn = (TextView) findViewById(R.id.login_get_code_btn);
        if (getCodeBtn != null) getCodeBtn.setOnClickListener(v -> openTelegramBot());
    }

    // ═════════════════════════════════════════════════════
    //  ② GOOGLE-ONLY UI
    // ═════════════════════════════════════════════════════
    private void buildGoogleOnlyUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(C_BG);
        root.setPadding(dp(32), dp(60), dp(32), dp(60));
        root.setAlpha(0f);
        root.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // logo
        FrameLayout logoWrap = makeLogoWrap();
        root.addView(logoWrap);

        // title
        root.addView(makeTv(getString(R.string.auth_google_title), 22f, 0xFFFFFFFF, Typeface.BOLD,
            0, 0, 0, dp(10), Gravity.CENTER));
        root.addView(makeTv(getString(R.string.auth_google_subtitle), 13f, C_TEXT_MUT, Typeface.NORMAL,
            0, 0, 0, dp(40), Gravity.CENTER));

        // progress
        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(dp(36), dp(36));
        plp.gravity = Gravity.CENTER_HORIZONTAL;
        plp.bottomMargin = dp(16);
        progress.setLayoutParams(plp);
        root.addView(progress);

        // error
        errorView = new TextView(this);
        errorView.setTextColor(0xFFEF5350);
        errorView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        errorView.setGravity(Gravity.CENTER);
        errorView.setVisibility(View.GONE);
        LinearLayout.LayoutParams elp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        elp.bottomMargin = dp(16);
        errorView.setLayoutParams(elp);
        root.addView(errorView);

        // google button
        LinearLayout googleBtn = buildGoogleBtn();
        googleBtn.setOnClickListener(v -> {
            if (isLoading) return;
            setLoadingState(true);
            launchGooglePicker();
        });
        root.addView(googleBtn);

        setContentView(root);

        // fade-in animation
        root.animate().alpha(1f).setDuration(450)
            .setInterpolator(new DecelerateInterpolator()).start();
    }

    // ═════════════════════════════════════════════════════
    //  ATTEMPT LOGIN — Anti-spam + real progress state
    // ═════════════════════════════════════════════════════
    private void attemptLogin() {
        if (isLoading) return;

        // Anti-spam cooldown
        long now = SystemClock.elapsedRealtime();
        if (now - lastAttemptTime < COOLDOWN_MS) {
            showError(getString(R.string.err_wait_retry));
            return;
        }
        lastAttemptTime = now;

        final String code = codeInput != null
            ? codeInput.getText().toString().trim().toUpperCase() : "";
        if (code.isEmpty()) { showError(getString(R.string.err_enter_code)); return; }

        hideError();
        setLoadingState(true);

        final String deviceId = session.getDeviceId();

        new Thread(() -> {
            final FirebaseLicenseClient.Result result =
                FirebaseLicenseClient.fetchAndVerify(code, deviceId);

            if (isFinishing() || isDestroyed()) return;

            runOnUiThread(() -> {
                setLoadingState(false);
                handleLoginResult(result, code);
            });
        }).start();
    }

    private void handleLoginResult(FirebaseLicenseClient.Result result, String code) {
        switch (result.status) {
            case VALID:
                session.loginWithCode(code);
                if (result.telegramId != 0) session.saveTelegramId(result.telegramId);
                new Thread(() -> FirebaseLicenseClient.updateLastLogin(code)).start();
                launchGoogleAfterCode();
                break;
            case UNBOUND:
                session.loginWithCode(code);
                launchGoogleAfterCode();
                break;
            case BOUND_OTHER:
                showError(getString(R.string.err_code_other_device)); shakeInput(); break;
            case NOT_FOUND:
                showError(getString(R.string.err_code_not_found)); shakeInput(); break;
            case INACTIVE:
                showError(getString(R.string.err_code_disabled)); shakeInput(); break;
            case BANNED:
                showError(getString(R.string.err_device_banned)); shakeInput(); break;
            case EXPIRED:
                showError(getString(R.string.err_code_expired)); shakeInput(); break;
            case NETWORK_ERROR:
                showError(getString(R.string.err_server));
                showRetryHint();
                break;
        }
    }

    // ═════════════════════════════════════════════════════
    //  GOOGLE FLOW
    // ═════════════════════════════════════════════════════
    private void launchGoogleAfterCode() {
        FirebaseUser fbUser = firebaseAuth.getCurrentUser();
        if (fbUser != null) {
            handleFirebaseUserReady(fbUser);
        } else {
            setLoadingState(true);
            launchGooglePicker();
        }
    }

    private void launchGooglePicker() {
        // sign out أولاً لإجبار اختيار حساب جديد
        googleSignInClient.signOut().addOnCompleteListener(task -> {
            if (!isFinishing() && !isDestroyed()) {
                startActivityForResult(googleSignInClient.getSignInIntent(), RC_GOOGLE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != RC_GOOGLE) return;

        // Google can return a completed Task carrying ApiException even when the
        // outer activity result is RESULT_CANCELED. Inspect that Task first.
        if (data == null) {
            setLoadingState(false);
            Log.w("LoginActivity", "Google sign-in returned no intent data; resultCode=" + resultCode);
            showError(getString(R.string.err_google_result_unavailable));
            return;
        }

        Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
        try {
            GoogleSignInAccount account = task.getResult(ApiException.class);
            String idToken = account == null ? null : account.getIdToken();
            if (idToken == null || idToken.trim().isEmpty()) {
                setLoadingState(false);
                showError(getString(R.string.err_google_config));
                return;
            }
            AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
            setLoadingState(true);

            firebaseAuth.signInWithCredential(credential).addOnCompleteListener(t -> {
                if (t.isSuccessful()) {
                    FirebaseUser user = firebaseAuth.getCurrentUser();
                    if (user != null) handleFirebaseUserReady(user);
                    else { setLoadingState(false); showError(getString(R.string.err_verify_failed)); }
                } else {
                    setLoadingState(false);
                    showError(getString(R.string.err_verify_failed));
                }
            });

        } catch (ApiException e) {
            setLoadingState(false);
            Log.w("LoginActivity", "Google sign-in failed; status=" + e.getStatusCode());
            showError(getString(googleStatusMessage(e.getStatusCode())));
        }
    }

    private int googleStatusMessage(int statusCode) {
        switch (GoogleSignInFailureClassifier.classify(statusCode)) {
            case USER_CANCELLED: return R.string.err_google_cancelled;
            case CONFIGURATION: return R.string.err_google_config;
            case NETWORK: return R.string.err_server;
            default: return R.string.err_google_failed;
        }
    }

    // ═════════════════════════════════════════════════════
    //  FIREBASE — المصدر الأساسي
    //  Flow: Firebase Read → Session Cache → Navigate
    // ═════════════════════════════════════════════════════
    private void handleFirebaseUserReady(FirebaseUser user) {
        // Session cache مؤقت ريثما تأتي بيانات Firebase
        String photoUrl = buildPhotoUrl(user);
        session.saveGoogleProfile(
            user.getDisplayName() != null ? user.getDisplayName() : getString(R.string.default_user_name),
            user.getEmail() != null ? user.getEmail() : "",
            photoUrl
        );

        firestore.collection("users").document(user.getUid()).get()
            .addOnSuccessListener(doc -> {
                if (isFinishing() || isDestroyed()) return;
                if (doc.exists()) {
                    mergeAndCacheFromFirestore(doc, user);
                } else {
                    saveToFirestoreAndNavigate(user);
                }
            })
            .addOnFailureListener(e -> {
                // Offline fallback — استخدم cache المحلي
                if (!isFinishing() && !isDestroyed()) showCinematicLoading();
            });
    }

    /** دمج بيانات Firestore مع Google وتحديث الـ cache */
    private void mergeAndCacheFromFirestore(DocumentSnapshot doc, FirebaseUser user) {
        // Google دائماً أحدث لـ name و photo
        String name     = buildGoogleName(user);
        String photoUrl = buildPhotoUrl(user);
        String email    = user.getEmail() != null ? user.getEmail() : "";

        // تحديث Firestore بآخر بيانات Google
        Map<String, Object> update = new HashMap<>();
        update.put("name",      name);
        update.put("photoUrl",  photoUrl);
        update.put("email",     email);
        update.put("lastLogin", System.currentTimeMillis());
        firestore.collection("users").document(user.getUid()).update(update);

        // تحديث cache
        session.saveGoogleProfile(name, email, photoUrl);
        showCinematicLoading();
    }

    /** حفظ أول مرة في Firestore */
    private void saveToFirestoreAndNavigate(FirebaseUser user) {
        String name     = buildGoogleName(user);
        String photoUrl = buildPhotoUrl(user);
        String email    = user.getEmail() != null ? user.getEmail() : "";

        Map<String, Object> data = new HashMap<>();
        data.put("uid",          user.getUid());
        data.put("name",         name);
        data.put("email",        email);
        data.put("photoUrl",     photoUrl);
        data.put("premiumCode",  session.getCode());
        data.put("deviceId",     session.getDeviceId());
        data.put("lastLogin",    System.currentTimeMillis());
        data.put("createdAt",    System.currentTimeMillis());

        firestore.collection("users").document(user.getUid())
            .set(data, SetOptions.merge())
            .addOnCompleteListener(t -> {
                if (!isFinishing() && !isDestroyed()) {
                    session.saveGoogleProfile(name, email, photoUrl);
                    showCinematicLoading();
                }
            });
    }

    // ═════════════════════════════════════════════════════
    //  CINEMATIC LOADING OVERLAY — قبل الانتقال
    // ═════════════════════════════════════════════════════
    private void showCinematicLoading() {
        if (navigationDone) return;
        navigationDone = true;

        // Overlay بنفسجي شفاف فوق كل شيء
        FrameLayout overlay = new FrameLayout(this);
        overlay.setBackgroundColor(C_BG);
        overlay.setAlpha(0f);
        overlay.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));

        // progress circle في المنتصف
        ProgressBar pb = new ProgressBar(this);
        pb.setIndeterminate(true);
        pb.setIndeterminateTintList(
            android.content.res.ColorStateList.valueOf(C_PURPLE));
        FrameLayout.LayoutParams pbp = new FrameLayout.LayoutParams(dp(48), dp(48));
        pbp.gravity = Gravity.CENTER;
        pb.setLayoutParams(pbp);
        overlay.addView(pb);

        // أضف الـ overlay على الـ decor view
        android.view.ViewGroup decor = (android.view.ViewGroup) getWindow().getDecorView();
        decor.addView(overlay);

        // fade in الـ overlay ← انتظر 600ms ← انتقل للرئيسية
        ObjectAnimator fadeIn = ObjectAnimator.ofFloat(overlay, "alpha", 0f, 1f);
        fadeIn.setDuration(400);
        fadeIn.setInterpolator(new DecelerateInterpolator());
        fadeIn.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                overlay.postDelayed(() -> {
                    if (!isFinishing() && !isDestroyed()) navigateToMain();
                }, 500);
            }
        });
        fadeIn.start();
    }

    private void navigateToMain() {
        startActivity(new Intent(this, MainActivity.class));
        overridePendingTransition(0, 0);
        finish();
    }

    // ═════════════════════════════════════════════════════
    //  HELPERS
    // ═════════════════════════════════════════════════════
    private String buildGoogleName(FirebaseUser user) {
        return (user.getDisplayName() != null && !user.getDisplayName().isEmpty())
            ? user.getDisplayName() : getString(R.string.default_user_name);
    }

    private String buildPhotoUrl(FirebaseUser user) {
        if (user.getPhotoUrl() == null) return "";
        return user.getPhotoUrl().toString().replace("=s96-c", "=s400-c");
    }

    private void setLoadingState(boolean loading) {
        isLoading = loading;
        if (progress != null) progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        if (loginBtn != null) {
            loginBtn.setAlpha(loading ? 0.5f : 1f);
            loginBtn.setClickable(!loading);
        }
        if (codeInput != null) codeInput.setEnabled(!loading);
    }

    private void showError(String msg) {
        if (errorView == null) return;
        errorView.setText(msg);
        errorView.setVisibility(View.VISIBLE);
        errorView.setAlpha(0f);
        errorView.animate().alpha(1f).setDuration(280).start();
    }

    private void hideError() {
        if (errorView != null) errorView.setVisibility(View.GONE);
    }

    private void shakeInput() {
        if (codeInput == null) return;
        ObjectAnimator shake = ObjectAnimator.ofFloat(codeInput, "translationX",
            0f, -12f, 12f, -10f, 10f, -6f, 6f, 0f);
        shake.setDuration(420);
        shake.start();
    }

    private void showRetryHint() {
        if (loginBtn == null) return;
        loginBtn.setText(R.string.auth_retry);
        loginBtn.postDelayed(() -> {
            if (!isFinishing() && !isDestroyed() && loginBtn != null)
                loginBtn.setText(R.string.auth_login_action);
        }, 3000);
    }

    private void openTelegramBot() {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse("tg://resolve?domain=amhnak_bot")));
        } catch (Exception e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                Uri.parse(Config.TELEGRAM_BOT_URL)));
        }
    }

    // ── View factory helpers ──────────────────────────────
    private FrameLayout makeLogoWrap() {
        FrameLayout wrap = new FrameLayout(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(80), dp(80));
        lp.gravity = Gravity.CENTER_HORIZONTAL;
        lp.bottomMargin = dp(28);
        wrap.setLayoutParams(lp);
        GradientDrawable bg = new GradientDrawable(
            GradientDrawable.Orientation.TL_BR, new int[]{C_PURPLE, C_PURPLE_DK});
        bg.setCornerRadius(dp(22));
        wrap.setBackground(bg);
        TextView v = new TextView(this);
        v.setText("V"); v.setTextColor(Color.WHITE);
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, 34f);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        v.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        wrap.addView(v);
        return wrap;
    }

    private LinearLayout buildGoogleBtn() {
        LinearLayout btn = new LinearLayout(this);
        btn.setOrientation(LinearLayout.HORIZONTAL);
        btn.setGravity(Gravity.CENTER);
        btn.setPadding(0, dp(17), 0, dp(17));
        GradientDrawable bg = new GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, new int[]{C_PURPLE, C_PURPLE_DK});
        bg.setCornerRadius(dp(16));
        btn.setBackground(bg);
        btn.setClickable(true);
        btn.setFocusable(true);
        btn.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        FrameLayout gCircle = new FrameLayout(this);
        LinearLayout.LayoutParams gcp = new LinearLayout.LayoutParams(dp(28), dp(28));
        gcp.setMarginEnd(dp(10));
        gCircle.setLayoutParams(gcp);
        GradientDrawable gBg = new GradientDrawable();
        gBg.setShape(GradientDrawable.OVAL);
        gBg.setColor(0xFF4285F4);
        gCircle.setBackground(gBg);
        TextView gIcon = new TextView(this);
        gIcon.setText("G"); gIcon.setTextColor(Color.WHITE);
        gIcon.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f);
        gIcon.setTypeface(Typeface.DEFAULT_BOLD);
        gIcon.setGravity(Gravity.CENTER);
        gIcon.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        gCircle.addView(gIcon);
        btn.addView(gCircle);

        TextView label = new TextView(this);
        label.setText(R.string.auth_google_btn);
        label.setTextColor(Color.WHITE);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f);
        label.setTypeface(Typeface.DEFAULT_BOLD);
        btn.addView(label);

        // touch feedback
        btn.setOnTouchListener((v, e) -> {
            if (e.getAction() == android.view.MotionEvent.ACTION_DOWN)
                btn.setAlpha(0.75f);
            else btn.setAlpha(1f);
            return false;
        });

        return btn;
    }

    private TextView makeTv(String text, float sp, int color, int style,
                             int ml, int mt, int mr, int mb, int gravity) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextColor(color);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        tv.setTypeface(Typeface.create(Typeface.DEFAULT, style));
        tv.setGravity(gravity);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(ml, mt, mr, mb);
        tv.setLayoutParams(lp);
        return tv;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override protected void onResume() { super.onResume(); MiuiBarFix.apply(this); }
    @Override protected void onDestroy() { super.onDestroy(); MiuiBarFix.release(this); }
}

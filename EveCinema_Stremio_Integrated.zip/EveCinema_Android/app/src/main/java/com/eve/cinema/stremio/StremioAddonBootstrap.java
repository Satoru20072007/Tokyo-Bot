package com.eve.cinema.stremio;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * First-run setup for Eve Cinema's built-in Stremio sources. The defaults live locally, not in
 * Firebase; once a user removes a built-in add-on we do not silently add it again. Credentials are
 * never logged or synchronized. All manifests are fetched concurrently and individually validated.
 */
public final class StremioAddonBootstrap {
    private StremioAddonBootstrap() {}

    private static final String PREFS = "eve_stremio_bootstrap";
    private static final String DONE_PREFIX = "done_";
    private static final String ATTEMPT_PREFIX = "attempt_";
    private static final long RETRY_AFTER_MS = 15L * 60L * 1000L;
    private static final int MANIFEST_TIMEOUT_MS = 5500;
    private static final Object LOCK = new Object();
    private static final ExecutorService COORDINATOR = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "EveStremio-bootstrap"); t.setDaemon(true); return t;
    });
    private static final ExecutorService WORKERS = Executors.newFixedThreadPool(5, r -> {
        Thread t = new Thread(r, "EveStremio-default"); t.setDaemon(true); return t;
    });
    private static Future<?> inFlight;

    /** Each manifest has already been checked online on 2026-10-29; responses are still validated at runtime. */
    private static final DefaultAddon[] DEFAULTS = {
            new DefaultAddon("com.penguplay",
                    "https://pengu.uk/%7B%22auth_token%22%3A%22MP2R1Kpo7xqJczdhx--G2cHXvHQXLlDhxiTqkpaaqak%22%7D/manifest.json"),
            new DefaultAddon("org.flickystream.addon",
                    "https://flixnest.app/flix-streams/u/2uufcbc3knuy/manifest.json"),
            new DefaultAddon("com.stremio.HdHub",
                    "https://hdhub.thevolecitor.qzz.io/eyJ0b3Jib3giOiJ1bnNldCIsInF1YWxpdGllcyI6IjIxNjBwLDEwODBwLDcyMHAsNDgwcCIsInNvcnQiOiJkZXNjIiwiY2F0YWxvZ3MiOiJmZWF0dXJlZCxwb3B1bGFyIn0/manifest.json"),
            new DefaultAddon("com.cinemahome.direct",
                    "https://reelora-addon.pages.dev/a/r1_0e4d15e4a05823d6de7ae2331fd5e3b7_81898d3bb663076d269aefadd47670e508097c27743c45e4b20eef9fa262ba3d/c/eyJ2IjoxLCJwIjpbInZpZGxpbmsiLCJjaW5leHRyZWFtIiwidmlkY29yZSIsImZyYW1leHR2IiwiYm93bGVyIl0sInEiOlsyMTYwLDEwODAsNzIwLDQ4MCwzNjBdLCJkIjoxMDgwLCJmIjp0cnVlLCJzIjp0cnVlLCJsIjoiYXIiLCJiIjoiZW4ifQ/manifest.json"),
            new DefaultAddon("org.stremio.opensubtitlesv3",
                    "https://opensubtitles-v3.strem.io/manifest.json")
    };

    private static final class DefaultAddon {
        final String expectedId, url;
        DefaultAddon(String expectedId, String url) { this.expectedId = expectedId; this.url = url; }
    }

    /** Starts setup in the background; safe to call repeatedly. */
    public static void startAsync(Context context) {
        if (context == null) return;
        final Context app = context.getApplicationContext();
        synchronized (LOCK) {
            if (inFlight != null && !inFlight.isDone()) return;
            inFlight = COORDINATOR.submit(() -> seed(app));
        }
    }

    /** Waits briefly for sources to become available before a watch search builds its targets. */
    public static void await(Context context, long timeoutMs) {
        if (context == null) return;
        startAsync(context);
        Future<?> future;
        synchronized (LOCK) { future = inFlight; }
        if (future == null) return;
        try { future.get(Math.max(0L, timeoutMs), TimeUnit.MILLISECONDS); }
        catch (Exception ignored) { /* partial successful installs are retained; a slow source can't block playback */ }
    }

    private static void seed(Context context) {
        final SharedPreferences state = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        final StremioAddonStore store = new StremioAddonStore(context);
        final StremioAddonClient client = new StremioAddonClient();
        final long now = System.currentTimeMillis();
        final CountDownLatch latch = new CountDownLatch(DEFAULTS.length);
        List<Future<?>> tasks = new ArrayList<>();
        for (final DefaultAddon addon : DEFAULTS) {
            tasks.add(WORKERS.submit(() -> {
                try { installOne(addon, store, client, state, now); }
                finally { latch.countDown(); }
            }));
        }
        try { latch.await(MANIFEST_TIMEOUT_MS + 1800L, TimeUnit.MILLISECONDS); }
        catch (InterruptedException ex) { Thread.currentThread().interrupt(); }
        // Do not cancel slow tasks: a validated manifest that arrives a little late is still useful.
    }

    private static void installOne(DefaultAddon item, StremioAddonStore store, StremioAddonClient client,
                                   SharedPreferences state, long now) {
        String key = digest(item.url);
        String doneKey = DONE_PREFIX + key;
        if (state.getBoolean(doneKey, false)) return;
        for (StremioAddonStore.Addon installed : store.list()) {
            if (installed.manifestUrl.equals(item.url) || installed.manifest.id.equals(item.expectedId)) {
                // Respect an already configured/custom instance of the same add-on and explicit removals.
                state.edit().putBoolean(doneKey, true).apply();
                return;
            }
        }
        long lastAttempt = state.getLong(ATTEMPT_PREFIX + key, 0L);
        if (lastAttempt > 0 && now - lastAttempt < RETRY_AFTER_MS) return;
        state.edit().putLong(ATTEMPT_PREFIX + key, now).apply();
        try {
            String normalized = StremioAddonClient.normalizeManifestUrl(item.url);
            JSONObject json = client.fetchManifest(normalized, MANIFEST_TIMEOUT_MS);
            StremioManifest manifest = StremioManifest.parse(json);
            // Never let a redirect or unexpected endpoint replace a different built-in by accident.
            if (!item.expectedId.equals(manifest.id)) return;
            if (store.find(item.expectedId) == null) {
                store.addOrUpdateDetailed(normalized, manifest, System.currentTimeMillis());
            }
            state.edit().putBoolean(doneKey, true).remove(ATTEMPT_PREFIX + key).apply();
        } catch (IOException | JSONException | RuntimeException ignored) {
            // Kept intentionally quiet: manifest URLs can contain per-user credentials.
        }
    }

    private static String digest(String value) {
        try {
            byte[] bytes = MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder(bytes.length * 2);
            for (byte b : bytes) out.append(String.format(java.util.Locale.ROOT, "%02x", b & 0xff));
            return out.toString();
        } catch (Exception impossible) { return Integer.toHexString(value.hashCode()); }
    }
}

package com.eve.cinema.stremio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Splits options into fixed quality groups and sorts each group by measured speed, fastest first.
 * Unknown speeds remain after measured speeds; unknown is never guessed or assigned a fake number.
 */
public final class StremioOptionRanker {
    private StremioOptionRanker() {}

    public static final class Group {
        public final StremioQuality.Bucket bucket;
        public final List<StremioStreamOption> options;
        Group(StremioQuality.Bucket bucket, List<StremioStreamOption> options) {
            this.bucket = bucket;
            this.options = Collections.unmodifiableList(options);
        }
    }

    /** Non-empty groups, best quality first, unknown last. */
    public static List<Group> group(List<StremioStreamOption> options) {
        List<Group> groups = new ArrayList<>();
        for (StremioQuality.Bucket bucket : StremioQuality.Bucket.values()) {
            List<StremioStreamOption> inGroup = new ArrayList<>();
            for (StremioStreamOption o : options) if (o.bucket() == bucket) inGroup.add(o);
            Collections.sort(inGroup, new java.util.Comparator<StremioStreamOption>() {
                @Override public int compare(StremioStreamOption a, StremioStreamOption b) {
                    if (a.hasKnownSpeed() != b.hasKnownSpeed()) return a.hasKnownSpeed() ? -1 : 1;
                    if (!a.hasKnownSpeed()) return 0;
                    return Double.compare(b.speedMbps, a.speedMbps);
                }
            });
            if (!inGroup.isEmpty()) groups.add(new Group(bucket, inGroup));
        }
        return groups;
    }

    /** All options flattened in group order (the order the UI lists them). */
    public static List<StremioStreamOption> rank(List<StremioStreamOption> options) {
        List<StremioStreamOption> flat = new ArrayList<>(options.size());
        for (Group g : group(options)) flat.addAll(g.options);
        return flat;
    }
}

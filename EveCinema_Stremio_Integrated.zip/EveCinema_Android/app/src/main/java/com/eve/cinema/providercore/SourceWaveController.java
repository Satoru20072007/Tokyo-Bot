package com.eve.cinema.providercore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * SourceWaveController — منسّق موجات المصادر (وحدة §4.1 وخطة §10).
 *
 *  - موجة أولى بمهلة ناعمة ثم موجة ثانية فور انتهائها دون انتظار إعادة
 *    المحاولة الطويلة (§6.3.2).
 *  - حد أعلى للتزامن (5–6 افتراضياً)؛ الموجة الأولى المستمرة في الخلفية
 *    تُدمج نتائجها المتأخرة إن بقيت صالحة ولا توقف بقية المصادر.
 *  - الإلغاء لا يُسجَّل فشلاً للمصدر (§10.3) ولا يفتح قاطعه.
 *  - فشل مصدر واحد لا يوقف أي Adapter آخر (قرار رقم 6).
 *
 * Pure Java, executor/clock-injectable — unit-tested on the JVM.
 */
public final class SourceWaveController {

    public interface Clock { long nowMillis(); }

    public static final long DEFAULT_SOFT_TIMEOUT_MS = Tuning.SOURCE_SOFT_TIMEOUT_MS;
    public static final long DEFAULT_HARD_BUDGET_MS  = Tuning.SOURCE_HARD_BUDGET_MS;
    public static final int  DEFAULT_MAX_CONCURRENCY = Tuning.SOURCE_MAX_CONCURRENCY;

    /** نتيجة مزوّد واحد داخل الجولة. */
    public static final class WaveResult {
        public final String providerId;
        public final ProviderResultState state;
        public final List<NormalizedCandidate> candidates;
        public final int wave;           // 1 أو 2
        public final boolean lateArrival; // وصلت بعد المهلة الناعمة
        public final long elapsedMs;

        WaveResult(String providerId, ProviderResultState state,
                   List<NormalizedCandidate> candidates, int wave,
                   boolean lateArrival, long elapsedMs) {
            this.providerId = providerId;
            this.state = state;
            this.candidates = candidates == null
                    ? Collections.<NormalizedCandidate>emptyList() : candidates;
            this.wave = wave;
            this.lateArrival = lateArrival;
            this.elapsedMs = elapsedMs;
        }
    }

    public interface Listener {
        /** تُستدعى فور اكتمال نتيجة أي مصدر (نتائج مؤكدة مبكراً — §1.3). */
        void onResult(WaveResult result);
    }

    private final ProviderRegistry registry;
    private final ProviderHealthStore health;
    private final ExecutorService executor;
    private final Clock clock;
    private final long softTimeoutMs;
    private final long hardBudgetMs;
    private final int maxConcurrency;

    public SourceWaveController(ProviderRegistry registry, ProviderHealthStore health,
                                ExecutorService executor, Clock clock,
                                long softTimeoutMs, long hardBudgetMs, int maxConcurrency) {
        this.registry = registry;
        this.health = health;
        this.executor = executor;
        this.clock = clock == null ? System::currentTimeMillis : clock;
        this.softTimeoutMs = softTimeoutMs > 0 ? softTimeoutMs : DEFAULT_SOFT_TIMEOUT_MS;
        this.hardBudgetMs = hardBudgetMs > 0 ? hardBudgetMs : DEFAULT_HARD_BUDGET_MS;
        this.maxConcurrency = maxConcurrency > 0 ? maxConcurrency : DEFAULT_MAX_CONCURRENCY;
    }

    public static SourceWaveController createDefault(ProviderRegistry registry,
                                                     ProviderHealthStore health) {
        ExecutorService ex = Executors.newCachedThreadPool(r -> {
            Thread t = new Thread(r, "eve-wave");
            t.setDaemon(true);
            return t;
        });
        return new SourceWaveController(registry, health, ex, System::currentTimeMillis,
                DEFAULT_SOFT_TIMEOUT_MS, DEFAULT_HARD_BUDGET_MS, DEFAULT_MAX_CONCURRENCY);
    }

    /**
     * جولة اكتشاف كاملة لهوية واحدة. ترجع كل النتائج المرتبة زمنياً، وتستدعي
     * listener فورياً. نشر مبكر (§1.3): حين توجد نتيجة قابلة للعرض بعد المهلة
     * الناعمة ترجع الجولة فوراً ولا تحتجزها مصادر بطيئة؛ يبقى مراقب خلفي يلغي
     * ما تبقى عند نفاد الميزانية الصلبة، وتُدمج النتائج المتأخرة عبر listener
     * حتى ذلك الحد (§6.3.2). الإلغاء لا يحسب عطلاً.
     */
    public List<WaveResult> run(CanonicalMediaIdentity identity, Listener listener) {
        long start = clock.nowMillis();
        List<WaveResult> ordered = Collections.synchronizedList(new ArrayList<>());
        AtomicBoolean softExpired = new AtomicBoolean(false);
        AtomicInteger inFlight = new AtomicInteger(0);
        List<Future<?>> futures = new ArrayList<>();

        List<ProviderAdapter> wave1 = registry.wave1();
        List<ProviderAdapter> wave2 = registry.wave2();

        // الموجة الأولى: تُطلق فوراً بمهلة ناعمة.
        for (ProviderAdapter a : wave1)
            futures.add(submit(identity, a, 1, softExpired, ordered, listener, inFlight, start));

        // مراقبة المهلة الناعمة: عند انتهائها دون نتيجة قابلة للعرض تُطلق
        // الموجة الثانية — دون انتظار استكمال الموجة الأولى.
        boolean wave2Launched = false;
        boolean earlyPublish = false;
        while (clock.nowMillis() - start < hardBudgetMs) {
            if (!softExpired.get() && clock.nowMillis() - start >= softTimeoutMs) {
                softExpired.set(true);
                if (!hasDisplayable(ordered)) {
                    for (ProviderAdapter a : wave2)
                        futures.add(submit(identity, a, 2, softExpired, ordered, listener, inFlight, start));
                    wave2Launched = true;
                }
            }
            if (allDone(futures)) break;
            // §1.3: النتيجة المؤكدة تُنشر مبكراً ولا يمنعها مصدر بطيء واحد.
            if (softExpired.get() && hasDisplayable(ordered)) { earlyPublish = true; break; }
            sleep(25);
        }
        // نتيجة مبكرة من الموجة الأولى لا تحجب الموجة الثانية إن لم يوجد
        // مرشح قابل للعرض بعد — لكن الميزانية الصلبة هي الحد الأخير.
        if (!earlyPublish && !wave2Launched && !hasDisplayable(ordered) && !allDone(futures)) {
            softExpired.set(true);
            for (ProviderAdapter a : wave2)
                futures.add(submit(identity, a, 2, softExpired, ordered, listener, inFlight, start));
            while (clock.nowMillis() - start < hardBudgetMs && !allDone(futures)) {
                if (hasDisplayable(ordered)) { earlyPublish = true; break; }
                sleep(25);
            }
        }

        if (earlyPublish) {
            // نشر مبكر: لا نلغي المتبقي فوراً حتى تُدمج النتائج المتأخرة عبر
            // listener؛ مراقب خلفي يفرض الميزانية الصلبة ثم يلغي — والإلغاء
            // لا يُسجَّل في الصحة (§10.3).
            scheduleHardCancel(futures, start);
            return new ArrayList<>(ordered);
        }

        // نفاد الميزانية: إلغاء الباقي — الإلغاء لا يُسجَّل في الصحة.
        for (Future<?> f : futures) if (!f.isDone()) f.cancel(true);
        return new ArrayList<>(ordered);
    }

    /** إلغاء المتبقي عند نفاد الميزانية الصلبة بعد نشر مبكر (§10.2). */
    private void scheduleHardCancel(List<Future<?>> futures, long start) {
        final long remaining = hardBudgetMs - (clock.nowMillis() - start);
        if (remaining <= 0L) {
            for (Future<?> f : futures) if (!f.isDone()) f.cancel(true);
            return;
        }
        Thread watchdog = new Thread(() -> {
            try { Thread.sleep(remaining); } catch (InterruptedException ignored) { }
            for (Future<?> f : futures) if (!f.isDone()) f.cancel(true);
        }, "eve-wave-watchdog");
        watchdog.setDaemon(true);
        watchdog.start();
    }

    private Future<?> submit(CanonicalMediaIdentity identity, ProviderAdapter adapter, int wave,
                             AtomicBoolean softExpired, List<WaveResult> ordered,
                             Listener listener, AtomicInteger inFlight, long start) {
        // حد التزامن بسيط: انتظار خانة فارغة ضمن الميزانية.
        return executor.submit((Callable<Void>) () -> {
            while (inFlight.get() >= maxConcurrency) {
                if (clock.nowMillis() - start >= hardBudgetMs) return null;
                sleep(10);
            }
            inFlight.incrementAndGet();
            long t0 = clock.nowMillis();
            String id = adapter.id();
            try {
                ProviderResultState preflight;
                try {
                    preflight = adapter.preflight(identity);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    return null;
                }
                if (preflight != null) {
                    emit(ordered, listener, new WaveResult(id, preflight,
                            null, wave, softExpired.get(), clock.nowMillis() - t0));
                    return null;
                }
                if (!health.tryAcquireProvider(id)) {
                    emit(ordered, listener, new WaveResult(id, ProviderResultState.UNREACHABLE,
                            null, wave, softExpired.get(), clock.nowMillis() - t0));
                    return null;
                }
                ProviderAdapter.ProbeResult probe;
                try {
                    probe = adapter.probe(identity);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    return null; // إلغاء — لا تسجيل صحة
                } catch (Exception e) {
                    probe = ProviderAdapter.ProbeResult.of(ProviderResultState.FAILED);
                }
                ProviderResultState state = probe.state;
                List<NormalizedCandidate> found = Collections.emptyList();
                if (state != ProviderResultState.CANCELLED) {
                    health.recordProvider(id, state);
                }
                if (state != ProviderResultState.CANCELLED
                        && state != ProviderResultState.UNREACHABLE
                        && state != ProviderResultState.TIMEOUT
                        && state != ProviderResultState.NETWORK_NOT_ELIGIBLE
                        && state != ProviderResultState.AUTH_REQUIRED
                        && state != ProviderResultState.FAILED) {
                    try {
                        found = adapter.candidates(identity);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        return null;
                    } catch (ProviderAdapter.ProviderException pe) {
                        state = pe.classification;
                        health.recordProvider(id, state);
                    } catch (Exception e) {
                        state = ProviderResultState.FAILED;
                        health.recordProvider(id, state);
                    }
                }
                emit(ordered, listener, new WaveResult(id, state, found, wave,
                        softExpired.get(), clock.nowMillis() - t0));
            } finally {
                inFlight.decrementAndGet();
            }
            return null;
        });
    }

    private static void emit(List<WaveResult> ordered, Listener listener, WaveResult r) {
        ordered.add(r);
        if (listener != null) {
            try { listener.onResult(r); } catch (Throwable ignored) {}
        }
    }

    private static boolean hasDisplayable(List<WaveResult> results) {
        synchronized (results) {
            for (WaveResult r : results) {
                // نتيجة فحص مثبتة (adapters مرحلة الفحص) تكفي للنشر المبكر،
                // كما يكفي مرشح مثبت من مرحلة الروابط.
                if (r.state != null && r.state.isDisplayable()) return true;
                for (NormalizedCandidate c : r.candidates)
                    if (c.validationStatus() == ProviderResultState.VERIFIED_PLAYABLE) return true;
            }
        }
        return false;
    }

    private static boolean allDone(List<Future<?>> futures) {
        for (Future<?> f : futures) if (!f.isDone()) return false;
        return !futures.isEmpty();
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
    }
}

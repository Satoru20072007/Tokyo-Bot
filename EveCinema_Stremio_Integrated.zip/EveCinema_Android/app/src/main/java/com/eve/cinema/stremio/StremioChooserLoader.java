package com.eve.cinema.stremio;

import android.content.Context;

import com.eve.cinema.Config;
import com.eve.cinema.NetworkUtil;
import com.eve.cinema.TmdbAuthorization;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Android glue for the Stremio search: reads the add-on list, resolves the IMDb id that stream
 * add-ons expect, starts the progressive {@link StremioSearchEngine} and feeds a
 * {@link StremioChooserSession.Entry}. All decisions live in pure classes (and are unit tested);
 * this class only wires them to the device.
 */
public final class StremioChooserLoader {
    private StremioChooserLoader() {}

    private static final int IMDB_LOOKUP_TIMEOUT_MS = 3500;
    private static final StremioSearchEngine.Gateway GATEWAY = new StremioAddonGateway();
    private static volatile StremioIdResolver resolver;

    /**
     * Starts (or restarts) the search for {@code entry}. Returns immediately; results arrive as
     * snapshots on {@code entry}. Safe to call again for "try again".
     */
    public static void start(final Context context, final StremioChooserSession.Entry entry) {
        final Context app = context.getApplicationContext();
        final int epoch = entry.restart();
        final Thread worker = new Thread(new Runnable() {
            @Override public void run() { runSearch(app, entry, epoch); }
        }, "stremio-start");
        worker.setDaemon(true);
        worker.start();
    }

    private static void runSearch(Context app, final StremioChooserSession.Entry entry, final int epoch) {
        try {
            StremioAddonBootstrap.await(app, 6500L);
            StremioContentRef ref = "movie".equals(entry.type)
                    ? StremioContentRef.movie(entry.tmdbId)
                    : StremioContentRef.episode(entry.tmdbId, entry.season, entry.episode, entry.type);
            List<StremioAddonStore.Addon> addons = new StremioAddonStore(app).list();
            // Only look the IMDb id up when at least one add-on could use it but cannot take the TMDB id.
            boolean needsImdb = false;
            for (StremioAddonStore.Addon addon : addons) {
                if (!addon.usable()) continue;
                if (ref.idFor(addon.manifest, StremioManifest.STREAM) == null
                        && ref.couldBeServedBy(addon.manifest, StremioManifest.STREAM)) needsImdb = true;
                if (ref.idFor(addon.manifest, StremioManifest.SUBTITLES) == null
                        && ref.couldBeServedBy(addon.manifest, StremioManifest.SUBTITLES)) needsImdb = true;
            }
            if (needsImdb) ref = ref.withImdb(resolver().resolveImdb(ref.type, ref.tmdbId, IMDB_LOOKUP_TIMEOUT_MS));
            List<StremioSearchEngine.Target> targets = StremioSearchEngine.buildTargets(addons, ref);
            if (StremioSearchEngine.idUnavailable(addons, ref, targets)) {
                entry.update(new StremioChooserData(1L, StremioChooserData.State.EMPTY,
                        StremioChooserData.EmptyReason.ID_UNAVAILABLE,
                        java.util.Collections.<StremioStreamOption>emptyList(),
                        java.util.Collections.<StremioSubtitle>emptyList(), StremioChooserData.Progress.NONE), epoch);
                return;
            }
            final Context ctx = app;
            StremioSearchEngine engine = StremioSearchEngine.production(GATEWAY,
                    new StremioSearchEngine.Connectivity() {
                        @Override public boolean isOnline() { return NetworkUtil.hasInternet(ctx); }
                    });
            StremioSearchEngine.Handle handle = engine.start(ref.type, targets, new StremioSearchEngine.Listener() {
                @Override public void onSnapshot(StremioChooserData data) { entry.update(data, epoch); }
            });
            entry.attach(handle, epoch);
        } catch (RuntimeException ex) {
            entry.update(new StremioChooserData(1L, StremioChooserData.State.FAILED,
                    StremioChooserData.EmptyReason.ALL_FAILED,
                    java.util.Collections.<StremioStreamOption>emptyList(),
                    java.util.Collections.<StremioSubtitle>emptyList(), StremioChooserData.Progress.NONE), epoch);
        }
    }

    private static StremioIdResolver resolver() {
        StremioIdResolver r = resolver;
        if (r == null) {
            r = new StremioIdResolver(new StremioIdResolver.Fetcher() {
                @Override public String get(String url, int timeoutMs) throws IOException {
                    HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                    try {
                        c.setInstanceFollowRedirects(false);
                        c.setConnectTimeout(timeoutMs);
                        c.setReadTimeout(timeoutMs);
                        c.setRequestProperty("Accept", "application/json");
                        TmdbAuthorization.apply(c, Config.TMDB_BEARER_TOKEN);
                        if (c.getResponseCode() != 200) throw new IOException("status");
                        try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                            byte[] buffer = new byte[4096];
                            int n, total = 0;
                            while ((n = in.read(buffer)) != -1) {
                                total += n;
                                if (total > 64 * 1024) throw new IOException("too large");
                                out.write(buffer, 0, n);
                            }
                            return new String(out.toByteArray(), StandardCharsets.UTF_8);
                        }
                    } finally {
                        c.disconnect();
                    }
                }
            }, Config.TMDB_BASE_URL);
            resolver = r;
        }
        return r;
    }
}

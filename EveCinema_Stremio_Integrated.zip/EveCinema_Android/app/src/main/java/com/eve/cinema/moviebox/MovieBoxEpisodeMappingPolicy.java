package com.eve.cinema.moviebox;

/** Conservative policy when the provider exposes no episode title/date crosswalk. */
public final class MovieBoxEpisodeMappingPolicy {
    private MovieBoxEpisodeMappingPolicy() {}
    public static boolean mayResolveByExactProviderNumberPair(boolean anime, boolean exactSeasonEpisodeExists) {
        return !anime && exactSeasonEpisodeExists;
    }
    public static boolean requiresExplicitUserConfirmation(boolean tmdbCrosswalkVerified) {
        return !tmdbCrosswalkVerified;
    }
}

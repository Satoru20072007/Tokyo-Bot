package com.eve.cinema;

/**
 * CinemaBoxCredentials — المحطة 0 من خريطة الطريق.
 *
 * بيانات دخول CinemaBox لم تعد نصاً ثابتاً داخل Config.java (كانت تنحمل داخل
 * أي APK يُنشر). تُحقن في وقت التشغيل من مخزن آمن (EncryptedSharedPreferences
 * عبر UserSession/Applications) بعد أن يسجّل المستخدم دخوله بحسابه الخاص.
 *
 * القواعد:
 *  - لا قيمة افتراضية ولا fallback ثابت هنا.
 *  - لا تُمرر القيم إلى السجلات أو التشخيص.
 *  - isConfigured() هو الفحص الوحيد المسموح قبل login.
 *
 * Pure Java holder — the Android-side installer lives in UserSession.
 */
public final class CinemaBoxCredentials {

    private static volatile String email;
    private static volatile String password;

    private CinemaBoxCredentials() {}

    /** يستدعيه مسار تسجيل الدخول بعد استلام القيم من المخزن الآمن. */
    public static synchronized void install(String emailValue, String passwordValue) {
        email = (emailValue == null || emailValue.trim().isEmpty()) ? null : emailValue.trim();
        password = (passwordValue == null || passwordValue.isEmpty()) ? null : passwordValue;
    }

    /** تُستدعى عند تسجيل الخروج أو تدوير الحساب. */
    public static synchronized void clear() {
        email = null;
        password = null;
    }

    public static boolean isConfigured() {
        return email != null && password != null;
    }

    /**
     * يعيد البريد وكلمة المرور لمسار login فقط.
     *
     * @throws IllegalStateException إن لم تُثبَّت البيانات — على الواجهة حينها
     *         فتح شاشة إدخال حساب CinemaBox بدل أي قيمة مضمّنة.
     */
    public static synchronized String email() {
        if (!isConfigured())
            throw new IllegalStateException("CinemaBox credentials not installed — prompt the user");
        return email;
    }

    public static synchronized String password() {
        if (!isConfigured())
            throw new IllegalStateException("CinemaBox credentials not installed — prompt the user");
        return password;
    }
}

package com.eve.cinema;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * ══════════════════════════════════════════════════════════
 *  TokenManager.java — نظام التحقق من التوكن وربط الجهاز
 *
 *  يستقبل التوكن من Deep Link: eve-cinema://play?token=XYZ
 *  يتحقق منه عبر: POST /api/v1/verify_token
 *  يحفظ حالة التفعيل في SharedPreferences
 * ══════════════════════════════════════════════════════════
 */
public class TokenManager {

    private static final String PREFS_NAME  = "eve_cinema_prefs";
    private static final String KEY_TOKEN   = "active_token";
    private static final String KEY_DEVICE  = "device_id";
    private static final String KEY_VALID   = "is_valid";

    private final SharedPreferences prefs;
    private final String deviceId;

    public TokenManager(Context ctx) {
        this.prefs    = ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        this.deviceId = getDeviceId(ctx);
    }

    /**
     * الحصول على Android ID كمعرّف الجهاز
     * (لا يحتاج صلاحية READ_PHONE_STATE على API 26+)
     */
    private String getDeviceId(Context ctx) {
        String saved = prefs.getString(KEY_DEVICE, null);
        if (saved != null) return saved;

        String id = Settings.Secure.getString(
            ctx.getContentResolver(),
            Settings.Secure.ANDROID_ID
        );
        if (id == null || id.isEmpty()) {
            id = java.util.UUID.randomUUID().toString();
        }
        prefs.edit().putString(KEY_DEVICE, id).apply();
        return id;
    }

    public String getDeviceId() {
        return deviceId;
    }

    /**
     * هل التطبيق مفعّل حالياً؟
     */
    public boolean isActivated() {
        if (!Config.REQUIRE_TOKEN) return true; // وضع التطوير
        return prefs.getBoolean(KEY_VALID, false);
    }

    /**
     * حفظ التوكن محلياً
     */
    public void saveToken(String token) {
        prefs.edit()
            .putString(KEY_TOKEN, token)
            .apply();
    }

    public String getSavedToken() {
        return prefs.getString(KEY_TOKEN, null);
    }

    /**
     * التحقق من التوكن عبر API السيرفر
     * يُشغَّل في خيط منفصل — لا تستدعيه من الـ Main Thread
     *
     * @param token التوكن القادم من Deep Link
     * @return true إذا كان التوكن صحيحاً
     */
    public boolean verifyToken(String token) {
        if (!Config.REQUIRE_TOKEN) return true;
        if (token == null || token.isEmpty()) return false;

        try {
            String urlStr = Config.API_VERIFY +
                "?token=" + token +
                "&device_id=" + deviceId;

            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(10_000);
            conn.setReadTimeout(10_000);
            conn.setRequestProperty("Accept", "application/json");

            int code = conn.getResponseCode();
            if (code == 200) {
                BufferedReader br = new BufferedReader(
                    new InputStreamReader(conn.getInputStream())
                );
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();

                JSONObject json = new JSONObject(sb.toString());
                boolean valid = json.optBoolean("valid", false);

                if (valid) {
                    prefs.edit()
                        .putBoolean(KEY_VALID, true)
                        .putString(KEY_TOKEN, token)
                        .apply();
                    return true;
                }
            }
        } catch (Exception e) {
            // في حالة فشل الشبكة، نسمح بالمشاهدة (graceful fallback)
            // غيّر هذا السلوك في الإنتاج إذا أردت منع الوصول بدون إنترنت
            return isActivated();
        }

        prefs.edit().putBoolean(KEY_VALID, false).apply();
        return false;
    }

    /**
     * إلغاء التفعيل (للاستخدام في صفحة الإعدادات)
     */
    public void deactivate() {
        prefs.edit()
            .remove(KEY_TOKEN)
            .putBoolean(KEY_VALID, false)
            .apply();
    }
}

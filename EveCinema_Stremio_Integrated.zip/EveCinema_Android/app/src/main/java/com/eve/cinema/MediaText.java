package com.eve.cinema;

import android.content.res.Resources;
import android.view.Gravity;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * MediaText — نصوص عناصر TMDB + اتجاه المحتوى (عربي/إنجليزي).
 * ────────────────────────────────────────────────────────────────
 * - org.json.optString يرجّع الكلمة "null" عند JSONObject.NULL، فنفلتر هنا مرة واحدة
 *   بدل تكرار الفحص في كل مكان (كان يسبّب تحميل صور من روابط تنتهي بـ "null").
 * - التطبيق LTR بالكامل (supportsRtl=false)، لذلك اتجاه "المحتوى" يُحدَّد من أول حرف قوي
 *   في النص نفسه، ونستخدم gravity مطلقة (LEFT/RIGHT) لأن textAlignment يُتجاهَل في
 *   وضع RTL-compat.
 */
final class MediaText {

    private MediaText() {}

    static String str(JSONObject o, String key) {
        if (o == null) return "";
        String s = o.optString(key, "");
        return "null".equals(s) ? "" : s;
    }

    static String title(JSONObject item) {
        String t = str(item, "title");
        if (t.isEmpty()) t = str(item, "name");
        if (t.isEmpty()) t = str(item, "original_title");
        if (t.isEmpty()) t = str(item, "original_name");
        return t;
    }

    static String year(JSONObject item) {
        String d = str(item, "release_date");
        if (d.isEmpty()) d = str(item, "first_air_date");
        return d.length() >= 4 ? d.substring(0, 4) : "";
    }

    /** true إذا أول حرف "قوي" في النص عربي/عبري (RTL). */
    static boolean isRtl(CharSequence s) {
        if (s == null) return false;
        final int n = s.length();
        for (int i = 0; i < n; ) {
            final int cp = Character.codePointAt(s, i);
            final byte d = Character.getDirectionality(cp);
            if (d == Character.DIRECTIONALITY_RIGHT_TO_LEFT
                    || d == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC) return true;
            if (d == Character.DIRECTIONALITY_LEFT_TO_RIGHT) return false;
            i += Character.charCount(cp);
        }
        return false;
    }

    /** محاذاة مطلقة حسب اتجاه المحتوى مع الحفاظ على الـ gravity العمودي. */
    static void align(TextView tv, boolean rtl) {
        final int vertical = tv.getGravity() & Gravity.VERTICAL_GRAVITY_MASK;
        tv.setGravity((rtl ? Gravity.RIGHT : Gravity.LEFT) | vertical);
    }

    /** اسم أول نوع (genre) من genre_ids — مترجم عبر arrays.xml / values-ar. */
    static String firstGenre(Resources res, JSONObject item) {
        final JSONArray ids = item == null ? null : item.optJSONArray("genre_ids");
        if (ids == null || ids.length() == 0) return "";
        final int[] keys = res.getIntArray(R.array.tmdb_genre_ids);
        final String[] names = res.getStringArray(R.array.tmdb_genre_names);
        final int id = ids.optInt(0, -1);
        final int n = Math.min(keys.length, names.length);
        for (int i = 0; i < n; i++) if (keys[i] == id) return names[i];
        return "";
    }

    /** تسمية نوع المحتوى (فيلم/مسلسل/أنمي). */
    static String typeLabel(Resources res, String mediaType) {
        if ("tv".equals(mediaType))    return res.getString(R.string.type_series);
        if ("anime".equals(mediaType)) return res.getString(R.string.type_anime);
        return res.getString(R.string.type_movie);
    }
}

package com.eve.cinema;

import androidx.recyclerview.widget.DiffUtil;

import org.json.JSONObject;

import java.util.List;

/**
 * EpisodeDiffCallback
 * ═══════════════════
 * Used by the episode paginator to compute minimal diffs
 * when switching seasons or appending pages.
 *
 * Rules:
 * - Two episodes are the SAME item if episode_number matches.
 * - Two episodes have the SAME content if name + number match.
 *
 * This avoids notifyDataSetChanged() which causes full redraws,
 * and instead uses fine-grained notifyItemRangeInserted / Removed.
 *
 * NOTE: For pagination appends, DiffUtil is overkill — we use
 * notifyItemRangeInserted directly. DiffUtil is used only for
 * full season swaps where the list changes significantly.
 */
public class EpisodeDiffCallback extends DiffUtil.Callback {

    private final List<JSONObject> oldList;
    private final List<JSONObject> newList;

    public EpisodeDiffCallback(List<JSONObject> oldList, List<JSONObject> newList) {
        this.oldList = oldList;
        this.newList = newList;
    }

    @Override
    public int getOldListSize() {
        return oldList != null ? oldList.size() : 0;
    }

    @Override
    public int getNewListSize() {
        return newList != null ? newList.size() : 0;
    }

    @Override
    public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
        try {
            int oldNum = oldList.get(oldItemPosition).optInt("episode_number", -1);
            int newNum = newList.get(newItemPosition).optInt("episode_number", -2);
            return oldNum == newNum && oldNum >= 0;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
        try {
            JSONObject oldEp = oldList.get(oldItemPosition);
            JSONObject newEp = newList.get(newItemPosition);
            int oldNum  = oldEp.optInt("episode_number", -1);
            int newNum  = newEp.optInt("episode_number", -2);
            String oldName = oldEp.optString("name", "");
            String newName = newEp.optString("name", "");
            return oldNum == newNum && oldName.equals(newName);
        } catch (Exception e) {
            return false;
        }
    }
}

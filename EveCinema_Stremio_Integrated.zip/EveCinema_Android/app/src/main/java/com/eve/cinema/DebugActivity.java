package com.eve.cinema;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * DebugActivity — شاشة الخطأ غير المتوقع
 * ─────────────────────────────────────────────────────────────────────
 * كانت AlertDialog نظامي بواجهة فاتحة ونص إنجليزي ("An error occured")
 * — خارج تماماً عن لغة التطبيق الداكنة. الآن سطح داكن بنفس الهوية:
 * أيقونة تحذير داخل tile زجاجي أحمر خافت + رسالة عربية واضحة +
 * التفاصيل التقنية في بطاقة قابلة للتمرير + زر إنهاء بنفس لغة الأزرار.
 * منطق تحليل الخطأ (exceptionType/errMessage) محفوظ كما هو.
 * ─────────────────────────────────────────────────────────────────────
 */
public class DebugActivity extends Activity {

	private static final int C_BG      = 0xFF08080F;
	private static final int C_CARD    = 0xFF101022;
	private static final int C_BORDER  = 0xFF22223A;
	private static final int C_TEXT    = 0xFFFFFFFF;
	private static final int C_MUTED   = 0xFF8C8CA6;
	private static final int C_FAINT   = 0xFF5A5A78;
	private static final int C_RED     = 0xFFF87171;
	private static final int C_RED_BG  = 0x14F87171;
	private static final int C_RED_BR  = 0x40F87171;
	private static final int C_VIOLET  = 0xFF9B6FC4;
	private static final int C_VIOLET2 = 0xFF7C4FA0;

	String[] exceptionType = {
			"StringIndexOutOfBoundsException",
			"IndexOutOfBoundsException",
			"ArithmeticException",
			"NumberFormatException",
			"ActivityNotFoundException"
	};
	String[] errMessage= {
			"Invalid string operation\n",
			"Invalid list operation\n",
			"Invalid arithmetical operation\n",
			"Invalid toNumber block operation\n",
			"Invalid intent operation"
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);

		String errMsg = "";
		String madeErrMsg = "";
		Intent intent = getIntent();
		if (intent != null) {
			errMsg = intent.getStringExtra("error");
			if (errMsg == null) errMsg = "";
			String[] spilt = errMsg.split("\n");
			try {
				for (int j = 0; j < exceptionType.length; j++) {
					if (spilt[0].contains(exceptionType[j])) {
						madeErrMsg = errMessage[j];
						int addIndex = spilt[0].indexOf(exceptionType[j]) + exceptionType[j].length();
						madeErrMsg += spilt[0].substring(addIndex);
						break;
					}
				}
				if (madeErrMsg.isEmpty()) madeErrMsg = errMsg;
			} catch (Exception e) {
				madeErrMsg = errMsg;
			}
		}
		if (madeErrMsg.trim().isEmpty()) madeErrMsg = "Unknown error";

		setContentView(buildUI(madeErrMsg.trim()));
	}

	// ══════════════════════════════════════════════════════════════════
	//  UI — dark, on-brand
	// ══════════════════════════════════════════════════════════════════
	private View buildUI(String details) {
		FrameLayout root = new FrameLayout(this);
		root.setBackgroundColor(C_BG);

		// هالة حمراء خافتة جداً أعلى الشاشة (عمق بدون صخب)
		View halo = new View(this);
		FrameLayout.LayoutParams haloLp = new FrameLayout.LayoutParams(dp(300), dp(300));
		haloLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
		haloLp.topMargin = -dp(190);
		halo.setLayoutParams(haloLp);
		GradientDrawable haloBg = new GradientDrawable();
		haloBg.setShape(GradientDrawable.OVAL);
		haloBg.setGradientType(GradientDrawable.RADIAL_GRADIENT);
		haloBg.setColors(new int[]{ 0x33F87171, 0x00F87171 });
		haloBg.setGradientRadius(dp(150));
		halo.setBackground(haloBg);
		root.addView(halo);

		LinearLayout col = new LinearLayout(this);
		col.setOrientation(LinearLayout.VERTICAL);
		col.setGravity(Gravity.CENTER_HORIZONTAL);
		col.setPadding(dp(28), dp(64), dp(28), dp(40));
		root.addView(col, new FrameLayout.LayoutParams(
			FrameLayout.LayoutParams.MATCH_PARENT,
			FrameLayout.LayoutParams.MATCH_PARENT));

		// أيقونة التحذير — tile زجاجي بلون الخطأ
		FrameLayout iconTile = new FrameLayout(this);
		LinearLayout.LayoutParams itLp = new LinearLayout.LayoutParams(dp(72), dp(72));
		itLp.bottomMargin = dp(22);
		iconTile.setLayoutParams(itLp);
		GradientDrawable tileBg = new GradientDrawable();
		tileBg.setCornerRadius(dp(22));
		tileBg.setColor(C_RED_BG);
		tileBg.setStroke(dp(1), C_RED_BR);
		iconTile.setBackground(tileBg);
		ImageView icon = new ImageView(this);
		FrameLayout.LayoutParams icLp = new FrameLayout.LayoutParams(dp(30), dp(30));
		icLp.gravity = Gravity.CENTER;
		icon.setLayoutParams(icLp);
		icon.setImageResource(R.drawable.ic_info_outline);
		icon.setColorFilter(C_RED);
		iconTile.addView(icon);
		col.addView(iconTile);

		// العنوان
		TextView title = tv("حدث خطأ غير متوقع", 20f, C_TEXT, Typeface.BOLD);
		title.setGravity(Gravity.CENTER);
		col.addView(title);

		TextView sub = tv("نعتذر — توقف التطبيق عن العمل.\nيمكنك إعادة فتحه ومتابعة المشاهدة.",
			13f, C_MUTED, Typeface.NORMAL);
		sub.setGravity(Gravity.CENTER);
		sub.setLineSpacing(dp(3), 1f);
		LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
		subLp.topMargin = dp(10);
		subLp.bottomMargin = dp(26);
		sub.setLayoutParams(subLp);
		col.addView(sub);

		// بطاقة التفاصيل التقنية (قابلة للتمرير)
		ScrollView sv = new ScrollView(this);
		sv.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		LinearLayout.LayoutParams svLp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f);
		svLp.bottomMargin = dp(22);
		sv.setLayoutParams(svLp);
		GradientDrawable cardBg = new GradientDrawable();
		cardBg.setCornerRadius(dp(16));
		cardBg.setColor(C_CARD);
		cardBg.setStroke(dp(1), C_BORDER);
		sv.setBackground(cardBg);

		TextView detail = new TextView(this);
		detail.setText(details);
		detail.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
		detail.setTextColor(C_FAINT);
		detail.setTypeface(Typeface.MONOSPACE);
		detail.setLineSpacing(dp(2), 1.35f);
		detail.setPadding(dp(16), dp(14), dp(16), dp(14));
		detail.setTextIsSelectable(true);
		detail.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
		sv.addView(detail);
		col.addView(sv);

		// زر الإنهاء — نفس لغة الأزرار الأساسية
		TextView endBtn = tv("إنهاء التطبيق", 15f, C_TEXT, Typeface.BOLD);
		endBtn.setGravity(Gravity.CENTER);
		endBtn.setLetterSpacing(0f);
		LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(
			LinearLayout.LayoutParams.MATCH_PARENT, dp(54));
		endBtn.setLayoutParams(btnLp);
		GradientDrawable btnBg = new GradientDrawable(
			GradientDrawable.Orientation.TL_BR, new int[]{ C_VIOLET, C_VIOLET2 });
		btnBg.setCornerRadius(dp(16));
		endBtn.setBackground(btnBg);
		endBtn.setClickable(true);
		endBtn.setFocusable(true);
		endBtn.setOnTouchListener((v, e) -> {
			if (e.getAction() == android.view.MotionEvent.ACTION_DOWN) v.setAlpha(0.8f);
			else if (e.getAction() == android.view.MotionEvent.ACTION_UP
					|| e.getAction() == android.view.MotionEvent.ACTION_CANCEL) v.setAlpha(1f);
			return false;
		});
		endBtn.setOnClickListener(v -> finishAffinity());
		col.addView(endBtn);

		return root;
	}

	private TextView tv(String text, float sp, int color, int style) {
		TextView t = new TextView(this);
		t.setText(text);
		t.setTextColor(color);
		t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
		t.setTypeface(Typeface.create(Typeface.DEFAULT, style));
		return t;
	}

	private int dp(int d) {
		return Math.round(d * getResources().getDisplayMetrics().density);
	}
}

package com.eve.cinema.stremio;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Short-lived, memory-only state for the "choose how to watch" flow: the live search snapshot,
 * the options that already failed, and the hand-off between the chooser, the player and the
 * screen that reopens it. Nothing here is persisted (stream URLs and headers may carry tokens)
 * and an entry expires after {@link #TTL_MS}: signed links go stale.
 */
public final class StremioChooserSession {
    private StremioChooserSession() {}

    public static final long TTL_MS = 10L * 60L * 1000L;

    /** Receives every new snapshot (any thread). */
    public interface Listener { void onData(StremioChooserData data); }

    public static final class Entry {
        public final String key;
        public final String title;
        /** "movie", "series" or "anime"; with the TMDB id and episode coordinates identifies the media. */
        public final String type;
        public final String tmdbId;
        public final int season;
        public final int episode;
        final long createdAtMs;
        private final Set<String> failed = new HashSet<>();
        private final List<Listener> listeners = new CopyOnWriteArrayList<>();
        private volatile StremioChooserData data;
        private volatile StremioSearchEngine.Handle search;
        private volatile int epoch;

        Entry(String key, String title, String type, String tmdbId, int season, int episode,
              StremioChooserData data, long createdAtMs) {
            this.key = key; this.title = title == null ? "" : title; this.type = type == null ? "" : type;
            this.tmdbId = tmdbId == null ? "" : tmdbId; this.season = season; this.episode = episode;
            this.data = data; this.createdAtMs = createdAtMs;
        }

        public StremioChooserData data() { return data; }

        public int epoch() { return epoch; }

        /**
         * Publishes a snapshot. Older snapshots of the same search are ignored; a snapshot from a
         * superseded search ({@code searchEpoch != epoch}) is dropped.
         */
        public void update(StremioChooserData next, int searchEpoch) {
            if (next == null) return;
            synchronized (this) {
                if (searchEpoch != epoch) return;
                if (next.version > 0 && next.version <= data.version) return;
                data = next;
            }
            for (Listener l : listeners) {
                try { l.onData(next); } catch (RuntimeException ignored) { /* a broken view must not stop others */ }
            }
        }

        /**
         * Starts a fresh search on this entry (first search or "try again"): cancels the previous
         * one, resets the snapshot to LOADING and returns the epoch the new search must publish with.
         */
        public int restart() {
            StremioSearchEngine.Handle old;
            int e;
            synchronized (this) {
                old = search;
                search = null;
                e = ++epoch;
                data = StremioChooserData.loading();
            }
            if (old != null) old.cancel();
            for (Listener l : listeners) {
                try { l.onData(data); } catch (RuntimeException ignored) { }
            }
            return e;
        }

        public void attach(StremioSearchEngine.Handle handle, int searchEpoch) {
            boolean stale;
            synchronized (this) {
                stale = searchEpoch != epoch;
                if (!stale) search = handle;
            }
            if (stale) handle.cancel();
        }

        /**
         * Stops the running search (if any) but keeps the last snapshot. An unfinished snapshot is
         * settled (no spinner, no "still searching") so a list reopened later is not stuck.
         */
        public void cancelSearch() {
            StremioSearchEngine.Handle h;
            StremioChooserData settled = null;
            synchronized (this) {
                h = search;
                search = null;
                if (h != null && !data.isFinal()) { settled = data.settled(); data = settled; }
            }
            if (h != null) h.cancel();
            if (settled != null) {
                for (Listener l : listeners) {
                    try { l.onData(settled); } catch (RuntimeException ignored) { }
                }
            }
        }

        public void addListener(Listener l) { listeners.add(l); }
        public void removeListener(Listener l) { listeners.remove(l); }

        public Set<String> failedIds() {
            synchronized (failed) { return Collections.unmodifiableSet(new HashSet<>(failed)); }
        }

        void fail(String optionId) { synchronized (failed) { failed.add(optionId); } }
        boolean hasFailed(String optionId) { synchronized (failed) { return failed.contains(optionId); } }
    }

    private static volatile Entry current;
    private static volatile String reopenKey;
    /** Test hook: shifts the clock used for expiry. */
    static volatile long clockSkewMs;

    static long now() { return System.currentTimeMillis() + clockSkewMs; }

    public static String movieKey(String tmdbId) {
        return "movie|" + StremioSourceResolver.movieId(tmdbId);
    }

    public static String episodeKey(String tmdbId, int season, int episode) {
        return "series|" + StremioSourceResolver.episodeId(tmdbId, season, episode);
    }

    /** Opens a new session in the LOADING state; a previous session's search is cancelled. */
    public static Entry begin(String key, String title, String type, String tmdbId, int season, int episode) {
        Entry previous = current;
        Entry entry = new Entry(key, title, type, tmdbId, season, episode, StremioChooserData.loading(), now());
        current = entry;
        reopenKey = null;
        if (previous != null) previous.cancelSearch();
        return entry;
    }

    /** Compatibility: a session that already holds finished data (no re-search possible). */
    public static void put(String key, String title, int season, int episode, StremioChooserData data) {
        Entry previous = current;
        current = new Entry(key, title, "", "", season, episode, data, now());
        reopenKey = null;
        if (previous != null) previous.cancelSearch();
    }

    public static Entry get(String key) {
        Entry entry = current;
        if (entry == null || key == null || !key.equals(entry.key)) return null;
        if (now() - entry.createdAtMs > TTL_MS) {
            if (current == entry) { current = null; entry.cancelSearch(); }
            return null;
        }
        return entry;
    }

    public static void markFailed(String key, String optionId) {
        Entry entry = get(key);
        if (entry != null && optionId != null && entry.data().find(optionId) != null) entry.fail(optionId);
    }

    public static Set<String> failedIds(String key) {
        Entry entry = get(key);
        return entry == null ? Collections.<String>emptySet() : entry.failedIds();
    }

    public static synchronized void requestReopen(String key) { reopenKey = key; }

    /**
     * Consumes the pending "reopen the chooser" request when it belongs to {@code keyPrefix}
     * (the title's own key or one of its episode keys) and the session is still alive.
     */
    public static synchronized String takeReopenKey(String keyPrefix) {
        String key = reopenKey;
        if (key == null || keyPrefix == null) return null;
        if (!(key.equals(keyPrefix) || key.startsWith(keyPrefix + ":"))) return null;
        reopenKey = null;
        return get(key) != null ? key : null;
    }

    public static void clear() {
        Entry previous = current;
        current = null;
        reopenKey = null;
        if (previous != null) previous.cancelSearch();
    }
}

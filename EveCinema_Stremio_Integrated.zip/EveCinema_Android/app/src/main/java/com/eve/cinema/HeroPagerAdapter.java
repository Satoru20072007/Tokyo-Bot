package com.eve.cinema;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * HeroPagerAdapter — الواجهة الأمامية لشرائح الـ Hero (السطح الزجاجي + النص + الأزرار).
 * ────────────────────────────────────────────────────────────────
 * الـ backdrop الكامل لا يُرسم هنا: MainActivity يملك طبقتين خلفيتين ويعمل بينهما
 * crossfade مستمر مع موضع السحب، فتتبدّل الصورة بنعومة بدل أن "تنزلق" مع الشريحة.
 *
 * الـ glass: لا blur حقيقي (مكلف على الأجهزة المتوسطة). بدلًا منه نحمّل نسخة 48×28 px
 * من نفس الـ backdrop ونكبّرها (bilinear) داخل اللوحة — تعطي تمويهًا ناعمًا ولونًا
 * مستمدًّا من المشهد بتكلفة تقارب الصفر.
 */
public class HeroPagerAdapter extends RecyclerView.Adapter<HeroPagerAdapter.VH> {

    public interface HeroActionListener {
        void onPlay(JSONObject item);
        void onInfo(JSONObject item);
    }

    private static final String IMG_FROST = "https://image.tmdb.org/t/p/w300";

    private final List<JSONObject> items = new ArrayList<>();
    private final HeroActionListener listener;
    private Typeface displayTypeface;

    public HeroPagerAdapter(HeroActionListener listener) {
        this.listener = listener;
    }

    public void submitList(List<JSONObject> list) {
        items.clear();
        if (list != null) items.addAll(list);
        notifyDataSetChanged();
    }

    public void setDisplayTypeface(Typeface tf) {
        if (tf == displayTypeface) return;
        displayTypeface = tf;
        if (!items.isEmpty()) notifyDataSetChanged();
    }

    public JSONObject getItem(int position) {
        return (position >= 0 && position < items.size()) ? items.get(position) : null;
    }

    @Override public int getItemCount() { return items.size(); }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        final View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_hero_slide, parent, false);
        final VH h = new VH(v);
        RoundOutline.apply(h.info, parent.getResources().getDimension(R.dimen.hero_panel_radius));
        UiMotion.pressSubtle(h.playBtn);
        UiMotion.pressSubtle(h.infoBtn);
        return h;
    }

    @Override
    public void onBindViewHolder(@NonNull final VH h, int position) {
        final JSONObject item = items.get(position);
        final Context ctx = h.itemView.getContext();
        final Resources res = ctx.getResources();

        // recycled views قد تحمل حالة الـ parallax السابقة
        h.info.setAlpha(1f);
        h.info.setTranslationX(0f);

        // ── Title ─────────────────────────────────────────
        final String title = MediaText.title(item);
        final boolean rtlTitle = MediaText.isRtl(title);
        h.title.setText(title);
        if (rtlTitle) {
            // Bebas Neue لا تحتوي حروفًا عربية، و letterSpacing يفكّك اتصال الحروف
            h.title.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            h.title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f);
            h.title.setLetterSpacing(0f);
        } else if (displayTypeface != null) {
            h.title.setTypeface(displayTypeface);
            h.title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 40f);
            h.title.setLetterSpacing(0.02f);
        } else {
            h.title.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
            h.title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 32f);
            h.title.setLetterSpacing(0f);
        }
        MediaText.align(h.title, rtlTitle);

        // ── Rating chip ───────────────────────────────────
        final double rating = item.optDouble("vote_average", 0);
        if (rating > 0) {
            h.ratingChip.setVisibility(View.VISIBLE);
            h.rating.setText(String.format(Locale.US, "%.1f", rating));
        } else {
            h.ratingChip.setVisibility(View.GONE);
        }

        // ── Meta: year • type • genre ─────────────────────
        final StringBuilder meta = new StringBuilder();
        append(meta, MediaText.year(item));
        append(meta, MediaText.typeLabel(res, item.optString("media_type", "movie")));
        append(meta, MediaText.firstGenre(res, item));
        h.meta.setText(meta);

        // ── Description (يُخفى إذا غير متوفر) ─────────────
        final String overview = MediaText.str(item, "overview").trim();
        if (overview.isEmpty()) {
            h.desc.setVisibility(View.GONE);
        } else {
            h.desc.setVisibility(View.VISIBLE);
            h.desc.setText(overview);
            MediaText.align(h.desc, MediaText.isRtl(overview));
        }

        // ── Frost layer ───────────────────────────────────
        final String backdrop = MediaText.str(item, "backdrop_path");
        if (backdrop.isEmpty()) {
            Glide.with(ctx).clear(h.frost);
            h.frost.setImageDrawable(null);
        } else {
            Glide.with(ctx).load(IMG_FROST + backdrop).override(48, 28).centerCrop().into(h.frost);
        }

        // ── Actions ───────────────────────────────────────
        h.playBtn.setOnClickListener(v -> { if (listener != null) listener.onPlay(item); });
        h.infoBtn.setOnClickListener(v -> { if (listener != null) listener.onInfo(item); });
        h.info.setOnClickListener(v -> { if (listener != null) listener.onInfo(item); });
    }

    private static void append(StringBuilder sb, String part) {
        if (part == null || part.isEmpty()) return;
        if (sb.length() > 0) sb.append("  \u2022  ");
        sb.append(part);
    }

    static final class VH extends RecyclerView.ViewHolder {
        final View info, ratingChip, playBtn, infoBtn;
        final ImageView frost;
        final TextView title, rating, meta, desc;

        VH(@NonNull View v) {
            super(v);
            info       = v.findViewById(R.id.slide_info);
            frost      = v.findViewById(R.id.slide_frost);
            title      = v.findViewById(R.id.slide_title);
            ratingChip = v.findViewById(R.id.slide_rating_chip);
            rating     = v.findViewById(R.id.slide_rating);
            meta       = v.findViewById(R.id.slide_meta);
            desc       = v.findViewById(R.id.slide_desc);
            playBtn    = v.findViewById(R.id.slide_play_btn);
            infoBtn    = v.findViewById(R.id.slide_info_btn);
        }
    }
}

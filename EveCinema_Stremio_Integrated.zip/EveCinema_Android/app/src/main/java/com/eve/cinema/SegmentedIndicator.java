package com.eve.cinema;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

/**
 * SegmentedIndicator — مؤشر Hero بأجزاء.
 * ────────────────────────────────────────────────────────────────
 * - الجزء النشط أعرض من الباقي ويمتلئ تدريجيًا = الوقت المتبقي للشريحة التالية.
 * - الأجزاء السابقة تبقى ممتلئة بشفافية أقل، واللاحقة مجرد مسار خافت.
 * - يحسب التقدّم من الساعة (uptimeMillis) وليس من ValueAnimator، فلا يتأثر
 *   بإعداد "Animator duration scale = 0" ويدعم pause/resume بدقة.
 * - عرض الـ View ثابت لأن مجموع (activeness) = 1 دائمًا → لا requestLayout أثناء الحركة.
 */
public class SegmentedIndicator extends View {

    private static final int MAX = 8;
    private static final int COLOR_TRACK = 0x38FFFFFF;
    private static final int COLOR_DONE  = 0x8CFFFFFF;
    private static final int COLOR_FILL  = 0xF5FFFFFF;

    private final float segH, segW, segWActive, gap;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect  = new RectF();
    private final float[] activeness = new float[MAX];
    private final float[] fromA      = new float[MAX];

    private int count = 0, active = 0;
    private ValueAnimator morph;

    private long    durationMs = 7000L;
    private long    elapsedBase = 0L;
    private long    startedAt   = 0L;
    private boolean running     = false;
    private boolean staticFill  = false;

    public SegmentedIndicator(Context c)                        { this(c, null, 0); }
    public SegmentedIndicator(Context c, AttributeSet a)        { this(c, a, 0); }
    public SegmentedIndicator(Context c, AttributeSet a, int s) {
        super(c, a, s);
        final float d = c.getResources().getDisplayMetrics().density;
        segH = 3f * d; segW = 9f * d; segWActive = 30f * d; gap = 4f * d;
    }

    public void setCount(int n) {
        count = Math.max(0, Math.min(MAX, n));
        if (active >= count) active = Math.max(0, count - 1);
        for (int i = 0; i < MAX; i++) activeness[i] = (i == active && i < count) ? 1f : 0f;
        setVisibility(count > 1 ? VISIBLE : GONE);
        requestLayout();
        invalidate();
    }

    public void setActive(int index, boolean animate) {
        if (count == 0) return;
        index = Math.max(0, Math.min(count - 1, index));
        active = index;
        for (int i = 0; i < count; i++) fromA[i] = activeness[i];
        if (morph != null) morph.cancel();
        if (!animate) {
            for (int i = 0; i < count; i++) activeness[i] = (i == active) ? 1f : 0f;
            invalidate();
            return;
        }
        morph = ValueAnimator.ofFloat(0f, 1f);
        morph.setDuration(280);
        morph.setInterpolator(new DecelerateInterpolator(2f));
        morph.addUpdateListener(a -> {
            final float t = (float) a.getAnimatedValue();
            for (int i = 0; i < count; i++) {
                final float to = (i == active) ? 1f : 0f;
                activeness[i] = fromA[i] + (to - fromA[i]) * t;
            }
            invalidate();
        });
        morph.start();
    }

    /** يبدأ مدّة جديدة للشريحة النشطة. runNow=false → تبقى متوقفة (مثلاً أثناء اللمس). */
    public void restart(long duration, boolean runNow) {
        durationMs  = Math.max(1L, duration);
        elapsedBase = 0L;
        startedAt   = SystemClock.uptimeMillis();
        running     = runNow;
        invalidate();
    }

    public void pause() {
        if (!running) return;
        elapsedBase += SystemClock.uptimeMillis() - startedAt;
        running = false;
        invalidate();
    }

    public void resume() {
        if (running) return;
        running   = true;
        startedAt = SystemClock.uptimeMillis();
        invalidate();
    }

    /** عند تعطيل الحركة (reduced motion): الجزء النشط ممتلئ بدل أن يتحرك. */
    public void setStaticFill(boolean on) { staticFill = on; invalidate(); }

    private float progress() {
        if (staticFill) return 1f;
        final long e = elapsedBase + (running ? SystemClock.uptimeMillis() - startedAt : 0L);
        return Math.min(1f, e / (float) durationMs);
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        final float total = count <= 0 ? 0f : (count - 1) * (segW + gap) + segWActive;
        setMeasuredDimension(resolveSize((int) Math.ceil(total), wSpec),
                             resolveSize((int) Math.ceil(segH), hSpec));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (count == 0) return;
        final float p = progress();
        final float r = segH / 2f;
        float x = 0f;
        for (int i = 0; i < count; i++) {
            final float w = segW + (segWActive - segW) * activeness[i];
            rect.set(x, 0f, x + w, segH);
            paint.setColor(COLOR_TRACK);
            canvas.drawRoundRect(rect, r, r, paint);
            if (i < active) {
                paint.setColor(COLOR_DONE);
                canvas.drawRoundRect(rect, r, r, paint);
            } else if (i == active && p > 0f) {
                rect.right = x + Math.max(segH, w * p);
                paint.setColor(COLOR_FILL);
                canvas.drawRoundRect(rect, r, r, paint);
            }
            x += w + gap;
        }
        if (running && p < 1f && !staticFill) postInvalidateOnAnimation();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (morph != null) morph.cancel();
    }
}

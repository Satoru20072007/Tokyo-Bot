package com.eve.cinema.stremio;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Identity of the video FILE behind a stream, built only from what the add-on declared in
 * {@code behaviorHints}: the OpenSubtitles-style {@code videoHash}, the byte {@code videoSize}
 * and the {@code filename}. A subtitle is only called an exact match for a file when it was
 * obtained with — or attached to — the same STRONG key.
 *
 * <ul>
 *   <li>strong: {@code h:<hash>} or {@code sf:<size>:<filename>} (a stream may have both);</li>
 *   <li>weak: filename alone or size alone — recorded, never used to claim a match.</li>
 * </ul>
 */
public final class StremioFileIdentity {
    public final Set<String> strongKeys;
    public final boolean weakOnly;
    public final boolean empty;

    private StremioFileIdentity(Set<String> strong, boolean weakOnly, boolean empty) {
        this.strongKeys = Collections.unmodifiableSet(strong);
        this.weakOnly = weakOnly;
        this.empty = empty;
    }

    public static StremioFileIdentity of(String videoHash, long videoSize, String filename) {
        Set<String> strong = new LinkedHashSet<>();
        String hash = videoHash == null ? "" : videoHash.trim().toLowerCase(Locale.ROOT);
        String name = normalizeFilename(filename);
        if (!hash.isEmpty() && hash.matches("[0-9a-z]{8,64}")) strong.add("h:" + hash);
        if (videoSize > 0 && !name.isEmpty()) strong.add("sf:" + videoSize + ":" + name);
        boolean any = !hash.isEmpty() || videoSize > 0 || !name.isEmpty();
        return new StremioFileIdentity(strong, strong.isEmpty() && any, !any);
    }

    public boolean isStrong() { return !strongKeys.isEmpty(); }

    public boolean sameFileAs(StremioFileIdentity other) {
        if (other == null) return false;
        for (String key : strongKeys) if (other.strongKeys.contains(key)) return true;
        return false;
    }

    /** Lower-case file name without any directory part. */
    public static String normalizeFilename(String filename) {
        if (filename == null) return "";
        String f = filename.trim().replace('\\', '/');
        int slash = f.lastIndexOf('/');
        if (slash >= 0) f = f.substring(slash + 1);
        return f.toLowerCase(Locale.ROOT);
    }
}

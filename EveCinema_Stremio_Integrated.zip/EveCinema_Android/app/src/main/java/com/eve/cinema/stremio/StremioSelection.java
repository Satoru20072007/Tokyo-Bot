package com.eve.cinema.stremio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * What the user has explicitly chosen in the chooser, kept apart from the data that keeps changing
 * while results arrive.
 *
 * <ul>
 *   <li>Nothing is ever chosen on the user's behalf: a fresh selection has no stream and no subtitle
 *       choice, and neither picking a stream nor picking a subtitle fills in the other.</li>
 *   <li>The selection is held by IDs, so a re-ranked or extended list never moves it.</li>
 *   <li>If a chosen item disappears (a dead link was removed), it is cleared and the caller is told.</li>
 * </ul>
 */
public final class StremioSelection {
    public enum SubtitleMode {
        /** The user has not decided: nothing is highlighted. */
        UNSET,
        /** The user explicitly chose "no subtitles". */
        NONE,
        SUBTITLE
    }

    private String optionId;
    private SubtitleMode mode = SubtitleMode.UNSET;
    private String subtitleId;

    public String optionId() { return optionId; }
    public SubtitleMode subtitleMode() { return mode; }
    public String subtitleId() { return subtitleId; }

    public void selectOption(String id) { optionId = id; }
    public void clearOption() { optionId = null; }
    public void selectNoSubtitle() { mode = SubtitleMode.NONE; subtitleId = null; }
    public void selectSubtitle(String id) { mode = SubtitleMode.SUBTITLE; subtitleId = id; }
    public void clearSubtitle() { mode = SubtitleMode.UNSET; subtitleId = null; }

    /** Result of {@link #reconcile}. */
    public static final class Change {
        public final boolean optionLost;
        public final boolean subtitleLost;
        Change(boolean optionLost, boolean subtitleLost) { this.optionLost = optionLost; this.subtitleLost = subtitleLost; }
    }

    /** Drops choices that no longer exist in {@code data}. */
    public Change reconcile(StremioChooserData data) {
        boolean optionLost = false, subtitleLost = false;
        if (optionId != null && data.find(optionId) == null) { optionId = null; optionLost = true; }
        if (mode == SubtitleMode.SUBTITLE && data.findSubtitle(subtitleId) == null) {
            clearSubtitle();
            subtitleLost = true;
        }
        return new Change(optionLost, subtitleLost);
    }

    public StremioStreamOption option(StremioChooserData data) { return data.find(optionId); }

    /** The chosen subtitle, or null for "none" / "undecided". */
    public StremioSubtitle subtitle(StremioChooserData data) {
        return mode == SubtitleMode.SUBTITLE ? data.findSubtitle(subtitleId) : null;
    }

    /** A subtitle bound to another file is chosen together with a stream it does not belong to. */
    public boolean conflict(StremioChooserData data) {
        StremioStreamOption o = option(data);
        StremioSubtitle s = subtitle(data);
        return o != null && s != null && data.match(s, o) == StremioChooserData.Match.INCOMPATIBLE;
    }

    /** Play is enabled only for an explicitly chosen, still existing stream without a conflict. */
    public boolean canPlay(StremioChooserData data) { return option(data) != null && !conflict(data); }

    /** True when the user has not decided about subtitles although an exact one exists for the stream. */
    public boolean needsSubtitleHint(StremioChooserData data) {
        StremioStreamOption o = option(data);
        return o != null && mode == SubtitleMode.UNSET && data.hasExactArabic(o);
    }

    /**
     * Subtitles in display order. Best language evidence first; once a stream is chosen, subtitles
     * proven for it come first, then unverified ones, then those bound to other files (kept visible
     * so the user can see why they are not offered, never hidden silently).
     */
    public List<StremioSubtitle> displayOrder(final StremioChooserData data) {
        List<StremioSubtitle> list = new ArrayList<>(data.subtitles);
        Collections.sort(list, new Comparator<StremioSubtitle>() {
            @Override public int compare(StremioSubtitle a, StremioSubtitle b) {
                return Integer.compare(b.languageConfidence, a.languageConfidence);
            }
        });
        final StremioStreamOption chosen = option(data);
        if (chosen == null) {
            Collections.sort(list, new Comparator<StremioSubtitle>() {
                @Override public int compare(StremioSubtitle a, StremioSubtitle b) {
                    return Boolean.compare(a.generic, b.generic);   // file-bound ones before generic ones
                }
            });
            return list;
        }
        Collections.sort(list, new Comparator<StremioSubtitle>() {
            @Override public int compare(StremioSubtitle a, StremioSubtitle b) {
                return rank(data.match(a, chosen)) - rank(data.match(b, chosen));
            }
        });
        return list;
    }

    private static int rank(StremioChooserData.Match m) {
        switch (m) {
            case EXACT: return 0;
            case UNVERIFIED: return 1;
            default: return 2;
        }
    }

    /** Stream rows that stay selectable but are shown dimmed because the chosen subtitle is bound elsewhere. */
    public boolean dimOption(StremioChooserData data, StremioStreamOption candidate) {
        StremioSubtitle s = subtitle(data);
        return s != null && data.match(s, candidate) == StremioChooserData.Match.INCOMPATIBLE;
    }
}

package com.eve.cinema.playback;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Lightweight pre-playback manifest probe: extracts the audio languages a
 * DASH MPD or HLS master playlist ACTUALLY declares. Used by the portrait
 * pre-player chooser so «دبلجة عربية» is only offered when a real Arabic audio
 * track (or a verified dub release) exists — never inferred from a title token
 * or a subtitle URL.
 *
 * Parsing is deliberately tolerant (regex over the header tags only): the
 * probe runs on-device before playback and must not fail the whole chooser on
 * a slightly malformed manifest — it simply returns fewer languages.
 *
 * Pure Java, no Android deps — unit-tested on the JVM.
 */
public final class ManifestAudioParser {

    private ManifestAudioParser() {}

    /** AdaptationSet opening tags (non-greedy, attributes only). */
    private static final Pattern ADAPTATION_SET =
            Pattern.compile("<AdaptationSet\\b[^>]*>", Pattern.CASE_INSENSITIVE);
    private static final Pattern ATTR_LANG =
            Pattern.compile("(?:^|\\s)(?:xml:)?lang\\s*=\\s*['\"]([^'\"]+)['\"]",
                    Pattern.CASE_INSENSITIVE);
    private static final Pattern ATTR_CONTENT_TYPE =
            Pattern.compile("contentType\\s*=\\s*['\"]([^'\"]+)['\"]",
                    Pattern.CASE_INSENSITIVE);
    private static final Pattern ATTR_MIME =
            Pattern.compile("mimeType\\s*=\\s*['\"]([^'\"]+)['\"]",
                    Pattern.CASE_INSENSITIVE);

    /** HLS: #EXT-X-MEDIA:TYPE=AUDIO,…,LANGUAGE="ar" */
    private static final Pattern HLS_MEDIA =
            Pattern.compile("#EXT-X-MEDIA:([^\\r\\n]+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern HLS_TYPE =
            Pattern.compile("TYPE\\s*=\\s*([A-Za-z-]+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern HLS_LANGUAGE =
            Pattern.compile("LANGUAGE\\s*=\\s*\"([^\"]+)\"", Pattern.CASE_INSENSITIVE);

    /**
     * Audio languages declared by a DASH manifest. Looks at AdaptationSet
     * headers whose contentType is "audio" or whose mimeType is audio/*.
     * A nested &lt;ContentComponent contentType="audio"/&gt; also qualifies
     * (seen in the wild when the AdaptationSet itself omits the attributes),
     * but only the AdaptationSet's own lang attribute is read — no guessing.
     */
    public static List<String> parseDashAudioLanguages(String mpd) {
        List<String> out = new ArrayList<>();
        if (mpd == null || mpd.isEmpty()) return out;
        Matcher sets = ADAPTATION_SET.matcher(mpd);
        while (sets.find()) {
            String tag = sets.group();
            boolean audio = false;
            Matcher ct = ATTR_CONTENT_TYPE.matcher(tag);
            if (ct.find() && "audio".equalsIgnoreCase(ct.group(1).trim())) audio = true;
            if (!audio) {
                Matcher mime = ATTR_MIME.matcher(tag);
                if (mime.find()) {
                    String m = mime.group(1).trim().toLowerCase(Locale.US);
                    if (m.startsWith("audio/")) audio = true;
                }
            }
            if (!audio) continue;
            Matcher lang = ATTR_LANG.matcher(tag);
            if (lang.find()) addDistinct(out, lang.group(1));
        }
        return out;
    }

    /** Audio languages declared by an HLS master playlist. */
    public static List<String> parseHlsAudioLanguages(String m3u8) {
        List<String> out = new ArrayList<>();
        if (m3u8 == null || m3u8.isEmpty()) return out;
        Matcher media = HLS_MEDIA.matcher(m3u8);
        while (media.find()) {
            String attrs = media.group(1);
            Matcher type = HLS_TYPE.matcher(attrs);
            if (!type.find() || !"AUDIO".equalsIgnoreCase(type.group(1).trim())) continue;
            Matcher lang = HLS_LANGUAGE.matcher(attrs);
            if (lang.find()) addDistinct(out, lang.group(1));
        }
        return out;
    }

    /** Routes by URL shape; returns an empty list for non-manifest URLs. */
    public static List<String> parseForUrl(String url, String body) {
        if (url == null || body == null) return new ArrayList<>();
        String clean = url.split("\\?")[0].toLowerCase(Locale.US);
        if (clean.endsWith(".mpd") || clean.contains("/dash/"))
            return parseDashAudioLanguages(body);
        if (clean.endsWith(".m3u8"))
            return parseHlsAudioLanguages(body);
        return new ArrayList<>();
    }

    private static void addDistinct(List<String> out, String lang) {
        if (lang == null) return;
        String v = lang.trim();
        if (v.isEmpty()) return;
        for (String e : out) if (e.equalsIgnoreCase(v)) return;
        out.add(v);
    }
}

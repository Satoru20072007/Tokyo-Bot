package com.eve.cinema.moviebox;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * What a MovieBox subject TITLE says about the release — e.g.
 * {@code "Re:ZERO -Starting Life in Another World- [English] S1-S3"} is a
 * language-labelled (dub) release that claims seasons 1–3.
 *
 * This is ONLY a ranking hint. A label never proves which audio or subtitle
 * tracks really exist (those are verified from the actual play-info / caption
 * responses), and it never selects a release on its own: a candidate must
 * already pass the title / media-type / year gates of
 * {@link MovieBoxTitleMatcher}.
 */
public final class MovieBoxReleaseTag {

    private static final Pattern BRACKETS = Pattern.compile("[\\[(]([^\\])]+)[\\])]");
    private static final Pattern SEASON_TAG = Pattern.compile(
            "(?i)(?<![A-Za-z0-9])S(?:eason)?\\s*0?(\\d{1,2})"
                    + "(?:\\s*[-\u2013\u2014~]\\s*S?(?:eason)?\\s*0?(\\d{1,2}))?(?![A-Za-z0-9])");

    /** The raw MovieBox title. */
    public final String rawTitle;
    /** Title without release decorations (tags, season ranges, resolution). */
    public final String baseTitle;
    /** Lower-case language/dub label found in the title, or null. */
    public final String languageTag;
    /**
     * True when the title labels the release as a non-original audio release
     * (a language tag other than the original Japanese, or an explicit "dub").
     */
    public final boolean dubLabelled;
    /** Season range the title claims (inclusive); 0/0 when it claims none. */
    public final int seasonFrom;
    public final int seasonTo;
    /**
     * What the title's bracket / " - " markers say about Arabic, kept separate from
     * {@link #dubLabelled}: ARABIC_DUB, ARABIC_SUBTITLE or ARABIC_AMBIGUOUS when an Arabic
     * marker is present; OTHER / UNKNOWN otherwise. A hint only — never proof of audio.
     */
    public final MovieBoxReleaseClassifier.Kind markerKind;

    private MovieBoxReleaseTag(String rawTitle, String baseTitle, String languageTag,
                               boolean dubLabelled, int seasonFrom, int seasonTo,
                               MovieBoxReleaseClassifier.Kind markerKind) {
        this.rawTitle = rawTitle;
        this.baseTitle = baseTitle;
        this.languageTag = languageTag;
        this.dubLabelled = dubLabelled;
        this.seasonFrom = seasonFrom;
        this.seasonTo = seasonTo;
        this.markerKind = markerKind;
    }

    /** Title says "Arabic subtitles" (e.g. {@code [ترجمة عربية]}); audio is NOT implied. */
    public boolean isArabicSubtitleHint() {
        return markerKind == MovieBoxReleaseClassifier.Kind.ARABIC_SUBTITLE;
    }

    /** Title says "Arabic dub" (e.g. {@code [مدبلج للعربية]}); audio still needs verifying. */
    public boolean isArabicDubHint() {
        return markerKind == MovieBoxReleaseClassifier.Kind.ARABIC_DUB;
    }

    public static MovieBoxReleaseTag parse(String rawTitle) {
        String raw = rawTitle == null ? "" : rawTitle.trim();
        String base = MovieBoxTitleCleaner.cleanMovieboxTitle(raw);

        String language = null;
        boolean dub = false;

        // Arabic markers are classified first and as a whole, so a subtitle marker is never
        // mistaken for a dub and a bare "[Arabic]" (audio-vs-subtitle unknown) is never
        // labelled a dub. Anything else falls through to the language-label logic below.
        java.util.List<String> markers = new java.util.ArrayList<>();
        Matcher mm = BRACKETS.matcher(raw);
        while (mm.find()) markers.add(mm.group(1));
        int dashAt = raw.lastIndexOf(" - ");
        if (dashAt >= 0) markers.add(raw.substring(dashAt + 3));
        MovieBoxReleaseClassifier.Kind kind = MovieBoxReleaseClassifier.classify(
                null, markers.toArray(new String[0])).kind;
        boolean arabicMarker = kind == MovieBoxReleaseClassifier.Kind.ARABIC_DUB
                || kind == MovieBoxReleaseClassifier.Kind.ARABIC_SUBTITLE
                || kind == MovieBoxReleaseClassifier.Kind.ARABIC_AMBIGUOUS;

        if (arabicMarker) {
            if (kind == MovieBoxReleaseClassifier.Kind.ARABIC_DUB) {
                language = "arabic dub";
                dub = true;
            } else if (kind == MovieBoxReleaseClassifier.Kind.ARABIC_SUBTITLE) {
                language = "arabic subtitle";
            } else {
                language = "arabic";
            }
        } else {
            Matcher m = BRACKETS.matcher(raw);
            while (m.find()) {
                String content = m.group(1).trim().toLowerCase(Locale.US);
                if (content.isEmpty()) continue;
                String found = languageLabel(content);
                if (found != null) {
                    language = found;
                    dub = isDubLabel(found, content);
                    break;
                }
            }
            if (language == null) {
                int dash = raw.lastIndexOf(" - ");
                if (dash >= 0) {
                    String suffix = raw.substring(dash + 3).trim().toLowerCase(Locale.US);
                    String found = languageLabel(suffix);
                    if (found != null) {
                        language = found;
                        dub = isDubLabel(found, suffix);
                    }
                }
            }
        }

        int from = 0, to = 0;
        Matcher sm = SEASON_TAG.matcher(raw);
        while (sm.find()) { // the LAST season token wins ("... S1-S3")
            int a = parseSeason(sm.group(1));
            int b = sm.group(2) == null ? a : parseSeason(sm.group(2));
            if (a > 0 && b > 0) { from = Math.min(a, b); to = Math.max(a, b); }
        }
        return new MovieBoxReleaseTag(raw, base, language, dub, from, to, kind);
    }

    /** True when the title claims no season range, or the range includes {@code tmdbSeason}. */
    public boolean coversSeason(int tmdbSeason) {
        if (tmdbSeason <= 0 || seasonFrom <= 0) return true;
        return tmdbSeason >= seasonFrom && tmdbSeason <= seasonTo;
    }

    private static String languageLabel(String lowerContent) {
        // "english", "hindi dub", "english dub", "dub", "dubbed" — never a bare word elsewhere.
        String cleaned = lowerContent.replace("dubbed", "").replace("dub", "")
                .replace("audio", "").trim();
        if (cleaned.isEmpty()) {
            return lowerContent.contains("dub") ? "dub" : null;
        }
        if (MovieBoxTitleCleaner.languageToCode(cleaned) != null) return cleaned;
        return null;
    }

    private static boolean isDubLabel(String language, String originalContent) {
        if (originalContent.contains("dub")) return true;
        // The original anime audio is not a dub.
        String code = MovieBoxTitleCleaner.languageToCode(language);
        return code == null || !code.equals("ja");
    }

    private static int parseSeason(String digits) {
        try { return Integer.parseInt(digits); } catch (NumberFormatException e) { return 0; }
    }
}

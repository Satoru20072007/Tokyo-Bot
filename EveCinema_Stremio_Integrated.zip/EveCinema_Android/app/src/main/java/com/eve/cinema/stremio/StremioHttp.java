package com.eve.cinema.stremio;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Bounded, policy-enforcing JSON GET used for manifests and add-on resources.
 *
 * <ul>
 *   <li>Redirects are followed by hand: every hop is re-checked against the {@link
 *       StremioNetPolicy.Policy}, HTTPS→HTTP is refused, and a URL that carries a credential path
 *       may only be redirected inside its own origin.</li>
 *   <li>Independent limits: connect timeout, read timeout, total wall-clock deadline (a server that
 *       trickles bytes cannot hold a worker forever), maximum body bytes, maximum redirect hops.</li>
 *   <li>JSON nesting depth is checked <i>before</i> parsing: the Android parser is recursive and a
 *       hostile 100 000-level document would otherwise throw an uncatchable {@link StackOverflowError}.</li>
 *   <li>Failures surface as {@link StremioException} whose text never contains a URL.</li>
 * </ul>
 */
public final class StremioHttp {

    /** Independent resource limits for one request. */
    public static final class Limits {
        public final int connectTimeoutMs;
        public final int readTimeoutMs;
        public final int totalTimeoutMs;
        public final int maxBytes;
        public final int maxRedirects;

        public Limits(int connectTimeoutMs, int readTimeoutMs, int totalTimeoutMs,
                      int maxBytes, int maxRedirects) {
            this.connectTimeoutMs = connectTimeoutMs;
            this.readTimeoutMs = readTimeoutMs;
            this.totalTimeoutMs = totalTimeoutMs;
            this.maxBytes = maxBytes;
            this.maxRedirects = maxRedirects;
        }

        /** Same limits with a smaller (never larger) overall deadline. */
        public Limits withTotalTimeout(int ms) {
            return new Limits(connectTimeoutMs, readTimeoutMs, Math.max(1, Math.min(totalTimeoutMs, ms)),
                    maxBytes, maxRedirects);
        }
    }

    /** Manifests are small; 512 KiB is far above any real one and far below the stream limit. */
    public static final Limits MANIFEST_LIMITS = new Limits(8_000, 10_000, 15_000, 512 * 1024, 3);
    /** stream / subtitles answers can list many releases; still capped. */
    public static final Limits RESOURCE_LIMITS = new Limits(8_000, 12_000, 20_000, 2 * 1024 * 1024, 3);
    public static final int MAX_JSON_DEPTH = 32;

    private static final String USER_AGENT = "EveCinema-Stremio/1.0";

    private final StremioNetPolicy.Policy policy;

    public StremioHttp(StremioNetPolicy.Policy policy) {
        if (policy == null) throw new IllegalArgumentException("policy");
        this.policy = policy;
    }

    public static StremioHttp production() { return new StremioHttp(StremioNetPolicy.Policy.addon()); }

    /**
     * @param strictOrigin true when the original URL can hold a credential: then no redirect may
     *                     leave the original origin (the secret must never travel to another host).
     */
    public JSONObject getJson(String url, Limits limits, boolean strictOrigin) throws StremioException {
        final long deadline = System.nanoTime() + limits.totalTimeoutMs * 1_000_000L;
        final URI origin;
        try {
            origin = URI.create(url);
        } catch (RuntimeException ex) {
            throw new StremioException(StremioException.Kind.UNSAFE_URL);
        }
        URI current = origin;
        for (int hop = 0; ; hop++) {
            policy.check(current);
            HttpURLConnection connection = null;
            try {
                int remainingMs = remainingMs(deadline);
                if (remainingMs <= 0) throw new StremioException(StremioException.Kind.TIMEOUT);
                connection = (HttpURLConnection) current.toURL().openConnection();
                connection.setInstanceFollowRedirects(false);
                connection.setUseCaches(false);
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(Math.min(limits.connectTimeoutMs, remainingMs));
                connection.setReadTimeout(Math.min(limits.readTimeoutMs, remainingMs));
                connection.setRequestProperty("Accept", "application/json");
                connection.setRequestProperty("User-Agent", USER_AGENT);

                int status = connection.getResponseCode();
                if (isRedirect(status)) {
                    if (hop >= limits.maxRedirects)
                        throw new StremioException(StremioException.Kind.REDIRECT_REJECTED);
                    URI next = resolveRedirect(current, connection.getHeaderField("Location"));
                    if (isDowngrade(current, next))
                        throw new StremioException(StremioException.Kind.REDIRECT_REJECTED);
                    if (strictOrigin && !StremioUrls.sameOrigin(origin, next))
                        throw new StremioException(StremioException.Kind.REDIRECT_REJECTED);
                    current = next;
                    continue;
                }
                if (status < 200 || status >= 300)
                    throw new StremioException(StremioException.Kind.HTTP_STATUS, status);
                String contentType = connection.getContentType();
                if (contentType != null && !contentType.toLowerCase(Locale.US).contains("json"))
                    throw new StremioException(StremioException.Kind.NOT_JSON);
                if (connection.getContentLengthLong() > limits.maxBytes)
                    throw new StremioException(StremioException.Kind.TOO_LARGE);
                return parseJson(readBounded(connection.getInputStream(), limits.maxBytes, deadline));
            } catch (StremioException ex) {
                throw ex;
            } catch (IOException ex) {
                throw StremioException.from(ex);
            } finally {
                if (connection != null) connection.disconnect();
            }
        }
    }

    // ───────────────────────────── helpers (package-visible for tests) ─────────────────────────────

    /** A redirect from https to anything that is not https. */
    static boolean isDowngrade(URI from, URI to) {
        return "https".equalsIgnoreCase(from.getScheme()) && !"https".equalsIgnoreCase(to.getScheme());
    }

    static boolean isRedirect(int status) {
        return status == 301 || status == 302 || status == 303 || status == 307 || status == 308;
    }

    static URI resolveRedirect(URI current, String location) throws StremioException {
        if (location == null || location.trim().isEmpty())
            throw new StremioException(StremioException.Kind.REDIRECT_REJECTED);
        try {
            return current.resolve(StremioUrls.encodeIllegal(location.trim(), true));
        } catch (RuntimeException ex) {
            throw new StremioException(StremioException.Kind.REDIRECT_REJECTED);
        }
    }

    private static int remainingMs(long deadlineNanos) {
        long ms = (deadlineNanos - System.nanoTime()) / 1_000_000L;
        return (int) Math.max(0L, Math.min(ms, Integer.MAX_VALUE));
    }

    static byte[] readBounded(InputStream input, int maxBytes, long deadlineNanos)
            throws IOException {
        try (InputStream in = input; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0, count;
            while ((count = in.read(buffer)) != -1) {
                total += count;
                if (total > maxBytes) throw new StremioException(StremioException.Kind.TOO_LARGE);
                if (System.nanoTime() > deadlineNanos) throw new StremioException(StremioException.Kind.TIMEOUT);
                out.write(buffer, 0, count);
            }
            return out.toByteArray();
        }
    }

    static JSONObject parseJson(byte[] bytes) throws StremioException {
        String text = new String(bytes, StandardCharsets.UTF_8);
        if (!text.isEmpty() && text.charAt(0) == '\uFEFF') text = text.substring(1);
        if (exceedsDepth(text, MAX_JSON_DEPTH)) throw new StremioException(StremioException.Kind.MALFORMED);
        try {
            return new JSONObject(text);
        } catch (JSONException ex) {
            throw new StremioException(StremioException.Kind.MALFORMED);
        }
    }

    /** Linear scan: true when {@code {}/[]} nesting (outside strings) goes deeper than {@code max}. */
    static boolean exceedsDepth(String json, int max) {
        int depth = 0;
        boolean inString = false, escaped = false;
        for (int i = 0; i < json.length(); i++) {
            char c = json.charAt(i);
            if (inString) {
                if (escaped) escaped = false;
                else if (c == '\\') escaped = true;
                else if (c == '"') inString = false;
                continue;
            }
            if (c == '"') inString = true;
            else if (c == '{' || c == '[') { if (++depth > max) return true; }
            else if (c == '}' || c == ']') depth--;
        }
        return false;
    }
}

package com.eve.cinema.providercore;

import java.util.List;

/**
 * ProviderAdapter — الواجهة الموحدة لكل مصدر (خطة §4.1).
 *
 * عقد صارم:
 *  - لا شبكة على خيط الواجهة؛ المنسّق يستدعي هذه الدوال داخل executor.
 *  - لا يرمي الـadapter استثناءً شبكياً عارياً؛ يصنّفه ProviderResultState.
 *  - الإلغاء (مهلة ناعمة/مغادرة صفحة) لا يُسجَّل فشلاً للمزوّد.
 *  - لا cookies/headers متبادلة بين مزوّد وآخر (§10.4).
 *
 * Pure Java interface — unit-tested on the JVM.
 */
public interface ProviderAdapter {

    /** معرّف داخلي ثابت — لا يُعرض في الواجهة أبداً (قرار رقم 2). */
    String id();

    /** قدرات عامة للمصدر — لترتيب الاستعلام فقط، لا تثبت عربية عنصر بعينه. */
    Capabilities capabilities();

    /**
     * تحقق محلي لا يحتاج شبكة، مثل غياب بيانات اعتماد لازمة.
     * أعد null للمتابعة؛ والنتيجة المصنفة تتجاوز قاطع الصحة ولا تُسجل كعطل.
     */
    default ProviderResultState preflight(CanonicalMediaIdentity identity)
            throws InterruptedException {
        return null;
    }

    /**
     * فحص سريع محدود المهلة: هل المصدر reachable من هذه الشبكة، وهل له
     * تطابق مثبت مع الهوية؟ لا يجلب روابط.
     */
    ProbeResult probe(CanonicalMediaIdentity identity) throws InterruptedException;

    /**
     * جلب المرشحين المطبعين للهوية. قائمة فارغة تعني «فُحص ولا نتيجة»
     * (NO_ARABIC_FOR_THIS_ITEM / NO_MATCH)، أما الفشل فيُصنَّف في ProbeResult
     * أو يُرمى ProviderException المصنّف.
     */
    List<NormalizedCandidate> candidates(CanonicalMediaIdentity identity)
            throws InterruptedException, ProviderException;

    /**
     * تجديد رابط منتهٍ لنفس المزوّد/العمل/الحلقة/النوع قدر الإمكان.
     * محاولة واحدة لكل فشل مصنّف مناسب (§10.4) — يقررها PlaybackSourceRouter.
     */
    NormalizedCandidate refresh(NormalizedCandidate stale)
            throws InterruptedException, ProviderException;

    /** قدرات معلنة للمصدر. */
    final class Capabilities {
        public final boolean movies;
        public final boolean series;
        public final boolean arabicDubPossible;
        public final boolean arabicInVideoPossible;
        public final boolean arabicExternalSubPossible;
        /** الوصول قد يكون مشروطاً بشبكة معيّنة (Vodu/Sinemana/CinemaBox). */
        public final boolean networkConstrained;

        public Capabilities(boolean movies, boolean series,
                            boolean dub, boolean inVideo, boolean extSub,
                            boolean networkConstrained) {
            this.movies = movies;
            this.series = series;
            this.arabicDubPossible = dub;
            this.arabicInVideoPossible = inVideo;
            this.arabicExternalSubPossible = extSub;
            this.networkConstrained = networkConstrained;
        }

        public boolean supports(CanonicalMediaIdentity id) {
            return id.mediaType() == CanonicalMediaIdentity.MediaType.MOVIE ? movies : series;
        }
    }

    /** نتيجة فحص مصنّفة. */
    final class ProbeResult {
        public final ProviderResultState state;
        public final String providerNativeId; // nullable — يُسجَّل فقط إن ثبتت المطابقة
        public final long elapsedMs;

        public ProbeResult(ProviderResultState state, String providerNativeId, long elapsedMs) {
            this.state = state == null ? ProviderResultState.UNKNOWN : state;
            this.providerNativeId = providerNativeId;
            this.elapsedMs = elapsedMs;
        }

        public static ProbeResult of(ProviderResultState s) { return new ProbeResult(s, null, -1); }
    }

    /** استثناء مصنّف — بديل إرجاع «لا توجد مصادر» العام (§11.3). */
    final class ProviderException extends Exception {
        public final ProviderResultState classification;

        public ProviderException(ProviderResultState classification, String internalMessage) {
            super(internalMessage);
            this.classification = classification == null ? ProviderResultState.FAILED : classification;
        }
    }
}

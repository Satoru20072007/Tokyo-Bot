package com.eve.cinema;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ActorActivity extends Activity {

    // ── TMDB ─────────────────────────────────────────────────────────────
    private static final String TMDB_TOKEN  = Config.TMDB_BEARER_TOKEN;
    private static final String IMG_BASE_W  = "https://image.tmdb.org/t/p/w500";
    private static final String IMG_BASE_F  = "https://image.tmdb.org/t/p/w185";

    // ── Colors ────────────────────────────────────────────────────────────
    private static final int C_VOID    = 0xFF08080F;
    private static final int C_CARD    = 0xFF111122;
    private static final int C_CARD2   = 0xFF1A1A2E;
    private static final int C_VIOLET  = 0xFF9B6FC4;
    private static final int C_VIOLET2 = 0xFF7C4FA0;
    private static final int C_LITE    = 0xFFC4A0E8;
    private static final int C_TEXT    = 0xFFFFFFFF;
    private static final int C_STAR    = 0xFFF5C518;
    private static final int C_BORDER  = 0xFF1E1E38;
    private static final int C_MUTED   = 0xFF7070A0;
    private static final int C_LABEL   = 0xFF4A4A68;

    // ── State ─────────────────────────────────────────────────────────────
    private int    actorId;
    private String actorName;
    private String actorProfilePath;

    // ── Views ─────────────────────────────────────────────────────────────
    private ImageView      ivHeroPhoto;
    private TextView       tvName;
    private TextView       tvKnownFor;
    private TextView       tvBirthday;
    private TextView       tvBirthplace;
    private TextView       tvPopularity;
    private TextView       tvBio;
    private TextView       tvBioReadMore;
    private LinearLayout   moviesGrid;
    private ProgressBar    moviesLoader;
    private LinearLayout   statsRow;
    private View           dividerLine;
    private boolean        bioExpanded = false;

    // ─────────────────────────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Edge-to-edge: draw behind status bar & notch
        getWindow().setFlags(
            android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);

        MiuiBarFix.apply(this);

        actorId          = getIntent().getIntExtra("actor_id", 0);
        actorName        = getIntent().getStringExtra("actor_name");
        actorProfilePath = getIntent().getStringExtra("actor_profile");
        if (actorName == null) actorName = "";
        if (actorProfilePath == null) actorProfilePath = "";

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(C_VOID);

        ScrollView scroll = new ScrollView(this);
        scroll.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));
        scroll.setFillViewport(true);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setLayoutParams(new ScrollView.LayoutParams(
            ScrollView.LayoutParams.MATCH_PARENT,
            ScrollView.LayoutParams.WRAP_CONTENT));

        // ── Hero header ───────────────────────────────────────────────
        page.addView(buildHeroHeader());

        // ── Info cards row ────────────────────────────────────────────
        page.addView(buildInfoSection());

        // ── Biography ─────────────────────────────────────────────────
        page.addView(buildBioSection());

        // ── Known-for movies ─────────────────────────────────────────
        page.addView(buildMoviesSection());

        scroll.addView(page);
        root.addView(scroll);

        // ── Back button (floating) ────────────────────────────────────
        root.addView(buildBackBtn());

        setContentView(root);

        // Kick off data fetch
        if (actorId != 0) new FetchActorTask().execute();
    }

    // ─────────────────────────────────────────────────────────────────────
    //  HERO HEADER
    // ─────────────────────────────────────────────────────────────────────
    private View buildHeroHeader() {
        // Measure status bar height for correct hero sizing
        int sbHeight = 0;
        int sbRes = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (sbRes > 0) sbHeight = getResources().getDimensionPixelSize(sbRes);
        final int heroH = dpToPx(320) + sbHeight;

        FrameLayout hero = new FrameLayout(this);
        hero.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, heroH));

        // Blurred backdrop (same photo, large)
        ImageView backdrop = new ImageView(this);
        backdrop.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));
        backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);
        backdrop.setAlpha(0.18f);
        if (!actorProfilePath.isEmpty()) {
            com.bumptech.glide.Glide.with(this)
                .load(IMG_BASE_W + actorProfilePath)
                .centerCrop()
                .into(backdrop);
        }
        hero.addView(backdrop);

        // Dark scrim bottom→top
        View scrim = new View(this);
        scrim.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));
        scrim.setBackground(new GradientDrawable(
            GradientDrawable.Orientation.BOTTOM_TOP,
            new int[]{ C_VOID, 0xF008080F, 0xBB08080F, 0x6008080F, Color.TRANSPARENT }));
        hero.addView(scrim);

        // Top scrim for back button
        View topScrim = new View(this);
        FrameLayout.LayoutParams tsLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, dpToPx(120));
        tsLp.gravity = Gravity.TOP;
        topScrim.setLayoutParams(tsLp);
        topScrim.setBackground(new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{ 0xBB000000, 0x55000000, Color.TRANSPARENT }));
        hero.addView(topScrim);

        // Content: photo + name stacked
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        FrameLayout.LayoutParams contentLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT);
        contentLp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        content.setLayoutParams(contentLp);
        int sbH2 = 0;
        int sbRes2 = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (sbRes2 > 0) sbH2 = getResources().getDimensionPixelSize(sbRes2);
        content.setPadding(dpToPx(24), sbH2, dpToPx(24), dpToPx(28));

        // Avatar ring + photo
        FrameLayout avatarFrame = new FrameLayout(this);
        LinearLayout.LayoutParams afLp = new LinearLayout.LayoutParams(dpToPx(116), dpToPx(116));
        afLp.gravity = Gravity.CENTER_HORIZONTAL;
        afLp.bottomMargin = dpToPx(16);
        avatarFrame.setLayoutParams(afLp);

        // Glow ring (outer)
        View glowRing = new View(this);
        FrameLayout.LayoutParams grLp = new FrameLayout.LayoutParams(dpToPx(116), dpToPx(116));
        glowRing.setLayoutParams(grLp);
        GradientDrawable glow = new GradientDrawable();
        glow.setShape(GradientDrawable.OVAL);
        glow.setColor(Color.TRANSPARENT);
        glow.setStroke(dpToPx(3), 0x44C4A0E8);
        glowRing.setBackground(glow);
        avatarFrame.addView(glowRing);

        // Violet ring (middle)
        View violetRing = new View(this);
        FrameLayout.LayoutParams vrLp = new FrameLayout.LayoutParams(dpToPx(110), dpToPx(110));
        vrLp.gravity = Gravity.CENTER;
        violetRing.setLayoutParams(vrLp);
        GradientDrawable vRing = new GradientDrawable();
        vRing.setShape(GradientDrawable.OVAL);
        vRing.setColor(Color.TRANSPARENT);
        GradientDrawable ringGrad = new GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            new int[]{ 0xFFD4A0F8, C_VIOLET2, 0xFF4A2A70 });
        ringGrad.setShape(GradientDrawable.OVAL);
        ringGrad.setStroke(dpToPx(2), 0xFFAA72D4);
        violetRing.setBackground(ringGrad);
        avatarFrame.addView(violetRing);

        // Photo
        ivHeroPhoto = new ImageView(this);
        FrameLayout.LayoutParams photoLp = new FrameLayout.LayoutParams(dpToPx(104), dpToPx(104));
        photoLp.gravity = Gravity.CENTER;
        ivHeroPhoto.setLayoutParams(photoLp);
        ivHeroPhoto.setScaleType(ImageView.ScaleType.CENTER_CROP);
        GradientDrawable photoCircle = new GradientDrawable();
        photoCircle.setShape(GradientDrawable.OVAL);
        photoCircle.setColor(C_CARD2);
        ivHeroPhoto.setBackground(photoCircle);
        ivHeroPhoto.setClipToOutline(true);
        ivHeroPhoto.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override
            public void getOutline(View v, android.graphics.Outline o) {
                o.setOval(0, 0, v.getWidth(), v.getHeight());
            }
        });
        if (!actorProfilePath.isEmpty()) {
            com.bumptech.glide.Glide.with(this)
                .load(IMG_BASE_W + actorProfilePath)
                .centerCrop()
                .circleCrop()
                .into(ivHeroPhoto);
        }
        avatarFrame.addView(ivHeroPhoto);
        content.addView(avatarFrame);

        // Name
        tvName = new TextView(this);
        tvName.setText(actorName);
        tvName.setTextSize(26f);
        tvName.setTextColor(C_TEXT);
        tvName.setTypeface(Typeface.DEFAULT_BOLD);
        tvName.setGravity(Gravity.CENTER);
        tvName.setLetterSpacing(0f);
        tvName.setShadowLayer(16, 0, 3, 0xCC000000);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        nameLp.bottomMargin = dpToPx(6);
        tvName.setLayoutParams(nameLp);
        content.addView(tvName);

        // "Known for" badge
        tvKnownFor = new TextView(this);
        tvKnownFor.setTextSize(11f);
        tvKnownFor.setTextColor(C_LITE);
        tvKnownFor.setGravity(Gravity.CENTER);
        tvKnownFor.setLetterSpacing(0f);
        tvKnownFor.setPadding(dpToPx(16), dpToPx(5), dpToPx(16), dpToPx(5));
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setCornerRadius(dpToPx(20));
        badgeBg.setColors(new int[]{ 0x33C4A0E8, 0x1A9B6FC4 });
        badgeBg.setOrientation(GradientDrawable.Orientation.TL_BR);
        badgeBg.setStroke(1, 0x66C4A0E8);
        tvKnownFor.setBackground(badgeBg);
        tvKnownFor.setVisibility(View.INVISIBLE); // shown after data loads
        content.addView(tvKnownFor);

        hero.addView(content);
        return hero;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  INFO STATS SECTION
    // ─────────────────────────────────────────────────────────────────────
    private View buildInfoSection() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        wrap.setPadding(dpToPx(18), dpToPx(20), dpToPx(18), 0);

        // Divider line
        dividerLine = new View(this);
        LinearLayout.LayoutParams dlLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(1));
        dlLp.bottomMargin = dpToPx(18);
        dividerLine.setLayoutParams(dlLp);
        GradientDrawable divBg = new GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{ Color.TRANSPARENT, 0x55C4A0E8, 0x88C4A0E8, 0x55C4A0E8, Color.TRANSPARENT });
        dividerLine.setBackground(divBg);
        wrap.addView(dividerLine);

        // Stats cards row
        statsRow = new LinearLayout(this);
        statsRow.setOrientation(LinearLayout.HORIZONTAL);
        statsRow.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        LinearLayout cardBirthday   = new LinearLayout(this);
        LinearLayout cardPopularity = new LinearLayout(this);
        LinearLayout cardBirthplace = new LinearLayout(this);

        tvBirthday   = makeStatCard("تاريخ الميلاد", "—", true,  cardBirthday);
        tvPopularity = makeStatCard("الشهرة",         "—", false, cardPopularity);
        tvBirthplace = makeStatCard("مكان الميلاد",  "—", false, cardBirthplace);

        statsRow.addView(cardBirthday);
        statsRow.addView(cardPopularity);
        statsRow.addView(cardBirthplace);
        wrap.addView(statsRow);

        return wrap;
    }

    // Helper: populates a stat card and returns the inner value TextView
    private TextView makeStatCard(String label, String value, boolean first, LinearLayout card) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        if (!first) lp.leftMargin = dpToPx(8);
        card.setLayoutParams(lp);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setPadding(dpToPx(10), dpToPx(14), dpToPx(10), dpToPx(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dpToPx(14));
        bg.setColors(new int[]{ 0xFF151526, C_CARD });
        bg.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
        bg.setStroke(1, 0xFF1C1C36);
        card.setBackground(bg);

        TextView lbl = new TextView(this);
        lbl.setText(label);
        lbl.setTextSize(9.5f);
        lbl.setTextColor(0xFF5A5A7A);
        lbl.setTypeface(Typeface.DEFAULT_BOLD);
        lbl.setLetterSpacing(0f);
        lbl.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lblLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lblLp.bottomMargin = dpToPx(5);
        lbl.setLayoutParams(lblLp);
        card.addView(lbl);

        TextView val = new TextView(this);
        val.setText(value);
        val.setTextSize(11.5f);
        val.setTextColor(0xFFD0D0EE);
        val.setTypeface(Typeface.DEFAULT_BOLD);
        val.setGravity(Gravity.CENTER);
        val.setMaxLines(2);
        val.setEllipsize(TextUtils.TruncateAt.END);
        card.addView(val);

        return val;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  BIOGRAPHY SECTION
    // ─────────────────────────────────────────────────────────────────────
    private View buildBioSection() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        wrap.setPadding(dpToPx(18), dpToPx(22), dpToPx(18), 0);

        // Section header
        wrap.addView(makeSectionHeader("السيرة الذاتية", "Biography"));

        LinearLayout bioCard = new LinearLayout(this);
        bioCard.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams bcLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        bcLp.topMargin = dpToPx(12);
        bioCard.setLayoutParams(bcLp);
        bioCard.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        GradientDrawable bcBg = new GradientDrawable();
        bcBg.setCornerRadius(dpToPx(14));
        bcBg.setColors(new int[]{ 0xFF151526, C_CARD });
        bcBg.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
        bcBg.setStroke(1, 0xFF1C1C36);
        bioCard.setBackground(bcBg);

        tvBio = new TextView(this);
        tvBio.setTextSize(13.5f);
        tvBio.setTextColor(0xFFB8B8D8);
        tvBio.setLineSpacing(0, 1.8f);
        tvBio.setMaxLines(5);
        tvBio.setText("جاري التحميل…");
        bioCard.addView(tvBio);

        tvBioReadMore = new TextView(this);
        tvBioReadMore.setText("اقرأ أكثر");
        setReadMoreChevron(tvBioReadMore, false);
        tvBioReadMore.setTextSize(12f);
        tvBioReadMore.setTextColor(C_VIOLET);
        tvBioReadMore.setLetterSpacing(0f);
        tvBioReadMore.setVisibility(View.GONE);
        LinearLayout.LayoutParams rmLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rmLp.topMargin = dpToPx(8);
        tvBioReadMore.setLayoutParams(rmLp);
        tvBioReadMore.setClickable(true);
        tvBioReadMore.setFocusable(true);
        tvBioReadMore.setOnClickListener(v -> {
            bioExpanded = !bioExpanded;
            tvBio.setMaxLines(bioExpanded ? Integer.MAX_VALUE : 5);
            tvBioReadMore.setText(bioExpanded ? "إخفاء" : "اقرأ أكثر");
            setReadMoreChevron(tvBioReadMore, bioExpanded);
        });
        bioCard.addView(tvBioReadMore);

        wrap.addView(bioCard);
        return wrap;
    }

    // سهم «اقرأ أكثر»: يشير لاتجاه النهاية عند التوسيع، ولأعلى عند الطيّ (يتعامل مع RTL)
    private void setReadMoreChevron(TextView tv, boolean expanded) {
        android.graphics.drawable.Drawable base = getDrawable(R.drawable.ic_chevron_end);
        if (base == null) return;
        android.graphics.drawable.Drawable d = base;
        if (expanded) {
            boolean rtl = getResources().getConfiguration().getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
            android.graphics.drawable.RotateDrawable rot = new android.graphics.drawable.RotateDrawable();
            rot.setDrawable(base);
            rot.setFromDegrees(0f);
            rot.setToDegrees(360f);
            rot.setLevel(rtl ? 2500 : 7500); // 90° من اليسار / 270° من اليمين = لأعلى
            d = rot;
        }
        int s = dpToPx(13);
        d.setBounds(0, 0, s, s);
        tv.setCompoundDrawablesRelative(null, null, d, null);
        tv.setCompoundDrawablePadding(dpToPx(6));
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MOVIES SECTION
    // ─────────────────────────────────────────────────────────────────────
    private View buildMoviesSection() {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        wrap.setPadding(dpToPx(18), dpToPx(22), dpToPx(18), dpToPx(32));

        // Section header
        wrap.addView(makeSectionHeader("أبرز الأعمال", "Known For"));

        // Loader
        moviesLoader = new ProgressBar(this);
        moviesLoader.setIndeterminate(true);
        LinearLayout.LayoutParams loaderLp = new LinearLayout.LayoutParams(
            dpToPx(36), dpToPx(36));
        loaderLp.gravity = Gravity.CENTER_HORIZONTAL;
        loaderLp.topMargin = dpToPx(24);
        moviesLoader.setLayoutParams(loaderLp);
        wrap.addView(moviesLoader);

        // Grid: 2-column
        moviesGrid = new LinearLayout(this);
        moviesGrid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams gridLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        gridLp.topMargin = dpToPx(14);
        moviesGrid.setLayoutParams(gridLp);
        moviesGrid.setVisibility(View.GONE);
        wrap.addView(moviesGrid);

        return wrap;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  BACK BUTTON
    // ─────────────────────────────────────────────────────────────────────
    private View buildBackBtn() {
        // Measure real status bar height to avoid notch overlap
        int statusBarH = 0;
        int resId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resId > 0) statusBarH = getResources().getDimensionPixelSize(resId);
        int btnTop = statusBarH + dpToPx(12);

        FrameLayout btn = new FrameLayout(this);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dpToPx(46), dpToPx(46));
        lp.topMargin  = btnTop;
        lp.leftMargin = dpToPx(16);
        btn.setLayoutParams(lp);
        btn.setElevation(dpToPx(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColors(new int[]{ 0xEE0E0E22, 0xCC08080F });
        bg.setOrientation(GradientDrawable.Orientation.TL_BR);
        bg.setStroke(1, 0x44FFFFFF);
        btn.setBackground(bg);
        btn.setClickable(true);
        btn.setFocusable(true);

        ImageView icon = new ImageView(this);
        FrameLayout.LayoutParams icLp = new FrameLayout.LayoutParams(dpToPx(20), dpToPx(20));
        icLp.gravity = Gravity.CENTER;
        icon.setLayoutParams(icLp);
        icon.setImageResource(R.drawable.ic_back);
        icon.setColorFilter(C_TEXT);
        btn.addView(icon);

        btn.setOnClickListener(v -> {
            finish();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        });
        applyPressEffect(btn);
        return btn;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  SECTION HEADER
    // ─────────────────────────────────────────────────────────────────────
    private View makeSectionHeader(String arabic, String english) {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        View accent = new View(this);
        LinearLayout.LayoutParams aLp = new LinearLayout.LayoutParams(dpToPx(4), dpToPx(26));
        aLp.rightMargin = dpToPx(12);
        accent.setLayoutParams(aLp);
        GradientDrawable accentBg = new GradientDrawable();
        accentBg.setCornerRadius(dpToPx(3));
        accentBg.setColors(new int[]{ 0xFFD4A0F8, C_VIOLET2, 0x449B6FC4 });
        accentBg.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
        accent.setBackground(accentBg);
        header.addView(accent);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText(arabic);
        title.setTextSize(17f);
        title.setTextColor(C_TEXT);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setLetterSpacing(0f);
        titleCol.addView(title);

        TextView sub = new TextView(this);
        sub.setText(english);
        sub.setTextSize(11f);
        sub.setTextColor(0xFF4E4E70);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        subLp.topMargin = dpToPx(2);
        sub.setLayoutParams(subLp);
        titleCol.addView(sub);

        header.addView(titleCol);
        return header;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  MOVIE CARD (2-column grid)
    // ─────────────────────────────────────────────────────────────────────
    private View buildMovieCard(int tmdbId, String title, String posterPath,
                                 double rating, int year, String mediaType) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setClickable(true);
        card.setFocusable(true);
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setCornerRadius(dpToPx(14));
        cardBg.setColors(new int[]{ 0xFF161628, C_CARD2 });
        cardBg.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
        card.setBackground(cardBg);
        card.setClipToOutline(true);
        card.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override
            public void getOutline(View v, android.graphics.Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dpToPx(14));
            }
        });

        // Poster image
        FrameLayout posterFrame = new FrameLayout(this);
        posterFrame.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(190)));

        ImageView poster = new ImageView(this);
        poster.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT));
        poster.setScaleType(ImageView.ScaleType.FIT_XY);
        GradientDrawable posterPlaceholder = new GradientDrawable();
        posterPlaceholder.setCornerRadii(new float[]{ dpToPx(14), dpToPx(14), dpToPx(14), dpToPx(14), 0, 0, 0, 0 });
        posterPlaceholder.setColor(C_CARD2);
        poster.setBackground(posterPlaceholder);
        if (!posterPath.isEmpty()) {
            com.bumptech.glide.Glide.with(this)
                .load("https://image.tmdb.org/t/p/w342" + posterPath)
                .fitCenter()
                .placeholder(posterPlaceholder)
                .into(poster);
        }
        posterFrame.addView(poster);

        // Gradient overlay on poster bottom
        View posterGrad = new View(this);
        FrameLayout.LayoutParams pgLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, dpToPx(80));
        pgLp.gravity = Gravity.BOTTOM;
        posterGrad.setLayoutParams(pgLp);
        posterGrad.setBackground(new GradientDrawable(
            GradientDrawable.Orientation.BOTTOM_TOP,
            new int[]{ 0xCC161628, 0x6616162A, Color.TRANSPARENT }));
        posterFrame.addView(posterGrad);

        // Rating badge on poster
        if (rating > 0) {
            TextView ratingBadge = new TextView(this);
            String ratingStr = String.format(java.util.Locale.US, "%.1f", rating);
            ratingBadge.setText("★ " + ratingStr);
            ratingBadge.setTextSize(10f);
            ratingBadge.setTextColor(C_STAR);
            ratingBadge.setTypeface(Typeface.DEFAULT_BOLD);
            ratingBadge.setPadding(dpToPx(7), dpToPx(4), dpToPx(7), dpToPx(4));
            FrameLayout.LayoutParams rbLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
            rbLp.gravity = Gravity.TOP | Gravity.START;
            rbLp.topMargin  = dpToPx(8);
            rbLp.leftMargin = dpToPx(8);
            ratingBadge.setLayoutParams(rbLp);
            GradientDrawable rbBg = new GradientDrawable();
            rbBg.setCornerRadius(dpToPx(8));
            rbBg.setColors(new int[]{ 0xCC0E0E20, 0xCC12122A });
            rbBg.setOrientation(GradientDrawable.Orientation.TL_BR);
            rbBg.setStroke(1, 0x44F5C518);
            ratingBadge.setBackground(rbBg);
            posterFrame.addView(ratingBadge);
        }

        // Media type badge
        if (mediaType != null && !mediaType.isEmpty()) {
            TextView typeBadge = new TextView(this);
            typeBadge.setText("tv".equals(mediaType) ? "مسلسل" : "فيلم");
            typeBadge.setTextSize(9f);
            typeBadge.setTextColor(C_LITE);
            typeBadge.setTypeface(Typeface.DEFAULT_BOLD);
            typeBadge.setLetterSpacing(0f);
            typeBadge.setPadding(dpToPx(8), dpToPx(3), dpToPx(8), dpToPx(3));
            FrameLayout.LayoutParams tbLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT);
            tbLp.gravity = Gravity.TOP | Gravity.END;
            tbLp.topMargin   = dpToPx(8);
            tbLp.rightMargin = dpToPx(8);
            typeBadge.setLayoutParams(tbLp);
            GradientDrawable tbBg = new GradientDrawable();
            tbBg.setCornerRadius(dpToPx(20));
            tbBg.setColors(new int[]{ 0x33C4A0E8, 0x1A9B6FC4 });
            tbBg.setOrientation(GradientDrawable.Orientation.TL_BR);
            tbBg.setStroke(1, 0x66C4A0E8);
            typeBadge.setBackground(tbBg);
            posterFrame.addView(typeBadge);
        }

        card.addView(posterFrame);

        // Info below poster
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dpToPx(10), dpToPx(10), dpToPx(10), dpToPx(12));

        TextView titleTv = new TextView(this);
        titleTv.setText(title);
        titleTv.setTextSize(12f);
        titleTv.setTextColor(0xFFD8D8F0);
        titleTv.setTypeface(Typeface.DEFAULT_BOLD);
        titleTv.setMaxLines(2);
        titleTv.setEllipsize(TextUtils.TruncateAt.END);
        titleTv.setLineSpacing(0, 1.3f);
        info.addView(titleTv);

        if (year > 0) {
            TextView yearTv = new TextView(this);
            yearTv.setText(String.valueOf(year));
            yearTv.setTextSize(10.5f);
            yearTv.setTextColor(C_MUTED);
            LinearLayout.LayoutParams yLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            yLp.topMargin = dpToPx(3);
            yearTv.setLayoutParams(yLp);
            info.addView(yearTv);
        }

        card.addView(info);

        // Click → open DetailActivity (pass item_json exactly as it expects)
        final int    fId    = tmdbId;
        final String fType  = "tv".equals(mediaType) ? "tv" : "movie";
        final String fTitle = title;
        final String fPost  = posterPath;
        final double fRat   = rating;
        card.setOnClickListener(v -> {
            try {
                org.json.JSONObject item = new org.json.JSONObject();
                item.put("id",           fId);
                item.put("media_type",   fType);
                item.put("title",        fTitle);
                item.put("name",         fTitle);
                item.put("poster_path",  fPost);
                item.put("vote_average", fRat);
                Intent intent = new Intent(ActorActivity.this, DetailActivity.class);
                intent.putExtra("item_json", item.toString());
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            } catch (Exception ignored) {}
        });
        applyPressEffect(card);
        return card;
    }

    // ─────────────────────────────────────────────────────────────────────
    //  POPULATE UI AFTER FETCH
    // ─────────────────────────────────────────────────────────────────────
    private void populateProfile(JSONObject details, JSONArray credits) {
        // Known-for badge
        String knownForDept = details.optString("known_for_department", "");
        if (!knownForDept.isEmpty()) {
            tvKnownFor.setText(translateDept(knownForDept));
            tvKnownFor.setVisibility(View.VISIBLE);
            tvKnownFor.setAlpha(0f);
            tvKnownFor.animate().alpha(1f).setDuration(400).setStartDelay(200).start();
        }

        // Birthday
        String bday = details.optString("birthday", "");
        if (!bday.isEmpty()) tvBirthday.setText(formatDate(bday));

        // Birthplace
        String place = details.optString("place_of_birth", "");
        if (!place.isEmpty()) {
            // Shorten long place strings
            if (place.length() > 24) {
                String[] parts = place.split(",");
                place = parts[parts.length - 1].trim();
            }
            tvBirthplace.setText(place);
        }

        // Popularity
        double pop = details.optDouble("popularity", 0);
        if (pop > 0) {
            tvPopularity.setText(String.format(java.util.Locale.US, "%.1f", pop));
        }

        // Biography
        String bio = details.optString("biography", "");
        if (!bio.isEmpty()) {
            tvBio.setText(bio);
            // Show read-more if long
            tvBio.post(() -> {
                if (tvBio.getLineCount() > 5) {
                    tvBioReadMore.setVisibility(View.VISIBLE);
                }
            });
        } else {
            tvBio.setText("لا تتوفر سيرة ذاتية لهذا الممثل.");
            tvBio.setMaxLines(Integer.MAX_VALUE);
        }

        // Movies grid
        if (credits != null) {
            buildMoviesGrid(credits);
        }

        // Fade in hero photo if not already loaded
        ivHeroPhoto.animate().alpha(1f).setDuration(300).start();
    }

    private void buildMoviesGrid(JSONArray cast) {
        // Sort by vote_count descending, take top 10
        List<JSONObject> items = new ArrayList<>();
        for (int i = 0; i < cast.length(); i++) {
            try { items.add(cast.getJSONObject(i)); }
            catch (Exception ignored) {}
        }
        Collections.sort(items, (a, b) -> {
            double pa = a.optDouble("vote_count", 0);
            double pb = b.optDouble("vote_count", 0);
            return Double.compare(pb, pa);
        });
        int limit = Math.min(items.size(), 10);

        moviesLoader.setVisibility(View.GONE);
        moviesGrid.setVisibility(View.VISIBLE);
        moviesGrid.removeAllViews();

        // Build rows of 2
        for (int i = 0; i < limit; i += 2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rowLp.bottomMargin = dpToPx(10);
            row.setLayoutParams(rowLp);

            JSONObject item1 = items.get(i);
            String mediaType1 = item1.optString("media_type", "movie");
            String title1 = item1.optString("title",
                item1.optString("name", ""));
            String poster1 = item1.optString("poster_path", "");
            double rating1 = item1.optDouble("vote_average", 0);
            int year1 = extractYear(item1.optString("release_date",
                item1.optString("first_air_date", "")));
            int id1 = item1.optInt("id", 0);

            LinearLayout.LayoutParams cardLp1 = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            View card1 = buildMovieCard(id1, title1, poster1, rating1, year1, mediaType1);
            card1.setLayoutParams(cardLp1);
            row.addView(card1);

            if (i + 1 < limit) {
                JSONObject item2 = items.get(i + 1);
                String mediaType2 = item2.optString("media_type", "movie");
                String title2 = item2.optString("title",
                    item2.optString("name", ""));
                String poster2 = item2.optString("poster_path", "");
                double rating2 = item2.optDouble("vote_average", 0);
                int year2 = extractYear(item2.optString("release_date",
                    item2.optString("first_air_date", "")));
                int id2 = item2.optInt("id", 0);

                LinearLayout.LayoutParams cardLp2 = new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
                cardLp2.leftMargin = dpToPx(10);
                View card2 = buildMovieCard(id2, title2, poster2, rating2, year2, mediaType2);
                card2.setLayoutParams(cardLp2);
                row.addView(card2);
            } else {
                // Empty placeholder for odd count
                View spacer = new View(this);
                spacer.setLayoutParams(new LinearLayout.LayoutParams(0,
                    LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                row.addView(spacer);
            }

            // Staggered fade-in
            row.setAlpha(0f);
            row.setTranslationY(dpToPx(20));
            final int delay = i * 60;
            row.animate()
                .alpha(1f)
                .translationY(0)
                .setDuration(350)
                .setStartDelay(delay)
                .setInterpolator(new DecelerateInterpolator())
                .start();

            moviesGrid.addView(row);
        }

        if (limit == 0) {
            TextView empty = new TextView(this);
            empty.setText("لا تتوفر أعمال مسجّلة.");
            empty.setTextColor(C_MUTED);
            empty.setTextSize(13f);
            empty.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams eLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            eLp.topMargin = dpToPx(20);
            empty.setLayoutParams(eLp);
            moviesGrid.addView(empty);
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  ASYNC TASK
    // ─────────────────────────────────────────────────────────────────────
    private class FetchActorTask extends AsyncTask<Void, Void, Object[]> {
        @Override
        protected Object[] doInBackground(Void... p) {
            try {
                String base = "https://api.themoviedb.org/3/person/" + actorId;
                // Fetch in English for consistent display
                JSONObject details = fetchJson(base + "?language=en-US");
                // Overlay Arabic biography if available
                JSONObject arDetails = fetchJson(base + "?language=ar");
                if (arDetails != null && !arDetails.optString("biography", "").isEmpty()) {
                    details.put("biography", arDetails.optString("biography", ""));
                }
                JSONObject creditsObj = fetchJson(base + "/combined_credits?language=en-US");
                JSONArray cast = creditsObj != null ? creditsObj.optJSONArray("cast") : null;
                return new Object[]{ details, cast };
            } catch (Exception e) {
                return null;
            }
        }

        @Override
        protected void onPostExecute(Object[] result) {
            if (result == null) {
                tvBio.setText("تعذّر تحميل البيانات.");
                moviesLoader.setVisibility(View.GONE);
                return;
            }
            JSONObject details = (JSONObject) result[0];
            JSONArray  cast    = (JSONArray)  result[1];
            if (details != null) populateProfile(details, cast);
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    //  HELPERS
    // ─────────────────────────────────────────────────────────────────────
    private void applyPressEffect(View v) {
        v.setOnTouchListener((view, event) -> {
            switch (event.getAction()) {
                case android.view.MotionEvent.ACTION_DOWN:
                    view.animate().scaleX(0.95f).scaleY(0.95f)
                        .setDuration(100).setInterpolator(new DecelerateInterpolator()).start();
                    break;
                case android.view.MotionEvent.ACTION_UP:
                case android.view.MotionEvent.ACTION_CANCEL:
                    view.animate().scaleX(1f).scaleY(1f)
                        .setDuration(150).setInterpolator(new OvershootInterpolator(1.5f)).start();
                    break;
            }
            return false;
        });
    }

    private String translateDept(String dept) {
        switch (dept) {
            case "Acting":    return "تمثيل";
            case "Directing": return "إخراج";
            case "Writing":   return "كتابة";
            case "Production":return "إنتاج";
            default:          return dept;
        }
    }

    private String formatDate(String raw) {
        // raw = "YYYY-MM-DD"
        if (raw == null || raw.length() < 4) return raw;
        String[] parts = raw.split("-");
        if (parts.length == 3) {
            String[] months = { "يناير","فبراير","مارس","أبريل","مايو","يونيو",
                                 "يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر" };
            try {
                int m = Integer.parseInt(parts[1]) - 1;
                return parts[2] + " " + months[m] + " " + parts[0];
            } catch (Exception ignored) {}
        }
        return raw;
    }

    private int extractYear(String dateStr) {
        if (dateStr == null || dateStr.length() < 4) return 0;
        try { return Integer.parseInt(dateStr.substring(0, 4)); }
        catch (Exception e) { return 0; }
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    private JSONObject fetchJson(String urlStr) throws Exception {
        JSONObject cached = TmdbCache.getJson(urlStr);
        if (cached != null) {
            DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, 200, 0, null, cached.toString(), null, true);
            return cached;
        }
        long diagnosticStart = android.os.SystemClock.elapsedRealtime();
        int diagnosticStatus = -1;
        String diagnosticBody = null;
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            TmdbAuthorization.apply(conn, TMDB_TOKEN);
        DiagnosticsRecorder.headers("TMDB", "fetch_json", "GET", urlStr, conn.getRequestProperties());
            conn.setRequestProperty("accept", "application/json");
            diagnosticStatus = conn.getResponseCode();
            if (diagnosticStatus != 200) {
                DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, diagnosticStatus,
                        android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, null, null, false);
                return null;
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            diagnosticBody = sb.toString();
            DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, diagnosticStatus,
                    android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, diagnosticBody, null, false);
            JSONObject obj = new JSONObject(diagnosticBody);
            TmdbCache.putJson(urlStr, obj);
            return obj;
        } catch (Exception e) {
            DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, diagnosticStatus,
                    android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, diagnosticBody, e, false);
            throw e;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        MiuiBarFix.apply(this);
        EveFloatingButton.attach(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        EveFloatingButton.detach(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        MiuiBarFix.release(this);
    }
}

package com.eve.cinema.providercore;

import com.eve.cinema.playback.PlaybackMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * NormalizedCandidate — عقد النتيجة الموحدة (خطة §4.2).
 *
 * playbackUri وrequiredHeaders بيانات قصيرة العمر: لا تُخزَّن كمرجع دائم،
 * ولا تُطبع في السجلات (قرار رقم 8 و§15). hasUri() متاح للفحص دون كشف القيمة.
 *
 * Pure Java, no Android deps — unit-tested on the JVM.
 */
public final class NormalizedCandidate {

    public enum StreamType { MP4, HLS, DASH, OTHER }

    /** جودة معيارية: 480/720/1080... أو 0 لـ AUTO/غير معروفة. */
    public static final int QUALITY_AUTO = 0;

    private final String mediaKey;
    private final String providerId;          // داخلي فقط — لا يصل الواجهة
    private final PlaybackMode playbackMode;  // واحد من الأنواع الثلاثة عند الإعلان
    private final int quality;                // 480/720/1080 أو QUALITY_AUTO
    private final StreamType streamType;
    private final String playbackUri;         // مؤقت — لا يسجَّل
    private final Map<String, String> requiredHeaders; // جلسة المصدر فقط
    private final List<String> audioTracks;   // مثل "ara","eng" بعد التحقق
    private final List<String> subtitleTracks;
    private final int height;                 // <=0 غير معروف
    private final long bitrate;               // <=0 غير معروف
    private final String codec;               // nullable
    private final Boolean rangeSupport;       // null غير معروف
    private final long linkExpiresAtMs;       // <=0 غير معروف/لا ينتهي
    private final CapabilityEvidence evidence;
    private final ProviderResultState validationStatus;
    private final long checkedAtMs;
    private final String hostKey;             // بصمة عائلة المضيف، لا الرابط

    private NormalizedCandidate(Builder b) {
        this.mediaKey = b.mediaKey;
        this.providerId = b.providerId;
        this.playbackMode = b.playbackMode;
        this.quality = b.quality;
        this.streamType = b.streamType == null ? StreamType.OTHER : b.streamType;
        this.playbackUri = b.playbackUri;
        this.requiredHeaders = Collections.unmodifiableMap(new LinkedHashMap<>(b.requiredHeaders));
        this.audioTracks = Collections.unmodifiableList(new ArrayList<>(b.audioTracks));
        this.subtitleTracks = Collections.unmodifiableList(new ArrayList<>(b.subtitleTracks));
        this.height = b.height;
        this.bitrate = b.bitrate;
        this.codec = b.codec;
        this.rangeSupport = b.rangeSupport;
        this.linkExpiresAtMs = b.linkExpiresAtMs;
        this.evidence = b.evidence == null ? CapabilityEvidence.none() : b.evidence;
        this.validationStatus = b.validationStatus == null
                ? ProviderResultState.UNKNOWN : b.validationStatus;
        this.checkedAtMs = b.checkedAtMs;
        this.hostKey = b.hostKey;
    }

    public String mediaKey() { return mediaKey; }
    public String providerId() { return providerId; }
    public PlaybackMode playbackMode() { return playbackMode; }
    public int quality() { return quality; }
    public StreamType streamType() { return streamType; }
    public boolean hasUri() { return playbackUri != null && !playbackUri.isEmpty(); }

    /**
     * الرابط المؤقت. على المستدعي عدم تمريره لأي سجل. للحالة استخدم hasUri().
     */
    public String playbackUri() { return playbackUri; }

    /** ترويسات جلسة المصدر — تُمرر للمشغّل فقط ولا تُطبع. */
    public Map<String, String> requiredHeaders() { return requiredHeaders; }
    public List<String> audioTracks() { return audioTracks; }
    public List<String> subtitleTracks() { return subtitleTracks; }
    public int height() { return height; }
    public long bitrate() { return bitrate; }
    public String codec() { return codec; }
    public Boolean rangeSupport() { return rangeSupport; }
    public long linkExpiresAtMs() { return linkExpiresAtMs; }
    public CapabilityEvidence evidence() { return evidence; }
    public ProviderResultState validationStatus() { return validationStatus; }
    public long checkedAtMs() { return checkedAtMs; }
    public String hostKey() { return hostKey; }

    /** هل الرابط منتهي/قارب على الانتهاء ضمن هامش الأمان؟ */
    public boolean linkStale(long nowMs, long safetyMarginMs) {
        return linkExpiresAtMs > 0 && nowMs + safetyMarginMs >= linkExpiresAtMs;
    }

    public NormalizedCandidate withValidation(ProviderResultState state, long checkedAt) {
        Builder b = toBuilder();
        b.validationStatus = state;
        b.checkedAtMs = checkedAt;
        return b.build();
    }

    public NormalizedCandidate withFreshUri(String freshUri, long expiresAtMs) {
        Builder b = toBuilder();
        b.playbackUri = freshUri;
        b.linkExpiresAtMs = expiresAtMs;
        return b.build();
    }

    public Builder toBuilder() {
        Builder b = new Builder(mediaKey, providerId, playbackMode);
        b.quality = quality;
        b.streamType = streamType;
        b.playbackUri = playbackUri;
        b.requiredHeaders.putAll(requiredHeaders);
        b.audioTracks.addAll(audioTracks);
        b.subtitleTracks.addAll(subtitleTracks);
        b.height = height;
        b.bitrate = bitrate;
        b.codec = codec;
        b.rangeSupport = rangeSupport;
        b.linkExpiresAtMs = linkExpiresAtMs;
        b.evidence = evidence;
        b.validationStatus = validationStatus;
        b.checkedAtMs = checkedAtMs;
        b.hostKey = hostKey;
        return b;
    }

    /** تمثيل آمن للسجلات: بلا رابط وبلا ترويسات (§15.2). */
    @Override public String toString() {
        return "Candidate{key=" + mediaKey + ", provider=" + providerId
                + ", mode=" + playbackMode + ", q=" + quality
                + ", type=" + streamType + ", uri=" + (hasUri() ? "present" : "absent")
                + ", state=" + validationStatus + ", host=" + hostKey + "}";
    }

    public static final class Builder {
        private final String mediaKey;
        private final String providerId;
        private final PlaybackMode playbackMode;
        private int quality = QUALITY_AUTO;
        private StreamType streamType;
        private String playbackUri;
        private final Map<String, String> requiredHeaders = new LinkedHashMap<>();
        private final List<String> audioTracks = new ArrayList<>();
        private final List<String> subtitleTracks = new ArrayList<>();
        private int height;
        private long bitrate;
        private String codec;
        private Boolean rangeSupport;
        private long linkExpiresAtMs;
        private CapabilityEvidence evidence;
        private ProviderResultState validationStatus;
        private long checkedAtMs;
        private String hostKey;

        public Builder(String mediaKey, String providerId, PlaybackMode playbackMode) {
            if (mediaKey == null || mediaKey.isEmpty())
                throw new IllegalArgumentException("mediaKey required");
            if (providerId == null || providerId.isEmpty())
                throw new IllegalArgumentException("providerId required");
            this.mediaKey = mediaKey;
            this.providerId = providerId;
            this.playbackMode = playbackMode;
        }

        public Builder quality(int q) { this.quality = q; return this; }
        public Builder streamType(StreamType t) { this.streamType = t; return this; }
        public Builder playbackUri(String u) { this.playbackUri = u; return this; }
        public Builder header(String k, String v) {
            if (k != null && v != null) this.requiredHeaders.put(k, v);
            return this;
        }
        public Builder audioTrack(String lang) { if (lang != null) this.audioTracks.add(lang); return this; }
        public Builder subtitleTrack(String lang) { if (lang != null) this.subtitleTracks.add(lang); return this; }
        public Builder height(int h) { this.height = h; return this; }
        public Builder bitrate(long bps) { this.bitrate = bps; return this; }
        public Builder codec(String c) { this.codec = c; return this; }
        public Builder rangeSupport(Boolean r) { this.rangeSupport = r; return this; }
        public Builder linkExpiresAt(long ms) { this.linkExpiresAtMs = ms; return this; }
        public Builder evidence(CapabilityEvidence e) { this.evidence = e; return this; }
        public Builder validationStatus(ProviderResultState s) { this.validationStatus = s; return this; }
        public Builder checkedAt(long ms) { this.checkedAtMs = ms; return this; }
        public Builder hostKey(String h) { this.hostKey = h; return this; }

        public NormalizedCandidate build() { return new NormalizedCandidate(this); }
    }
}

package com.eve.cinema;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * SearchActivity — Eve Cinema Live Search
 * ─────────────────────────────────────────────────────────────────
 * Architecture:
 *   • Single RecyclerView, GridLayoutManager(3) with SpanSizeLookup
 *   • Grid poster cards (span=1) = 3-column grid matching main screen
 *   • Headers / Recent / Empty (span=3) = full-width rows
 *   • Handler-based debounce: 260ms, no Rx dependency
 *   • AtomicInteger token: only latest query updates UI
 *   • ExecutorService + Future cancel: prevents race conditions
 *   • DiffUtil on every update: zero notifyDataSetChanged calls
 *   • Shared skeleton shimmer ValueAnimator (one animator for all items)
 *   • Trending: fetched once on open, cached in memory
 *   • Recent: SharedPreferences, max 8, newest first
 *
 * MIUI Fix:
 *   • Removed windowFullscreen from theme (purple bar fix)
 *   • Sets FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS + statusBarColor = void_black
 *   • SYSTEM_UI_FLAG_FULLSCREEN still hides the status bar in UI
 *
 * Search flow:
 *   EMPTY (< 2 chars) → Recent + Trending grid
 *   TYPING (≥ 2 chars) → debounce 260ms → skeleton grid → fetch → results grid
 *   50 results: fetches pages 1+2 for movie+TV concurrently (4 requests)
 * ─────────────────────────────────────────────────────────────────
 */
public class SearchActivity extends Activity {

    // ── TMDB ────────────────────────────────────────────────────────
    private static final String TMDB_TOKEN =
            Config.TMDB_BEARER_TOKEN;

    // ── Tuning constants ─────────────────────────────────────────────
    private static final int    DEBOUNCE_MS       = 260;
    private static final int    MIN_QUERY_LENGTH  = 2;
    private static final int    MAX_RESULTS       = 50;   // was 10 — now 50
    private static final int    MAX_RECENT        = 8;
    private static final int    SKELETON_COUNT    = 15;   // 5 rows × 3 cols
    private static final int    TRENDING_COUNT    = 30;   // 10 rows × 3 cols
    private static final int    GRID_COLUMNS      = 3;
    private static final String PREFS_NAME        = "eve_search_prefs";
    private static final String PREFS_RECENT_KEY  = "recent_searches_v1";

    // ── Shared shimmer animator — accessible by adapter ViewHolders ──
    // static so GridPosterVH can attach/detach without a reference to Activity
    public static ValueAnimator sShimmerAnimator;

    // ── Interpolators ────────────────────────────────────────────────
    private static final DecelerateInterpolator DECEL = new DecelerateInterpolator(2f);

    // ── Views ────────────────────────────────────────────────────────
    private EditText              searchInput;
    private View                  clearBtn;
    private View                  backBtn;
    private RecyclerView          recyclerView;
    private View                  skeletonOverlay;

    // ── Adapter + LayoutManager ──────────────────────────────────────
    private SearchSuggestionAdapter adapter;
    private GridLayoutManager       gridLayoutManager;

    // ── Debounce ─────────────────────────────────────────────────────
    private final Handler   debounceHandler  = new Handler(Looper.getMainLooper());
    private Runnable        debounceRunnable;

    // ── Cancellation ─────────────────────────────────────────────────
    private final AtomicInteger requestToken = new AtomicInteger(0);
    private final ExecutorService executor   = Executors.newFixedThreadPool(2);
    private Future<?>           pendingFuture;

    // ── Data ─────────────────────────────────────────────────────────
    private LinkedList<String>                           recentSearches = new LinkedList<>();
    private List<SearchSuggestionAdapter.SearchItem>     trendingItems  = null;
    private SharedPreferences                            prefs;

    // ── State ────────────────────────────────────────────────────────
    private String  currentQuery    = "";
    private boolean trendingFetched = false;

    // ════════════════════════════════════════════════════════════════
    // Lifecycle
    // ════════════════════════════════════════════════════════════════

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ── MIUI Purple Bar Fix ──────────────────────────────────────
        // windowFullscreen=true in the theme caused MIUI to render its
        // control center pull indicator as a purple bar on top of the app.
        // Fix: use SYSTEM_UI_FLAG_FULLSCREEN (hides status bar in UI) +
        //      FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS (tells MIUI we own the bar)
        //      + statusBarColor = void_black (#08080F).
        MiuiBarFix.apply(this);

        // Soft keyboard adjusts content (not resize — prevents layout jumps)
        getWindow().setSoftInputMode(
                WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE |
                WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        setContentView(R.layout.activity_search);

        prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        loadRecentSearches();

        setupViews();
        setupGridLayoutManager();
        setupAdapter();
        setupSearch();
        setupShimmerAnimator();

        showIdleState();
        fetchTrending();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        MiuiBarFix.release(this);
        debounceHandler.removeCallbacksAndMessages(null);
        requestToken.incrementAndGet();
        executor.shutdownNow();
        if (sShimmerAnimator != null) {
            sShimmerAnimator.cancel();
            sShimmerAnimator = null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        MiuiBarFix.apply(this);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(0, R.anim.fade_out);
    }

    // ════════════════════════════════════════════════════════════════
    // Setup
    // ════════════════════════════════════════════════════════════════

    private void setupViews() {
        searchInput    = findViewById(R.id.search_input);
        clearBtn       = findViewById(R.id.search_clear_btn);
        backBtn        = findViewById(R.id.search_back_btn);
        recyclerView   = findViewById(R.id.search_recycler);
        skeletonOverlay = findViewById(R.id.skeleton_overlay);

        backBtn.setOnClickListener(v -> { hideKeyboard(); finish(); });
        clearBtn.setOnClickListener(v -> {
            searchInput.setText("");
            searchInput.requestFocus();
            showKeyboard();
        });
    }

    /**
     * GridLayoutManager with SpanSizeLookup:
     *   TYPE_GRID_POSTER → span 1  (3 per row — main screen style)
     *   TYPE_SKELETON    → span 1  (3 per row — grid skeleton)
     *   everything else  → span 3  (full width)
     */
    private void setupGridLayoutManager() {
        gridLayoutManager = new GridLayoutManager(this, GRID_COLUMNS);
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                int type = adapter != null ? adapter.getItemViewType(position) : GRID_COLUMNS;
                if (type == SearchSuggestionAdapter.TYPE_GRID_POSTER ||
                    type == SearchSuggestionAdapter.TYPE_SKELETON) {
                    return 1; // 3 per row
                }
                return GRID_COLUMNS; // full width
            }
        });
        gridLayoutManager.setSpanSizeLookup(gridLayoutManager.getSpanSizeLookup());
        // Cache span indices for smoother scrolling
        gridLayoutManager.getSpanSizeLookup().setSpanIndexCacheEnabled(true);
    }

    private void setupAdapter() {
        adapter = new SearchSuggestionAdapter(this);

        adapter.setSuggestionClickListener(item -> {
            if (!currentQuery.isEmpty()) {
                saveRecentSearch(item.title != null ? item.title : currentQuery);
            }
            openDetail(item);
        });

        adapter.setRecentClickListener(new SearchSuggestionAdapter.OnRecentClickListener() {
            @Override public void onRecentClick(String query) {
                searchInput.setText(query);
                searchInput.setSelection(query.length());
            }
            @Override public void onRecentDelete(String query) {
                recentSearches.remove(query);
                persistRecentSearches();
                showIdleState();
            }
        });

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setItemAnimator(null);
        recyclerView.setHasFixedSize(false);
        recyclerView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        // Important: re-set spanSizeLookup after adapter is assigned
        // so getItemViewType() calls in SpanSizeLookup resolve correctly
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                int type = adapter.getItemViewType(position);
                if (type == SearchSuggestionAdapter.TYPE_GRID_POSTER ||
                    type == SearchSuggestionAdapter.TYPE_SKELETON) {
                    return 1;
                }
                return GRID_COLUMNS;
            }
        });
        gridLayoutManager.getSpanSizeLookup().setSpanIndexCacheEnabled(true);
    }

    private void setupSearch() {
        searchInput.post(() -> { searchInput.requestFocus(); showKeyboard(); });

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void afterTextChanged(Editable s) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                String query = s.toString().trim();
                onQueryChanged(query);
                clearBtn.setVisibility(query.isEmpty() ? View.GONE : View.VISIBLE);
            }
        });

        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                String q = searchInput.getText().toString().trim();
                if (!q.isEmpty()) {
                    saveRecentSearch(q);
                    debounceHandler.removeCallbacksAndMessages(null);
                    triggerSearch(q, true);
                }
                return true;
            }
            return false;
        });
    }

    private void setupShimmerAnimator() {
        // One shared ValueAnimator for all skeleton/grid items
        // Much cheaper than per-item animators
        sShimmerAnimator = ValueAnimator.ofFloat(0.04f, 0.14f, 0.04f);
        sShimmerAnimator.setDuration(1400);
        sShimmerAnimator.setRepeatCount(ValueAnimator.INFINITE);
        sShimmerAnimator.setInterpolator(DECEL);
        sShimmerAnimator.addUpdateListener(anim -> {
            if (skeletonOverlay != null) {
                skeletonOverlay.setAlpha((float) anim.getAnimatedValue());
            }
        });
    }

    // ════════════════════════════════════════════════════════════════
    // Query handling
    // ════════════════════════════════════════════════════════════════

    private void onQueryChanged(String query) {
        currentQuery = query;

        if (debounceRunnable != null) {
            debounceHandler.removeCallbacks(debounceRunnable);
        }

        if (query.length() < MIN_QUERY_LENGTH) {
            cancelPendingSearch();
            stopShimmer();
            showIdleState();
            return;
        }

        debounceRunnable = () -> triggerSearch(query, false);
        debounceHandler.postDelayed(debounceRunnable, DEBOUNCE_MS);
    }

    /**
     * Fetches search results.
     * TMDB: movie + TV (4 concurrent) + AniList: anime
     */
    private void triggerSearch(final String query, boolean immediate) {
        cancelPendingSearch();
        DiagnosticsRecorder.newTrace("search");
        DiagnosticsRecorder.event("search", "query", "started", DiagnosticsRecorder.details("originalQuery", query, "contentType", "multi", "normalizedQuery", query.toLowerCase(java.util.Locale.ROOT)));
        final int myToken = requestToken.incrementAndGet();

        if (!immediate) {
            showSkeletonState();
        }

        pendingFuture = executor.submit(() -> {
            try {
                String enc = java.net.URLEncoder.encode(query, "UTF-8");

                // 4 طلبات TMDB متوازية: movie p1, movie p2, tv p1, tv p2
                final JSONArray[] mv1 = {null}, mv2 = {null};
                final JSONArray[] tv1 = {null}, tv2 = {null};
                // AniList للأنمي
                final java.util.List<AniListClient.AniSearchResult>[] aniResults =
                    new java.util.List[]{new java.util.ArrayList<>()};

                Thread tMv1 = new Thread(() -> {
                    try {
                        JSONObject r = fetchJson("https://api.themoviedb.org/3/search/movie?query="
                                + enc + "&language=en-US&page=1&include_adult=false");
                        if (r != null) mv1[0] = r.optJSONArray("results");
                    } catch (Exception ignored) {}
                });
                Thread tMv2 = new Thread(() -> {
                    try {
                        JSONObject r = fetchJson("https://api.themoviedb.org/3/search/movie?query="
                                + enc + "&language=en-US&page=2&include_adult=false");
                        if (r != null) mv2[0] = r.optJSONArray("results");
                    } catch (Exception ignored) {}
                });
                Thread tTv1 = new Thread(() -> {
                    try {
                        JSONObject r = fetchJson("https://api.themoviedb.org/3/search/tv?query="
                                + enc + "&language=en-US&page=1&include_adult=false");
                        if (r != null) tv1[0] = r.optJSONArray("results");
                    } catch (Exception ignored) {}
                });
                Thread tTv2 = new Thread(() -> {
                    try {
                        JSONObject r = fetchJson("https://api.themoviedb.org/3/search/tv?query="
                                + enc + "&language=en-US&page=2&include_adult=false");
                        if (r != null) tv2[0] = r.optJSONArray("results");
                    } catch (Exception ignored) {}
                });
                // AniList بحث أنمي
                Thread tAni = new Thread(() -> {
                    try {
                        aniResults[0] = AniListClient.search(query);
                    } catch (Exception ignored) {}
                });

                tMv1.start(); tMv2.start(); tTv1.start(); tTv2.start(); tAni.start();
                tMv1.join(8000); tMv2.join(8000); tTv1.join(8000); tTv2.join(8000); tAni.join(8000);

                // ── TMDB: ترتيب ذكي ──────────────────────────────────
                List<JSONObject> exact   = new ArrayList<>();
                List<JSONObject> prefix  = new ArrayList<>();
                List<JSONObject> partial = new ArrayList<>();
                String qLower = query.toLowerCase();

                processResults(mv1[0], "movie", qLower, exact, prefix, partial);
                processResults(mv2[0], "movie", qLower, exact, prefix, partial);
                processResults(tv1[0], "tv",    qLower, exact, prefix, partial);
                processResults(tv2[0], "tv",    qLower, exact, prefix, partial);

                sortByPopularity(exact);
                sortByPopularity(prefix);
                sortByPopularity(partial);

                List<JSONObject> sorted = new ArrayList<>();
                sorted.addAll(exact);
                sorted.addAll(prefix);
                sorted.addAll(partial);

                List<SearchSuggestionAdapter.SearchItem> items = new ArrayList<>();
                Set<String> seen = new HashSet<>();

                // ── أضف نتائج AniList أولاً (أنمي بمواسم صحيحة) ─────
                for (AniListClient.AniSearchResult ani : aniResults[0]) {
                    if (items.size() >= MAX_RESULTS) break;
                    String key = "ani:" + ani.anilistId;
                    if (seen.contains(key)) continue;
                    seen.add(key);
                    items.add(buildAniGridItem(ani));
                }

                // ── أضف نتائج TMDB (أفلام + مسلسلات) ────────────────
                for (JSONObject obj : sorted) {
                    if (items.size() >= MAX_RESULTS) break;
                    String mediaType = obj.optString("media_type", "movie");
                    String key       = obj.optInt("id") + ":" + mediaType;
                    if (seen.contains(key)) continue;
                    seen.add(key);
                    items.add(buildGridItem(obj));
                }

                DiagnosticsRecorder.event("TMDB/AniList", "search_decision", "completed", DiagnosticsRecorder.details("originalQuery", query, "tmdbMoviePage1Candidates", mv1[0] == null ? 0 : mv1[0].length(), "tmdbMoviePage2Candidates", mv2[0] == null ? 0 : mv2[0].length(), "tmdbTvPage1Candidates", tv1[0] == null ? 0 : tv1[0].length(), "tmdbTvPage2Candidates", tv2[0] == null ? 0 : tv2[0].length(), "anilistCandidates", aniResults[0].size(), "selectedCount", items.size(), "selectionRule", "existing app ordering: AniList first, then TMDB exact/prefix/partial popularity; MAX_RESULTS cap"));
                if (requestToken.get() == myToken) {
                    final List<SearchSuggestionAdapter.SearchItem> finalItems = items;
                    runOnUiThread(() -> {
                        if (requestToken.get() != myToken) return;
                        stopShimmer();
                        if (finalItems.isEmpty()) {
                            showEmptyState();
                        } else {
                            showGridResults(finalItems);
                        }
                    });
                }

            } catch (Exception e) {
                if (requestToken.get() == myToken) {
                    runOnUiThread(() -> {
                        if (requestToken.get() == myToken) showEmptyState();
                    });
                }
            }
        });
    }

    private void processResults(JSONArray arr, String mediaType, String queryLower,
                                 List<JSONObject> exact, List<JSONObject> prefix,
                                 List<JSONObject> partial) {
        if (arr == null) return;
        for (int i = 0; i < arr.length(); i++) {
            try {
                JSONObject item = arr.getJSONObject(i);
                // ── كشف الأنمي: Animation (16) + لغة يابانية ──────────────
                String effectiveType = mediaType;
                if ("tv".equals(mediaType)) {
                    JSONArray genreIds = item.optJSONArray("genre_ids");
                    boolean hasAnimation = false;
                    if (genreIds != null) {
                        for (int g = 0; g < genreIds.length(); g++) {
                            if (genreIds.optInt(g) == 16) { hasAnimation = true; break; }
                        }
                    }
                    if (hasAnimation && "ja".equals(item.optString("original_language", ""))) {
                        effectiveType = "anime";
                    }
                }
                item.put("media_type", effectiveType);
                String name = item.optString("title", item.optString("name", "")).toLowerCase();
                if (name.isEmpty()) continue;
                if (name.equals(queryLower))           exact.add(item);
                else if (name.startsWith(queryLower))  prefix.add(item);
                else if (name.contains(queryLower))    partial.add(item);
            } catch (Exception ignored) {}
        }
    }

    private void sortByPopularity(List<JSONObject> list) {
        list.sort((a, b) -> Double.compare(
                b.optDouble("popularity", 0),
                a.optDouble("popularity", 0)));
    }

    /** Build a TYPE_GRID_POSTER item — stores full raw JSON for DetailActivity */
    private SearchSuggestionAdapter.SearchItem buildGridItem(JSONObject obj) {
        int    id      = obj.optInt("id", -1);
        String title   = obj.optString("title", obj.optString("name", "Unknown"));
        String poster  = obj.optString("poster_path", null);
        String type    = obj.optString("media_type", "movie");
        double rating  = obj.optDouble("vote_average", 0);
        String year    = "";
        String dateStr = obj.optString("release_date", obj.optString("first_air_date", ""));
        if (dateStr.length() >= 4) year = dateStr.substring(0, 4);
        // Pass the FULL raw JSONObject so DetailActivity has backdrop, overview, etc.
        return SearchSuggestionAdapter.SearchItem.gridPoster(id, title, poster, type, year, rating, obj.toString());
    }

    /** Build a TYPE_GRID_POSTER item من نتيجة AniList */
    private SearchSuggestionAdapter.SearchItem buildAniGridItem(AniListClient.AniSearchResult ani) {
        try {
            // نبني JSON مشابه لـ TMDB حتى يعمل DetailActivity بشكل صحيح
            JSONObject obj = new JSONObject();
            obj.put("id",           ani.anilistId);
            obj.put("anilist_id",   ani.anilistId);
            obj.put("media_type",   "anime");
            obj.put("name",         ani.title);
            obj.put("title",        ani.titleEn.isEmpty() ? ani.title : ani.titleEn);
            obj.put("poster_path",  ""); // صورة AniList مباشرة في coverImage
            obj.put("anilist_cover", ani.coverImage);
            obj.put("vote_average", ani.rating);
            obj.put("first_air_date", ani.year > 0 ? ani.year + "-01-01" : "");

            String year = ani.year > 0 ? String.valueOf(ani.year) : "";
            String displayTitle = ani.titleEn.isEmpty() ? ani.title : ani.titleEn;

            return SearchSuggestionAdapter.SearchItem.gridPoster(
                ani.anilistId, displayTitle, null, "anime",
                year, ani.rating, obj.toString()
            );
        } catch (Exception e) {
            return null;
        }
    }

    /** Build a TYPE_SUGGESTION item (list-style — used for trending in idle if needed) */
    private SearchSuggestionAdapter.SearchItem buildGridItemFromRaw(JSONObject obj) {
        return buildGridItem(obj);
    }

    private void cancelPendingSearch() {
        if (pendingFuture != null && !pendingFuture.isDone()) {
            pendingFuture.cancel(true);
        }
    }

    // ════════════════════════════════════════════════════════════════
    // State management
    // ════════════════════════════════════════════════════════════════

    /** Idle: recent searches (full-width) + trending grid */
    private void showIdleState() {
        List<SearchSuggestionAdapter.SearchItem> items = new ArrayList<>();

        if (!recentSearches.isEmpty()) {
            items.add(SearchSuggestionAdapter.SearchItem.header("Recent Searches"));
            for (String q : recentSearches) {
                items.add(SearchSuggestionAdapter.SearchItem.recent(q));
            }
        }

        if (trendingItems != null && !trendingItems.isEmpty()) {
            items.add(SearchSuggestionAdapter.SearchItem.header("Trending Now"));
            items.addAll(trendingItems); // TYPE_GRID_POSTER items → 3-col grid
        } else if (!trendingFetched) {
            items.add(SearchSuggestionAdapter.SearchItem.header("Trending Now"));
            for (int i = 0; i < 9; i++) { // 3 rows of skeleton
                items.add(SearchSuggestionAdapter.SearchItem.skeleton(1000 + i));
            }
        }

        stopShimmer();
        submitWithFade(items);
    }

    /** Skeleton grid while loading results */
    private void showSkeletonState() {
        List<SearchSuggestionAdapter.SearchItem> items = new ArrayList<>();
        for (int i = 0; i < SKELETON_COUNT; i++) {
            items.add(SearchSuggestionAdapter.SearchItem.skeleton(i));
        }
        adapter.setItems(items);
        startShimmer();
    }

    /** Grid results after search */
    private void showGridResults(List<SearchSuggestionAdapter.SearchItem> results) {
        submitWithFade(results);
    }

    /** Empty state */
    private void showEmptyState() {
        List<SearchSuggestionAdapter.SearchItem> items = new ArrayList<>();
        items.add(SearchSuggestionAdapter.SearchItem.empty());
        submitWithFade(items);
    }

    /** Fade-in transition on list update */
    private void submitWithFade(List<SearchSuggestionAdapter.SearchItem> items) {
        recyclerView.setAlpha(0f);
        adapter.setItems(items);
        recyclerView.animate()
                .alpha(1f)
                .setDuration(180)
                .setInterpolator(DECEL)
                .start();
    }

    // ════════════════════════════════════════════════════════════════
    // Shimmer — single shared animator
    // ════════════════════════════════════════════════════════════════

    private void startShimmer() {
        if (skeletonOverlay != null) skeletonOverlay.setVisibility(View.VISIBLE);
        if (sShimmerAnimator != null && !sShimmerAnimator.isRunning()) {
            sShimmerAnimator.start();
        }
    }

    private void stopShimmer() {
        if (sShimmerAnimator != null) sShimmerAnimator.cancel();
        if (skeletonOverlay != null) {
            skeletonOverlay.setAlpha(0f);
            skeletonOverlay.setVisibility(View.GONE);
        }
    }

    // ════════════════════════════════════════════════════════════════
    // Trending
    // ════════════════════════════════════════════════════════════════

    private void fetchTrending() {
        executor.submit(() -> {
            try {
                // Fetch 2 pages of trending for a full 30-item grid
                final JSONArray[] p1 = {null}, p2 = {null};
                Thread t1 = new Thread(() -> {
                    try {
                        JSONObject r = fetchJson("https://api.themoviedb.org/3/trending/all/week?language=en-US&page=1");
                        if (r != null) p1[0] = r.optJSONArray("results");
                    } catch (Exception ignored) {}
                });
                Thread t2 = new Thread(() -> {
                    try {
                        JSONObject r = fetchJson("https://api.themoviedb.org/3/trending/all/week?language=en-US&page=2");
                        if (r != null) p2[0] = r.optJSONArray("results");
                    } catch (Exception ignored) {}
                });
                t1.start(); t2.start();
                t1.join(8000); t2.join(8000);

                List<SearchSuggestionAdapter.SearchItem> trending = new ArrayList<>();
                appendTrending(trending, p1[0]);
                appendTrending(trending, p2[0]);

                trendingFetched = true;
                trendingItems   = trending;

                runOnUiThread(() -> {
                    if (currentQuery.length() < MIN_QUERY_LENGTH) showIdleState();
                });
            } catch (Exception e) {
                trendingFetched = true;
            }
        });
    }

    private void appendTrending(List<SearchSuggestionAdapter.SearchItem> list, JSONArray arr) {
        if (arr == null) return;
        for (int i = 0; i < arr.length() && list.size() < TRENDING_COUNT; i++) {
            try {
                JSONObject obj = arr.getJSONObject(i);
                // ── كشف الأنمي في التريندينج ──────────────────────────────
                String mt = obj.optString("media_type", "movie");
                if ("tv".equals(mt)) {
                    JSONArray genreIds = obj.optJSONArray("genre_ids");
                    boolean hasAnimation = false;
                    if (genreIds != null) {
                        for (int g = 0; g < genreIds.length(); g++) {
                            if (genreIds.optInt(g) == 16) { hasAnimation = true; break; }
                        }
                    }
                    if (hasAnimation && "ja".equals(obj.optString("original_language", ""))) {
                        obj.put("media_type", "anime");
                    }
                }
                list.add(buildGridItem(obj));
            } catch (Exception ignored) {}
        }
    }

    // ════════════════════════════════════════════════════════════════
    // Navigation
    // ════════════════════════════════════════════════════════════════

    private void openDetail(SearchSuggestionAdapter.SearchItem item) {
        hideKeyboard();
        try {
            // Use rawJson if available (grid poster) — has full TMDB data (backdrop, overview, etc.)
            // Fall back to building minimal JSON for list-style suggestions
            JSONObject obj;
            if (item.rawJson != null && !item.rawJson.isEmpty()) {
                obj = new JSONObject(item.rawJson);
                // Ensure media_type is always set correctly (search results may not have it)
                obj.put("media_type", item.mediaType != null ? item.mediaType : "movie");
            } else {
                obj = new JSONObject();
                obj.put("id",          item.tmdbId);
                obj.put("media_type",  item.mediaType);
                obj.put("title",       item.title != null ? item.title : "");
                obj.put("name",        item.title != null ? item.title : "");
                obj.put("poster_path", item.posterPath != null ? item.posterPath : "");
            }
            Intent intent = new Intent(this, DetailActivity.class);
            intent.putExtra("item_json", obj.toString());
            startActivity(intent);
            overridePendingTransition(R.anim.enter_from_right, R.anim.exit_to_left);
        } catch (Exception ignored) {}
    }

    // ════════════════════════════════════════════════════════════════
    // Recent searches persistence
    // ════════════════════════════════════════════════════════════════

    private void loadRecentSearches() {
        recentSearches.clear();
        for (int i = 0; i < MAX_RECENT; i++) {
            String val = prefs.getString(PREFS_RECENT_KEY + "_" + i, null);
            if (val != null) recentSearches.addLast(val);
        }
    }

    private void saveRecentSearch(String query) {
        if (query == null || query.trim().isEmpty()) return;
        String trimmed = query.trim();
        recentSearches.remove(trimmed);
        recentSearches.addFirst(trimmed);
        while (recentSearches.size() > MAX_RECENT) recentSearches.removeLast();
        persistRecentSearches();
    }

    private void persistRecentSearches() {
        SharedPreferences.Editor editor = prefs.edit();
        for (int i = 0; i < MAX_RECENT; i++) editor.remove(PREFS_RECENT_KEY + "_" + i);
        int idx = 0;
        for (String q : recentSearches) editor.putString(PREFS_RECENT_KEY + "_" + idx++, q);
        editor.apply();
    }

    // ════════════════════════════════════════════════════════════════
    // Network
    // ════════════════════════════════════════════════════════════════

    private JSONObject fetchJson(String urlStr) throws Exception {
        JSONObject cached = TmdbCache.getJson(urlStr);
        if (cached != null) {
            DiagnosticsRecorder.network("TMDB", "search_fetch_json", "GET", urlStr, 200, 0, null, cached.toString(), null, true);
            return cached;
        }
        long diagnosticStart = android.os.SystemClock.elapsedRealtime();
        int diagnosticStatus = -1;
        String diagnosticBody = null;
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        TmdbAuthorization.apply(conn, TMDB_TOKEN);
        DiagnosticsRecorder.headers("TMDB", "fetch_json", "GET", urlStr, conn.getRequestProperties());
        conn.setRequestProperty("accept", "application/json");

        diagnosticStatus = conn.getResponseCode();
        if (diagnosticStatus != 200) {
            DiagnosticsRecorder.network("TMDB", "search_fetch_json", "GET", urlStr, diagnosticStatus,
                    android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, null, null, false);
            conn.disconnect(); return null;
        }

        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        conn.disconnect();

        diagnosticBody = sb.toString();
        DiagnosticsRecorder.network("TMDB", "search_fetch_json", "GET", urlStr, diagnosticStatus,
                android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, diagnosticBody, null, false);
        JSONObject obj = new JSONObject(diagnosticBody);
        TmdbCache.putJson(urlStr, obj);
        return obj;
    }

    // ════════════════════════════════════════════════════════════════
    // Keyboard utils
    // ════════════════════════════════════════════════════════════════

    private void showKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        View focus = getCurrentFocus();
        if (imm != null && focus != null) imm.hideSoftInputFromWindow(focus.getWindowToken(), 0);
    }
}

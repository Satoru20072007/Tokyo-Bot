package com.eve.cinema;

/** Maps documented Google Play services status codes to safe user-facing categories. */
public final class GoogleSignInFailureClassifier {
    public enum Category {
        USER_CANCELLED,
        CONFIGURATION,
        NETWORK,
        OTHER
    }

    private GoogleSignInFailureClassifier() {}

    public static Category classify(int statusCode) {
        if (statusCode == 12501) return Category.USER_CANCELLED;
        if (statusCode == 10) return Category.CONFIGURATION;
        if (statusCode == 7) return Category.NETWORK;
        return Category.OTHER;
    }
}

package com.eve.cinema.stremio;

import org.json.JSONObject;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Resolves a TMDB id to the IMDb id that stream add-ons expect, through TMDB's own
 * {@code /movie/{id}/external_ids} and {@code /tv/{id}/external_ids} endpoints (verified
 * 2026-10-27). Pure logic: the HTTP call and the credential are injected, so nothing here knows a
 * token and nothing is logged.
 *
 * <p>Definitive answers (an id, or "TMDB has no IMDb id for this title") are cached in memory;
 * network failures are NOT cached, so the next attempt can succeed.
 */
public final class StremioIdResolver {
    /** Returns the response body of a GET to {@code url}, or throws. */
    public interface Fetcher {
        String get(String url, int timeoutMs) throws IOException;
    }

    private static final int MAX_CACHE = 256;
    private final Fetcher fetcher;
    private final String apiBase;
    private final Map<String, String> cache = new LinkedHashMap<String, String>() {
        @Override protected boolean removeEldestEntry(Map.Entry<String, String> eldest) { return size() > MAX_CACHE; }
    };
    private static final String NONE = "";

    public StremioIdResolver(Fetcher fetcher, String apiBase) {
        this.fetcher = fetcher;
        this.apiBase = apiBase.endsWith("/") ? apiBase.substring(0, apiBase.length() - 1) : apiBase;
    }

    /** The {@code tt…} id, or null when unknown/unavailable. Never throws. */
    public String resolveImdb(String type, String tmdbId, int timeoutMs) {
        if (tmdbId == null || !tmdbId.matches("\\d{1,12}")) return null;
        String kind = StremioContentRef.SERIES.equals(type) || "anime".equals(type) ? "tv" : "movie";
        String key = kind + "|" + tmdbId;
        synchronized (cache) {
            String cached = cache.get(key);
            if (cached != null) return cached.isEmpty() ? null : cached;
        }
        try {
            String body = fetcher.get(apiBase + "/" + kind + "/" + tmdbId + "/external_ids", timeoutMs);
            if (body == null || body.length() > 64 * 1024) return null;
            JSONObject json = new JSONObject(body);
            String imdb = json.isNull("imdb_id") ? "" : json.optString("imdb_id", "").trim();
            String result = StremioContentRef.isImdbId(imdb) ? imdb : NONE;
            synchronized (cache) { cache.put(key, result); }
            return result.isEmpty() ? null : result;
        } catch (Exception transientFailure) {
            return null;   // not cached: try again next time
        }
    }

    /** Test/diagnostic helper. */
    int cachedEntries() { synchronized (cache) { return cache.size(); } }
}

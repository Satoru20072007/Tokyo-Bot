package com.eve.cinema;

import android.app.Activity;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.WindowManager;

/**
 * MiuiBarFix
 * ─────────────────────────────────────────────────────────────────
 * يحل مشكلتين:
 *
 * 1. المستطيل الأسود حول ثقب الكاميرا (Notch / DisplayCutout)
 *    السبب: النظام يحجز منطقة الـ notch ويملأها بلون أسود افتراضي.
 *    الحل: LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES → يجعل التطبيق
 *    يمتد خلف منطقة الكاميرا كاملاً، فيصبح لونها = لون خلفية التطبيق
 *    (void_black #08080F) بدلاً من الأسود الصريح.
 *
 * 2. الشريط البنفسجي عند سحب مركز التحكم MIUI
 *    الحل: statusBarColor = void_black + FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS
 *    + إعادة إخفاء الـ system UI تلقائياً بعد 1500ms.
 * ─────────────────────────────────────────────────────────────────
 */
public final class MiuiBarFix {

    private static final int    AUTO_HIDE_MS = 1500;
    private static final Handler handler     = new Handler(Looper.getMainLooper());

    private MiuiBarFix() {}

    @SuppressWarnings("deprecation")
    public static void apply(final Activity activity) {
        if (activity == null || activity.isFinishing()) return;

        // ── 1. Notch / Camera Cutout Fix (API 28+) ──────────────────
        // SHORT_EDGES = التطبيق يمتد خلف منطقة الكاميرا كاملاً
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = activity.getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            activity.getWindow().setAttributes(lp);
        }

        // ── 2. Status bar شفاف تماماً ────────────────────────────────
        // TRANSPARENT = يظهر windowBackground (#08080F void_black) في منطقة الكاميرا
        // بدلاً من أي لون رمادي يرسمه النظام
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            activity.getWindow().clearFlags(
                    WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            activity.getWindow().addFlags(
                    WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            activity.getWindow().setStatusBarColor(android.graphics.Color.TRANSPARENT);
        }

        // أخفِ الـ system UI الآن
        hideNow(activity);

        // ── 3. Auto-restore fullscreen بعد سحب مركز التحكم ──────────
        final View decor = activity.getWindow().getDecorView();
        decor.setOnSystemUiVisibilityChangeListener(null);
        decor.setOnSystemUiVisibilityChangeListener(visibility -> {
            if ((visibility & View.SYSTEM_UI_FLAG_FULLSCREEN) == 0) {
                handler.removeCallbacksAndMessages(activity);
                handler.postAtTime(() -> {
                    if (!activity.isFinishing()) hideNow(activity);
                }, activity, SystemClock.uptimeMillis() + AUTO_HIDE_MS);
            }
        });
    }

    public static void release(Activity activity) {
        if (activity == null) return;
        handler.removeCallbacksAndMessages(activity);
        try {
            activity.getWindow().getDecorView()
                    .setOnSystemUiVisibilityChangeListener(null);
        } catch (Exception ignored) {}
    }

    @SuppressWarnings("deprecation")
    private static void hideNow(Activity activity) {
        // LAYOUT_FULLSCREEN: يجعل الـ windowBackground يمتد لمنطقة الكاميرا
        // بدونه النظام يرسم لون رمادي في الـ cutout حتى مع TRANSPARENT statusBar
        activity.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN        |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }
}

package com.eve.cinema.playback;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Short-lived shared cache of details-page source decisions, keyed by
 * "tmdbId|mediaType". Shared between DetailActivity (which probes) and
 * EpisodesActivity (which consumes the choice) so a fast tap on
 * «ابدأ المشاهدة» or a direct entry can still recover the verified decision.
 *
 * WP2 classification contract (I6/I7):
 *  - a VERIFIED decision is cached for {@link #TTL_VERIFIED_MS};
 *  - a DEFINITIVE negative (search completed, nothing passed) is cached only
 *    briefly ({@link #TTL_NEGATIVE_MS}) so a fixed provider/title recovers fast;
 *  - an UNRESOLVED_TRANSIENT outcome is NEVER stored — a timeout must not be
 *    remembered as "no source".
 * The cache is keyed by the identity it describes: a series-level decision
 * says nothing about any single episode.
 *
 * Pure Java — unit-tested on the JVM.
 */
public final class SourceDecisionCache {

    private static final long TTL_VERIFIED_MS =
            com.eve.cinema.providercore.Tuning.VERIFIED_DECISION_TTL_MS;
    private static final long TTL_NEGATIVE_MS =
            com.eve.cinema.providercore.Tuning.NEGATIVE_DECISION_TTL_MS;
    private static final int MAX_ENTRIES = 32;

    private static final class CachedDecision {
        final SourceChoice.Decision decision;
        final long ttl;
        final long at;
        CachedDecision(SourceChoice.Decision d, long ttl, long at) {
            this.decision = d; this.ttl = ttl; this.at = at;
        }
    }

    private static final Map<String, CachedDecision> MAP = Collections.synchronizedMap(
            new LinkedHashMap<String, CachedDecision>(MAX_ENTRIES, 0.75f, true) {
                @Override protected boolean removeEldestEntry(Map.Entry<String, CachedDecision> e) {
                    return size() > MAX_ENTRIES;
                }
            });

    private SourceDecisionCache() {}

    /** Cached decision or null when absent/stale. */
    public static SourceChoice.Decision get(String key) {
        if (key == null) return null;
        synchronized (MAP) {
            CachedDecision e = MAP.get(key);
            if (e == null) return null;
            if (System.currentTimeMillis() - e.at >= e.ttl) {
                MAP.remove(key);
                return null;
            }
            return e.decision;
        }
    }

    /**
     * Classified store (WP2): the outcome decides whether and how long the
     * decision may be remembered. A transient outcome is dropped on the floor.
     */
    public static void put(String key, SourceChoice.Decision decision, ProbeOutcome outcome) {
        if (key == null || decision == null || outcome == null) return;
        if (!outcome.isResolved()) return; // transient: never cached
        long ttl = outcome == ProbeOutcome.VERIFIED ? TTL_VERIFIED_MS : TTL_NEGATIVE_MS;
        synchronized (MAP) {
            MAP.put(key, new CachedDecision(decision, ttl, System.currentTimeMillis()));
        }
    }

    /**
     * Compatibility store for legacy callers: keeps the historical semantics
     * (full TTL). New code must use {@link #put(String, SourceChoice.Decision,
     * ProbeOutcome)} so transient failures are never persisted.
     */
    public static void put(String key, SourceChoice.Decision decision) {
        if (key == null || decision == null) return;
        synchronized (MAP) {
            MAP.put(key, new CachedDecision(decision, TTL_VERIFIED_MS,
                    System.currentTimeMillis()));
        }
    }

    /** Test hook. */
    public static void clear() {
        synchronized (MAP) { MAP.clear(); }
    }
}

package com.eve.cinema;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * SettingsStore — تخزين الإعدادات الحقيقية الوحيد في التطبيق.
 * ─────────────────────────────────────────────────────────────────────────────
 * كل إعداد ظاهر في شاشة الإعدادات يُقرأ ويُكتب من هنا، ويستهلكه المشغّل
 * أو الواجهة فعليًا. لا توجد مفاتيح وهمية: إن لم يكن للإعداد مستهلك حقيقي
 * فلا مكان له هنا.
 *
 * المستهلكون:
 *   • defaultQuality   → PlayerActivity (اختيار الجودة الافتراضية للبث)
 *   • subtitleLanguage → PlayerActivity (اختيار مسار الترجمة المفضل)
 *   • subtitleSize     → PlayerActivity (الحجم الابتدائي لنص الترجمة)
 *   • autoplayNext     → PlayerActivity (تشغيل الحلقة التالية تلقائيًا)
 *   • reduceMotion     → MainActivity / SettingsActivity (تخفيف الحركة)
 * ─────────────────────────────────────────────────────────────────────────────
 */
public final class SettingsStore {

    private static final String PREFS = "eve_settings";

    // ── Playback ──────────────────────────────────────────
    public static final String QUALITY_AUTO  = "auto";
    public static final String QUALITY_1080  = "1080p";
    public static final String QUALITY_720   = "720p";
    public static final String QUALITY_480   = "480p";

    public static final String SUB_LANG_AUTO = "auto";
    public static final String SUB_LANG_AR   = "ar";
    public static final String SUB_LANG_EN   = "en";

    public static final int SUB_SIZE_S = 0;
    public static final int SUB_SIZE_M = 1;
    public static final int SUB_SIZE_L = 2;

    /** أحجام الترجمة الفعلية (sp) المقابلة لـ S/M/L — تُستخدم في PlayerActivity */
    public static final float SUB_SIZE_S_SP = 15f;
    public static final float SUB_SIZE_M_SP = 18f;
    public static final float SUB_SIZE_L_SP = 22f;

    private static final String KEY_QUALITY       = "default_quality";
    private static final String KEY_SUB_LANG      = "subtitle_language";
    private static final String KEY_SUB_SIZE      = "subtitle_size";
    private static final String KEY_AUTOPLAY_NEXT = "autoplay_next";
    private static final String KEY_REDUCE_MOTION = "reduce_motion";

    private SettingsStore() {}

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    // ── Playback quality ──────────────────────────────────
    public static String getDefaultQuality(Context ctx) {
        return prefs(ctx).getString(KEY_QUALITY, QUALITY_AUTO);
    }

    public static void setDefaultQuality(Context ctx, String quality) {
        prefs(ctx).edit().putString(KEY_QUALITY, quality).apply();
    }

    // ── Subtitles ─────────────────────────────────────────
    public static String getSubtitleLanguage(Context ctx) {
        return prefs(ctx).getString(KEY_SUB_LANG, SUB_LANG_AUTO);
    }

    public static void setSubtitleLanguage(Context ctx, String lang) {
        prefs(ctx).edit().putString(KEY_SUB_LANG, lang).apply();
    }

    public static int getSubtitleSize(Context ctx) {
        return prefs(ctx).getInt(KEY_SUB_SIZE, SUB_SIZE_M);
    }

    public static void setSubtitleSize(Context ctx, int size) {
        prefs(ctx).edit().putInt(KEY_SUB_SIZE, size).apply();
    }

    public static float getSubtitleSizeSp(Context ctx) {
        switch (getSubtitleSize(ctx)) {
            case SUB_SIZE_S: return SUB_SIZE_S_SP;
            case SUB_SIZE_L: return SUB_SIZE_L_SP;
            default:         return SUB_SIZE_M_SP;
        }
    }

    // ── Autoplay ──────────────────────────────────────────
    public static boolean isAutoplayNext(Context ctx) {
        return prefs(ctx).getBoolean(KEY_AUTOPLAY_NEXT, true);
    }

    public static void setAutoplayNext(Context ctx, boolean on) {
        prefs(ctx).edit().putBoolean(KEY_AUTOPLAY_NEXT, on).apply();
    }

    // ── Motion ────────────────────────────────────────────
    public static boolean isReduceMotion(Context ctx) {
        return prefs(ctx).getBoolean(KEY_REDUCE_MOTION, false);
    }

    public static void setReduceMotion(Context ctx, boolean on) {
        prefs(ctx).edit().putBoolean(KEY_REDUCE_MOTION, on).apply();
    }
}

package com.eve.cinema.moviebox;

import java.util.List;

/**
 * Explicit lexicographic release-choice comparator (WP3).
 *
 * Ordering — a stronger tier always beats every weaker one:
 *   identity ≻ covers the requested episode ≻ stream resolves ≻
 *   verified Arabic subtitle ≻ verified Arabic audio (only set when Arabic
 *   audio was requested) ≻ verified English fallback ≻ exact-season release
 *   over a multi-season pack ≻ stable tie-break by subject id.
 *
 * Every flag is VERIFIED evidence, never a label: identity/coverage come from
 * the matcher gates, language flags from captions/audio actually resolved for
 * that release. A language preference can therefore never beat a failed
 * identity or coverage check (I1).
 *
 * Pure Java — unit-tested on the JVM.
 */
public final class ReleaseRanker {

    private ReleaseRanker() {}

    /** Verified evidence about one evaluated release candidate. */
    public static final class Evidence {
        /** Passed the title/type/year identity gates. */
        public boolean identityOk;
        /** The release covers the requested episode (label claim + mapping succeeded). */
        public boolean coversRequestedEpisode;
        /** Play-info/resources produced at least one stream for the episode. */
        public boolean streamResolves;
        /** A selectable Arabic caption belongs to this release's own stream. */
        public boolean arabicSubtitle;
        /** Arabic audio verified for this release (set only when Arabic audio was requested). */
        public boolean arabicAudio;
        /** A selectable English caption or English audio exists as a fallback. */
        public boolean englishFallback;
        /** The release targets exactly the requested season (not a multi-season pack). */
        public boolean exactSeasonRelease;
        /** Stable tie-breaker. */
        public String subjectId = "";
    }

    /** Negative when {@code a} ranks before {@code b}. */
    public static int compare(Evidence a, Evidence b) {
        int c;
        c = Boolean.compare(b.identityOk, a.identityOk);                 if (c != 0) return c;
        c = Boolean.compare(b.coversRequestedEpisode,
                            a.coversRequestedEpisode);                     if (c != 0) return c;
        c = Boolean.compare(b.streamResolves, a.streamResolves);           if (c != 0) return c;
        c = Boolean.compare(b.arabicSubtitle, a.arabicSubtitle);           if (c != 0) return c;
        c = Boolean.compare(b.arabicAudio, a.arabicAudio);                 if (c != 0) return c;
        c = Boolean.compare(b.englishFallback, a.englishFallback);         if (c != 0) return c;
        c = Boolean.compare(b.exactSeasonRelease, a.exactSeasonRelease);   if (c != 0) return c;
        String ia = a.subjectId == null ? "" : a.subjectId;
        String ib = b.subjectId == null ? "" : b.subjectId;
        return ia.compareTo(ib);
    }

    /** Index of the best evidence in {@code list}, or -1 when empty. */
    public static int indexOfBest(List<Evidence> list) {
        if (list == null || list.isEmpty()) return -1;
        int best = 0;
        for (int i = 1; i < list.size(); i++) {
            if (compare(list.get(i), list.get(best)) < 0) best = i;
        }
        return best;
    }
}

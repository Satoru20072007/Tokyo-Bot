package com.eve.cinema;

import com.eve.cinema.extractor.CinemaBoxExtractor;
import com.eve.cinema.moviebox.MovieBoxBridge;
import com.eve.cinema.moviebox.MovieBoxModels;
import com.eve.cinema.playback.ManifestProber;
import com.eve.cinema.playback.ModeResolver;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Shared genuine-mode evidence for the pre-player chooser (P4), used by both
 * DetailActivity (movies) and EpisodesActivity (episodes) so the two screens
 * can never disagree about what «ترجمة عربية» / «دبلجة عربية» mean.
 *
 * Evidence rules (see requirement G):
 *  - External Arabic subtitle: Arabic metadata for a parseable external caption associated
 *    with the active release subject and episode. This is availability evidence,
 *    not proof that a provider file matches the exact cut or is synchronized.
 *  - In-video Arabic subtitle: a separate MovieBox subject with subtitle-release
 *    metadata and a verified playable stream for this exact title/episode. The
 *    metadata cannot prove that text is visibly burned into the pixels.
 *  - Arabic dub: an Arabic audio language declared by the ACTUAL adaptive
 *    manifest, or a documented MovieBox dub release that verifyDubRelease
 *    confirmed resolves to a playable stream for the exact episode. A release
 *    label, title token, or Arabic subtitle URL is never dub evidence.
 *  - CinemaBox exposes no dub metadata, so dub is never offered there.
 */
final class ModeEvidence {

    private ModeEvidence() {}

    /** Verified Arabic-dub probes (subjectId|s|e → verdict). */
    private static final long DUB_TTL_MS = 30 * 60 * 1000L;
    /** WP6: a NEGATIVE verdict may stem from a transient network failure —
     *  verifyDubRelease swallows exceptions into false — so negatives expire
     *  quickly instead of hiding a real dub for 30 minutes (I6). */
    private static final long DUB_NEGATIVE_TTL_MS = 2 * 60 * 1000L;
    private static final class DubVerdict {
        final boolean ok; final long at;
        DubVerdict(boolean ok, long at) { this.ok = ok; this.at = at; }
    }
    private static final Map<String, DubVerdict> DUB_VERDICTS =
            Collections.synchronizedMap(new LinkedHashMap<String, DubVerdict>(32, 0.75f, true));
    private static final Map<String, DubVerdict> VIDEO_SUB_VERDICTS =
            Collections.synchronizedMap(new LinkedHashMap<String, DubVerdict>(32, 0.75f, true));

    /**
     * MovieBox payload evidence. Runs network preflights (manifest probe, dub
     * verification) — call from a background thread only.
     */
    static ModeResolver.Availability forMovieBox(MovieBoxBridge bridge,
                                                 MovieBoxModels.Playback p) {
        List<String> subLangs = new ArrayList<>();
        List<String> audioLangs = new ArrayList<>();
        if (p == null || p.streams == null || p.streams.isEmpty())
            return ModeResolver.evaluate(subLangs, audioLangs, false, false);

        // The exact stream the player will start with (adaptive preferred).
        int idx = 0;
        for (int i = 0; i < p.streams.size(); i++) {
            if (p.streams.get(i).isAdaptive()) { idx = i; break; }
        }
        MovieBoxModels.StreamSource stream = p.streams.get(idx);
        for (MovieBoxModels.SubtitleOption o : p.subtitlesFor(stream)) {
            if (o == null) continue;
            if (!MovieBoxModels.Playback.belongsTo(o, stream, p)) continue;
            subLangs.add(o.languageEvidence());
        }
        if (p.audioLanguage != null) audioLangs.add(p.audioLanguage);
        if (stream.isAdaptive())
            audioLangs.addAll(ManifestProber.fetchAudioLanguages(stream.url, stream.headers));

        boolean dubVerified = false;
        MovieBoxModels.DubOption dub = p.arabicDub();
        if (dub != null) dubVerified = verifyDubCached(bridge, p, dub);
        boolean videoSubtitleVerified = p.inVideoSubtitleRelease;
        MovieBoxModels.DubOption videoSubtitle = p.arabicSubtitleRelease();
        if (!videoSubtitleVerified && videoSubtitle != null)
            videoSubtitleVerified = verifyVideoSubtitleCached(bridge, p, videoSubtitle);
        return ModeResolver.evaluate(subLangs, audioLangs, dubVerified, videoSubtitleVerified);
    }

    /**
     * CinemaBox media evidence: subtitles from the resolved media; audio only
     * when the chosen stream is an HLS manifest that declares languages.
     * Dub is never claimed — CinemaBox exposes no dub evidence source.
     */
    static ModeResolver.Availability forCinemaBox(CinemaBoxExtractor.MediaResult media) {
        List<String> subLangs = new ArrayList<>();
        List<String> audioLangs = new ArrayList<>();
        if (media != null) {
            if (media.subtitles != null) {
                for (CinemaBoxExtractor.SubtitleTrack t : media.subtitles)
                    if (t != null && t.language != null) subLangs.add(t.language);
            }
            CinemaBoxExtractor.VideoStream best = media.getBestQuality();
            if (best != null && best.isHls())
                audioLangs.addAll(ManifestProber.fetchAudioLanguages(best.url, null));
        }
        return ModeResolver.evaluate(subLangs, audioLangs, false, false);
    }

    /** verifyDubRelease is a network call — cache verdicts briefly per release/episode. */
    static boolean verifyDubCached(MovieBoxBridge bridge, MovieBoxModels.Playback p,
                                   MovieBoxModels.DubOption dub) {
        String key = dub.subjectId + "|" + p.tmdbSeason + "|" + p.tmdbEpisode;
        synchronized (DUB_VERDICTS) {
            DubVerdict v = DUB_VERDICTS.get(key);
            if (v != null) {
                long ttl = v.ok ? DUB_TTL_MS : DUB_NEGATIVE_TTL_MS;
                if (System.currentTimeMillis() - v.at < ttl) return v.ok;
            }
        }
        boolean ok;
        try {
            ok = bridge.verifyDubRelease(p, dub);
        } catch (Exception e) { ok = false; }
        synchronized (DUB_VERDICTS) {
            DUB_VERDICTS.put(key, new DubVerdict(ok, System.currentTimeMillis()));
        }
        return ok;
    }

    /** Probe a separate in-video subtitle release independently of external captions. */
    static boolean verifyVideoSubtitleCached(MovieBoxBridge bridge, MovieBoxModels.Playback p,
                                             MovieBoxModels.DubOption release) {
        String key = release.subjectId + "|" + p.tmdbSeason + "|" + p.tmdbEpisode;
        synchronized (VIDEO_SUB_VERDICTS) {
            DubVerdict v = VIDEO_SUB_VERDICTS.get(key);
            if (v != null) {
                long ttl = v.ok ? DUB_TTL_MS : DUB_NEGATIVE_TTL_MS;
                if (System.currentTimeMillis() - v.at < ttl) return v.ok;
            }
        }
        boolean ok;
        try { ok = bridge.verifyArabicSubtitleRelease(p, release); }
        catch (Exception e) { ok = false; }
        synchronized (VIDEO_SUB_VERDICTS) {
            VIDEO_SUB_VERDICTS.put(key, new DubVerdict(ok, System.currentTimeMillis()));
        }
        return ok;
    }
}

package com.eve.cinema.providers;

import android.content.Context;
import com.eve.cinema.DiagnosticRedactor;
import com.eve.cinema.DiagnosticsRecorder;
import com.eve.cinema.moviebox.MovieBoxParser;
import com.eve.cinema.playback.ManifestProber;
import com.eve.cinema.providercore.CanonicalMediaIdentity;
import com.eve.cinema.providercore.PlayableCandidateValidator;
import com.eve.cinema.providercore.ProviderHealthStore;
import com.eve.cinema.providercore.SafeDiagnostics;
import com.eve.cinema.providercore.Tuning;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * EveProviders — جذر تركيب وحدات المنسّق داخل التطبيق (إغلاق بنود الربط
 * المتبقية في تقرير التنفيذ §5):
 *
 *  - ExecutorService واحد مشترك لكل جولات الموجات (لا pools لكل طلب).
 *  - ProviderHealthStore واحد مشترك: قاطع كل مصدر يعيش بين الاستدعاءات
 *    (خطة §10.3) كما كانت بوابات ParallelProviderProbe الساكنة.
 *  - SafeDiagnostics.Sink → DiagnosticsRecorder الموجود، مع تنقيح مزدوج
 *    عبر DiagnosticRedactor (§15.2).
 *  - PlayableCandidateValidator بحقن حقيقي: LinkProbe → ManifestProber.probeLink
 *    وكاشف placeholder → MovieBoxParser.isDeprecationNoticeUrl (§11).
 *
 * كل ما هنا شبكة/تخزين مجاني من الأسرار؛ لا قيم حسابات ولا روابط موقعة.
 */
public final class EveProviders {

    private static volatile EveProviders instance;

    private final Context appContext;
    private final ExecutorService executor;
    private final ProviderHealthStore health;
    private final SafeDiagnostics diagnostics;
    private final PlayableCandidateValidator validator;
    private final CinemaBoxProviderAdapter cinemaBox;
    private final MovieBoxProviderAdapter movieBox;

    private EveProviders(Context ctx) {
        this.appContext = ctx == null ? null : ctx.getApplicationContext();
        this.executor = new ThreadPoolExecutor(
                0, Tuning.SOURCE_MAX_CONCURRENCY, 30L, TimeUnit.SECONDS,
                new SynchronousQueue<Runnable>(),
                new ThreadFactory() {
                    private final AtomicInteger ids = new AtomicInteger();
                    @Override public Thread newThread(Runnable r) {
                        Thread t = new Thread(r, "EveWave-" + ids.incrementAndGet());
                        t.setDaemon(true);
                        return t;
                    }
                }, new ThreadPoolExecutor.AbortPolicy());
        this.health = new ProviderHealthStore();
        this.diagnostics = new SafeDiagnostics(line -> {
            if (line == null || !DiagnosticsRecorder.isRecordingEnabled()) return;
            String safe = DiagnosticRedactor.redactText(line);
            DiagnosticsRecorder.event("providercore", "wave", "trace",
                    DiagnosticsRecorder.details("line", safe));
        });
        // §11: كاشف placeholder المثبت في MovieBoxParser + فحص شبكي محدود عبر
        // ManifestProber — لا تنزيل للفيلم كاملاً (§11.2).
        this.validator = new PlayableCandidateValidator(
                (uri, contentType, durationSeconds) -> MovieBoxParser.isDeprecationNoticeUrl(uri),
                (uri, headers) -> {
                    ManifestProber.LinkInfo info = ManifestProber.probeLink(uri, headers);
                    if (info == null) return null;
                    return new PlayableCandidateValidator.LinkProbeResult(
                            info.httpCode, info.contentType, info.contentLength,
                            info.rangeSupport, info.manifestValid, info.mediaDurationSec);
                });
        this.cinemaBox = new CinemaBoxProviderAdapter();
        this.movieBox = new MovieBoxProviderAdapter(appContext);
    }

    public static EveProviders get(Context ctx) {
        EveProviders v = instance;
        if (v == null) {
            synchronized (EveProviders.class) {
                v = instance;
                if (v == null) { v = new EveProviders(ctx); instance = v; }
            }
        }
        return v;
    }

    public ProviderHealthStore health() { return health; }
    public SafeDiagnostics diagnostics() { return diagnostics; }
    public PlayableCandidateValidator validator() { return validator; }
    public CinemaBoxProviderAdapter cinemaBox() { return cinemaBox; }
    public MovieBoxProviderAdapter movieBox() { return movieBox; }

    /**
     * فحص توفر لصفحة التفاصيل/الحلقات عبر SourceWaveController — البديل
     * المباشر لاستدعاء ParallelProviderProbe.run القديم.
     */
    public ProviderProbeGateway.Result probeSources(String tmdbId, String title,
                                                    String originalTitle, int year,
                                                    boolean series, boolean anime) {
        return ProviderProbeGateway.run(
                identity(tmdbId, title, originalTitle, year, series),
                anime, movieBox, cinemaBox, health, executor, diagnostics);
    }

    /** هوية معيارية من اختيار TMDB (§9.1) — بلا تخمين معرّفات مزوّدين. */
    static CanonicalMediaIdentity identity(String tmdbId, String title,
                                           String originalTitle, int year, boolean series) {
        CanonicalMediaIdentity.Builder b = new CanonicalMediaIdentity.Builder(
                series ? CanonicalMediaIdentity.MediaType.SERIES
                       : CanonicalMediaIdentity.MediaType.MOVIE,
                title == null ? "" : title);
        long id = 0L;
        try { id = Long.parseLong(tmdbId == null ? "" : tmdbId.trim()); }
        catch (NumberFormatException ignored) { }
        b.tmdbId(id);
        if (originalTitle != null && !originalTitle.trim().isEmpty()
                && !originalTitle.equals(title))
            b.alias(originalTitle.trim());
        if (year > 0) b.releaseYear(year);
        return b.build();
    }
}

package com.eve.cinema.providercore;

import java.net.URI;
import java.util.Locale;

/**
 * CandidateNormalizer — تحويل استجابات المصادر المختلفة إلى النموذج الموحد
 * (وحدة §4.1) مع الحفاظ على providerId الداخلي.
 *
 * Pure Java — unit-tested on the JVM.
 */
public final class CandidateNormalizer {

    private CandidateNormalizer() {}

    /** تطبيع الجودة إلى قيمة معيارية: 480/720/1080/2160 أو QUALITY_AUTO. */
    public static int normalizeQuality(String raw) {
        if (raw == null) return NormalizedCandidate.QUALITY_AUTO;
        String s = raw.trim().toLowerCase(Locale.US);
        // "1080p", "1080", "fhd", "hd 720", "4k"...
        if (s.contains("4k") || s.contains("2160") || s.contains("uhd")) return 2160;
        if (s.contains("1440") || s.contains("2k")) return 1440;
        if (s.contains("1080") || s.equals("fhd") || s.contains("fullhd")) return 1080;
        if (s.contains("720") || s.equals("hd")) return 720;
        if (s.contains("480") || s.equals("sd")) return 480;
        if (s.contains("360")) return 360;
        if (s.contains("240")) return 240;
        if (s.equals("auto") || s.equals("automatic")) return NormalizedCandidate.QUALITY_AUTO;
        // أول رقم من 3-4 خانات يُفترض ارتفاعاً.
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{3,4})").matcher(s);
        if (m.find()) {
            try { return Integer.parseInt(m.group(1)); } catch (NumberFormatException ignored) {}
        }
        return NormalizedCandidate.QUALITY_AUTO;
    }

    public static NormalizedCandidate.StreamType normalizeStreamType(String raw, String uri) {
        String s = raw == null ? "" : raw.trim().toLowerCase(Locale.US);
        if (s.contains("dash") || s.contains("mpd")) return NormalizedCandidate.StreamType.DASH;
        if (s.contains("hls") || s.contains("m3u8")) return NormalizedCandidate.StreamType.HLS;
        if (s.contains("mp4")) return NormalizedCandidate.StreamType.MP4;
        if (uri != null) {
            String u = uri.toLowerCase(Locale.US);
            if (u.contains(".mpd")) return NormalizedCandidate.StreamType.DASH;
            if (u.contains(".m3u8")) return NormalizedCandidate.StreamType.HLS;
            if (u.contains(".mp4")) return NormalizedCandidate.StreamType.MP4;
        }
        return NormalizedCandidate.StreamType.OTHER;
    }

    /**
     * بصمة عائلة المضيف للمساعدة على كشف CDN المشترك (§6.4):
     * النطاق الفعّال بصيغة lowercase — لا الرابط الكامل. يحسب النطاقات
     * المركبة الشائعة (com.iq, co.uk ...) حتى لا تُجمَّع كل نطاقات .iq
     * تحت بصمة واحدة.
     */
    private static final java.util.Set<String> SECOND_LEVEL_TLDS =
            new java.util.HashSet<>(java.util.Arrays.asList(
                    "com.iq", "net.iq", "co.uk", "com.sa", "com.tr", "com.eg",
                    "com.au", "co.jp", "com.br", "com.mx", "co.in"));

    public static String hostKey(String uri) {
        if (uri == null) return null;
        try {
            String host = URI.create(uri).getHost();
            if (host == null) return null;
            host = host.toLowerCase(Locale.US);
            String[] parts = host.split("\\.");
            if (parts.length >= 3) {
                String last2 = parts[parts.length - 2] + "." + parts[parts.length - 1];
                if (SECOND_LEVEL_TLDS.contains(last2))
                    return parts[parts.length - 3] + "." + last2;
                return last2;
            }
            if (parts.length == 2) return host;
            return host;
        } catch (Exception e) {
            return null;
        }
    }
}

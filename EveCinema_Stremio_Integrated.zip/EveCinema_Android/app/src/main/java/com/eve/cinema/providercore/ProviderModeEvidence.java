package com.eve.cinema.providercore;

import com.eve.cinema.playback.PlaybackMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;

/** Immutable evidence boundary for one provider and one canonical media identity. */
public final class ProviderModeEvidence {
    private final String providerId;
    private final String mediaKey;
    private final List<NormalizedCandidate> candidates;
    private final EnumMap<PlaybackMode, CapabilityEvidence.Level> levels =
            new EnumMap<>(PlaybackMode.class);

    public ProviderModeEvidence(String providerId, String mediaKey,
                                List<NormalizedCandidate> candidates) {
        if (providerId == null || providerId.trim().isEmpty())
            throw new IllegalArgumentException("providerId required");
        if (mediaKey == null || mediaKey.trim().isEmpty())
            throw new IllegalArgumentException("mediaKey required");
        this.providerId = providerId;
        this.mediaKey = mediaKey;
        List<NormalizedCandidate> accepted = new ArrayList<>();
        if (candidates != null) {
            for (NormalizedCandidate candidate : candidates) {
                if (candidate == null || !providerId.equals(candidate.providerId())
                        || !mediaKey.equals(candidate.mediaKey())) continue;
                accepted.add(candidate);
                PlaybackMode mode = candidate.playbackMode();
                if (mode != null) {
                    CapabilityEvidence.Level level = candidate.evidence().forMode(mode);
                    levels.put(mode, stronger(levels.get(mode), level));
                }
            }
        }
        this.candidates = Collections.unmodifiableList(accepted);
    }

    public String providerId() { return providerId; }
    public String mediaKey() { return mediaKey; }

    /** Evidence for a mode is informative only; UNKNOWN/FAILED never become absence. */
    public CapabilityEvidence.Level evidenceFor(PlaybackMode mode) {
        if (mode == null) return CapabilityEvidence.Level.UNKNOWN;
        CapabilityEvidence.Level level = levels.get(mode);
        return level == null ? CapabilityEvidence.Level.UNKNOWN : level;
    }

    /** Candidates that independently prove this exact mode, identity and provider. */
    public List<NormalizedCandidate> verifiedCandidatesFor(PlaybackMode mode) {
        if (mode == null) return Collections.emptyList();
        List<NormalizedCandidate> out = new ArrayList<>();
        for (NormalizedCandidate candidate : candidates) {
            if (candidate.playbackMode() == mode
                    && candidate.validationStatus() == ProviderResultState.VERIFIED_PLAYABLE
                    && candidate.evidence().isVerified(mode)
                    && candidate.hasUri()) out.add(candidate);
        }
        return Collections.unmodifiableList(out);
    }

    private static CapabilityEvidence.Level stronger(CapabilityEvidence.Level a,
                                                      CapabilityEvidence.Level b) {
        if (a == null) return b == null ? CapabilityEvidence.Level.UNKNOWN : b;
        if (b == null) return a;
        return strength(b) > strength(a) ? b : a;
    }

    private static int strength(CapabilityEvidence.Level level) {
        switch (level) {
            case VERIFIED: return 5;
            case FAILED: return 4;
            case HINTED: return 3;
            case UNKNOWN: return 2;
            case ABSENT: return 1;
            default: return 0;
        }
    }
}

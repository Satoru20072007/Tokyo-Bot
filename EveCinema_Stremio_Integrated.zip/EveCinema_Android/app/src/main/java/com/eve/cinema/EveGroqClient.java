package com.eve.cinema;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Eve v6 — Cognitive Pipeline Orchestrator
 *
 * ════════════════════════════════════════════════════════════════════
 *  الـ Pipeline:
 *
 *   1. IntentEngine.classify()        ← تصنيف النية بالأوزان
 *   2. EvePromptBuilder.buildMessages ← بناء prompt مبني على النية
 *   3. callGroq / callWithRetry       ← استدعاء LLM
 *   4. EveResponseParser.parse()      ← استخراج النص والـ mentions
 *   5. EveTmdbResolver.resolveAll()   ← حل TMDB async (لا blocking)
 *   6. callback.onResponse()          ← إعادة النتيجة للـ UI
 *
 * ════════════════════════════════════════════════════════════════════
 *  ما تم حذفه من v5:
 *   • isCasualMessage()         → EveIntentEngine
 *   • buildContextHint()        → EvePromptBuilder
 *   • EVE_BASE_SYSTEM           → EvePromptBuilder (3 templates)
 *   • extractMentions()         → EveResponseParser
 *   • searchTmdbParallel()      → EveTmdbResolver.resolveAll()
 *   • searchTmdb/Multi/Direct   → EveTmdbResolver
 *   • titleMatchScore()         → EveTmdbResolver
 *   • tmdbCache                 → EveTmdbResolver
 *   • TMDB_IO pool              → EveTmdbResolver
 *   • MediaMention inner class  → EveTmdbResolver.ResolvedMention
 *   • CountDownLatch blocking   → AtomicInteger + callbacks
 *   • DNA mergeAndTrim calls    → EveMemorySystem.mergeFromJson
 *
 *  ما تبقى هنا:
 *   • Pipeline orchestration
 *   • Groq HTTP calls
 *   • DNA update logic
 *   • Thread safety (dnaLocks)
 * ════════════════════════════════════════════════════════════════════
 */
public class EveGroqClient {

    private static final String GROQ_ENDPOINT = "https://api.groq.com/openai/v1/chat/completions";
    private static final String GROQ_KEY       = "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";
    private static final String MODEL_PRIMARY  = "meta-llama/llama-4-scout-17b-16e-instruct";
    private static final String MODEL_FALLBACK = "openai/gpt-oss-120b";

    /** Pool للـ LLM calls فقط (TMDB له pool منفصل في EveTmdbResolver) */
    private static final ExecutorService IO   = Executors.newFixedThreadPool(3);
    private static final Handler         MAIN = new Handler(Looper.getMainLooper());

    /** قفل per-userId — يحمي DNA read-modify-write من التزامن */
    private static final ConcurrentHashMap<String, Object> dnaLocks = new ConcurrentHashMap<>();

    /** آخر HTTP status على هذا thread — لقرارات retry ذكية */
    private static final ThreadLocal<Integer> lastHttpCode = ThreadLocal.withInitial(() -> 0);

    // ─────────────────────────────────────────────────────────────────
    //  ChatCallback — الواجهة العامة للـ UI
    // ─────────────────────────────────────────────────────────────────

    public interface ChatCallback {
        void onTyping();
        void onResponse(String cleanText, List<EveTmdbResolver.ResolvedMention> mentions);
        void onError(String msg);
    }

    // ─────────────────────────────────────────────────────────────────
    //  sendMessage — الـ Pipeline الرئيسي
    // ─────────────────────────────────────────────────────────────────

    public static void sendMessage(
            final String userId,
            final String userMessage,
            final List<JSONObject> history,
            final EveMemoryDb.UserDna dna,
            final ChatCallback callback) {

        MAIN.post(callback::onTyping);

        IO.submit(() -> {
            try {
                // ── Stage 1: تصنيف النية ──────────────────────────────
                // استخدام آخر رد لإيف للكشف عن FOLLOW_UP
                String prevReply = getLastAssistantReply(history);
                EveIntentEngine.IntentSignal intent =
                        EveIntentEngine.classify(userMessage, prevReply);

                // ── Stage 2: بناء Prompt مبني على النية ──────────────
                JSONArray messages =
                        EvePromptBuilder.buildMessages(intent, dna, history, userMessage);

                // ── Stage 3: استدعاء LLM ──────────────────────────────
                EvePromptBuilder.LlmConfig cfg = EvePromptBuilder.configFor(intent.primary);
                String raw = callWithRetry(messages, MODEL_PRIMARY,  cfg.maxTokens, cfg.temperature);
                if (raw == null) {
                    // Fallback model: maxTokens أقل قليلاً للسرعة
                    raw = callWithRetry(messages, MODEL_FALLBACK,
                            Math.max(cfg.maxTokens - 100, 200), cfg.temperature);
                }
                if (raw == null) {
                    MAIN.post(() -> callback.onError("لم تستجب إيف. تحقق من الاتصال وحاول مجدداً."));
                    return;
                }

                // ── Stage 4: تحليل الرد ───────────────────────────────
                // minConfidence = 0.5f (يقبل حتى bare-title fallback)
                EveResponseParser.ParsedResponse parsed =
                        EveResponseParser.parse(raw, intent.expectsMediaCard, 0.5f);

                // ── Stage 5: حل TMDB بشكل async (لا يحجب IO thread) ──
                final String finalText = parsed.cleanText;
                if (!parsed.mentions.isEmpty()) {
                    EveTmdbResolver.resolveAll(parsed.mentions, resolved -> {
                        // هذا يُستدعى على Main Thread (من EveTmdbResolver)
                        callback.onResponse(finalText, resolved);
                    }, MAIN);
                } else {
                    MAIN.post(() -> callback.onResponse(finalText, new ArrayList<>()));
                }

            } catch (Exception e) {
                MAIN.post(() -> callback.onError("خطأ غير متوقع. حاول مجدداً."));
            }
        });
    }

    // ─────────────────────────────────────────────────────────────────
    //  updateDnaAsync — تحليل المحادثة وتحديث DNA في الخلفية
    // ─────────────────────────────────────────────────────────────────

    public static void updateDnaAsync(
            final Context appCtx,
            final String userId,
            final List<JSONObject> recentHistory,
            final boolean hasCinemaContent) {

        // لا داعي للتحديث إذا لا يوجد محتوى سينمائي
        if (!hasCinemaContent && !historyCinemaCheck(recentHistory)) return;

        IO.submit(() -> {
            try {
                // بناء المحادثة للتحليل (آخر 20 رسالة)
                JSONArray messages = new JSONArray();
                JSONObject sys = new JSONObject();
                sys.put("role",    "system");
                sys.put("content", EvePromptBuilder.DNA_SYSTEM);
                messages.put(sys);

                StringBuilder conv  = new StringBuilder();
                int           start = Math.max(0, recentHistory.size() - 20);
                for (int i = start; i < recentHistory.size(); i++) {
                    JSONObject m = recentHistory.get(i);
                    conv.append(m.optString("role")).append(": ")
                        .append(m.optString("content")).append("\n");
                }
                JSONObject userMsg = new JSONObject();
                userMsg.put("role",    "user");
                userMsg.put("content", "المحادثة:\n" + conv.toString());
                messages.put(userMsg);

                // temperature منخفضة جداً لأن الـ DNA analysis يحتاج دقة لا إبداع
                String raw = callWithRetry(messages, MODEL_FALLBACK, 400, 0.10f);
                if (raw == null) return;

                // تنظيف JSON من markdown fences إن وُجدت
                raw = raw.replaceAll("```json", "").replaceAll("```", "").trim();
                int jStart = raw.indexOf('{');
                int jEnd   = raw.lastIndexOf('}');
                if (jStart < 0 || jEnd <= jStart) return;
                raw = raw.substring(jStart, jEnd + 1);

                JSONObject update = new JSONObject(raw);
                EveMemoryDb db    = EveMemoryDb.get(appCtx);

                // قفل per-userId يمنع race condition على نفس DNA
                Object lock = dnaLocks.computeIfAbsent(userId, k -> new Object());
                synchronized (lock) {
                    EveMemoryDb.UserDna existing = db.getDna(userId);
                    // smartMerge بدل mergeAndTrim
                    EveMemorySystem.mergeFromJson(existing, update);
                    db.updateDna(existing);
                    // sync مع Firebase في الخلفية
                    MAIN.post(() -> EveFirebaseSync.uploadDna(userId, existing, null));
                }

            } catch (Exception ignored) {}
        });
    }

    // ─────────────────────────────────────────────────────────────────
    //  Groq HTTP — مع retry ذكي
    // ─────────────────────────────────────────────────────────────────

    /**
     * retry ذكي:
     *  • 401/403 → لا retry (خطأ دائم، المفتاح خاطئ)
     *  • 429     → انتظر 2500ms (Rate limit)
     *  • غيرها  → انتظر 700ms
     */
    private static String callWithRetry(JSONArray messages, String model,
                                         int maxTokens, float temp) {
        String result = callGroq(messages, model, maxTokens, temp);
        if (result != null) return result;

        int code = lastHttpCode.get();
        if (code == 401 || code == 403) return null; // خطأ دائم — لا تضيع الوقت

        long waitMs = (code == 429) ? 2500L : 700L;
        try {
            Thread.sleep(waitMs);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return null;
        }

        return callGroq(messages, model, maxTokens, temp);
    }

    private static String callGroq(JSONArray messages, String model,
                                    int maxTokens, float temp) {
        HttpURLConnection conn = null;
        try {
            JSONObject body = new JSONObject();
            body.put("model",       model);
            body.put("max_tokens",  maxTokens);
            body.put("temperature", temp);
            body.put("messages",    messages);

            conn = (HttpURLConnection) new URL(GROQ_ENDPOINT).openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(18000);
            conn.setReadTimeout(25000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type",  "application/json");
            conn.setRequestProperty("Authorization", "Bearer " + GROQ_KEY);

            OutputStream os = conn.getOutputStream();
            os.write(body.toString().getBytes("UTF-8"));
            os.close();

            int code = conn.getResponseCode();
            lastHttpCode.set(code);

            if (code != 200) return null;

            BufferedReader br = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();

            return new JSONObject(sb.toString())
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content");

        } catch (Exception e) {
            lastHttpCode.set(0);
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    // ─────────────────────────────────────────────────────────────────
    //  Helpers
    // ─────────────────────────────────────────────────────────────────

    /** يُرجع آخر رد لإيف من التاريخ — لكشف FOLLOW_UP في IntentEngine */
    private static String getLastAssistantReply(List<JSONObject> history) {
        if (history == null || history.isEmpty()) return "";
        for (int i = history.size() - 1; i >= 0; i--) {
            JSONObject msg = history.get(i);
            if ("assistant".equals(msg.optString("role", ""))) {
                return msg.optString("content", "");
            }
        }
        return "";
    }

    /** يتحقق من وجود tags سينمائية في آخر 10 رسائل (لتحديد إذا يستحق DNA update) */
    private static boolean historyCinemaCheck(List<JSONObject> history) {
        if (history == null || history.isEmpty()) return false;
        int start = Math.max(0, history.size() - 10);
        for (int i = start; i < history.size(); i++) {
            String c = history.get(i).optString("content", "");
            if (c.contains("{{MOVIE:") || c.contains("{{TV:") || c.contains("{{ANIME:"))
                return true;
        }
        return false;
    }

    // ─────────────────────────────────────────────────────────────────
    //  Lifecycle
    // ─────────────────────────────────────────────────────────────────

    /**
     * يُوقف جميع thread pools بشكل نظيف.
     * يُستدعى من Application.onTerminate() أو آخر Activity's onDestroy().
     */
    public static void shutdown() {
        IO.shutdown();
        EveTmdbResolver.shutdown();
    }
}

package com.eve.cinema.stremio;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;

import javax.net.ssl.SSLException;

/**
 * Failure of a Stremio add-on operation. The {@link Kind} is the only thing callers and the UI may
 * rely on: the message is a fixed token that NEVER contains a URL, a host, a path segment or any
 * text copied from a server response, and the original exception is deliberately not attached
 * because JDK network exceptions routinely embed the request URL (which may hold a credential).
 */
public final class StremioException extends IOException {
    public enum Kind {
        /** The URL violates the public-HTTPS policy (scheme, host form, private address...). */
        UNSAFE_URL,
        /** Host unreachable, DNS failure, connection refused/reset, device offline. */
        NETWORK,
        TIMEOUT,
        /** Certificate / handshake failure. */
        TLS,
        /** Non-2xx answer; see {@link #httpStatus}. */
        HTTP_STATUS,
        TOO_LARGE,
        /** The server answered with something that is not JSON. */
        NOT_JSON,
        /** JSON that is syntactically invalid, too deeply nested, or not a valid manifest. */
        MALFORMED,
        REDIRECT_REJECTED,
        /** The add-on needs a configured manifest URL before it can be queried. */
        CONFIG_REQUIRED,
        /** The request is not allowed by the add-on's own declaration. */
        UNSUPPORTED,
        CANCELLED
    }

    public final Kind kind;
    public final int httpStatus;

    public StremioException(Kind kind) { this(kind, 0); }

    public StremioException(Kind kind, int httpStatus) {
        super(kind.name() + (httpStatus > 0 ? " " + httpStatus : ""));
        this.kind = kind;
        this.httpStatus = httpStatus;
    }

    /**
     * True for failures worth one bounded retry: timeouts, network hiccups and 5xx gateway errors.
     * Never true for 401/403/404/429, malformed manifests or policy rejections.
     */
    public boolean isTransient() {
        if (kind == Kind.TIMEOUT || kind == Kind.NETWORK) return true;
        return kind == Kind.HTTP_STATUS
                && (httpStatus == 500 || httpStatus == 502 || httpStatus == 503 || httpStatus == 504);
    }

    /** Maps any I/O failure to a URL-free {@link StremioException}. */
    public static StremioException from(IOException failure) {
        if (failure instanceof StremioException) return (StremioException) failure;
        if (failure instanceof SocketTimeoutException) return new StremioException(Kind.TIMEOUT);
        if (failure instanceof SSLException) return new StremioException(Kind.TLS);
        if (failure instanceof InterruptedIOException) return new StremioException(Kind.CANCELLED);
        return new StremioException(Kind.NETWORK);
    }

    /** Diagnostic-safe description of any throwable: class name only, never its message. */
    public static String safeDescription(Throwable failure) {
        if (failure == null) return "none";
        if (failure instanceof StremioException) return failure.getMessage();
        return failure.getClass().getSimpleName();
    }
}

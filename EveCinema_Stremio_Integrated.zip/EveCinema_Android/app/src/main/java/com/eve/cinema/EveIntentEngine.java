package com.eve.cinema;

import java.util.EnumMap;
import java.util.Map;

/**
 * Eve v6 — Intent Engine
 *
 * Weighted scoring classifier that replaces isCasualMessage() + buildContextHint().
 *
 * Design principles:
 *  • No binary decisions — outputs confidence scores for ALL categories
 *  • No regex — pure substring matching with per-feature weights
 *  • Cinema-signal awareness — greetings that contain cinema words → non-casual
 *  • O(n) over feature tables — <1ms on mobile
 *
 * Usage:
 *   IntentSignal signal = EveIntentEngine.classify(userMessage, lastAssistantReply);
 *   if (signal.primary == Intent.RECOMMENDATION) { ... }
 *   if (signal.expectsMediaCard) { ... }
 */
public class EveIntentEngine {

    // ─── Intent Categories ────────────────────────────────────────────

    public enum Intent {
        CASUAL_CHAT,    // تحية، شكر، إقرار، محادثة بلا هدف سينمائي
        MOOD_BASED,     // تعبير عن مزاج → يستلزم توصية تلقائية
        RECOMMENDATION, // طلب توصية صريح (نوع / فئة / مجرد "أبغى فيلم")
        DIRECT_QUERY,   // سؤال عن عمل أو شخص بعينه
        FOLLOW_UP       // متابعة سياق محادثة سينمائية سابقة
    }

    // ─── Output ───────────────────────────────────────────────────────

    public static class IntentSignal {
        public final Intent               primary;
        public final float                confidence;       // [0.0 – 1.0]
        public final Map<Intent, Float>   allScores;        // normalized scores per category
        public final boolean              expectsMediaCard; // should response include {{}} tags?
        public final String               detectedContext;  // genre / mood hint for prompt

        IntentSignal(Intent primary, float confidence,
                     Map<Intent, Float> allScores,
                     boolean expectsMediaCard, String detectedContext) {
            this.primary          = primary;
            this.confidence       = confidence;
            this.allScores        = allScores;
            this.expectsMediaCard = expectsMediaCard;
            this.detectedContext  = detectedContext;
        }
    }

    // ─────────────────────────────────────────────────────────────────
    //  Feature Tables  (keyword, weight)
    //  All matching uses text.contains(keyword) after lowercase trim.
    // ─────────────────────────────────────────────────────────────────

    // CASUAL — تحيات، إقرارات، ردود قصيرة
    private static final String[] K_CASUAL = {
        "مرحبا", "مرحباً", "هلا", "هلو", "أهلاً", "أهلا", "اهلا",
        "السلام عليكم", "وعليكم السلام", "صباح الخير", "مساء الخير",
        "صباح النور", "مساء النور",
        "كيفك", "كيف حالك", "كيف حالكي", "كيف الحال", "شو اخبارك",
        "شكرا", "شكراً", "شكرا جزيلا", "شكراً جزيلاً", "مشكور",
        "تسلم", "يسلمو", "الله يسلمك",
        "وداعاً", "باي", "مع السلامة", "في أمان الله",
        "ايوه", "نعم", "لا", "يلا", "خلاص", "تمام", "ماشي",
        "عادي", "بخير", "الحمدلله", "ممتاز", "كويس", "زين",
        "ok", "okay", "hi", "hello", "hey", "thanks", "thx",
        "نوّرتِ", "نورتِ"
    };
    private static final float[] W_CASUAL = {
        35,35,32,32,32,32,32,
        30,30,28,28,
        26,26,
        20,20,20,20,18,
        22,22,22,22,20,
        20,20,20,
        18,18,18,18,
        15,12,12,12,12,12,12,
        12,12,10,10,10,10,
        12,12,18,18,18,12,12,
        18,18
    };

    // MOOD — مزاج سلبي / ملل → يستلزم توصية
    private static final String[] K_MOOD = {
        "مللت",  "زهقت",    "بايخ",      "فاضي",   "فاضية",
        "تعبت",  "وحيد",    "وحيدة",     "زعلان",  "زعلانة",
        "حزين",  "حزينة",   "مكتئب",     "مكتئبة", "ضايق",
        "قلقان", "ما عندي مود", "مو بطل",
        "ما فيه شي أشوف",  "ما أعرف شو أشوف",  "مو عارف شو أشوف",
        "بدي أسلي نفسي",   "محتاج شي أشوفه",
        "ما عندي شغل",     "عندي وقت فاضي",    "الليلة وحيد",
        "جو ممطر",         "عايز أنسى",
        "ما في شيء أحسن من",  "أمزاجي ما عندي"
    };
    private static final float[] W_MOOD = {
        48,48,42,40,40,
        35,38,38,38,38,
        38,38,42,42,35,
        35,40,35,
        45,45,45,
        42,42,
        38,38,35,
        28,30,
        30,35
    };

    // RECOMMENDATION — طلب صريح
    private static final String[] K_REC = {
        // طلبات مشاهدة متعددة اللهجات
        "أبغى فيلم",  "ابغى فيلم",  "أبغى مسلسل", "ابغى مسلسل",
        "أبغى أنمي",  "ابغى انمي",  "أبغا فيلم",  "ابغا فيلم",
        "حابب اشوف",  "حابب أشوف",  "حابي اشوف",  "بدي اشوف",
        "بدي أشوف",   "ودي اشوف",   "ودي أشوف",   "نفسي اشوف",
        "نفسي أشوف",  "عايز اشوف",  "عايز أشوف",
        "أريد فيلم",  "اريد فيلم",  "أريد مسلسل", "اريد مسلسل",
        "أريد أنمي",  "اريد انمي",  "عطني فيلم",  "شوف لي",
        "شو اشوف",    "شو أشوف",    "ايش اشوف",   "ايش أشوف",
        "إيش أشوف",
        // توصية / نصيحة
        "توصية",   "توصيه",   "اقتراح",   "نصيحة",   "نصيحه",
        "نصحني",   "اقترح",   "اقترحي",   "رأيك",    "رأيكي",
        "ايش تنصح","وش تنصح","إيش تقول", "ايش أحسن",
        "أي فيلم", "أي مسلسل",
        // أنواع وحدها (وزن أقل — تحتاج تضافراً مع غيرها)
        "رعب",  "رومانسي", "كوميدي",  "إثارة",   "خيال علمي",
        "دراما","جريمة",   "تشويق",   "أكشن",    "تاريخي",
        "وثائقي","مغامرات","فانتازيا","رياضي",   "حرب",
        "أنمي يستحق","مسلسل يستحق","فيلم أجنبي","فيلم عربي"
    };
    private static final float[] W_REC = {
        55,55,55,55,
        55,55,55,55,
        52,52,52,52,
        52,52,52,52,
        52,52,52,
        55,55,55,55,
        55,55,52,52,
        48,48,48,48,
        48,
        50,50,48,50,50,
        52,50,50,38,38,
        50,50,42,40,
        42,42,
        27,27,27,27,32,
        27,27,27,27,27,
        27,27,27,27,27,
        48,48,42,42
    };

    // DIRECT_QUERY — سؤال عن عمل / شخص بعينه
    private static final String[] K_QUERY = {
        "عن فيلم",    "عن مسلسل",   "مين مخرج",   "من مخرج",
        "قصة فيلم",   "قصة مسلسل",  "ملخص",       "كم حلقة",
        "كم موسم",    "هل يستحق",   "هل الفيلم",  "هل المسلسل",
        "سنة الفيلم", "إصدار",      "أحسن فيلم",  "أفضل فيلم",
        "أحسن مسلسل", "أشهر فيلم",  "من أبطال",   "مين يمثل",
        "يستحق المشاهدة", "يشبه"
    };
    private static final float[] W_QUERY = {
        52,52,58,58,
        55,55,50,52,
        52,50,50,50,
        45,40,42,42,
        42,40,45,45,
        48,38
    };

    // FOLLOW_UP — متابعة سياق سابق
    private static final String[] K_FOLLOW = {
        "وبعد",      "وكمان",    "زيه",      "زيها",
        "زي هذا",    "زي هاد",   "مشابه",    "مثله",
        "نفس النوع", "غير هذا",  "غيره",     "ثاني",
        "آخر",       "تاني",     "بعده",     "قبله",
        "بس أنا",    "الفيلم اللي",  "هو نفسه"
    };
    private static final float[] W_FOLLOW = {
        38,35,32,32,
        38,38,40,38,
        40,35,30,28,
        25,28,28,28,
        18,35,32
    };

    // Cinema signals — كلمات تدل على سياق سينمائي
    private static final String[] CINEMA_SIGNALS = {
        "فيلم","مسلسل","أنمي","انمي","سينما","مشاهدة","شاهد","شاهدت",
        "نتفليكس","مخرج","ممثل","حلقة","موسم","بطل","أشوف","اشوف",
        "تشوف","تشوفه","شايف","شايفة","imdb","tmdb"
    };

    // Genre context words — for detectedContext field
    private static final String[] GENRE_WORDS = {
        "رعب","رومانسي","كوميدي","إثارة","خيال علمي","دراما",
        "جريمة","تشويق","أكشن","تاريخي","وثائقي","مغامرات",
        "فانتازيا","رياضي","حرب","نفسي","غموض"
    };

    // ─────────────────────────────────────────────────────────────────
    //  Public API
    // ─────────────────────────────────────────────────────────────────

    /**
     * Classify a user message.
     *
     * @param message           The user's current message (raw Arabic text)
     * @param prevAssistantMsg  Last assistant reply (used for FOLLOW_UP detection)
     * @return IntentSignal with primary intent, confidence, and card expectation
     */
    public static IntentSignal classify(String message, String prevAssistantMsg) {
        if (message == null || message.trim().isEmpty()) {
            return trivial(Intent.CASUAL_CHAT);
        }

        String t = message.trim().toLowerCase();
        if (t.length() <= 3) return trivial(Intent.CASUAL_CHAT);

        // ─── Raw scores ───────────────────────────────────────────────
        float sCasual = dot(t, K_CASUAL, W_CASUAL);
        float sMood   = dot(t, K_MOOD,   W_MOOD);
        float sRec    = dot(t, K_REC,    W_REC);
        float sQuery  = dot(t, K_QUERY,  W_QUERY);
        float sFollow = dot(t, K_FOLLOW, W_FOLLOW);

        // ─── Cinema signal adjustment ─────────────────────────────────
        boolean cinemaSignal = hasCinemaSignal(t);
        if (cinemaSignal) {
            sCasual -= 35f;
            sMood   += 15f;
            sRec    += 20f;
            sQuery  += 20f;
            sFollow += 15f;
        }

        // ─── Follow-up boost: if previous assistant reply had media tags ──
        if (prevAssistantMsg != null && (
                prevAssistantMsg.contains("{{MOVIE:")  ||
                prevAssistantMsg.contains("{{TV:")     ||
                prevAssistantMsg.contains("{{ANIME:"))) {
            sFollow += 18f;
        }

        // ─── Clamp negatives to 0 ─────────────────────────────────────
        sCasual = Math.max(0f, sCasual);
        sMood   = Math.max(0f, sMood);
        sRec    = Math.max(0f, sRec);
        sQuery  = Math.max(0f, sQuery);
        sFollow = Math.max(0f, sFollow);

        // ─── Normalize ────────────────────────────────────────────────
        float total = sCasual + sMood + sRec + sQuery + sFollow;
        if (total < 1f) total = 1f;

        Map<Intent, Float> scores = new EnumMap<>(Intent.class);
        scores.put(Intent.CASUAL_CHAT,    sCasual / total);
        scores.put(Intent.MOOD_BASED,     sMood   / total);
        scores.put(Intent.RECOMMENDATION, sRec    / total);
        scores.put(Intent.DIRECT_QUERY,   sQuery  / total);
        scores.put(Intent.FOLLOW_UP,      sFollow / total);

        // ─── Winner ───────────────────────────────────────────────────
        Intent winner   = Intent.CASUAL_CHAT;
        float  winScore = 0f;
        for (Map.Entry<Intent, Float> e : scores.entrySet()) {
            if (e.getValue() > winScore) { winScore = e.getValue(); winner = e.getKey(); }
        }

        // ─── Tie-break: casual vs recommendation ──────────────────────
        // "مرحبا أبغى فيلم" → rec score should win even if casual has higher raw
        if (winner == Intent.CASUAL_CHAT && cinemaSignal) {
            float recScore = scores.getOrDefault(Intent.RECOMMENDATION, 0f);
            float moodScore = scores.getOrDefault(Intent.MOOD_BASED, 0f);
            if (recScore > 0.12f)  { winner = Intent.RECOMMENDATION; winScore = recScore; }
            else if (moodScore > 0.12f) { winner = Intent.MOOD_BASED;  winScore = moodScore; }
        }

        // ─── expectsMediaCard ─────────────────────────────────────────
        boolean expectsCard =
                winner == Intent.MOOD_BASED     ||
                winner == Intent.RECOMMENDATION ||
                winner == Intent.DIRECT_QUERY   ||
                (winner == Intent.FOLLOW_UP && cinemaSignal);

        String context = extractContext(t, winner);

        return new IntentSignal(winner, winScore, scores, expectsCard, context);
    }

    // ─────────────────────────────────────────────────────────────────
    //  Private helpers
    // ─────────────────────────────────────────────────────────────────

    /** Dot product: sum weights of matched keywords */
    private static float dot(String text, String[] keywords, float[] weights) {
        float score = 0f;
        int len = Math.min(keywords.length, weights.length);
        for (int i = 0; i < len; i++) {
            if (text.contains(keywords[i])) score += weights[i];
        }
        return score;
    }

    private static boolean hasCinemaSignal(String text) {
        for (String s : CINEMA_SIGNALS) {
            if (text.contains(s)) return true;
        }
        return false;
    }

    /** Extract genre/mood context for prompt hint injection */
    private static String extractContext(String text, Intent intent) {
        if (intent != Intent.RECOMMENDATION && intent != Intent.MOOD_BASED) return "";
        StringBuilder ctx = new StringBuilder();
        for (String g : GENRE_WORDS) {
            if (text.contains(g)) {
                if (ctx.length() > 0) ctx.append("، ");
                ctx.append(g);
            }
        }
        return ctx.toString();
    }

    private static IntentSignal trivial(Intent intent) {
        Map<Intent, Float> s = new EnumMap<>(Intent.class);
        for (Intent i : Intent.values()) s.put(i, 0f);
        s.put(intent, 1.0f);
        boolean card = intent == Intent.RECOMMENDATION || intent == Intent.MOOD_BASED;
        return new IntentSignal(intent, 1.0f, s, card, "");
    }
}

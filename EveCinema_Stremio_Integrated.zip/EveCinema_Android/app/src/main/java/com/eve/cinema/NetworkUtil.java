package com.eve.cinema;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.os.Build;

import java.net.NetworkInterface;
import java.util.Collections;
import java.util.List;

/**
 * NetworkUtil — للتحقق من الإنترنت ووجود VPN قبل تحميل المحتوى.
 */
public final class NetworkUtil {

    private NetworkUtil() {}

    public static boolean hasInternet(Context ctx) {
        try {
            ConnectivityManager cm = (ConnectivityManager)
                ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;

            if (Build.VERSION.SDK_INT >= 23) {
                Network n = cm.getActiveNetwork();
                if (n == null) return false;
                NetworkCapabilities caps = cm.getNetworkCapabilities(n);
                if (caps == null) return false;
                return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                       caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
            } else {
                NetworkInfo info = cm.getActiveNetworkInfo();
                return info != null && info.isConnected();
            }
        } catch (Exception e) {
            return false;
        }
    }

    /** يكتشف وجود VPN فعّال على الجهاز. */
    public static boolean isVpnActive(Context ctx) {
        // 1) عبر ConnectivityManager (الأدق على Android 6+)
        try {
            ConnectivityManager cm = (ConnectivityManager)
                ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null && Build.VERSION.SDK_INT >= 23) {
                Network[] nets = cm.getAllNetworks();
                if (nets != null) {
                    for (Network n : nets) {
                        NetworkCapabilities caps = cm.getNetworkCapabilities(n);
                        if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                            return true;
                        }
                    }
                }
            }
        } catch (Exception ignored) {}

        // 2) فحص واجهات الشبكة (tun0/ppp0/...) — احتياط
        try {
            List<NetworkInterface> ifaces =
                Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface ni : ifaces) {
                if (!ni.isUp()) continue;
                String name = ni.getName();
                if (name == null) continue;
                String n = name.toLowerCase();
                if (n.startsWith("tun") || n.startsWith("ppp") ||
                    n.startsWith("ipsec") || n.contains("vpn")) {
                    return true;
                }
            }
        } catch (Exception ignored) {}

        return false;
    }
}

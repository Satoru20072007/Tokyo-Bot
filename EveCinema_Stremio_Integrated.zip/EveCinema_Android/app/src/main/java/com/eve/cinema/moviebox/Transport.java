package com.eve.cinema.moviebox;

import java.util.List;
import java.util.Map;

public interface Transport {

    Response execute(String method, String url, Map<String, String> headers, String body,
                     int connectTimeoutMs, int readTimeoutMs) throws TransportException;

    final class Response {
        public final int status;
        public final String body;
        public final Map<String, List<String>> headers;

        public Response(int status, String body, Map<String, List<String>> headers) {
            this.status = status;
            this.body = body == null ? "" : body;
            this.headers = headers == null ? java.util.Collections.<String, List<String>>emptyMap()
                    : java.util.Collections.unmodifiableMap(
                            new java.util.LinkedHashMap<>(headers));
        }

        public String header(String name) {
            if (name == null) return null;
            for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
                if (entry.getKey() != null && name.equalsIgnoreCase(entry.getKey())) {
                    List<String> values = entry.getValue();
                    return values == null || values.isEmpty() ? null : values.get(0);
                }
            }
            return null;
        }
    }
}

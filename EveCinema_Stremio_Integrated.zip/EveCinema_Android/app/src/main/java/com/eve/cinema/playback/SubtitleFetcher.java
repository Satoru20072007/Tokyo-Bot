package com.eve.cinema.playback;

import com.eve.cinema.DiagnosticsRecorder;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/**
 * Downloads a subtitle file with the provider's own headers. The full URL
 * (including signed query strings) is used verbatim. Redirects are followed
 * manually with sensitive headers removed after crossing origins. Non-2xx,
 * empty, oversized and cancelled downloads raise {@link SubtitleException}.
 */
public class SubtitleFetcher {

    public static final int MAX_BYTES = 8 * 1024 * 1024;
    private static final int MAX_REDIRECTS = 5;

    public interface Cancellation { boolean isCancelled(); }
    public interface ConnectionOpener { HttpURLConnection open(URL url) throws IOException; }
    /** Optional per-hop policy; used for Stremio so redirects are revalidated too. */
    public interface UrlPolicy { boolean allows(URL url); }

    public static final class SubtitleException extends Exception {
        public final int httpStatus;
        public SubtitleException(String msg, int httpStatus) { super(msg); this.httpStatus = httpStatus; }
    }

    public static Map<String, String> cinemaBoxHeaders() {
        Map<String, String> h = new LinkedHashMap<>();
        h.put("Referer", "https://cinema.albox.co/");
        h.put("User-Agent", "CinemaBox/5.0 (Android)");
        return Collections.unmodifiableMap(h);
    }

    private final int timeoutMs;
    private final ConnectionOpener opener;
    private final boolean diagnosticsEnabled;
    private final UrlPolicy urlPolicy;

    public SubtitleFetcher() { this(15_000, null, true, null); }
    public SubtitleFetcher(int timeoutMs) { this(timeoutMs, null, true, null); }
    public SubtitleFetcher(int timeoutMs, ConnectionOpener opener) { this(timeoutMs, opener, true, null); }
    public SubtitleFetcher(int timeoutMs, ConnectionOpener opener,
                           boolean diagnosticsEnabled, UrlPolicy urlPolicy) {
        this.timeoutMs = Math.max(1000, timeoutMs);
        this.opener = opener != null ? opener : url -> (HttpURLConnection) url.openConnection();
        this.diagnosticsEnabled = diagnosticsEnabled;
        this.urlPolicy = urlPolicy;
    }

    public String fetch(String url, Map<String, String> headers, Cancellation cancel)
            throws SubtitleException {
        URL currentUrl;
        try {
            currentUrl = url == null ? null : new URL(url);
        } catch (IOException e) {
            currentUrl = null;
        }
        if (!isHttpUrl(currentUrl))
            throw new SubtitleException("رابط ترجمة غير صالح", 0);
        if (urlPolicy != null && !urlPolicy.allows(currentUrl))
            throw new SubtitleException("رابط ترجمة غير آمن", 0);
        URL fromUrl = currentUrl;
        boolean strippedHeaders = false;
        for (int hop = 0; hop <= MAX_REDIRECTS; hop++) {
            checkCancel(cancel);
            if (urlPolicy != null && !urlPolicy.allows(currentUrl))
                throw new SubtitleException("وجهة ترجمة غير آمنة", 0);
            HttpURLConnection conn = null;
            long diagnosticStart = android.os.SystemClock.elapsedRealtime();
            int diagnosticStatus = -1;
            String diagnosticResponse = null;
            URL diagnosticUrl = currentUrl;
            try {
                conn = opener.open(currentUrl);
                conn.setInstanceFollowRedirects(false);
                conn.setConnectTimeout(timeoutMs);
                conn.setReadTimeout(timeoutMs);
                conn.setRequestProperty("Accept-Encoding", "gzip");
                conn.setRequestProperty("Accept", "*/*");
                Map<String, String> hopHeaders =
                        headersForHop(headers, fromUrl, currentUrl, strippedHeaders);
                if (!sameOrigin(fromUrl, currentUrl)) strippedHeaders = true;
                for (Map.Entry<String, String> e : hopHeaders.entrySet()) {
                    if (e.getKey() != null && e.getValue() != null && !e.getValue().isEmpty())
                        conn.setRequestProperty(e.getKey(), e.getValue());
                }
                if (diagnosticsEnabled)
                    DiagnosticsRecorder.headers("subtitle", "download", "GET", diagnosticUrl.toString(), conn.getRequestProperties());
                int code = conn.getResponseCode();
                diagnosticStatus = code;
                if (code >= 300 && code < 400) {
                    if (hop == MAX_REDIRECTS)
                        throw new SubtitleException("إعادة توجيه كثيرة", 0);
                    String loc = conn.getHeaderField("Location");
                    if (loc == null || loc.isEmpty())
                        throw new SubtitleException("إعادة توجيه بدون عنوان", code);
                    URL nextUrl = new URL(currentUrl, loc);
                    if (!isHttpUrl(nextUrl))
                        throw new SubtitleException("رابط ترجمة غير صالح", 0);
                    if ("https".equalsIgnoreCase(currentUrl.getProtocol())
                            && "http".equalsIgnoreCase(nextUrl.getProtocol()))
                        throw new SubtitleException("إعادة توجيه غير آمنة", code);
                    if (!sameOrigin(currentUrl, nextUrl)) strippedHeaders = true;
                    fromUrl = currentUrl;
                    currentUrl = nextUrl;
                    continue;
                }
                if (code < 200 || code >= 300)
                    throw new SubtitleException("HTTP " + code, code);
                byte[] body = readAll(conn, cancel);
                checkCancel(cancel);
                if (body.length == 0) throw new SubtitleException("ملف الترجمة فارغ", code);
                String decoded = decode(body);
                diagnosticResponse = decoded;
                if (diagnosticsEnabled)
                    DiagnosticsRecorder.network("subtitle", "download", "GET", diagnosticUrl.toString(), code,
                            android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, decoded, null, false);
                String normalized = decoded.trim().toLowerCase(Locale.US);
                if (normalized.startsWith("<!doctype") || normalized.startsWith("<html")
                        || normalized.startsWith("{"))
                    throw new SubtitleException("ليس ملف ترجمة", code);
                return decoded;
            } catch (SubtitleException e) {
                if (diagnosticsEnabled)
                    DiagnosticsRecorder.network("subtitle", "download", "GET", diagnosticUrl.toString(), diagnosticStatus,
                            android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, diagnosticResponse, e, false);
                throw e;
            } catch (IOException e) {
                if (diagnosticsEnabled)
                    DiagnosticsRecorder.network("subtitle", "download", "GET", diagnosticUrl.toString(), diagnosticStatus,
                            android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, diagnosticResponse, e, false);
                throw new SubtitleException("خطأ شبكة: " + e.getClass().getSimpleName(), 0);
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        throw new SubtitleException("إعادة توجيه كثيرة", 0);
    }

    static Map<String, String> headersForHop(Map<String, String> original, URL from, URL to,
                                              boolean alreadyStripped) {
        Map<String, String> out = new LinkedHashMap<>();
        if (original == null) return out;
        boolean dropSensitive = alreadyStripped || !sameOrigin(from, to);
        for (Map.Entry<String, String> entry : original.entrySet()) {
            String name = entry.getKey();
            String value = entry.getValue();
            if (name == null || value == null) continue;
            String lower = name.toLowerCase(Locale.US);
            if (dropSensitive && (lower.equals("authorization")
                    || lower.equals("proxy-authorization") || lower.equals("cookie")
                    || lower.startsWith("x-"))) continue;
            out.put(name, value);
        }
        return out;
    }

    static boolean sameOrigin(URL a, URL b) {
        return a != null && b != null
                && a.getProtocol().equalsIgnoreCase(b.getProtocol())
                && a.getHost().equalsIgnoreCase(b.getHost())
                && effectivePort(a) == effectivePort(b);
    }

    private static int effectivePort(URL url) {
        if (url.getPort() >= 0) return url.getPort();
        if ("https".equalsIgnoreCase(url.getProtocol())) return 443;
        if ("http".equalsIgnoreCase(url.getProtocol())) return 80;
        return -1;
    }

    private static boolean isHttpUrl(URL url) {
        return url != null && url.getHost() != null && !url.getHost().isEmpty()
                && ("http".equalsIgnoreCase(url.getProtocol())
                    || "https".equalsIgnoreCase(url.getProtocol()));
    }

    private static void checkCancel(Cancellation c) throws SubtitleException {
        if (c != null && c.isCancelled()) throw new SubtitleException("cancelled", -1);
    }

    private static byte[] readAll(HttpURLConnection conn, Cancellation cancel)
            throws IOException, SubtitleException {
        InputStream raw = conn.getInputStream();
        InputStream in = "gzip".equalsIgnoreCase(conn.getContentEncoding())
                ? new GZIPInputStream(raw) : raw;
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) {
                checkCancel(cancel);
                out.write(buf, 0, n);
                if (out.size() > MAX_BYTES) throw new SubtitleException("ملف الترجمة كبير جداً", 0);
            }
            byte[] bytes = out.toByteArray();
            if (bytes.length >= 2 && (bytes[0] & 0xFF) == 0x1F && (bytes[1] & 0xFF) == 0x8B) {
                return readAllPlain(new GZIPInputStream(new java.io.ByteArrayInputStream(bytes)));
            }
            return bytes;
        } finally {
            in.close();
        }
    }

    private static byte[] readAllPlain(InputStream in) throws IOException, SubtitleException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[16 * 1024];
        int n;
        while ((n = in.read(buf)) != -1) {
            out.write(buf, 0, n);
            if (out.size() > MAX_BYTES)
                throw new SubtitleException("ملف الترجمة كبير جداً", 0);
        }
        return out.toByteArray();
    }

    /** UTF-8 (with/without BOM), UTF-16 BOMs, else legacy Arabic windows-1256. */
    public static String decode(byte[] b) {
        if (b.length >= 3 && (b[0] & 0xFF) == 0xEF && (b[1] & 0xFF) == 0xBB && (b[2] & 0xFF) == 0xBF)
            return new String(b, 3, b.length - 3, StandardCharsets.UTF_8);
        if (b.length >= 2 && (b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xFE)
            return new String(b, 2, b.length - 2, StandardCharsets.UTF_16LE);
        if (b.length >= 2 && (b[0] & 0xFF) == 0xFE && (b[1] & 0xFF) == 0xFF)
            return new String(b, 2, b.length - 2, StandardCharsets.UTF_16BE);
        try {
            return StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(b)).toString();
        } catch (CharacterCodingException e) {
            try {
                return new String(b, Charset.forName("windows-1256"));
            } catch (Exception ignored) {
                return new String(b, StandardCharsets.UTF_8);
            }
        }
    }
}

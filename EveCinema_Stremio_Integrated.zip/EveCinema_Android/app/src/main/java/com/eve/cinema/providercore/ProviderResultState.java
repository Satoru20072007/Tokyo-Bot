package com.eve.cinema.providercore;

/**
 * ProviderResultState — حالات النتيجة الموحدة (خطة §4/§5 الخطوة 4 و§10.3).
 *
 * القاعدة الصلبة: لا يتحول FAILED أو UNKNOWN أبداً إلى «لا يوجد محتوى عربي»،
 * ولا تُحسب إلغاءات المهلة الناعمة أو الإجابات القاطعة السلبية أعطالاً تفتح
 * قاطع المصدر.
 *
 * Pure Java, no Android deps — unit-tested on the JVM.
 */
public enum ProviderResultState {

    // ── نتائج مرشح قاطعة ─────────────────────────────────────────────
    /** رابط ووسيط ونوع عربي مثبت. */
    VERIFIED_PLAYABLE,
    /** الهوية والنوع مدعومان لكن الاتصال فشل مؤقتاً؛ لا يُعرض الزر إلا بمرشح صالح آخر. */
    VERIFIED_BUT_TEMPORARILY_UNREACHABLE,
    /** فُحصت الأماكن المحددة بنجاح ولا نتيجة عربية لهذا العنصر — جواب سلبي حقيقي. */
    NO_ARABIC_FOR_THIS_ITEM,
    /** رابط رسالة تحديث/صفحة متخفية كفيديو — مرفوض دائماً حتى لو HTTP 200. */
    REJECTED_PLACEHOLDER,

    // ── تصنيفات فشل الفحص (خطة §5 الخطوة 2 و§7.1) ────────────────────
    /** لا وصول إلى الخدمة من هذه الشبكة حالياً. */
    UNREACHABLE,
    TIMEOUT,
    AUTH_REQUIRED,
    /** اكتمل البحث ولا تطابق — ليس عطل شبكة. */
    NO_MATCH,
    /** المصدر سليم لكن لا خيار عربي — ليس عطل شبكة. */
    NO_ARABIC_OPTION,
    /** الوصول مشروط بشبكة معيّنة وهذه الشبكة غير مؤهلة. */
    NETWORK_NOT_ELIGIBLE,
    /** المهلة الناعمة أو مغادرة الصفحة — لا يُسجَّل فشلاً للمزوّد. */
    CANCELLED,

    // ── لا دليل كافٍ ─────────────────────────────────────────────────
    UNKNOWN,
    /** انتهت المهلة أو فشل parsing/network قبل جواب قاطع. */
    FAILED;

    /** جواب قاطع عن سؤال التوفر (إيجاباً أو سلباً). */
    public boolean isDefinitive() {
        return this == VERIFIED_PLAYABLE || this == NO_ARABIC_FOR_THIS_ITEM
                || this == NO_MATCH || this == NO_ARABIC_OPTION;
    }

    /** يظهر زر مشاهدة فقط من هذه الحالة (خطة §1.3 وقرار رقم 7). */
    public boolean isDisplayable() {
        return this == VERIFIED_PLAYABLE;
    }

    /**
     * هل يُحسب عطلاً يفتح قاطع المصدر؟ (خطة §10.3)
     * NO_MATCH وNO_ARABIC_OPTION وCANCELLED ليست أعطالاً؛ والإجابات القاطعة
     * تثبت أن المصدر reachable فتُغلق القاطع.
     */
    public boolean countsAgainstHealth() {
        switch (this) {
            case UNREACHABLE:
            case TIMEOUT:
            case NETWORK_NOT_ELIGIBLE:
            case FAILED:
                return true;
            default:
                return false;
        }
    }

    /** تحويل إلى ProbeOutcome الموجود ليتكامل مع ProviderGate الحالي. */
    public com.eve.cinema.playback.ProbeOutcome toProbeOutcome() {
        switch (this) {
            case VERIFIED_PLAYABLE:
                return com.eve.cinema.playback.ProbeOutcome.VERIFIED;
            case NO_ARABIC_FOR_THIS_ITEM:
            case NO_MATCH:
            case NO_ARABIC_OPTION:
            case REJECTED_PLACEHOLDER:
                return com.eve.cinema.playback.ProbeOutcome.NOT_FOUND_DEFINITIVE;
            case CANCELLED:
            case UNKNOWN:
            case UNREACHABLE:
            case TIMEOUT:
            case AUTH_REQUIRED:
            case NETWORK_NOT_ELIGIBLE:
            case FAILED:
            default:
                return com.eve.cinema.playback.ProbeOutcome.UNRESOLVED_TRANSIENT;
        }
    }
}

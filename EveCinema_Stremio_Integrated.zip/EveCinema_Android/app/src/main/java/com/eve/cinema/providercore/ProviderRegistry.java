package com.eve.cinema.providercore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * ProviderRegistry — سجل المصادر وإعداداتها وقراراتها (وحدة §4.1).
 *
 *  - كل مصدر يُسجَّل بورقة قرار؛ REJECTED/DISABLED لا يعملان أبداً.
 *  - يمكن تعطيل مصدر من السجل دون حذف أو كسر غيره (بوابة المرحلة 2).
 *  - الموجة الأولى تُحدَّد صراحة بقائمة معرّفات، لا بترتيب التسجيل.
 *
 * Pure Java — unit-tested on the JVM.
 */
public final class ProviderRegistry {

    public static final class Entry {
        public final ProviderAdapter adapter;
        private volatile ProviderDecision decision;
        /** أولوية داخل الموجة الثانية؛ الأصغر يُستعلَم أولاً. */
        public final int wave2Order;

        Entry(ProviderAdapter adapter, ProviderDecision decision, int wave2Order) {
            this.adapter = adapter;
            this.decision = decision;
            this.wave2Order = wave2Order;
        }

        public ProviderDecision decision() { return decision; }
    }

    private final Map<String, Entry> entries = new LinkedHashMap<>();
    private final List<String> wave1Ids = new ArrayList<>();

    public synchronized void register(ProviderAdapter adapter, ProviderDecision decision, int wave2Order) {
        if (adapter == null) throw new IllegalArgumentException("adapter required");
        ProviderDecision d = decision == null ? ProviderDecision.currentFor(adapter.id()) : decision;
        entries.put(adapter.id(), new Entry(adapter, d, wave2Order));
    }

    /** تعريف موجة أولى صريح (مثلاً cinemabox + vodu عند فتح بوابته). */
    public synchronized void setWave1(String... providerIds) {
        wave1Ids.clear();
        if (providerIds != null)
            for (String id : providerIds) if (id != null) wave1Ids.add(id);
    }

    public synchronized void setDecision(String providerId, ProviderDecision decision) {
        Entry e = entries.get(providerId);
        if (e != null && decision != null) e.decision = decision;
    }

    public synchronized ProviderDecision decisionOf(String providerId) {
        Entry e = entries.get(providerId);
        return e == null ? ProviderDecision.REJECTED : e.decision();
    }

    /** adapters الموجة الأولى المسموح بمرورها حالياً. */
    public synchronized List<ProviderAdapter> wave1() {
        List<ProviderAdapter> out = new ArrayList<>();
        for (String id : wave1Ids) {
            Entry e = entries.get(id);
            if (e != null && e.decision().allowsTraffic()) out.add(e.adapter);
        }
        return out;
    }

    /** adapters الموجة الثانية المسموح بها، مرتبة بأولوية الاختبار (§6.3). */
    public synchronized List<ProviderAdapter> wave2() {
        List<Entry> allowed = new ArrayList<>();
        for (Entry e : entries.values())
            if (e.decision().allowsTraffic() && !wave1Ids.contains(e.adapter.id()))
                allowed.add(e);
        Collections.sort(allowed, (a, b) -> Integer.compare(a.wave2Order, b.wave2Order));
        List<ProviderAdapter> out = new ArrayList<>();
        for (Entry e : allowed) out.add(e.adapter);
        return out;
    }

    public synchronized int size() { return entries.size(); }
}

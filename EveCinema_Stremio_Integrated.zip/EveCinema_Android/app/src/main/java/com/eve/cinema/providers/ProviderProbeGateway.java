package com.eve.cinema.providers;

import com.eve.cinema.playback.ProbeOutcome;
import com.eve.cinema.providercore.CanonicalMediaIdentity;
import com.eve.cinema.providercore.ProviderAdapter;
import com.eve.cinema.providercore.ProviderDecision;
import com.eve.cinema.providercore.ProviderHealthStore;
import com.eve.cinema.providercore.ProviderIds;
import com.eve.cinema.providercore.ProviderRegistry;
import com.eve.cinema.providercore.SafeDiagnostics;
import com.eve.cinema.providercore.SourceWaveController;
import java.util.List;
import java.util.concurrent.ExecutorService;

/**
 * ProviderProbeGateway — بوابة فحص التوفر لصفحة التفاصيل/الحلقات.
 *
 * تستبدل ParallelProviderProbe القديمة: الموجات والصحة والمهلات صارت ملك
 * SourceWaveController (خطة §10)، وهذه البوابة تترجم نتائجه إلى عقد الواجهة
 * الحالي (ProbeOutcome + قاعدة combine) دون تغيير سلوك مرئي:
 *
 *  - المصدران يُفحصان بالتوازي منذ اللحظة صفر (كلاهما موجة أولى حالياً؛ عند
 *    فتح بوابة Vodu يُنقل MovieBox إلى wave2Order=1 بسطر واحد في EveProviders).
 *  - الأنمي: لا يُسجَّل CinemaBox ولا يُستدعى (P7). المصدر الأساسي للأنمي
 *    هو Stremio ويقع خارج هذه البوابة (يُضاف في SourceChoice).
 *  - مزوّد مُطفأ بقرار (DISABLED/REJECTED) يُعدّ «غير معروض» = نتيجة قاطعة
 *    NOT_FOUND_DEFINITIVE؛ لا يبقى عابراً أبداً وإلا حجب «العابر يسود» كل قرار.
 *  - نتيجة مثبتة بعد المهلة الناعمة تُنشر مبكراً ولا يحتجزها مصدر بطيء (§1.3).
 *  - REJECTED/DISABLED لا يمرّر أي traffic — السجل يفرض القرار قبل الاستدعاء.
 *  - فشل عابر لا يتحول أبداً إلى «لا يوجد» — UNRESOLVED_TRANSIENT يبقى قابلاً
 *    لإعادة المحاولة ولا يُخزَّن سلبياً قاطعاً.
 *
 * Pure Java (adapters/health/executor تُحقن) — unit-tested on the JVM.
 */
public final class ProviderProbeGateway {

    private ProviderProbeGateway() {}

    /** نتيجة مترجمة لعقد الواجهة الحالي — مطابق شكلاً لنتيجة ParallelProviderProbe. */
    public static final class Result {
        public final ProbeOutcome movieBox;
        public final ProbeOutcome cinemaBox; // null حين يُستثنى (أنمي)
        public final ProbeOutcome combined;
        public final boolean authRequired;

        Result(ProbeOutcome movieBox, ProbeOutcome cinemaBox) {
            this(movieBox, cinemaBox, false);
        }

        Result(ProbeOutcome movieBox, ProbeOutcome cinemaBox, boolean authRequired) {
            this.movieBox = movieBox;
            this.cinemaBox = cinemaBox;
            this.combined = combine(movieBox, cinemaBox);
            this.authRequired = authRequired;
        }

        public boolean movieBoxVerified() { return movieBox == ProbeOutcome.VERIFIED; }
        public boolean cinemaBoxVerified() { return cinemaBox == ProbeOutcome.VERIFIED; }
    }

    /**
     * يشغّل جولة فحص واحدة. health/executor مشتركان عبر EveProviders حتى يعيش
     * قاطع كل مصدر بين الاستدعاءات (مثل البوابات الساكنة سابقاً).
     */
    public static Result run(CanonicalMediaIdentity identity, boolean anime,
                             ProviderAdapter movieBox, ProviderAdapter cinemaBox,
                             ProviderHealthStore health, ExecutorService executor,
                             SafeDiagnostics diagnostics) {
        return run(identity, anime, movieBox, cinemaBox, health, executor, diagnostics,
                SourceWaveController.DEFAULT_SOFT_TIMEOUT_MS,
                SourceWaveController.DEFAULT_HARD_BUDGET_MS);
    }

    /** Visible for deterministic JVM tests; production uses the defaults above. */
    public static Result run(CanonicalMediaIdentity identity, boolean anime,
                             ProviderAdapter movieBox, ProviderAdapter cinemaBox,
                             ProviderHealthStore health, ExecutorService executor,
                             SafeDiagnostics diagnostics,
                             long softTimeoutMs, long hardBudgetMs) {
        return run(identity, anime, movieBox, cinemaBox, null, null, health, executor,
                diagnostics, softTimeoutMs, hardBudgetMs);
    }

    /**
     * القرارات قابلة للحقن حتى لا تتعلق الاختبارات بورقة القرار الإنتاجية؛
     * null = {@link ProviderDecision#currentFor(String)}.
     */
    public static Result run(CanonicalMediaIdentity identity, boolean anime,
                             ProviderAdapter movieBox, ProviderAdapter cinemaBox,
                             ProviderDecision movieBoxDecision, ProviderDecision cinemaBoxDecision,
                             ProviderHealthStore health, ExecutorService executor,
                             SafeDiagnostics diagnostics,
                             long softTimeoutMs, long hardBudgetMs) {
        ProviderDecision mbDecision = movieBoxDecision != null ? movieBoxDecision
                : ProviderDecision.currentFor(ProviderIds.MOVIEBOX);
        ProviderDecision cbDecision = cinemaBoxDecision != null ? cinemaBoxDecision
                : ProviderDecision.currentFor(ProviderIds.CINEMABOX);
        boolean mbOn = mbDecision.allowsTraffic();
        boolean cbOn = !anime && cbDecision.allowsTraffic();

        // مزوّد مُطفأ = «غير معروض» (قاطع) لا «عابر»: النتيجة العابرة تسود في combine()
        // فتمنع التخزين المؤقت وتُظهر «تعذر التحقق» للأبد بلا أي عطل فعلي.
        ProbeOutcome mb = mbOn ? ProbeOutcome.UNRESOLVED_TRANSIENT : ProbeOutcome.NOT_FOUND_DEFINITIVE;
        ProbeOutcome cb = anime ? null
                : (cbOn ? ProbeOutcome.UNRESOLVED_TRANSIENT : ProbeOutcome.NOT_FOUND_DEFINITIVE);
        if (!mbOn && !cbOn) return new Result(mb, cb, false); // لا شيء يُستدعى

        // سجل بطلب واحد: يفرض قرارات المصادر ويحدد تشكيلة الموجة لهذا الطلب
        // فقط — لا يتسابق مع طلب صفحة أخرى بعَلَم أنمي مختلف.
        ProviderRegistry scoped = new ProviderRegistry();
        if (anime) {
            scoped.register(movieBox, mbDecision, 1);
            scoped.setWave1(ProviderIds.MOVIEBOX);
        } else {
            scoped.register(cinemaBox, cbDecision, 1);
            scoped.register(movieBox, mbDecision, 2);
            scoped.setWave1(ProviderIds.CINEMABOX, ProviderIds.MOVIEBOX);
        }
        SourceWaveController controller = new SourceWaveController(scoped, health, executor,
                System::currentTimeMillis,
                softTimeoutMs, hardBudgetMs,
                SourceWaveController.DEFAULT_MAX_CONCURRENCY);

        String corr = diagnostics == null ? null : diagnostics.newCorrelationId();
        if (diagnostics != null)
            diagnostics.event(corr, "resolver.start", "-", null, -1);

        List<SourceWaveController.WaveResult> results = controller.run(identity, null);

        boolean authRequired = false;
        for (SourceWaveController.WaveResult r : results) {
            if (diagnostics != null)
                diagnostics.event(corr, "provider.probe", r.providerId, r.state, r.elapsedMs);
            if (ProviderIds.MOVIEBOX.equals(r.providerId)) mb = r.state.toProbeOutcome();
            else if (ProviderIds.CINEMABOX.equals(r.providerId)) {
                cb = r.state.toProbeOutcome();
                authRequired = r.state == com.eve.cinema.providercore.ProviderResultState.AUTH_REQUIRED;
            }
        }
        return new Result(mb, cb, authRequired);
    }

    /** قاعدة الدمج نفسها: العابر يسود، ثم المثبت، ثم السلبي القاطع. */
    private static ProbeOutcome combine(ProbeOutcome movieBox, ProbeOutcome cinemaBox) {
        if (movieBox == ProbeOutcome.UNRESOLVED_TRANSIENT
                || (cinemaBox != null && cinemaBox == ProbeOutcome.UNRESOLVED_TRANSIENT))
            return ProbeOutcome.UNRESOLVED_TRANSIENT;
        if (movieBox == ProbeOutcome.VERIFIED || cinemaBox == ProbeOutcome.VERIFIED)
            return ProbeOutcome.VERIFIED;
        return ProbeOutcome.NOT_FOUND_DEFINITIVE;
    }
}

package com.eve.cinema.providercore;

import java.net.InetAddress;
import java.net.URI;
import java.util.Locale;

/**
 * PlayableCandidateValidator — فحوص قبول الرابط قبل إظهاره (خطة §11).
 *
 * البوابات المحلية (بلا شبكة): صيغة URI، رفض javascript:/file:/content:،
 * رفض العناوين الداخلية، رفض placeholder عبر كاشف قابل للحقن. الفحوص
 * الشبكية (HEAD/Range/Manifest) تُحقن عبر LinkProbe لتبقى الوحدة قابلة
 * لاختبار JVM ولإعادة استعمال ManifestProber الموجود داخل التطبيق.
 *
 * Pure Java — unit-tested on the JVM.
 */
public final class PlayableCandidateValidator {

    /** كاشف placeholder — يربط MovieBoxParser كشفَ رابط الإشعار الموجود. */
    public interface PlaceholderDetector {
        boolean isPlaceholder(String uri, String contentType, Long durationSeconds);
    }

    /** فحص شبكي محدود — HEAD أو Range صغير أو قراءة Manifest (§11.1 بند 6-7). */
    public interface LinkProbe {
        LinkProbeResult probe(String uri, java.util.Map<String, String> headers)
                throws Exception;
    }

    public static final class LinkProbeResult {
        public final int httpCode;          // -1 عند تعذر القياس
        public final String contentType;    // nullable
        public final Long contentLength;    // nullable
        public final Boolean rangeSupport;  // nullable
        public final Boolean manifestValid; // null = لا manifest
        public final Long mediaDurationSec; // من manifest فعلي، لا من play-info

        public LinkProbeResult(int httpCode, String contentType, Long contentLength,
                               Boolean rangeSupport, Boolean manifestValid, Long mediaDurationSec) {
            this.httpCode = httpCode;
            this.contentType = contentType;
            this.contentLength = contentLength;
            this.rangeSupport = rangeSupport;
            this.manifestValid = manifestValid;
            this.mediaDurationSec = mediaDurationSec;
        }
    }

    private final PlaceholderDetector placeholderDetector;
    private final LinkProbe linkProbe; // nullable — الفحص المحلي فقط عند غيابه

    public PlayableCandidateValidator(PlaceholderDetector detector, LinkProbe probe) {
        this.placeholderDetector = detector;
        this.linkProbe = probe;
    }

    /** الفحص المحلي الكامل (بلا شبكة). لا يرمي — يصنّف. */
    public ProviderResultState validateLocal(NormalizedCandidate c) {
        if (c == null || !c.hasUri()) return ProviderResultState.FAILED;
        String uri = c.playbackUri();
        String lower = uri.toLowerCase(Locale.US);

        // بند 1: https افتراضياً؛ رفض السكيمات غير الوسائطية.
        if (lower.startsWith("javascript:") || lower.startsWith("file:")
                || lower.startsWith("content:") || lower.startsWith("data:"))
            return ProviderResultState.REJECTED_PLACEHOLDER;
        URI parsed;
        try {
            parsed = URI.create(uri);
        } catch (Exception e) {
            return ProviderResultState.FAILED;
        }
        String scheme = parsed.getScheme();
        if (scheme == null || !(scheme.equalsIgnoreCase("https") || scheme.equalsIgnoreCase("http")))
            return ProviderResultState.FAILED;

        // بند 2: مضيف صالح وليس عنواناً داخلياً محظوراً.
        String host = parsed.getHost();
        if (host == null || host.isEmpty()) return ProviderResultState.FAILED;
        if (isInternalHost(host)) return ProviderResultState.FAILED;

        // بند 4: placeholder معروف.
        if (placeholderDetector != null
                && placeholderDetector.isPlaceholder(uri, null, null))
            return ProviderResultState.REJECTED_PLACEHOLDER;

        return ProviderResultState.UNKNOWN; // نجا محلياً — يحتاج فحصاً شبكياً ليُثبت
    }

    /**
     * الفحص الشبكي المحدود بعد النجاة المحلية. لا يستهلك الفيلم كاملاً
     * (§11.2) — HEAD/Range/Manifest فقط عبر LinkProbe المحقون.
     */
    public ProviderResultState validateRemote(NormalizedCandidate c) {
        ProviderResultState local = validateLocal(c);
        if (local != ProviderResultState.UNKNOWN) return local;
        if (linkProbe == null) return ProviderResultState.UNKNOWN;

        LinkProbeResult r;
        try {
            r = linkProbe.probe(c.playbackUri(), c.requiredHeaders());
        } catch (Exception e) {
            return ProviderResultState.UNREACHABLE;
        }
        if (r == null) return ProviderResultState.UNKNOWN;

        // HTTP 200 وحده ليس دليلاً (قرار رقم 7).
        if (r.httpCode == 401 || r.httpCode == 403) return ProviderResultState.AUTH_REQUIRED;
        if (r.httpCode >= 400) return ProviderResultState.UNREACHABLE;

        String ct = r.contentType == null ? "" : r.contentType.toLowerCase(Locale.US);
        boolean looksHtml = ct.contains("text/html");
        if (looksHtml) return ProviderResultState.REJECTED_PLACEHOLDER;

        if (placeholderDetector != null
                && placeholderDetector.isPlaceholder(c.playbackUri(), ct, r.mediaDurationSec))
            return ProviderResultState.REJECTED_PLACEHOLDER;

        // بند 7: عند HLS/DASH يلزم Manifest بمسارات فعلية.
        if ((c.streamType() == NormalizedCandidate.StreamType.HLS
                || c.streamType() == NormalizedCandidate.StreamType.DASH)
                && r.manifestValid != null && !r.manifestValid)
            return ProviderResultState.FAILED;

        boolean typeOk = ct.isEmpty()
                || ct.contains("video") || ct.contains("mpegurl")
                || ct.contains("dash") || ct.contains("octet-stream");
        if (!typeOk) return ProviderResultState.UNKNOWN;

        return ProviderResultState.VERIFIED_PLAYABLE;
    }

    static boolean isInternalHost(String host) {
        String h = host.toLowerCase(Locale.US);
        if (h.equals("localhost") || h.endsWith(".local") || h.endsWith(".internal")) return true;
        // صيغة IP حرفية: رفض المدارات الخاصة/الـloopback/الـlink-local.
        if (h.matches("\\d+\\.\\d+\\.\\d+\\.\\d+")) {
            try {
                InetAddress addr = InetAddress.getByName(h);
                return addr.isLoopbackAddress() || addr.isSiteLocalAddress()
                        || addr.isLinkLocalAddress() || addr.isAnyLocalAddress();
            } catch (Exception e) {
                return true;
            }
        }
        if (h.contains(":")) return true; // IPv6 حرفي — محظور افتراضياً
        return false;
    }
}

package com.eve.cinema.stremio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * One direct stream the user can choose. The add-on that produced it is kept only for
 * header scoping inside the player; it is never part of what the UI shows.
 */
public final class StremioStreamOption {
    public static final double SPEED_UNKNOWN = -1d;
    public static final long SIZE_UNKNOWN = -1L;

    public final String id;
    public final String url;
    public final Map<String, String> headers;
    public final String addonManifestUrl;
    public final String streamType;
    /** Video height in pixels, or {@link StremioQuality#UNKNOWN}. */
    public final int qualityHeight;
    /** Field that stated the height (name, filename, description, url, manifest) or "". */
    public final String qualitySource;
    /** True when the add-on's own fields disagreed about the resolution. */
    public final boolean qualityContradictory;
    /** Estimated throughput in Mbps from a small bounded sample, or {@link #SPEED_UNKNOWN}. */
    public final double speedMbps;
    /** Arabic subtitles the add-on attached directly to this stream. */
    public final List<StremioSubtitle> attachedSubtitles;
    /** Stable, arrival-ordered number shown as "source N"; 0 until the engine assigns one. */
    public final int sourceNumber;
    /** File name declared in behaviorHints (display only), or "". */
    public final String fileName;
    /** Size in bytes declared in behaviorHints, or {@link #SIZE_UNKNOWN}. */
    public final long videoSize;
    public final String videoHash;
    /** Strong identity keys of the file (see {@link StremioFileIdentity}); empty when unknown. */
    public final Set<String> fileKeys;

    public StremioStreamOption(String id, String url, Map<String, String> headers,
                               String addonManifestUrl, String streamType, int qualityHeight,
                               double speedMbps, List<StremioSubtitle> attachedSubtitles) {
        this(id, url, headers, addonManifestUrl, streamType, qualityHeight, "", false, speedMbps,
                attachedSubtitles, 0, "", SIZE_UNKNOWN, "", Collections.<String>emptySet());
    }

    public StremioStreamOption(String id, String url, Map<String, String> headers,
                               String addonManifestUrl, String streamType, int qualityHeight,
                               String qualitySource, boolean qualityContradictory, double speedMbps,
                               List<StremioSubtitle> attachedSubtitles, int sourceNumber,
                               String fileName, long videoSize, String videoHash, Set<String> fileKeys) {
        this.id = id;
        this.url = url;
        this.headers = headers == null ? Collections.<String, String>emptyMap()
                : Collections.unmodifiableMap(headers);
        this.addonManifestUrl = addonManifestUrl == null ? "" : addonManifestUrl;
        this.streamType = streamType == null ? "UNKNOWN" : streamType;
        this.qualityHeight = Math.max(0, qualityHeight);
        this.qualitySource = qualitySource == null ? "" : qualitySource;
        this.qualityContradictory = qualityContradictory;
        this.speedMbps = speedMbps > 0 ? speedMbps : SPEED_UNKNOWN;
        this.attachedSubtitles = attachedSubtitles == null
                ? Collections.<StremioSubtitle>emptyList()
                : Collections.unmodifiableList(new ArrayList<>(attachedSubtitles));
        this.sourceNumber = sourceNumber;
        this.fileName = fileName == null ? "" : fileName;
        this.videoSize = videoSize > 0 ? videoSize : SIZE_UNKNOWN;
        this.videoHash = videoHash == null ? "" : videoHash;
        this.fileKeys = fileKeys == null ? Collections.<String>emptySet()
                : Collections.unmodifiableSet(new LinkedHashSet<>(fileKeys));
    }

    public boolean hasKnownSpeed() { return speedMbps > 0; }

    public StremioQuality.Bucket bucket() { return StremioQuality.bucketOf(qualityHeight); }

    /** True when {@code other} is provably the same video file (a shared strong key). */
    public boolean sameFileAs(StremioStreamOption other) {
        if (other == null) return false;
        for (String key : fileKeys) if (other.fileKeys.contains(key)) return true;
        return false;
    }

    /**
     * Returns a copy with the measured speed and, when the stream's own HLS/DASH manifest declared
     * one, that height. A manifest resolution is measured data and replaces a text-derived value.
     */
    public StremioStreamOption withProbe(double mbps, int manifestHeight) {
        boolean fromManifest = manifestHeight > 0;
        return new StremioStreamOption(id, url, headers, addonManifestUrl, streamType,
                fromManifest ? manifestHeight : qualityHeight,
                fromManifest ? "manifest" : qualitySource,
                fromManifest ? false : qualityContradictory,
                mbps, attachedSubtitles, sourceNumber, fileName, videoSize, videoHash, fileKeys);
    }

    /** Copy carrying the engine-assigned number. */
    public StremioStreamOption withSourceNumber(int number) {
        return new StremioStreamOption(id, url, headers, addonManifestUrl, streamType, qualityHeight,
                qualitySource, qualityContradictory, speedMbps, attachedSubtitles, number,
                fileName, videoSize, videoHash, fileKeys);
    }

    /** "HLS", "DASH", or the file extension in capitals ("MKV"), or "" when unknown. */
    public String formatLabel() {
        if ("HLS".equals(streamType)) return "HLS";
        if ("DASH".equals(streamType)) return "DASH";
        try {
            String path = java.net.URI.create(url).getPath();
            if (path == null) return "";
            int dot = path.lastIndexOf('.');
            if (dot < 0 || path.length() - dot > 6) return "";
            String ext = path.substring(dot + 1).toUpperCase(Locale.ROOT);
            return ext.matches("MP4|MKV|M4V|WEBM|MOV|TS") ? ext : "";
        } catch (RuntimeException ex) {
            return "";
        }
    }

    /** "12" for 12.3, "4.2" for 4.2, "0.6" for 0.6; always Latin digits. */
    public static String formatMbps(double mbps) {
        if (mbps <= 0) return "";
        if (mbps >= 10d) return String.format(Locale.US, "%d", Math.round(mbps));
        return String.format(Locale.US, "%.1f", mbps);
    }

    /** "2.3 GB" / "850 MB" with Latin digits, or "" when the size is unknown. */
    public static String formatSize(long bytes) {
        if (bytes <= 0) return "";
        double gb = bytes / (1024d * 1024d * 1024d);
        if (gb >= 1d) return String.format(Locale.US, "%.1f GB", gb);
        return String.format(Locale.US, "%d MB", Math.max(1L, Math.round(bytes / (1024d * 1024d))));
    }
}

package com.eve.cinema;

import android.os.Handler;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Eve v6 — TMDB Resolver
 *
 * يستبدل: searchTmdbParallel (CountDownLatch blocking) + searchTmdb + titleMatchScore
 *
 * التحسينات الجوهرية:
 *  1. ZERO BLOCKING: AtomicInteger بدل CountDownLatch — IO thread لا يُحجَز أبداً
 *  2. Safety timeout: الـ callback يُطلَق بعد 10 ثوانٍ حتى لو TMDB لم يرد
 *  3. AtomicBoolean: يمنع double-fire للـ callback (timeout + completion في وقت واحد)
 *  4. Article normalization: "The" / "A" / "An" تُحذف قبل المقارنة
 *  5. Anime JP bonus: +500 نقطة للأعمال اليابانية الأصل → Kingdom الياباني يفوز دائماً
 *  6. FIFO cache: LinkedHashMap مع removeEldestEntry — 100 نتيجة
 *  7. Original order: النتائج تُعاد بترتيب الذكر الأصلي
 *  8. Pool منفصل (6 threads) — لا يتداخل مع IO pool الرئيسي
 */
public class EveTmdbResolver {

    private static final String TMDB_TOKEN =
        Config.TMDB_BEARER_TOKEN;

    private static final long    TIMEOUT_MS = 10_000L;
    private static final int     CACHE_SIZE = 100;

    private static final ExecutorService POOL = Executors.newFixedThreadPool(6);

    // FIFO Cache — thread-safe via Collections.synchronizedMap
    private static final Map<String, JSONObject> CACHE =
            Collections.synchronizedMap(
                new LinkedHashMap<String, JSONObject>(CACHE_SIZE + 1, 0.75f, false) {
                    @Override
                    protected boolean removeEldestEntry(Map.Entry<String, JSONObject> eldest) {
                        return size() > CACHE_SIZE;
                    }
                });

    // ─────────────────────────────────────────────────────────────────
    //  Interfaces
    // ─────────────────────────────────────────────────────────────────

    /** يُستدعى على Main Thread عند اكتمال كل عمليات TMDB (أو timeout). */
    public interface ResolveAllCallback {
        void onAllResolved(List<ResolvedMention> results);
    }

    /** للاستخدام الفردي (خارج pipeline المحادثة). */
    public interface ResolveSingleCallback {
        void onResult(JSONObject tmdbData);
    }

    // ─────────────────────────────────────────────────────────────────
    //  Data Class
    // ─────────────────────────────────────────────────────────────────

    public static class ResolvedMention {
        public final EveResponseParser.RawMention source;
        public final JSONObject                   tmdbData;

        public ResolvedMention(EveResponseParser.RawMention source, JSONObject tmdbData) {
            this.source   = source;
            this.tmdbData = tmdbData;
        }
    }

    // ─────────────────────────────────────────────────────────────────
    //  Public API — Async resolution
    // ─────────────────────────────────────────────────────────────────

    /**
     * يُحلّل جميع mentions بشكل متوازٍ بدون حجب IO thread.
     *
     * Callback يُطلَق على Main Thread عند:
     *  (أ) اكتمال جميع TMDB calls، أو
     *  (ب) مرور TIMEOUT_MS ثانية — مع النتائج الجزئية المتوفرة
     *
     * @param mentions    قائمة الـ mentions من EveResponseParser
     * @param callback    يُستدعى مرة واحدة فقط (AtomicBoolean يمنع double-fire)
     * @param mainHandler Handler للـ Main Thread
     */
    public static void resolveAll(
            final List<EveResponseParser.RawMention> mentions,
            final ResolveAllCallback callback,
            final Handler mainHandler) {

        if (mentions == null || mentions.isEmpty()) {
            mainHandler.post(() -> callback.onAllResolved(new ArrayList<>()));
            return;
        }

        final int                         total   = mentions.size();
        final AtomicInteger               pending = new AtomicInteger(total);
        final AtomicBoolean               fired   = new AtomicBoolean(false);
        final List<ResolvedMention>       results =
                Collections.synchronizedList(new ArrayList<>());

        // Safety timeout — يُطلق callback بعد TIMEOUT_MS إن لم تكتمل المهام
        mainHandler.postDelayed(() -> {
            if (fired.compareAndSet(false, true)) {
                List<ResolvedMention> partial = sortByOriginalOrder(
                        new ArrayList<>(results), mentions);
                callback.onAllResolved(partial);
            }
        }, TIMEOUT_MS);

        // تشغيل كل TMDB call على POOL منفصل (لا يحجب IO thread الرئيسي)
        for (final EveResponseParser.RawMention mention : mentions) {
            POOL.submit(() -> {
                try {
                    JSONObject data = resolve(mention.title, mention.mediaType);
                    if (data != null) {
                        results.add(new ResolvedMention(mention, data));
                    }
                } catch (Exception ignored) {
                } finally {
                    // عند اكتمال آخر مهمة: أطلق callback (إذا لم يُطلقه timeout بعد)
                    if (pending.decrementAndGet() == 0 && fired.compareAndSet(false, true)) {
                        // إلغاء timeout (لم يعد ضرورياً)
                        mainHandler.removeCallbacksAndMessages(null);
                        List<ResolvedMention> sorted = sortByOriginalOrder(
                                new ArrayList<>(results), mentions);
                        mainHandler.post(() -> callback.onAllResolved(sorted));
                    }
                }
            });
        }
    }

    /**
     * تحليل mention واحد — للاستخدام الخارجي (e.g. من تفاصيل الفيلم).
     */
    public static void resolveOne(
            final String title,
            final String mediaType,
            final Handler mainHandler,
            final ResolveSingleCallback callback) {
        POOL.submit(() -> {
            JSONObject result = resolve(title, mediaType);
            mainHandler.post(() -> callback.onResult(result));
        });
    }

    public static void clearCache() {
        CACHE.clear();
    }

    public static void shutdown() {
        POOL.shutdown();
    }

    // ─────────────────────────────────────────────────────────────────
    //  Core Resolution Logic
    // ─────────────────────────────────────────────────────────────────

    private static JSONObject resolve(String title, String mediaType) {
        if (title == null || title.trim().isEmpty()) return null;
        String key = mediaType + ":" + title.toLowerCase(Locale.US).trim();

        // Cache check
        JSONObject cached = CACHE.get(key);
        if (cached != null) return cached;

        // Multi-search first (أكثر دقة), ثم direct search كـ fallback
        JSONObject result = searchMulti(title, mediaType);
        if (result == null) result = searchDirect(title, mediaType);

        if (result != null) CACHE.put(key, result);
        return result;
    }

    /**
     * /search/multi — يبحث في جميع الأنواع ويختار بالنقاط.
     *
     * نظام النقاط:
     *  1000 = تطابق تام         "Kingdom" ↔ "Kingdom"
     *   800 = يبدأ بـ           "Kingdom" ↔ "Kingdom of Heaven"
     *   600 = ينتهي بـ          "Kingdom" ↔ "The Kingdom"
     *   400 = يحتوي             "Kingdom" ↔ "Animal Kingdom"
     *   300 = كل الكلمات موجودة
     *  + (10-position)*5 لكسر التعادل
     *  + 500 للأعمال اليابانية الأصل (Anime JP bonus)
     */
    private static JSONObject searchMulti(String title, String preferredType) {
        try {
            String encoded = java.net.URLEncoder.encode(title, "UTF-8");
            String url     = "https://api.themoviedb.org/3/search/multi"
                           + "?query=" + encoded + "&language=en-US&page=1";

            JSONArray results = fetchResults(url);
            if (results == null || results.length() == 0) return null;

            // نوع البحث: anime → tv (TMDB لا يُصنّف anime منفردًا)
            String targetType = "anime".equals(preferredType) ? "tv" : preferredType;

            JSONObject best      = null;
            int        bestScore = -1;

            for (int i = 0; i < Math.min(results.length(), 10); i++) {
                JSONObject item = results.optJSONObject(i);
                if (item == null) continue;
                if (!targetType.equals(item.optString("media_type", ""))) continue;

                String name  = item.optString("title", item.optString("name", ""));
                int    score = titleScore(title, name) + (10 - i) * 5;

                // Anime JP bonus: الياباني الأصل يُعطى أولوية عالية
                if ("anime".equals(preferredType)) {
                    JSONArray origins = item.optJSONArray("origin_country");
                    if (origins != null) {
                        for (int j = 0; j < origins.length(); j++) {
                            if ("JP".equals(origins.optString(j))) {
                                score += 500;
                                break;
                            }
                        }
                    }
                }

                if (score > bestScore) {
                    bestScore = score;
                    best      = item;
                }
            }

            if (best != null) {
                best.put("media_type", preferredType);
                return best;
            }

            // لا توجد نتيجة من النوع المطلوب → أفضل نتيجة مع نوعها الحقيقي
            JSONObject first = results.optJSONObject(0);
            if (first != null && "anime".equals(preferredType)
                    && "tv".equals(first.optString("media_type", ""))) {
                first.put("media_type", "anime");
            }
            return first;

        } catch (Exception e) { return null; }
    }

    /** /search/movie أو /search/tv — fallback إذا لم يُجدِ multi شيئاً. */
    private static JSONObject searchDirect(String title, String mediaType) {
        try {
            String encoded    = java.net.URLEncoder.encode(title, "UTF-8");
            String searchType = "anime".equals(mediaType) ? "tv" : mediaType;
            String url        = "https://api.themoviedb.org/3/search/" + searchType
                              + "?query=" + encoded + "&language=en-US&page=1";

            JSONArray results = fetchResults(url);
            if (results == null || results.length() == 0) return null;

            JSONObject best      = results.optJSONObject(0);
            int        bestScore = 0;

            for (int i = 0; i < Math.min(results.length(), 10); i++) {
                JSONObject item = results.optJSONObject(i);
                if (item == null) continue;
                String name  = item.optString("title", item.optString("name", ""));
                int    score = titleScore(title, name) + (10 - i) * 5;
                if (score > bestScore) { bestScore = score; best = item; }
            }

            if (best != null) best.put("media_type", mediaType);
            return best;

        } catch (Exception e) { return null; }
    }

    // ─────────────────────────────────────────────────────────────────
    //  Title Scoring
    // ─────────────────────────────────────────────────────────────────

    /**
     * حساب درجة تشابه العنوان مع نتيجة TMDB.
     *
     * Article normalization: "the/a/an" تُحذف قبل المقارنة
     *   "the kingdom" ↔ "kingdom" → تطابق تام (1000)
     *   لا "the kingdom" ↔ "the kingdom" فقط (600 بدون التطبيع)
     */
    static int titleScore(String query, String candidate) {
        if (query == null || candidate == null) return 0;
        String q = normalizeTitle(query);
        String c = normalizeTitle(candidate);
        if (q.isEmpty() || c.isEmpty()) return 0;

        if (c.equals(q))                                        return 1000;
        if (c.startsWith(q + " ") || c.startsWith(q + ":"))    return 800;
        if (c.endsWith(" " + q))                                return 600;
        if (c.contains(q))                                      return 400;

        // مطابقة على مستوى الكلمات
        String[] qw = q.split("\\s+");
        String[] cw = c.split("\\s+");
        int matched = 0;
        for (String qWord : qw) {
            for (String cWord : cw) {
                if (cWord.equals(qWord)) { matched++; break; }
            }
        }
        if (matched > 0 && matched == qw.length) return 300;
        return matched * 60;
    }

    /** يُزيل articles الإنجليزية ويُحوّل للأحرف الصغيرة للمقارنة. */
    private static String normalizeTitle(String t) {
        return t.toLowerCase(Locale.US)
                .replaceAll("^(the|a|an)\\s+", "")
                .trim();
    }

    // ─────────────────────────────────────────────────────────────────
    //  HTTP Helper
    // ─────────────────────────────────────────────────────────────────

    private static JSONArray fetchResults(String urlStr) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(urlStr).openConnection();
            TmdbAuthorization.apply(conn, TMDB_TOKEN);
            conn.setRequestProperty("Accept", "application/json");
            conn.setConnectTimeout(9000);
            conn.setReadTimeout(9000);

            if (conn.getResponseCode() != 200) return null;

            BufferedReader br = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();

            return new JSONObject(sb.toString()).optJSONArray("results");

        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    // ─────────────────────────────────────────────────────────────────
    //  Order Preservation
    // ─────────────────────────────────────────────────────────────────

    /**
     * يُعيد النتائج بنفس ترتيب mentions الأصلي.
     * مهم لعرض البطاقات بترتيب ذكرها في المحادثة.
     */
    private static List<ResolvedMention> sortByOriginalOrder(
            List<ResolvedMention> results,
            List<EveResponseParser.RawMention> original) {

        List<ResolvedMention> sorted = new ArrayList<>();
        for (EveResponseParser.RawMention src : original) {
            for (ResolvedMention r : results) {
                if (r.source.title.equalsIgnoreCase(src.title)
                        && r.source.mediaType.equals(src.mediaType)) {
                    sorted.add(r);
                    break;
                }
            }
        }
        return sorted;
    }
}

package com.eve.cinema.providercore;

import com.eve.cinema.playback.PlaybackMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * PlaybackProfileBuilder — ملف تشغيل لكل نوع عربي (خطة §5 الخطوة 5 و§12.4).
 *
 * القواعد الصلبة:
 *  - كل صف جودة يحمل مرشحين من النوع العربي نفسه فقط (قرار رقم 4).
 *  - لا دمج بين دبلجة وترجمة محروقة وترجمة خارجية، ولا بين حلقات مختلفة.
 *  - الواجهة تستلم QualitySummary فقط: بلا providerId ولا روابط (§4.2).
 *
 * Pure Java — unit-tested on the JVM.
 */
public final class PlaybackProfileBuilder {

    /** ملف نوع واحد: جودة → مرشحون مرتبون. */
    public static final class ModeProfile {
        public final PlaybackMode mode;
        private final Map<Integer, List<NormalizedCandidate>> byQuality = new TreeMap<>();

        ModeProfile(PlaybackMode mode) { this.mode = mode; }

        /** جودات متاحة تصاعدياً، AUTO أخيراً إن وجد. */
        public List<Integer> qualities() {
            List<Integer> out = new ArrayList<>();
            Integer auto = null;
            for (Integer q : byQuality.keySet()) {
                if (q == NormalizedCandidate.QUALITY_AUTO) auto = q;
                else out.add(q);
            }
            if (auto != null) out.add(auto);
            return out;
        }

        public List<NormalizedCandidate> candidatesFor(int quality) {
            List<NormalizedCandidate> l = byQuality.get(quality);
            return l == null ? Collections.<NormalizedCandidate>emptyList()
                    : Collections.unmodifiableList(l);
        }

        /** بدائل مستقلة قدر الإمكان: مضيفو fallback مختلفون عن المختار. */
        public List<NormalizedCandidate> alternatesFor(int quality, String excludeHostKey) {
            List<NormalizedCandidate> out = new ArrayList<>();
            for (NormalizedCandidate c : candidatesFor(quality))
                if (excludeHostKey == null || !excludeHostKey.equals(c.hostKey()))
                    out.add(c);
            return out;
        }

        public boolean isEmpty() { return byQuality.isEmpty(); }
    }

    /** ملخص آمن للواجهة: أنواع + جودات فقط (لا مزوّد، لا رابط — §4.2). */
    public static final class QualitySummary {
        public final PlaybackMode mode;
        public final List<Integer> qualities;

        QualitySummary(PlaybackMode mode, List<Integer> qualities) {
            this.mode = mode;
            this.qualities = Collections.unmodifiableList(new ArrayList<>(qualities));
        }
    }

    public static final class PlaybackProfile {
        private final String mediaKey;
        private final EnumMap<PlaybackMode, ModeProfile> modes = new EnumMap<>(PlaybackMode.class);

        PlaybackProfile(String mediaKey) { this.mediaKey = mediaKey; }

        public String mediaKey() { return mediaKey; }

        public ModeProfile forMode(PlaybackMode mode) { return modes.get(mode); }

        /** الأنواع المثبتة فقط — مصدر أزرار الواجهة (بحد أقصى 3). */
        public List<PlaybackMode> availableModes() {
            List<PlaybackMode> out = new ArrayList<>();
            for (Map.Entry<PlaybackMode, ModeProfile> e : modes.entrySet())
                if (!e.getValue().isEmpty()) out.add(e.getKey());
            return out;
        }

        /** الملخصات الآمنة للواجهة. */
        public List<QualitySummary> uiSummaries() {
            List<QualitySummary> out = new ArrayList<>();
            for (PlaybackMode m : availableModes())
                out.add(new QualitySummary(m, modes.get(m).qualities()));
            return out;
        }
    }

    /**
     * يبني الملف من مرشحين مثبتين لهوية واحدة. أي مرشح غير VERIFIED_PLAYABLE
     * أو بدون دليل نوع VERIFIED أو من mediaKey مختلف يُستبعد بصمت.
     */
    public static PlaybackProfile build(String mediaKey, List<NormalizedCandidate> verified) {
        PlaybackProfile profile = new PlaybackProfile(mediaKey);
        if (verified == null) return profile;
        for (NormalizedCandidate c : verified) {
            if (c == null) continue;
            if (mediaKey != null && !mediaKey.equals(c.mediaKey())) continue; // حلقة أخرى
            if (c.validationStatus() != ProviderResultState.VERIFIED_PLAYABLE) continue;
            PlaybackMode mode = c.playbackMode();
            if (mode == null || !c.evidence().isVerified(mode)) continue; // لا زر بلا دليل

            ModeProfile mp = profile.modes.get(mode);
            if (mp == null) {
                mp = new ModeProfile(mode);
                profile.modes.put(mode, mp);
            }
            List<NormalizedCandidate> bucket = mp.byQuality.get(c.quality());
            if (bucket == null) {
                bucket = new ArrayList<>();
                mp.byQuality.put(c.quality(), bucket);
            }
            bucket.add(c);
        }
        return profile;
    }
}

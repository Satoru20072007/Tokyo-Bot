package com.eve.cinema;

import android.graphics.Bitmap;
import android.util.LruCache;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * TmdbCache — كاش بسيط بالـRAM لطلبات TMDB والصور.
 * يخزن نتائج الأقسام لمدة TTL ليُسرّع إعادة فتح الشاشة.
 */
public final class TmdbCache {

    private static final long DEFAULT_TTL_MS = 10 * 60 * 1000L; // 10 دقائق

    private static class Entry {
        final Object value;
        final long ts;
        Entry(Object v, long t) { this.value = v; this.ts = t; }
    }

    private static final java.util.concurrent.ConcurrentHashMap<String, Entry> JSON_CACHE
        = new java.util.concurrent.ConcurrentHashMap<>();

    // كاش صور (~ 1/8 من الذاكرة المتاحة)
    private static final LruCache<String, Bitmap> BMP_CACHE;
    static {
        int max = (int) (Runtime.getRuntime().maxMemory() / 1024); // KB
        int size = Math.max(8 * 1024, max / 8);
        BMP_CACHE = new LruCache<String, Bitmap>(size) {
            @Override protected int sizeOf(String key, Bitmap value) {
                return value.getByteCount() / 1024;
            }
        };
    }

    private TmdbCache() {}

    public static JSONObject getJson(String url) {
        Entry e = JSON_CACHE.get(url);
        if (e == null) return null;
        if (System.currentTimeMillis() - e.ts > DEFAULT_TTL_MS) {
            JSON_CACHE.remove(url);
            return null;
        }
        return (e.value instanceof JSONObject) ? (JSONObject) e.value : null;
    }

    public static void putJson(String url, JSONObject obj) {
        if (url == null || obj == null) return;
        JSON_CACHE.put(url, new Entry(obj, System.currentTimeMillis()));
    }

    public static Bitmap getBitmap(String url) {
        if (url == null) return null;
        return BMP_CACHE.get(url);
    }

    public static void putBitmap(String url, Bitmap bmp) {
        if (url == null || bmp == null) return;
        BMP_CACHE.put(url, bmp);
    }

    public static void clearAll() {
        JSON_CACHE.clear();
        BMP_CACHE.evictAll();
    }
}

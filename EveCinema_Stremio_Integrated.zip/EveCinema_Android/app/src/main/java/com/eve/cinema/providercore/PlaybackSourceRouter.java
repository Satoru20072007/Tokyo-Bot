package com.eve.cinema.providercore;

import com.eve.cinema.playback.PlaybackMode;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * PlaybackSourceRouter — اختيار الرابط الداخلي للجودة المختارة وتجديده أو
 * استبداله عند الفشل (وحدة §4.1 وخطة §13.2 و§10.4).
 *
 *  - لا ينتقل لنوع عربي مختلف تلقائياً أبداً.
 *  - تجديد واحد لكل فشل مناسب ثم بديل لنفس النوع/الجودة.
 *  - generation guard: كل اختيار حلقة/جودة جديد يلغي نتائج قديمة، ونتيجة
 *    تحمل generation أقدم تُرفض (§13.4 — منع callback قديم).
 *
 * Pure Java — unit-tested on the JVM.
 */
public final class PlaybackSourceRouter {

    public interface Clock { long nowMillis(); }

    /** هامش أمان انتهاء الرابط قبل التجديد الاستباقي. */
    public static final long DEFAULT_STALE_MARGIN_MS = 60_000L;

    private final ProviderRegistry registry;
    private final Clock clock;
    private final long staleMarginMs;
    private final AtomicLong generation = new AtomicLong(0);

    public PlaybackSourceRouter(ProviderRegistry registry, Clock clock) {
        this.registry = registry;
        this.clock = clock == null ? System::currentTimeMillis : clock;
        this.staleMarginMs = DEFAULT_STALE_MARGIN_MS;
    }

    /** قرار التوجيه — ما يصل المشغّل. */
    public static final class Route {
        public final NormalizedCandidate candidate;
        public final long generation;
        /** true إن كان هذا الرابط جُدّد للتو. */
        public final boolean refreshed;

        Route(NormalizedCandidate c, long g, boolean refreshed) {
            this.candidate = c;
            this.generation = g;
            this.refreshed = refreshed;
        }

        /** صلاحية الاستخدام: جيل قديم = callback متأخر يُرمى (§13.4). */
        public boolean isCurrent(PlaybackSourceRouter router) {
            return router.currentGeneration() == generation;
        }
    }

    /** جيل جديد لكل تغيير حلقة/جودة متعمد. */
    public long newGeneration() { return generation.incrementAndGet(); }
    public long currentGeneration() { return generation.get(); }

    /**
     * أفضل مرشح للجودة المختارة ضمن النوع. يجدّد الرابط مرة واحدة إن كان
     * قديماً/قصير الصلاحية، ثم ينتقل لبديل من نفس الجودة (يفضّل مضيفاً
     * مستقلاً) إن فشل التجديد. لا خفض صامت للجودة هنا.
     */
    public Route route(PlaybackProfileBuilder.PlaybackProfile profile,
                       PlaybackMode mode, int quality, long gen) {
        if (profile == null || mode == null || gen != currentGeneration()) return null;
        PlaybackProfileBuilder.ModeProfile mp = profile.forMode(mode);
        if (mp == null) return null;

        List<NormalizedCandidate> bucket = mp.candidatesFor(quality);
        if (bucket.isEmpty() && quality != NormalizedCandidate.QUALITY_AUTO)
            bucket = mp.candidatesFor(NormalizedCandidate.QUALITY_AUTO);
        if (bucket.isEmpty()) return null;

        for (NormalizedCandidate c : bucket) {
            if (gen != currentGeneration()) return null;
            long now = clock.nowMillis();
            if (!c.linkStale(now, staleMarginMs))
                return new Route(c, gen, false);

            // رابط منتهٍ/قارب: محاولة تجديد واحدة لنفس المزوّد (§10.4).
            NormalizedCandidate fresh = tryRefresh(c);
            if (fresh != null && gen == currentGeneration())
                return new Route(fresh, gen, true);
        }
        return null; // نفد مرشحو هذه الجودة — القرار للواجهة، لا خفض صامت
    }

    /** بديل عند فشل تشغيل المرشح الحالي: نفس النوع والجودة، مضيف مختلف أولاً. */
    public Route alternate(PlaybackProfileBuilder.PlaybackProfile profile,
                           PlaybackMode mode, int quality,
                           NormalizedCandidate failed, long gen) {
        if (profile == null || mode == null || gen != currentGeneration()) return null;
        PlaybackProfileBuilder.ModeProfile mp = profile.forMode(mode);
        if (mp == null) return null;
        String failedHost = failed == null ? null : failed.hostKey();
        String failedId = failed == null ? null : failed.providerId();
        for (NormalizedCandidate c : mp.alternatesFor(quality, failedHost)) {
            if (failedId != null && failedId.equals(c.providerId())
                    && (failedHost == null || failedHost.equals(c.hostKey())))
                continue; // نفس المزوّد ونفس المضيف — لا فائدة متوقعة
            if (!c.linkStale(clock.nowMillis(), staleMarginMs))
                return new Route(c, gen, false);
            NormalizedCandidate fresh = tryRefresh(c);
            if (fresh != null && gen == currentGeneration())
                return new Route(fresh, gen, true);
        }
        return null;
    }

    private NormalizedCandidate tryRefresh(NormalizedCandidate stale) {
        ProviderRegistry reg = registry;
        if (reg == null) return null;
        ProviderAdapter adapter = findAdapter(stale.providerId());
        if (adapter == null) return null;
        try {
            NormalizedCandidate fresh = adapter.refresh(stale);
            if (fresh != null && fresh.hasUri()
                    && fresh.validationStatus() == ProviderResultState.VERIFIED_PLAYABLE)
                return fresh;
        } catch (InterruptedException ie) {
            Thread.currentThread().interrupt();
        } catch (Exception ignored) {
            // فشل التجديد — ينتقل الموجّه للبديل
        }
        return null;
    }

    private ProviderAdapter findAdapter(String providerId) {
        for (ProviderAdapter a : registry.wave1()) if (a.id().equals(providerId)) return a;
        for (ProviderAdapter a : registry.wave2()) if (a.id().equals(providerId)) return a;
        return null;
    }
}

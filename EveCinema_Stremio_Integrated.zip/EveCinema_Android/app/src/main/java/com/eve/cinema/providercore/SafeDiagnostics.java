package com.eve.cinema.providercore;

import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * SafeDiagnostics — سجل تشخيصي آمن (وحدة §4.1 وخطة §15.2 و§8.2).
 *
 *  - correlationId داخلي يربط البحث والتحقق والمشغّل.
 *  - عدادات تجميعية فقط: لا URL كامل، لا Cookie، لا توقيع، لا حساب.
 *  - أي نص يُمرَّر يُنقّى من أنماط الأسرار الشائعة قبل الكتابة.
 *
 * Pure Java — unit-tested on the JVM. الوجهة الفعلية (DiagnosticsRecorder
 * الموجود) تُحقن عبر Sink.
 */
public final class SafeDiagnostics {

    /** وجهة الكتابة — تُربط بـ DiagnosticsRecorder داخل التطبيق. */
    public interface Sink { void log(String safeLine); }

    private final Sink sink;
    private final AtomicLong correlationSeq = new AtomicLong(0);
    private final Map<String, AtomicLong> counters = new ConcurrentHashMap<>();

    public SafeDiagnostics(Sink sink) { this.sink = sink; }

    public String newCorrelationId() {
        return "c" + correlationSeq.incrementAndGet();
    }

    /** عدّادات §8.2 — مثل streamsReturned / placeholderRejected / manifestValid. */
    public void count(String key) {
        if (key == null) return;
        AtomicLong c = counters.get(key);
        if (c == null) {
            c = new AtomicLong(0);
            AtomicLong prev = counters.putIfAbsent(key, c);
            if (prev != null) c = prev;
        }
        c.incrementAndGet();
    }

    public long counter(String key) {
        AtomicLong c = counters.get(key);
        return c == null ? 0 : c.get();
    }

    /** سطر آمن: provider.probe id=cinemabox elapsed_ms=814 state=timeout */
    public void event(String correlationId, String name, String providerId,
                      ProviderResultState state, long elapsedMs) {
        write(String.format(Locale.US,
                "%s corr=%s provider=%s state=%s elapsed_ms=%d",
                safe(name), safe(correlationId), safe(providerId),
                state == null ? "unknown" : state.name().toLowerCase(Locale.US),
                Math.max(0, elapsedMs)));
    }

    /** سطر حر — يُنقّى إجبارياً من أنماط الأسرار قبل الكتابة. */
    public void line(String text) { write(redact(text)); }

    /** تنقية رموز موجزة (اسم حدث/مزوّد): بلا فراغات ولا محارف تحكم. */
    private static String safe(String token) {
        if (token == null) return "-";
        String s = token.replaceAll("[\\s\\p{Cntrl}]+", "_");
        return s.isEmpty() ? "-" : s;
    }

    private void write(String line) {
        if (sink != null && line != null) sink.log(line);
    }

    /**
     * تنقيح دفاعي: يحذف قيم query الموقعة وأنماط التوكن. لا يستبدل قاعدة
     * «لا تمرر الرابط أصلاً» — هو خط دفاع ثانٍ.
     */
    public static String redact(String input) {
        if (input == null) return null;
        String s = input;
        s = s.replaceAll("(?i)([?&])(sig|signature|token|policy|expires|key-pair-id|cookie|auth|password|session)[^\\s&]*", "$1[redacted]");
        s = s.replaceAll("(?i)https?://\\S+", "[url]");
        s = s.replaceAll("(?i)bearer\\s+\\S+", "bearer [redacted]");
        return s;
    }
}

package com.eve.cinema.providercore;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * CanonicalMediaIdentity — العقدة المرجعية لهوية العمل داخل Eve (خطة §9.1).
 *
 * يُبنى مرة واحدة من اختيار TMDB ويُمرر لكل ProviderAdapter. لا تُملأ
 * providerNativeIds بتخمينات: كل Adapter يسجّل معرّفه المحلي بعد أن يثبت
 * بحثُه/تفاصيلُه العلاقة مع هذا العنوان (قرار رقم 9).
 *
 * Pure Java, no Android deps — unit-tested on the JVM.
 */
public final class CanonicalMediaIdentity {

    public enum MediaType { MOVIE, SERIES }

    private final long tmdbId;
    private final String imdbId;           // nullable
    private final MediaType mediaType;
    private final String titleOriginal;
    private final List<String> titleAliases;
    private final int releaseYear;         // <=0 when unknown
    private final int seasonNumber;        // <=0 when not applicable
    private final int episodeNumber;       // <=0 when not applicable
    private final String episodeTitle;     // nullable
    private final Map<String, String> providerNativeIds;

    private CanonicalMediaIdentity(Builder b) {
        this.tmdbId = b.tmdbId;
        this.imdbId = emptyToNull(b.imdbId);
        this.mediaType = b.mediaType;
        this.titleOriginal = b.titleOriginal == null ? "" : b.titleOriginal.trim();
        this.titleAliases = Collections.unmodifiableList(new ArrayList<>(b.titleAliases));
        this.releaseYear = b.releaseYear;
        this.seasonNumber = b.seasonNumber;
        this.episodeNumber = b.episodeNumber;
        this.episodeTitle = emptyToNull(b.episodeTitle);
        this.providerNativeIds = Collections.unmodifiableMap(new LinkedHashMap<>(b.providerNativeIds));
    }

    private static String emptyToNull(String s) {
        return (s == null || s.trim().isEmpty()) ? null : s.trim();
    }

    public long tmdbId() { return tmdbId; }
    public String imdbId() { return imdbId; }
    public MediaType mediaType() { return mediaType; }
    public String titleOriginal() { return titleOriginal; }
    public List<String> titleAliases() { return titleAliases; }
    public int releaseYear() { return releaseYear; }
    public int seasonNumber() { return seasonNumber; }
    public int episodeNumber() { return episodeNumber; }
    public String episodeTitle() { return episodeTitle; }

    /** معرّف العمل لدى مزوّد بعينه، أو null إن لم يثبت بعد. */
    public String nativeIdFor(String providerId) {
        return providerId == null ? null : providerNativeIds.get(providerId);
    }

    public Map<String, String> providerNativeIds() { return providerNativeIds; }

    /** true عندما تُطلب حلقة محددة (مسلسل بموسم/حلقة موجبين). */
    public boolean isEpisodeRequest() {
        return mediaType == MediaType.SERIES && seasonNumber > 0 && episodeNumber > 0;
    }

    /**
     * مفتاح داخلي مستقر للسجلات والذاكرة المؤقتة — لا يحتوي أسراراً.
     * مثال: tmdb:12345:tv:S02E03
     */
    public String mediaKey() {
        String base = "tmdb:" + tmdbId + (mediaType == MediaType.MOVIE ? ":movie" : ":tv");
        return isEpisodeRequest()
                ? base + String.format(java.util.Locale.US, ":S%02dE%02d", seasonNumber, episodeNumber)
                : base;
    }

    /** نسخة جديدة تضيف معرّفاً أصلياً مثبتاً لمزوّد. */
    public CanonicalMediaIdentity withNativeId(String providerId, String nativeId) {
        if (providerId == null || providerId.trim().isEmpty()
                || nativeId == null || nativeId.trim().isEmpty()) return this;
        Builder b = toBuilder();
        b.providerNativeIds.put(providerId.trim(), nativeId.trim());
        return b.build();
    }

    public Builder toBuilder() {
        Builder b = new Builder(mediaType, titleOriginal);
        b.tmdbId = tmdbId;
        b.imdbId = imdbId;
        b.titleAliases.addAll(titleAliases);
        b.releaseYear = releaseYear;
        b.seasonNumber = seasonNumber;
        b.episodeNumber = episodeNumber;
        b.episodeTitle = episodeTitle;
        b.providerNativeIds.putAll(providerNativeIds);
        return b;
    }

    public static final class Builder {
        private long tmdbId;
        private String imdbId;
        private final MediaType mediaType;
        private final String titleOriginal;
        private final List<String> titleAliases = new ArrayList<>();
        private int releaseYear;
        private int seasonNumber;
        private int episodeNumber;
        private String episodeTitle;
        private final Map<String, String> providerNativeIds = new LinkedHashMap<>();

        public Builder(MediaType mediaType, String titleOriginal) {
            if (mediaType == null) throw new IllegalArgumentException("mediaType required");
            this.mediaType = mediaType;
            this.titleOriginal = titleOriginal;
        }

        public Builder tmdbId(long v) { this.tmdbId = v; return this; }
        public Builder imdbId(String v) { this.imdbId = v; return this; }
        public Builder alias(String v) { if (v != null && !v.trim().isEmpty()) this.titleAliases.add(v.trim()); return this; }
        public Builder releaseYear(int v) { this.releaseYear = v; return this; }
        public Builder episode(int season, int number) { this.seasonNumber = season; this.episodeNumber = number; return this; }
        public Builder episodeTitle(String v) { this.episodeTitle = v; return this; }
        public Builder nativeId(String providerId, String nativeId) {
            if (providerId != null && nativeId != null) this.providerNativeIds.put(providerId, nativeId);
            return this;
        }

        public CanonicalMediaIdentity build() {
            if (mediaType == MediaType.SERIES && (seasonNumber > 0) != (episodeNumber > 0))
                throw new IllegalStateException("season and episode must be set together");
            return new CanonicalMediaIdentity(this);
        }
    }
}

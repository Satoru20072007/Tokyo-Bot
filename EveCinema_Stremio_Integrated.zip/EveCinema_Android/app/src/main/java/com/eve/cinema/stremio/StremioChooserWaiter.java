package com.eve.cinema.stremio;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

/**
 * Keeps the source chooser closed while the first useful batch is being gathered. The short
 * bounded wait makes the usual case open with a ready list, without trapping the user when an
 * add-on is slow or offline. Subtitle lookup can continue in the background after the chooser opens.
 */
public final class StremioChooserWaiter {
    private StremioChooserWaiter() { }

    public interface Ticket { void cancel(); }

    public static Ticket waitForReady(final StremioChooserSession.Entry entry,
                                      final long minimumWaitMs, final long maximumWaitMs,
                                      final Runnable onReady) {
        final Handler main = new Handler(Looper.getMainLooper());
        final long started = SystemClock.elapsedRealtime();
        final Object gate = new Object();
        final boolean[] completed = {false};
        final Runnable[] checker = new Runnable[1];
        final StremioChooserSession.Listener[] listener = new StremioChooserSession.Listener[1];

        final Ticket ticket = new Ticket() {
            @Override public void cancel() {
                synchronized (gate) {
                    if (completed[0]) return;
                    completed[0] = true;
                }
                main.removeCallbacks(checker[0]);
                entry.removeListener(listener[0]);
            }
        };

        Runnable finish = new Runnable() {
            @Override public void run() {
                synchronized (gate) {
                    if (completed[0]) return;
                    completed[0] = true;
                }
                main.removeCallbacks(checker[0]);
                entry.removeListener(listener[0]);
                if (onReady != null) onReady.run();
            }
        };

        checker[0] = new Runnable() {
            @Override public void run() {
                synchronized (gate) { if (completed[0]) return; }
                long elapsed = SystemClock.elapsedRealtime() - started;
                StremioChooserData snapshot = entry.data();
                StremioChooserData.Progress p = snapshot.progress;
                boolean streamsSettled = p.addonsTotal > 0 && p.addonsFinished >= p.addonsTotal;
                // Prefer a list whose current speed samples have settled. The hard time cap below
                // prevents a broken source from trapping the user in the resolving overlay.
                boolean listReady = !snapshot.options.isEmpty() && streamsSettled && !p.measuring;
                boolean terminal = snapshot.isFinal();
                if (elapsed >= minimumWaitMs && (listReady || terminal)) {
                    finish.run();
                    return;
                }
                if (elapsed >= maximumWaitMs) {
                    finish.run();
                    return;
                }
                main.postDelayed(this, 160L);
            }
        };
        listener[0] = new StremioChooserSession.Listener() {
            @Override public void onData(StremioChooserData ignored) { main.post(checker[0]); }
        };
        entry.addListener(listener[0]);
        main.post(checker[0]);
        return ticket;
    }
}

package com.eve.cinema;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Eve v6 — Memory System
 *
 * يُحسّن: mergeAndTrim() في EveMemoryDb بمنطق أذكى
 *
 * الفرق الجوهري مع v5:
 *
 *  v5 — mergeAndTrim:
 *   • يُلحق الجديد في النهاية + يحذف الأقدم عند تجاوز الحد
 *   • "رعب" المذكور مرة = "رعب" المذكور 10 مرات (وزن متساوٍ)
 *   • لا decay → تفضيل من سنة ماضية يبقى بنفس الأهمية
 *
 *  v6 — smartMerge:
 *   • العنصر المذكور مجدداً يُرفع إلى الأمام (Frequency boost)
 *   • يُقلّص القائمة من الأقل ذكراً (في النهاية)
 *   • لا يخترع ولا يُكرر
 *
 * ملاحظة الـ Decay:
 *   Decay حقيقي يتطلب حفظ timestamps لكل preference في SQLite.
 *   هذا يحتاج migration لـ DB schema. لتبقى الامور بسيطة في الإنتاج،
 *   نُطبّق "soft decay" عبر smartMerge: العناصر القديمة غير المُعادة ذكرها
 *   تنزلق إلى نهاية القائمة وتُحذف تدريجياً عند تجاوز الحد الأقصى.
 *   هذا يحاكي decay بدون تعقيد DB.
 */
public class EveMemorySystem {

    // ─────────────────────────────────────────────────────────────────
    //  smartMerge — يستبدل db.mergeAndTrim في updateDnaAsync
    // ─────────────────────────────────────────────────────────────────

    /**
     * يدمج قيمة جديدة مع الموجودة بمنطق frequency-boost.
     *
     * الخوارزمية:
     *  1. اقرأ العناصر الحالية كقائمة مُرتّبة (الأهم أولاً)
     *  2. للكل عنصر جديد:
     *     - إذا كان موجوداً → ارفعه للأمام (يُذكر مجدداً = مهم)
     *     - إذا كان جديداً → أضفه في النهاية
     *  3. اقطع عند maxItems
     *
     * @param current  القيمة الحالية (CSV عربي مفصول بفاصلة)
     * @param incoming القيمة الجديدة من تحليل LLM
     * @param maxItems الحد الأقصى للعناصر
     * @return القيمة المدمجة مع frequency boost
     */
    public static String smartMerge(String current, String incoming, int maxItems) {
        if (incoming == null || incoming.trim().isEmpty()) {
            return current != null ? current.trim() : "";
        }
        if (current == null || current.trim().isEmpty()) {
            return trimTo(incoming, maxItems);
        }

        List<String> currentList  = splitCSV(current);
        List<String> incomingList = splitCSV(incoming);

        // القائمة النتيجة — تبدأ فارغة وتُملأ بترتيب الأهمية
        List<String> result = new ArrayList<>();

        // الخطوة 1: العناصر الجديدة المُكرَّرة تُرفع للأمام
        for (String item : incomingList) {
            if (containsIgnoreCase(currentList, item)) {
                if (!containsIgnoreCase(result, item)) {
                    result.add(0, normalizeItem(item)); // رفع للأمام
                }
            }
        }

        // الخطوة 2: العناصر الحالية غير المُكرَّرة تحتفظ بترتيبها
        for (String item : currentList) {
            if (!containsIgnoreCase(result, item)) {
                result.add(normalizeItem(item));
            }
        }

        // الخطوة 3: العناصر الجديدة التي لم تكن موجودة تُضاف في النهاية
        for (String item : incomingList) {
            if (!containsIgnoreCase(currentList, item)
                    && !containsIgnoreCase(result, item)) {
                result.add(normalizeItem(item));
            }
        }

        // الخطوة 4: قطع عند الحد الأقصى (يحذف الأقل أهمية في النهاية)
        if (result.size() > maxItems) {
            result = result.subList(0, maxItems);
        }

        return joinCSV(result);
    }

    // ─────────────────────────────────────────────────────────────────
    //  mergeFromJson — يُطبّق smartMerge على JSONObject كامل من LLM
    // ─────────────────────────────────────────────────────────────────

    /**
     * يدمج نتيجة JSON من DNA_SYSTEM مع UserDna الموجودة.
     * يستخدم smartMerge لكل حقل.
     *
     * @param existing الـ DNA الحالية من SQLite
     * @param update   JSON من تحليل LLM
     * @return الـ DNA المحدَّثة (نفس الكائن، مُعدَّل in-place)
     */
    public static EveMemoryDb.UserDna mergeFromJson(
            EveMemoryDb.UserDna existing,
            JSONObject update) {

        if (update == null || existing == null) return existing;

        String newGenreLikes    = update.optString("genre_likes",       "").trim();
        String newGenreDislikes = update.optString("genre_dislikes",    "").trim();
        String newDirectors     = update.optString("fav_directors",     "").trim();
        String newActors        = update.optString("fav_actors",        "").trim();
        String newMoodTags      = update.optString("mood_tags",         "").trim();
        String newDecade        = update.optString("fav_decade",        "").trim();
        String newPattern       = update.optString("emotional_pattern", "").trim();
        String newSummary       = update.optString("summary",           "").trim();

        // smartMerge مع الحدود القصوى لكل حقل
        if (!newGenreLikes.isEmpty())
            existing.genreLikes    = smartMerge(existing.genreLikes,    newGenreLikes,    5);
        if (!newGenreDislikes.isEmpty())
            existing.genreDislikes = smartMerge(existing.genreDislikes, newGenreDislikes, 5);
        if (!newDirectors.isEmpty())
            existing.favDirectors  = smartMerge(existing.favDirectors,  newDirectors,     5);
        if (!newActors.isEmpty())
            existing.favActors     = smartMerge(existing.favActors,     newActors,        5);
        if (!newMoodTags.isEmpty())
            existing.moodTags      = smartMerge(existing.moodTags,      newMoodTags,      6);
        if (!newDecade.isEmpty())
            existing.favDecade     = smartMerge(existing.favDecade,     newDecade,        3);

        // الحقول النصية الأحادية: الأحدث يُحل محل القديم فقط إذا كان غير فارغ
        if (!newPattern.isEmpty()) existing.emotionalPattern = newPattern;
        if (!newSummary.isEmpty()) existing.summary          = newSummary;

        return existing;
    }

    // ─────────────────────────────────────────────────────────────────
    //  Private helpers
    // ─────────────────────────────────────────────────────────────────

    private static List<String> splitCSV(String csv) {
        List<String> list = new ArrayList<>();
        if (csv == null || csv.trim().isEmpty()) return list;
        for (String part : csv.split("[,،]")) {
            String t = part.trim();
            if (!t.isEmpty()) list.add(t);
        }
        return list;
    }

    private static String joinCSV(List<String> items) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < items.size(); i++) {
            if (i > 0) sb.append("، ");
            sb.append(items.get(i));
        }
        return sb.toString();
    }

    private static String trimTo(String csv, int maxItems) {
        List<String> items = splitCSV(csv);
        if (items.size() <= maxItems) return csv.trim();
        return joinCSV(items.subList(0, maxItems));
    }

    private static boolean containsIgnoreCase(List<String> list, String item) {
        if (item == null) return false;
        String norm = item.trim().toLowerCase();
        for (String s : list) {
            if (s.trim().toLowerCase().equals(norm)) return true;
        }
        return false;
    }

    /** يُوحّد شكل العنصر: يُزيل الفراغات الزائدة فقط */
    private static String normalizeItem(String item) {
        return item == null ? "" : item.trim();
    }
}

package com.eve.cinema.providercore;

import com.eve.cinema.playback.ProbeOutcome;
import com.eve.cinema.playback.ProviderGate;
import java.util.HashMap;
import java.util.Map;

/**
 * ProviderHealthStore — تعميم ProviderGate الحالي لكل providerId ولكل عائلة
 * مضيف (خطة §6.4 و§10.3 ووحدة §4.1).
 *
 *  - قاطع كل مصدر مستقل؛ فشل مصدر لا يعطّل غيره (قرار رقم 6).
 *  - سجل صحة لكل hostKey حتى لا يُعامَل مزوّدان يتشاركان CDN واحداً
 *    كمستقلَّين كاملَين.
 *  - الإلغاء والإجابات السلبية القاطعة لا تفتح القواطع.
 *
 * Pure Java, clock-injectable — unit-tested on the JVM.
 */
public final class ProviderHealthStore {

    public interface Clock { long nowMillis(); }

    private final Clock clock;
    private final int failureThreshold;
    private final long openDurationMs;
    private final Map<String, ProviderGate> providerGates = new HashMap<>();
    private final Map<String, ProviderGate> hostGates = new HashMap<>();

    public ProviderHealthStore() {
        this(System::currentTimeMillis, 2, 120_000L);
    }

    public ProviderHealthStore(Clock clock, int failureThreshold, long openDurationMs) {
        this.clock = clock == null ? System::currentTimeMillis : clock;
        this.failureThreshold = Math.max(1, failureThreshold);
        this.openDurationMs = Math.max(1L, openDurationMs);
    }

    private ProviderGate gateFor(Map<String, ProviderGate> map, String key) {
        ProviderGate g = map.get(key);
        if (g == null) {
            g = new ProviderGate(failureThreshold, openDurationMs, clock::nowMillis);
            map.put(key, g);
        }
        return g;
    }

    /** هل يُسمح بمحاولة شبكة لهذا المصدر الآن؟ */
    public synchronized boolean tryAcquireProvider(String providerId) {
        return gateFor(providerGates, providerId).tryAcquire();
    }

    /** هل يُسمح بمحاولة نحو عائلة المضيف؟ */
    public synchronized boolean tryAcquireHost(String hostKey) {
        if (hostKey == null || hostKey.isEmpty()) return true;
        return gateFor(hostGates, hostKey).tryAcquire();
    }

    /** تسجيل نتيجة مصنّفة — لا تستدعِه إلا بما أنتجه الفحص فعلاً. */
    public synchronized void recordProvider(String providerId, ProviderResultState state) {
        if (state == null || state == ProviderResultState.CANCELLED) return;
        gateFor(providerGates, providerId).record(toOutcome(state));
    }

    public synchronized void recordHost(String hostKey, ProviderResultState state) {
        if (hostKey == null || hostKey.isEmpty()) return;
        if (state == null || state == ProviderResultState.CANCELLED) return;
        gateFor(hostGates, hostKey).record(toOutcome(state));
    }

    /** يمسح حالة قاطع مزود واحد بعد تدوير بيانات اعتماده. */
    public synchronized void reset(String providerId) {
        if (providerId != null && !providerId.isEmpty()) providerGates.remove(providerId);
    }

    private static ProbeOutcome toOutcome(ProviderResultState state) {
        return state.countsAgainstHealth()
                ? ProbeOutcome.UNRESOLVED_TRANSIENT
                : (state.isDefinitive() ? ProbeOutcome.VERIFIED : ProbeOutcome.NOT_FOUND_DEFINITIVE);
    }

    public synchronized ProviderGate.State providerState(String providerId) {
        ProviderGate g = providerGates.get(providerId);
        return g == null ? ProviderGate.State.CLOSED : g.state();
    }

    public synchronized ProviderGate.State hostState(String hostKey) {
        ProviderGate g = hostGates.get(hostKey);
        return g == null ? ProviderGate.State.CLOSED : g.state();
    }
}

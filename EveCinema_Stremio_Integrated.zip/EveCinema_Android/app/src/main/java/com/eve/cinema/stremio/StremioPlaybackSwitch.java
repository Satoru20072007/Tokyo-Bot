package com.eve.cinema.stremio;

/**
 * Rules for changing the stream (quality / source) while a Stremio title is playing.
 * Pure decisions only; the player applies them.
 *
 * <ul>
 *   <li>The playback position and the play/pause intent are carried over to the new stream.</li>
 *   <li>A subtitle is carried over ONLY when it is still proven to belong to the new file: the new
 *       stream is the same file (shared strong key), or the subtitle is an exact match for it. A subtitle
 *       that was merely "unverified" for the old file is not assumed to fit a different release.</li>
 * </ul>
 */
public final class StremioPlaybackSwitch {
    private StremioPlaybackSwitch() {}

    public enum SubtitleDecision {
        /** No subtitle was active. */
        NONE,
        /** Still valid for the new stream. */
        KEEP,
        /** Not provably valid for the new stream: turn it off and ask the user again. */
        DROP
    }

    public static final class Plan {
        public final long positionMs;
        public final boolean playWhenReady;
        public final SubtitleDecision subtitle;
        Plan(long positionMs, boolean playWhenReady, SubtitleDecision subtitle) {
            this.positionMs = positionMs;
            this.playWhenReady = playWhenReady;
            this.subtitle = subtitle;
        }
    }

    public static Plan plan(StremioChooserData data, StremioStreamOption from, StremioStreamOption to,
                            StremioSubtitle activeSubtitle, long positionMs, boolean playWhenReady) {
        return new Plan(Math.max(0L, positionMs), playWhenReady, decideSubtitle(data, from, to, activeSubtitle));
    }

    public static SubtitleDecision decideSubtitle(StremioChooserData data, StremioStreamOption from,
                                                  StremioStreamOption to, StremioSubtitle activeSubtitle) {
        if (activeSubtitle == null) return SubtitleDecision.NONE;
        if (to == null) return SubtitleDecision.DROP;
        if (from != null && from.sameFileAs(to)) return SubtitleDecision.KEEP;
        if (data != null && data.match(activeSubtitle, to) == StremioChooserData.Match.EXACT)
            return SubtitleDecision.KEEP;
        return SubtitleDecision.DROP;
    }
}

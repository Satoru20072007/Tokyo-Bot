package com.eve.cinema.stremio;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Parsed, capability-aware view of a Stremio add-on manifest.
 *
 * <p>Contract notes (Stremio add-on SDK docs and stremio-core types, checked 2026-10-27):
 * the manifest-level {@code types} and {@code idPrefixes} apply to every resource declared as a
 * plain string. For a resource OBJECT that omits its own {@code types}/{@code idPrefixes}, stremio-core
 * falls back to the manifest-level values while the SDK text says an omitted {@code idPrefixes} means
 * "all ids"; this parser takes the conservative reading (inherit), which can only make the app skip an
 * add-on for an id form it might have accepted, never send an id the manifest ruled out.
 * A resource's own values win when present. {@code catalogs} is listed as required by the SDK docs
 * but defaults to [] in the reference client, so a missing array is tolerated.
 */
public final class StremioManifest {
    public static final String MANIFEST = "manifest";
    public static final String CATALOG = "catalog";
    public static final String META = "meta";
    public static final String STREAM = "stream";
    public static final String SUBTITLES = "subtitles";
    private static final Set<String> KNOWN = new LinkedHashSet<>();
    static {
        KNOWN.add(MANIFEST); KNOWN.add(CATALOG); KNOWN.add(META);
        KNOWN.add(STREAM); KNOWN.add(SUBTITLES);
    }

    /** One declared resource with its EFFECTIVE types and id prefixes (fallbacks already applied). */
    public static final class Resource {
        public final String name;
        public final Set<String> types;
        public final List<String> idPrefixes;
        Resource(String name, Set<String> types, List<String> idPrefixes) {
            this.name = name;
            this.types = Collections.unmodifiableSet(types);
            this.idPrefixes = Collections.unmodifiableList(idPrefixes);
        }
        public boolean accepts(String type, String id) {
            if (!types.isEmpty() && !types.contains(type)) return false;
            if (idPrefixes.isEmpty()) return true;
            if (id == null) return false;
            for (String prefix : idPrefixes) if (id.startsWith(prefix)) return true;
            return false;
        }
    }

    private final JSONObject raw;
    public final String id, name, version, description;
    public final List<String> types;
    /** Manifest-level {@code idPrefixes}; empty when the add-on accepts every id. */
    public final List<String> idPrefixes;
    public final List<Resource> resources;
    public final List<JSONObject> catalogs;
    public final boolean configurationRequired;

    private StremioManifest(JSONObject raw, String id, String name, String version,
                            String description, List<String> types, List<String> idPrefixes,
                            List<Resource> resources, List<JSONObject> catalogs,
                            boolean configurationRequired) {
        this.raw = raw;
        this.id = id; this.name = name; this.version = version;
        this.description = description;
        this.types = Collections.unmodifiableList(types);
        this.idPrefixes = Collections.unmodifiableList(idPrefixes);
        this.resources = Collections.unmodifiableList(resources);
        this.catalogs = Collections.unmodifiableList(catalogs);
        this.configurationRequired = configurationRequired;
    }

    public JSONObject raw() {
        try { return new JSONObject(raw.toString()); }
        catch (JSONException ex) {
            throw new IllegalStateException("Stored manifest JSON could not be copied", ex);
        }
    }

    public static StremioManifest parse(JSONObject json) throws JSONException {
        if (json == null) throw new JSONException("Missing manifest");
        String id = requiredString(json, "id", 200);
        String name = requiredString(json, "name", 200);
        String version = requiredString(json, "version", 64);
        String description = requiredString(json, "description", 2000);
        if (!id.matches("[A-Za-z0-9._:@+~-]+") || !version.matches("[A-Za-z0-9][A-Za-z0-9.+_-]*"))
            throw new JSONException("Invalid manifest identity or version");
        List<String> types = strings(json.optJSONArray("types"), true, 100);
        if (types.isEmpty()) throw new JSONException("Manifest has no supported types");
        List<String> globalPrefixes = strings(json.optJSONArray("idPrefixes"), false, 100);

        JSONArray rawResources = json.optJSONArray("resources");
        if (rawResources == null || rawResources.length() == 0 || rawResources.length() > 64)
            throw new JSONException("Manifest has no resources");
        List<Resource> resources = new ArrayList<>();
        Set<String> duplicateGuard = new LinkedHashSet<>();
        for (int i = 0; i < rawResources.length(); i++) {
            Object item = rawResources.get(i);
            String resourceName;
            Set<String> resourceTypes = new LinkedHashSet<>();
            List<String> prefixes = new ArrayList<>();
            try {
                if (item instanceof String) {
                    resourceName = (String) item;
                } else if (item instanceof JSONObject) {
                    JSONObject obj = (JSONObject) item;
                    resourceName = requiredString(obj, "name", 64);
                    resourceTypes.addAll(strings(obj.optJSONArray("types"), false, 100));
                    prefixes.addAll(strings(obj.optJSONArray("idPrefixes"), false, 100));
                } else {
                    continue;                                   // unknown shape: skip this entry only
                }
            } catch (JSONException invalidEntry) {
                continue;
            }
            if (resourceName == null || resourceName.trim().isEmpty() || resourceName.length() > 64) continue;
            if (resourceTypes.isEmpty()) resourceTypes.addAll(types);      // fall back to the manifest's types
            if (prefixes.isEmpty()) prefixes.addAll(globalPrefixes);       // ...and to the manifest's idPrefixes
            if (!duplicateGuard.add(resourceName + "|" + resourceTypes + "|" + prefixes)) continue;
            resources.add(new Resource(resourceName, resourceTypes, prefixes));
        }
        if (resources.isEmpty()) throw new JSONException("Manifest has no resources");

        // The SDK docs list `catalogs` as required, but the reference client (stremio-core) defaults it
        // to []; this app only consumes stream/subtitles, so a missing array costs nothing.
        JSONArray rawCatalogs = json.optJSONArray("catalogs");
        if (rawCatalogs != null && rawCatalogs.length() > 200) throw new JSONException("Too many catalogs");
        List<JSONObject> catalogs = new ArrayList<>();
        for (int i = 0; rawCatalogs != null && i < rawCatalogs.length(); i++) {
            Object value = rawCatalogs.get(i);
            if (!(value instanceof JSONObject)) continue;       // a bad catalog never invalidates stream add-ons
            JSONObject catalog = (JSONObject) value;
            try {
                requiredString(catalog, "type", 100);
                requiredString(catalog, "id", 200);
            } catch (JSONException invalidCatalog) {
                continue;
            }
            catalogs.add(new JSONObject(value.toString()));
        }
        JSONObject hints = json.optJSONObject("behaviorHints");
        boolean configRequired = hints != null && hints.optBoolean("configurationRequired", false);
        return new StremioManifest(json, id, name, version, description,
                types, globalPrefixes, resources, catalogs, configRequired);
    }

    public boolean supports(String resource, String type, String id) {
        if (!KNOWN.contains(resource) || type == null) return false;
        if (CATALOG.equals(resource)) {
            if (id == null) return false;
            for (JSONObject catalog : catalogs) {
                if (!type.equals(catalog.optString("type")) || !id.equals(catalog.optString("id"))) continue;
                for (Resource declared : resources) {
                    // Catalog ids are the manifest's own catalog ids; idPrefixes do not apply to catalogs.
                    if (CATALOG.equals(declared.name)
                            && (declared.types.isEmpty() || declared.types.contains(type))) return true;
                }
            }
            return false;
        }
        for (Resource r : resources) {
            if (resource.equals(r.name) && r.accepts(type, id)) return true;
        }
        return false;
    }

    /** True when at least one of {@code ids} is accepted for the resource (capability probing). */
    public boolean supportsAny(String resource, String type, List<String> ids) {
        for (String candidate : ids) if (supports(resource, type, candidate)) return true;
        return false;
    }

    public List<String> resourceNames() {
        List<String> out = new ArrayList<>();
        out.add(MANIFEST);
        for (Resource resource : resources) if (!out.contains(resource.name)) out.add(resource.name);
        return Collections.unmodifiableList(out);
    }

    /**
     * Validates {@code provided} against the catalog's declared {@code extra} rules (modern
     * {@code extra[]} or legacy {@code extraSupported}/{@code extraRequired}): undeclared names are
     * dropped, a required name without a value or a value outside {@code options} makes the request
     * unsupported. Nothing is ever invented.
     */
    public Map<String, String> sanitizeCatalogExtras(String type, String catalogId,
                                                      Map<String, String> provided) throws StremioException {
        JSONObject catalog = null;
        for (JSONObject candidate : catalogs) {
            if (type.equals(candidate.optString("type")) && catalogId.equals(candidate.optString("id"))) {
                catalog = candidate;
                break;
            }
        }
        if (catalog == null) throw new StremioException(StremioException.Kind.UNSUPPORTED);
        Map<String, Boolean> required = new LinkedHashMap<>();
        Map<String, Set<String>> options = new LinkedHashMap<>();
        JSONArray extra = catalog.optJSONArray("extra");
        if (extra != null) {
            for (int i = 0; i < extra.length(); i++) {
                JSONObject entry = extra.optJSONObject(i);
                if (entry == null || entry.isNull("name")) continue;
                String name = entry.optString("name", "");
                if (name.isEmpty()) continue;
                required.put(name, entry.optBoolean("isRequired", false));
                JSONArray allowed = entry.optJSONArray("options");
                if (allowed != null && allowed.length() > 0) {
                    Set<String> set = new LinkedHashSet<>();
                    for (int j = 0; j < allowed.length(); j++) if (!allowed.isNull(j)) set.add(allowed.optString(j, ""));
                    options.put(name, set);
                }
            }
        } else {
            JSONArray supported = catalog.optJSONArray("extraSupported");
            JSONArray mandatory = catalog.optJSONArray("extraRequired");
            if (supported != null)
                for (int i = 0; i < supported.length(); i++) if (!supported.isNull(i)) required.put(supported.optString(i, ""), false);
            if (mandatory != null)
                for (int i = 0; i < mandatory.length(); i++) if (!mandatory.isNull(i)) required.put(mandatory.optString(i, ""), true);
        }
        Map<String, String> out = new LinkedHashMap<>();
        for (Map.Entry<String, Boolean> declared : required.entrySet()) {
            String value = provided == null ? null : provided.get(declared.getKey());
            boolean has = value != null && !value.isEmpty();
            if (!has) {
                if (declared.getValue()) throw new StremioException(StremioException.Kind.UNSUPPORTED);
                continue;
            }
            Set<String> allowed = options.get(declared.getKey());
            if (allowed != null && !allowed.contains(value)) throw new StremioException(StremioException.Kind.UNSUPPORTED);
            out.put(declared.getKey(), value);
        }
        return out;
    }

    private static String requiredString(JSONObject json, String key, int max) throws JSONException {
        if (json.isNull(key)) throw new JSONException("Invalid " + key);
        String value = json.optString(key, "").trim();
        if (value.isEmpty() || value.length() > max) throw new JSONException("Invalid " + key);
        return value;
    }

    private static List<String> strings(JSONArray array, boolean required, int max) throws JSONException {
        List<String> out = new ArrayList<>();
        if (array == null) {
            if (required) throw new JSONException("Missing array");
            return out;
        }
        if (array.length() > max) throw new JSONException("Array too large");
        for (int i = 0; i < array.length(); i++) {
            if (array.isNull(i)) throw new JSONException("Invalid array value");
            String value = array.optString(i, "").trim();
            if (value.isEmpty() || value.length() > 256) throw new JSONException("Invalid array value");
            if (!out.contains(value)) out.add(value);
        }
        return out;
    }
}

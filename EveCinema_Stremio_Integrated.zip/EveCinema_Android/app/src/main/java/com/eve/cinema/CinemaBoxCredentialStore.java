package com.eve.cinema;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * CinemaBoxCredentialStore — تخزين آمن لحساب CinemaBox (المحطة 0، الإجراء 2).
 *
 * كل مستخدم بحسابه (قرار خريطة الكنز): تُشفَّر القيم بمفتاح AES/GCM يعيش في
 * Android Keystore (لا يغادر الجهاز ولا يُصدَّر)، وتُحفظ الناتجة في
 * SharedPreferences خاصة. لا اعتماد على مكتبة خارجية ولا قيمة افتراضية.
 *
 *  - save(): تُستدعى من شاشة إدخال الحساب في الإعدادات.
 *  - loadIntoRuntime(): تُستدعى عند إقلاع التطبيق (Applications) وتغذّي
 *    CinemaBoxCredentials حتى يعمل CinemaBoxBridge.ensureLoggedIn كما كان.
 *  - clear(): إزالة الحساب (تسجيل خروج/تدوير) — تمسح التخزين والحامل معاً.
 *  - لا تُمرَّر القيم أبداً إلى السجلات أو التشخيص.
 */
public final class CinemaBoxCredentialStore {

    private static final String PREFS        = "eve_cinemabox_account";
    private static final String KEY_EMAIL    = "email_enc";
    private static final String KEY_PASSWORD = "password_enc";
    private static final String KEYSTORE     = "AndroidKeyStore";
    private static final String ALIAS        = "eve_cinemabox_key";
    private static final String TRANSFORM    = "AES/GCM/NoPadding";
    private static final int    GCM_TAG_BITS = 128;
    private static final int    GCM_IV_BYTES = 12;

    private CinemaBoxCredentialStore() {}

    public static synchronized boolean isStored(Context ctx) {
        SharedPreferences p = prefs(ctx);
        return p.getString(KEY_EMAIL, null) != null
                && p.getString(KEY_PASSWORD, null) != null;
    }

    /** يحفظ الحساب مشفّراً ويثبّته في الحامل فوراً. false عند فشل Keystore. */
    public static synchronized boolean save(Context ctx, String email, String password) {
        if (ctx == null || email == null || email.trim().isEmpty()
                || password == null || password.isEmpty()) return false;
        try {
            String encEmail = encrypt(email.trim());
            String encPassword = encrypt(password);
            prefs(ctx).edit()
                    .putString(KEY_EMAIL, encEmail)
                    .putString(KEY_PASSWORD, encPassword)
                    .apply();
            CinemaBoxCredentials.install(email, password);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * يقرأ المخزن ويثبّت الحامل. تُستدعى مرة عند إقلاع التطبيق.
     * @return true إن وُجد حساب وثُبّت بنجاح.
     */
    public static synchronized boolean loadIntoRuntime(Context ctx) {
        if (ctx != null && isStored(ctx)) {
            try {
                String email = decrypt(prefs(ctx).getString(KEY_EMAIL, null));
                String password = decrypt(prefs(ctx).getString(KEY_PASSWORD, null));
                if (email != null && password != null) {
                    CinemaBoxCredentials.install(email, password);
                    return true;
                }
            } catch (Exception e) {
                clear(ctx);
            }
        }
        // رجوع للسلوك القديم: حساب Config.java إن كان مضبوطاً (الحساب المحفوظ من الإعدادات يتقدّم).
        String e = Config.CINEMABOX_EMAIL;
        String p = Config.CINEMABOX_PASSWORD;
        if (e == null || e.trim().isEmpty() || p == null || p.isEmpty()) return false;
        CinemaBoxCredentials.install(e, p);
        return true;
    }

    public static synchronized void clear(Context ctx) {
        if (ctx != null) prefs(ctx).edit().clear().apply();
        CinemaBoxCredentials.clear();
    }

    /** البريد المخزن (للعرض في الإعدادات فقط) — بلا فك تشفير كلمة المرور. */
    public static synchronized String storedEmail(Context ctx) {
        if (ctx == null) return null;
        try {
            return decrypt(prefs(ctx).getString(KEY_EMAIL, null));
        } catch (Exception e) {
            return null;
        }
    }

    // ── التشفير ───────────────────────────────────────────

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance(KEYSTORE);
        ks.load(null);
        KeyStore.Entry entry = ks.getEntry(ALIAS, null);
        if (entry instanceof KeyStore.SecretKeyEntry)
            return ((KeyStore.SecretKeyEntry) entry).getSecretKey();
        KeyGenerator gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE);
        gen.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build());
        return gen.generateKey();
    }

    /** IV (12 بايت) ملحوق بالنص المشفر ثم Base64 — صيغة ذاتية الاحتواء. */
    private static String encrypt(String plain) throws Exception {
        Cipher cipher = Cipher.getInstance(TRANSFORM);
        cipher.init(Cipher.ENCRYPT_MODE, key());
        byte[] iv = cipher.getIV();
        byte[] ct = cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));
        byte[] out = new byte[iv.length + ct.length];
        System.arraycopy(iv, 0, out, 0, iv.length);
        System.arraycopy(ct, 0, out, iv.length, ct.length);
        return Base64.encodeToString(out, Base64.NO_WRAP);
    }

    private static String decrypt(String encoded) throws Exception {
        if (encoded == null) return null;
        byte[] blob = Base64.decode(encoded, Base64.NO_WRAP);
        if (blob.length <= GCM_IV_BYTES) return null;
        byte[] iv = new byte[GCM_IV_BYTES];
        byte[] ct = new byte[blob.length - GCM_IV_BYTES];
        System.arraycopy(blob, 0, iv, 0, GCM_IV_BYTES);
        System.arraycopy(blob, GCM_IV_BYTES, ct, 0, ct.length);
        Cipher cipher = Cipher.getInstance(TRANSFORM);
        cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(GCM_TAG_BITS, iv));
        return new String(cipher.doFinal(ct), StandardCharsets.UTF_8);
    }
}

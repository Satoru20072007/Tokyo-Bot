package com.eve.cinema.stremio;

import android.content.Context;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/** Aggregates enabled Stremio stream add-ons as the app's third source. */
public final class StremioSourceResolver {
    private static final long RESOLVE_BUDGET_MS = 15000L;
    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(4,
            new ThreadFactory() {
                private final AtomicInteger ids = new AtomicInteger();
                @Override public Thread newThread(Runnable task) {
                    Thread thread = new Thread(task, "EveStremio-" + ids.incrementAndGet());
                    thread.setDaemon(true);
                    return thread;
                }
            });

    private StremioSourceResolver() {}

    public static final class ResolvedStream {
        public final String addonName;
        public final String addonManifestUrl;
        public final StremioAddonClient.StreamCandidate stream;

        ResolvedStream(String addonName, String addonManifestUrl,
                       StremioAddonClient.StreamCandidate stream) {
            this.addonName = addonName;
            this.addonManifestUrl = addonManifestUrl;
            this.stream = stream;
        }
    }

    /**
     * True when at least one usable (enabled, configured, URL accepted) add-on declares a stream
     * capability for this kind of title. {@code id} is the app's own TMDB form ({@code tmdb:<id>},
     * possibly the bare prefix {@code tmdb:}); because most stream add-ons only accept IMDb ids
     * ({@code tt…}), an add-on also counts when it accepts that scheme: the IMDb id itself is resolved
     * later, when the user actually searches.
     */
    public static boolean hasEnabledStreamAddon(Context context, String type, String id) {
        if (context == null) return false;
        try {
            return anyUsableStreamAddon(new StremioAddonStore(context).list(), type, id);
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    /** Pure core of {@link #hasEnabledStreamAddon}: no Android, directly unit tested. */
    static boolean anyUsableStreamAddon(java.util.List<StremioAddonStore.Addon> addons, String type, String id) {
        if (addons == null || type == null || type.isEmpty() || id == null || id.isEmpty()) return false;
        String imdbProbe = imdbCapabilityProbe(type, id);
        for (StremioAddonStore.Addon addon : addons) {
            if (!addon.usable() || addon.manifest == null) continue;
            if (addon.manifest.supports(StremioManifest.STREAM, type, id)
                    || (imdbProbe != null
                    && addon.manifest.supports(StremioManifest.STREAM, type, imdbProbe))) return true;
            if ("anime".equals(type) && (addon.manifest.supports(StremioManifest.STREAM, "series", id)
                    || (imdbProbe != null && addon.manifest.supports(StremioManifest.STREAM, "series", imdbProbe)))) return true;
        }
        return false;
    }

    /** The IMDb-shaped id that asks the same capability question as a {@code tmdb:} id; null otherwise. */
    static String imdbCapabilityProbe(String type, String id) {
        if (!id.startsWith("tmdb:")) return null;
        String[] parts = id.split(":", -1);
        if (parts.length >= 4) return StremioContentRef.CAPABILITY_PROBE_IMDB + ":" + parts[2] + ":" + parts[3];
        return StremioContentRef.CAPABILITY_PROBE_IMDB;
    }

    /**
     * Queries matching enabled add-ons in parallel and returns the first safe HTTP(S)
     * stream within a fixed total budget. Network calls must be made off the UI thread.
     *
     * @deprecated Source 3 no longer auto-picks a link: the UI uses
     *     {@link StremioChooserLoader} and lets the user choose. Kept for callers that need a
     *     single best-effort stream without UI.
     */
    @Deprecated
    public static ResolvedStream resolveFirst(Context context, String type, String id)
            throws IOException, InterruptedException {
        if (context == null || type == null || type.isEmpty() || id == null || id.isEmpty())
            throw new IOException("Invalid Stremio request");
        List<StremioAddonStore.Addon> matching = new ArrayList<>();
        for (StremioAddonStore.Addon addon : new StremioAddonStore(context).list()) {
            if (addon.usable() && addon.manifest != null
                    && addon.manifest.supports(StremioManifest.STREAM, type, id))
                matching.add(addon);
        }
        if (matching.isEmpty()) return null;

        CompletionService<ResolvedStream> completion = new ExecutorCompletionService<>(EXECUTOR);
        List<Future<ResolvedStream>> pending = new ArrayList<>();
        final StremioAddonClient client = new StremioAddonClient();
        for (final StremioAddonStore.Addon addon : matching) {
            pending.add(completion.submit(() -> {
                try {
                    List<StremioAddonClient.StreamCandidate> streams = client.streamCandidates(
                            addon, type, id, Collections.<String, String>emptyMap());
                    if (streams.isEmpty()) return null;
                    return new ResolvedStream(addon.manifest.name, addon.manifestUrl,
                            streams.get(0));
                } catch (Exception ignored) {
                    return null;
                }
            }));
        }

        long deadline = System.currentTimeMillis() + RESOLVE_BUDGET_MS;
        try {
            for (int completed = 0; completed < pending.size(); completed++) {
                long remaining = deadline - System.currentTimeMillis();
                if (remaining <= 0) break;
                Future<ResolvedStream> result = completion.poll(remaining, TimeUnit.MILLISECONDS);
                if (result == null) break;
                try {
                    ResolvedStream resolved = result.get();
                    if (resolved != null) return resolved;
                } catch (Exception ignored) { }
            }
            return null;
        } finally {
            for (Future<ResolvedStream> task : pending) task.cancel(true);
        }
    }

    public static String movieId(String tmdbId) {
        String digits = safeDigits(tmdbId);
        return digits.isEmpty() ? "" : "tmdb:" + digits;
    }

    public static String episodeId(String tmdbId, int season, int episode) {
        String digits = safeDigits(tmdbId);
        if (digits.isEmpty() || season < 1 || episode < 1) return "";
        return "tmdb:" + digits + ":" + season + ":" + episode;
    }

    private static String safeDigits(String value) {
        if (value == null || !value.matches("[0-9]{1,12}")) return "";
        return value;
    }
}

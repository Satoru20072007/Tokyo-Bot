package com.eve.cinema;

/** حالة محلية صريحة: يحتاج المستخدم إلى إدخال حسابه المصرح به. */
public final class CinemaBoxAuthRequiredException extends Exception {
    private static final long serialVersionUID = 1L;

    public CinemaBoxAuthRequiredException() {
        super("حساب CinemaBox مطلوب");
    }
}

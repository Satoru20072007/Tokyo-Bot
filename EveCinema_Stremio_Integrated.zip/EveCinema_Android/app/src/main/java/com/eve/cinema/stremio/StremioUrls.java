package com.eve.cinema.stremio;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.List;
import java.util.Map;

/**
 * Pure URL building for Stremio add-ons.
 *
 * <p>Add-on URLs may carry a credential <i>inside the path</i> (a percent-encoded configuration
 * segment). Therefore nothing here decodes and re-encodes a path: the raw path the user supplied is
 * kept byte for byte, only characters that are illegal in a URI are percent-encoded (an existing
 * {@code %XX} escape is never touched, so {@code %7B} can not become {@code %257B}).
 */
public final class StremioUrls {
    private StremioUrls() {}

    public static final String MANIFEST_FILE = "manifest.json";
    private static final int MAX_URL_LENGTH = 4096;

    public static String normalizeManifestUrl(String value) throws StremioException {
        return normalizeManifestUrl(value, StremioNetPolicy.Policy.addon());
    }

    /**
     * Turns what the user pasted into the canonical manifest URL. Accepts only {@code https://}
     * (and {@code http://} when the policy allows it, tests only). A URL that does not end with
     * {@code manifest.json} gets it appended; a trailing {@code /configure} page URL is mapped to
     * the manifest next to it. The credential path segments are never altered.
     */
    public static String normalizeManifestUrl(String value, StremioNetPolicy.Policy policy)
            throws StremioException {
        String raw = value == null ? "" : value.trim();
        if (raw.isEmpty() || raw.length() > MAX_URL_LENGTH) throw unsafe();
        int sep = raw.indexOf("://");
        if (sep <= 0) throw unsafe();
        String scheme = raw.substring(0, sep).toLowerCase(Locale.ROOT);
        if (!("https".equals(scheme) || ("http".equals(scheme) && policy.allowsHttp()))) throw unsafe();
        String rest = raw.substring(sep + 3);
        if (rest.indexOf('#') >= 0) throw unsafe();

        int end = indexOfAny(rest, '/', '?');
        String authority = end < 0 ? rest : rest.substring(0, end);
        String tail = end < 0 ? "" : rest.substring(end);
        int q = tail.indexOf('?');
        String path = q < 0 ? tail : tail.substring(0, q);
        String query = q < 0 ? null : tail.substring(q + 1);
        path = encodeIllegal(path, false);
        if (query != null) query = encodeIllegal(query, true);

        String trimmed = path;
        while (trimmed.endsWith("/")) trimmed = trimmed.substring(0, trimmed.length() - 1);
        String last = trimmed.substring(trimmed.lastIndexOf('/') + 1);
        if (MANIFEST_FILE.equalsIgnoreCase(last)) {
            path = trimmed;
        } else if ("configure".equalsIgnoreCase(last)) {
            path = trimmed.substring(0, trimmed.length() - last.length()) + MANIFEST_FILE;
        } else {
            path = trimmed + "/" + MANIFEST_FILE;
        }

        URI uri;
        try {
            uri = URI.create(scheme + "://" + authority + path + (query == null ? "" : "?" + query));
        } catch (RuntimeException ex) {
            throw unsafe();
        }
        policy.checkSyntax(uri);
        String result = scheme + "://" + authority(uri) + uri.getRawPath()
                + (uri.getRawQuery() == null ? "" : "?" + uri.getRawQuery());
        if (result.length() > MAX_URL_LENGTH) throw unsafe();
        return result;
    }


    /** Stable comparison key for duplicate stream responses. The playback URL itself is never changed. */
    public static String streamDedupKey(String value) {
        if (value == null) return "";
        try {
            URI uri = URI.create(value.trim());
            String scheme = uri.getScheme() == null ? "" : uri.getScheme().toLowerCase(Locale.ROOT);
            String host = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            int port = uri.getPort();
            StringBuilder key = new StringBuilder(scheme).append("://").append(host);
            if (port != -1 && !("https".equals(scheme) && port == 443) && !("http".equals(scheme) && port == 80))
                key.append(':').append(port);
            String path = uri.getRawPath();
            key.append(path == null ? "" : path);
            String rawQuery = uri.getRawQuery();
            if (rawQuery != null && !rawQuery.isEmpty()) {
                List<String> parts = new java.util.ArrayList<>();
                for (String part : rawQuery.split("&")) {
                    String name = part;
                    int eq = name.indexOf('=');
                    if (eq >= 0) name = name.substring(0, eq);
                    String lower = name.toLowerCase(Locale.ROOT);
                    if (lower.startsWith("utm_") || "fbclid".equals(lower) || "gclid".equals(lower)) continue;
                    parts.add(part);
                }
                java.util.Collections.sort(parts);
                if (!parts.isEmpty()) key.append('?').append(join(parts, "&"));
            }
            return key.toString();
        } catch (RuntimeException invalid) {
            return value.trim();
        }
    }

    private static String join(List<String> values, String separator) {
        StringBuilder out = new StringBuilder();
        for (String value : values) {
            if (out.length() > 0) out.append(separator);
            out.append(value);
        }
        return out.toString();
    }

    /**
     * Builds {@code <base>/<resource>/<type>/<id>[/<extra>].json[?query]} from a canonical manifest
     * URL. The credential path in front of the resource name is reused untouched.
     */
    public static String resourceUrl(String manifestUrl, String resource, String type, String id,
                                     Map<String, String> extras, StremioNetPolicy.Policy policy)
            throws StremioException {
        if (!StremioManifest.CATALOG.equals(resource) && !StremioManifest.META.equals(resource)
                && !StremioManifest.STREAM.equals(resource) && !StremioManifest.SUBTITLES.equals(resource))
            throw new StremioException(StremioException.Kind.UNSUPPORTED);
        if (type == null || id == null || type.isEmpty() || id.isEmpty()
                || type.length() > 100 || id.length() > 1024)
            throw new StremioException(StremioException.Kind.UNSUPPORTED);
        String manifest = normalizeManifestUrl(manifestUrl, policy);
        URI base = URI.create(manifest);
        String rawPath = base.getRawPath();
        String dir = rawPath.substring(0, rawPath.length() - MANIFEST_FILE.length());
        StringBuilder result = new StringBuilder(base.getScheme()).append("://").append(authority(base))
                .append(dir).append(resource).append('/').append(encodeComponent(type)).append('/')
                .append(encodeComponent(id));
        if (extras != null && !extras.isEmpty()) {
            if (extras.size() > 32) throw new StremioException(StremioException.Kind.UNSUPPORTED);
            StringBuilder encoded = new StringBuilder();
            for (Map.Entry<String, String> e : extras.entrySet()) {
                String key = e.getKey(), value = e.getValue();
                if (key == null || value == null || key.isEmpty() || key.length() > 128
                        || value.length() > 1024) continue;
                if (encoded.length() > 0) encoded.append('&');
                encoded.append(encodeComponent(key)).append('=').append(encodeComponent(value));
            }
            if (encoded.length() > 0) result.append('/').append(encoded);
        }
        result.append(".json");
        if (base.getRawQuery() != null && !base.getRawQuery().isEmpty())
            result.append('?').append(base.getRawQuery());
        return result.toString();
    }

    /**
     * True when the manifest URL can hold a secret: anything other than exactly
     * {@code /manifest.json} without a query (a personal configuration segment or a signed query).
     */
    public static boolean carriesCredential(String manifestUrl) {
        try {
            URI uri = URI.create(manifestUrl);
            String path = uri.getRawPath();
            return uri.getRawQuery() != null || !("/" + MANIFEST_FILE).equalsIgnoreCase(path);
        } catch (RuntimeException ex) {
            return true;
        }
    }

    public static boolean sameOrigin(URI a, URI b) {
        if (a == null || b == null || a.getScheme() == null || b.getScheme() == null
                || a.getHost() == null || b.getHost() == null) return false;
        return a.getScheme().equalsIgnoreCase(b.getScheme())
                && StremioNetPolicy.normalizeHost(a.getHost()).equals(StremioNetPolicy.normalizeHost(b.getHost()))
                && effectivePort(a) == effectivePort(b);
    }

    private static int effectivePort(URI uri) {
        if (uri.getPort() != -1) return uri.getPort();
        return "https".equalsIgnoreCase(uri.getScheme()) ? 443 : 80;
    }

    /** {@code host[:port]} with the host lower-cased (hosts are case-insensitive, paths are not). */
    private static String authority(URI uri) {
        String host = StremioNetPolicy.normalizeHost(uri.getHost());
        return uri.getPort() == -1 ? host : host + ":" + uri.getPort();
    }

    private static int indexOfAny(String s, char a, char b) {
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == a || c == b) return i;
        }
        return -1;
    }

    private static StremioException unsafe() {
        return new StremioException(StremioException.Kind.UNSAFE_URL);
    }

    // ───────────────────────────── percent-encoding ─────────────────────────────

    private static final String HEX = "0123456789ABCDEF";

    /**
     * Percent-encodes ONLY what a URI cannot carry (spaces, quotes, braces, non-ASCII...). Valid
     * text, including every existing {@code %XX}, is returned unchanged; a lone '%' becomes %25.
     */
    static String encodeIllegal(String value, boolean query) {
        StringBuilder out = new StringBuilder(value.length() + 16);
        int i = 0;
        while (i < value.length()) {
            char c = value.charAt(i);
            if (c == '%' && i + 2 < value.length()
                    && isHex(value.charAt(i + 1)) && isHex(value.charAt(i + 2))) {
                out.append(c).append(value.charAt(i + 1)).append(value.charAt(i + 2));
                i += 3;
                continue;
            }
            if (isAllowed(c, query)) {
                out.append(c);
                i++;
                continue;
            }
            int cp = value.codePointAt(i);
            byte[] bytes = new String(Character.toChars(cp)).getBytes(StandardCharsets.UTF_8);
            for (byte b : bytes) out.append('%').append(HEX.charAt((b >> 4) & 0xF)).append(HEX.charAt(b & 0xF));
            i += Character.charCount(cp);
        }
        return out.toString();
    }

    private static boolean isHex(char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
    }

    private static boolean isAllowed(char c, boolean query) {
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) return true;
        if ("-._~!$&'()*+,;=:@/".indexOf(c) >= 0) return true;
        return query && c == '?';
    }

    /** Percent-encodes every byte except RFC 3986 unreserved characters. */
    static String encodeComponent(String value) {
        StringBuilder out = new StringBuilder(value.length() + 8);
        for (byte b : value.getBytes(StandardCharsets.UTF_8)) {
            int v = b & 0xFF;
            boolean unreserved = (v >= 'a' && v <= 'z') || (v >= 'A' && v <= 'Z') || (v >= '0' && v <= '9')
                    || v == '-' || v == '.' || v == '_' || v == '~';
            if (unreserved) out.append((char) v);
            else out.append('%').append(HEX.charAt(v >> 4)).append(HEX.charAt(v & 0xF));
        }
        return out.toString();
    }
}

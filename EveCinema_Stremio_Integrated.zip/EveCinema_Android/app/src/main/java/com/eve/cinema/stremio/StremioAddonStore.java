package com.eve.cinema.stremio;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Private local add-on list. Values are never logged or synchronized.
 *
 * <p>What this class guarantees:
 * <ul>
 *   <li>One process-wide lock: two store instances (the screens create their own) can not lose each
 *       other's writes.</li>
 *   <li>A failed refresh only records {@code lastFailure*}: the last valid manifest, the URL and the
 *       user's enabled/disabled choice are untouched. Only {@link #remove} deletes an add-on.</li>
 *   <li>An entry that the CURRENT URL policy no longer accepts stays in the list flagged
 *       {@link Addon#urlRejected} (so the user can see and remove it) instead of silently vanishing;
 *       an entry whose manifest JSON is unreadable is preserved verbatim across saves.</li>
 * </ul>
 */
public final class StremioAddonStore {
    private static final String PREFS = "eve_stremio_addons";
    private static final String KEY_LIST = "addons_v1";
    private static final int MAX_ADDONS = 50;
    private static final int MAX_STORED_ITEMS = 100;
    private static final Object LOCK = new Object();
    private final SharedPreferences preferences;

    public enum AddResult {
        ADDED,
        /** Same normalized URL: the entry was refreshed. */
        UPDATED_SAME_URL,
        /** Same manifest id behind a DIFFERENT URL (e.g. reconfigured): the old configuration was replaced. */
        REPLACED_SAME_ID
    }

    public static final class Addon {
        public final String manifestUrl;
        public final StremioManifest manifest;
        public final boolean enabled;
        public final long lastCheckedMs;
        public final long lastSuccessMs;
        public final long lastFailureMs;
        /** {@link StremioException.Kind} name of the most recent failed refresh, or "". */
        public final String lastFailureKind;
        /** The stored URL no longer passes the current public-HTTPS policy; it is never requested. */
        public final boolean urlRejected;

        Addon(String manifestUrl, StremioManifest manifest, boolean enabled, long lastCheckedMs) {
            this(manifestUrl, manifest, enabled, lastCheckedMs, lastCheckedMs, 0L, "", false);
        }

        Addon(String manifestUrl, StremioManifest manifest, boolean enabled, long lastCheckedMs,
              long lastSuccessMs, long lastFailureMs, String lastFailureKind, boolean urlRejected) {
            this.manifestUrl = manifestUrl;
            this.manifest = manifest;
            this.enabled = enabled;
            this.lastCheckedMs = lastCheckedMs;
            this.lastSuccessMs = lastSuccessMs;
            this.lastFailureMs = lastFailureMs;
            this.lastFailureKind = lastFailureKind == null ? "" : lastFailureKind;
            this.urlRejected = urlRejected;
        }

        /** Can this entry take part in a search right now? */
        public boolean usable() { return enabled && !urlRejected && !manifest.configurationRequired; }

        /** The most recent refresh failed (and no later refresh succeeded). */
        public boolean lastRefreshFailed() { return !lastFailureKind.isEmpty() && lastFailureMs >= lastSuccessMs; }

        public Addon withEnabled(boolean value) {
            return new Addon(manifestUrl, manifest, value, lastCheckedMs, lastSuccessMs, lastFailureMs,
                    lastFailureKind, urlRejected);
        }
        public Addon withChecked(long time) {
            return new Addon(manifestUrl, manifest, enabled, time, lastSuccessMs, lastFailureMs,
                    lastFailureKind, urlRejected);
        }
        Addon withSuccess(String url, StremioManifest fresh, long time) {
            return new Addon(url, fresh, enabled, time, time, 0L, "", false);
        }
        Addon withFailure(String kind, long time) {
            return new Addon(manifestUrl, manifest, enabled, time, lastSuccessMs, time, kind, urlRejected);
        }
    }

    private static final class Loaded {
        final List<Addon> addons = new ArrayList<>();
        /** Raw items that could not be turned into an Addon: kept so a save never destroys them. */
        final List<JSONObject> preserved = new ArrayList<>();
    }

    public StremioAddonStore(Context context) {
        this(prefsOf(context));
    }

    /** Direct constructor (also used by the JVM tests with an in-memory SharedPreferences). */
    public StremioAddonStore(SharedPreferences preferences) {
        if (preferences == null) throw new IllegalArgumentException("Preferences required");
        this.preferences = preferences;
    }

    private static SharedPreferences prefsOf(Context context) {
        if (context == null) throw new IllegalArgumentException("Context required");
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public List<Addon> list() {
        synchronized (LOCK) { return Collections.unmodifiableList(new ArrayList<>(load().addons)); }
    }

    public Addon find(String addonId) {
        synchronized (LOCK) {
            for (Addon addon : load().addons) if (addon.manifest.id.equals(addonId)) return addon;
            return null;
        }
    }

    /** Compatibility form of {@link #addOrUpdateDetailed}: true when an existing entry was replaced. */
    public boolean addOrUpdate(String manifestUrl, StremioManifest manifest, long checkedAt)
            throws JSONException, IOException {
        return addOrUpdateDetailed(manifestUrl, manifest, checkedAt) != AddResult.ADDED;
    }

    public AddResult addOrUpdateDetailed(String manifestUrl, StremioManifest manifest, long checkedAt)
            throws JSONException, IOException {
        if (manifest == null) throw new IllegalArgumentException("Manifest required");
        String normalized = StremioUrls.normalizeManifestUrl(manifestUrl);
        synchronized (LOCK) {
            Loaded loaded = load();
            List<Addon> items = loaded.addons;
            int sameUrl = -1, sameId = -1;
            for (int i = 0; i < items.size(); i++) {
                if (sameUrl < 0 && items.get(i).manifestUrl.equals(normalized)) sameUrl = i;
                if (sameId < 0 && items.get(i).manifest.id.equals(manifest.id)) sameId = i;
            }
            AddResult result;
            if (sameUrl >= 0) {
                items.set(sameUrl, items.get(sameUrl).withSuccess(normalized, manifest, checkedAt));
                result = AddResult.UPDATED_SAME_URL;
            } else if (sameId >= 0) {
                items.set(sameId, items.get(sameId).withSuccess(normalized, manifest, checkedAt));
                result = AddResult.REPLACED_SAME_ID;
            } else {
                if (items.size() >= MAX_ADDONS) throw new IllegalStateException("Add-on limit reached");
                items.add(new Addon(normalized, manifest, true, checkedAt));
                result = AddResult.ADDED;
            }
            save(loaded);
            return result;
        }
    }

    /** Successful refresh of an existing entry (URL may have been edited). */
    public boolean update(String existingAddonId, String manifestUrl, StremioManifest manifest,
                          long checkedAt) throws JSONException, IOException {
        if (existingAddonId == null || manifest == null) return false;
        String normalized = StremioUrls.normalizeManifestUrl(manifestUrl);
        synchronized (LOCK) {
            Loaded loaded = load();
            for (int i = 0; i < loaded.addons.size(); i++) {
                Addon old = loaded.addons.get(i);
                if (old.manifest.id.equals(existingAddonId)) {
                    loaded.addons.set(i, old.withSuccess(normalized, manifest, checkedAt));
                    save(loaded);
                    return true;
                }
            }
            return false;
        }
    }

    /**
     * A refresh failed. Records the kind and time ONLY: the cached manifest, the URL and the
     * enabled flag are left exactly as they were (a network error is not a removal).
     */
    public boolean recordFailure(String addonId, StremioException.Kind kind, long time) {
        synchronized (LOCK) {
            Loaded loaded = load();
            for (int i = 0; i < loaded.addons.size(); i++) {
                Addon item = loaded.addons.get(i);
                if (item.manifest.id.equals(addonId)) {
                    loaded.addons.set(i, item.withFailure(kind.name(), time));
                    save(loaded);
                    return true;
                }
            }
            return false;
        }
    }

    public boolean setEnabled(String addonId, boolean enabled) {
        synchronized (LOCK) {
            Loaded loaded = load();
            for (int i = 0; i < loaded.addons.size(); i++) {
                if (loaded.addons.get(i).manifest.id.equals(addonId)) {
                    loaded.addons.set(i, loaded.addons.get(i).withEnabled(enabled));
                    save(loaded);
                    return true;
                }
            }
            return false;
        }
    }

    /** The only operation that deletes an add-on; it exists for the user's explicit "remove". */
    public boolean remove(String addonId) {
        synchronized (LOCK) {
            Loaded loaded = load();
            boolean removed = false;
            for (int i = loaded.addons.size() - 1; i >= 0; i--) {
                if (loaded.addons.get(i).manifest.id.equals(addonId)) { loaded.addons.remove(i); removed = true; }
            }
            if (removed) save(loaded);
            return removed;
        }
    }

    // ───────────────────────────── persistence ─────────────────────────────

    private Loaded load() {
        Loaded loaded = new Loaded();
        String saved = preferences.getString(KEY_LIST, "[]");
        JSONArray array;
        try { array = new JSONArray(saved); } catch (Exception unreadable) { return loaded; }
        for (int i = 0; i < array.length() && i < MAX_STORED_ITEMS; i++) {
            JSONObject item = array.optJSONObject(i);
            if (item == null) continue;
            String url = item.isNull("manifestUrl") ? "" : item.optString("manifestUrl", "");
            JSONObject rawManifest = item.optJSONObject("manifest");
            StremioManifest manifest = null;
            if (!url.isEmpty() && rawManifest != null) {
                try { manifest = StremioManifest.parse(rawManifest); } catch (Exception ignored) { /* preserved below */ }
            }
            if (manifest == null || loaded.addons.size() >= MAX_ADDONS) {
                loaded.preserved.add(item);
                continue;
            }
            String normalized = url;
            boolean rejected = false;
            try { normalized = StremioUrls.normalizeManifestUrl(url); }
            catch (StremioException policy) { rejected = true; }
            long checked = item.optLong("lastCheckedMs", 0L);
            loaded.addons.add(new Addon(normalized, manifest, item.optBoolean("enabled", true), checked,
                    item.has("lastSuccessMs") ? item.optLong("lastSuccessMs", 0L) : checked,
                    item.optLong("lastFailureMs", 0L),
                    item.isNull("lastFailureKind") ? "" : item.optString("lastFailureKind", ""), rejected));
        }
        return loaded;
    }

    private void save(Loaded loaded) {
        JSONArray array = new JSONArray();
        for (Addon addon : loaded.addons) {
            JSONObject item = new JSONObject();
            try {
                item.put("manifestUrl", addon.manifestUrl);
                item.put("manifest", addon.manifest.raw());
                item.put("enabled", addon.enabled);
                item.put("lastCheckedMs", addon.lastCheckedMs);
                item.put("lastSuccessMs", addon.lastSuccessMs);
                item.put("lastFailureMs", addon.lastFailureMs);
                item.put("lastFailureKind", addon.lastFailureKind);
                array.put(item);
            } catch (JSONException keepGoing) {
                // One entry that cannot be serialized must not take the others down with it.
            }
        }
        for (JSONObject item : loaded.preserved) {
            if (array.length() >= MAX_STORED_ITEMS) break;
            array.put(item);
        }
        preferences.edit().putString(KEY_LIST, array.toString()).apply();
    }
}

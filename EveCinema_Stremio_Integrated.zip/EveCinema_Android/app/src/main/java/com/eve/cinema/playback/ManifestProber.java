package com.eve.cinema.playback;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Fetches an adaptive manifest (DASH MPD / HLS master) with the stream's own
 * provider headers and extracts the audio languages it declares. Used ONLY by
 * the portrait pre-player chooser as a lightweight, cancellable preflight —
 * playback itself is still done by Media3, which re-reads the manifest.
 *
 * Safety rules:
 *  - the response body is capped ({@link #MAX_MANIFEST_BYTES}) — a manifest is
 *    kilobytes, a media segment is not; oversize bodies are abandoned;
 *  - only http(s) URLs are fetched; signed query strings are sent as-is and
 *    never logged here;
 *  - any failure returns an empty list: the chooser simply offers fewer modes,
 *    it never invents an audio language.
 *
 * Pure Java (HttpURLConnection is JDK) — unit-tested with a local HTTP server.
 */
public final class ManifestProber {

    public static final int MAX_MANIFEST_BYTES = 512 * 1024;
    public static final int CONNECT_TIMEOUT_MS = 8000;
    public static final int READ_TIMEOUT_MS    = 8000;

    private ManifestProber() {}

    /**
     * Downloads the manifest at {@code url} (only when the URL shape says it
     * is an adaptive manifest) and returns its declared audio languages.
     * Never throws; empty list on any error or non-manifest URL.
     */
    public static List<String> fetchAudioLanguages(String url, Map<String, String> headers) {
        List<String> out = new ArrayList<>();
        if (url == null || url.isEmpty()) return out;
        String clean = url.split("\\?")[0].toLowerCase(java.util.Locale.US);
        boolean dash = clean.endsWith(".mpd") || clean.contains("/dash/");
        boolean hls  = clean.endsWith(".m3u8");
        if (!dash && !hls) return out;
        if (!url.startsWith("https://") && !url.startsWith("http://")) return out;

        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
            conn.setReadTimeout(READ_TIMEOUT_MS);
            conn.setInstanceFollowRedirects(true);
            if (headers != null) {
                for (Map.Entry<String, String> h : headers.entrySet()) {
                    if (h.getKey() == null || h.getValue() == null) continue;
                    conn.setRequestProperty(h.getKey(), h.getValue());
                }
            }
            int code = conn.getResponseCode();
            if (code / 100 != 2) return out;
            String body = readCapped(conn.getInputStream(), MAX_MANIFEST_BYTES);
            if (body == null) return out;
            return dash ? ManifestAudioParser.parseDashAudioLanguages(body)
                        : ManifestAudioParser.parseHlsAudioLanguages(body);
        } catch (Exception e) {
            return out;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    /** Reads at most {@code max} bytes; null when the body exceeds the cap. */
    private static String readCapped(InputStream in, int max) throws Exception {
        if (in == null) return null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int total = 0;
        int n;
        try {
            while ((n = in.read(buf)) != -1) {
                total += n;
                if (total > max) return null;
                bos.write(buf, 0, n);
            }
        } finally {
            try { in.close(); } catch (Exception ignored) {}
        }
        return new String(bos.toByteArray(), "UTF-8");
    }

    // ══════════════════════════════════════════════════════════
    //  probeLink — فحص شبكي محدود لصالح PlayableCandidateValidator (§11)
    // ══════════════════════════════════════════════════════════

    /**
     * نتيجة فحص رابط محدود: لا نزّل أبداً أكثر من Manifest مقيّد الحجم
     * (§11.2). الحقول null تعني «غير قابل للقياس» وليس «فاشل».
     */
    public static final class LinkInfo {
        public final int httpCode;          // -1 عند تعذر القياس
        public final String contentType;    // nullable
        public final Long contentLength;    // nullable
        public final Boolean rangeSupport;  // nullable
        public final Boolean manifestValid; // null = الرابط ليس Manifest
        public final Long mediaDurationSec; // من manifest فعلي فقط — لا من play-info

        public LinkInfo(int httpCode, String contentType, Long contentLength,
                        Boolean rangeSupport, Boolean manifestValid, Long mediaDurationSec) {
            this.httpCode = httpCode;
            this.contentType = contentType;
            this.contentLength = contentLength;
            this.rangeSupport = rangeSupport;
            this.manifestValid = manifestValid;
            this.mediaDurationSec = mediaDurationSec;
        }
    }

    /**
     * HEAD أولاً (مع سقوط إلى Range GET صغير عند 405/501 — §11.1 بند 6)،
     * وقراءة Manifest مقيّدة عند HLS/DASH مع تحقق بنيوي ومدة فعلية (بند 7).
     * Never throws; null on network failure.
     */
    public static LinkInfo probeLink(String url, Map<String, String> headers) {
        if (url == null || url.isEmpty()) return null;
        if (!url.startsWith("https://") && !url.startsWith("http://")) return null;
        String clean = url.split("\\?")[0].toLowerCase(java.util.Locale.US);
        boolean dash = clean.endsWith(".mpd") || clean.contains("/dash/");
        boolean hls  = clean.endsWith(".m3u8");
        if (dash || hls) return probeManifest(url, headers, dash);

        HttpURLConnection conn = null;
        try {
            conn = open(url, headers, "HEAD");
            int code = conn.getResponseCode();
            String contentType = conn.getContentType();
            Long contentLength = conn.getContentLengthLong() >= 0
                    ? conn.getContentLengthLong() : null;
            Boolean rangeSupport = acceptsRanges(conn);
            if (code == HttpURLConnection.HTTP_BAD_METHOD
                    || code == HttpURLConnection.HTTP_NOT_IMPLEMENTED) {
                // خادم بلا HEAD: عينة Range من بايت واحد فقط (§11.1 بند 6).
                conn.disconnect();
                conn = open(url, headers, "GET");
                conn.setRequestProperty("Range", "bytes=0-0");
                code = conn.getResponseCode();
                contentType = conn.getContentType();
                contentLength = null;
                rangeSupport = code == HttpURLConnection.HTTP_PARTIAL || acceptsRanges(conn);
            }
            return new LinkInfo(code, contentType, contentLength,
                    rangeSupport, null, null);
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static LinkInfo probeManifest(String url, Map<String, String> headers, boolean dash) {
        HttpURLConnection conn = null;
        try {
            conn = open(url, headers, "GET");
            int code = conn.getResponseCode();
            String contentType = conn.getContentType();
            if (code / 100 != 2)
                return new LinkInfo(code, contentType, null, null, Boolean.FALSE, null);
            String body = readCapped(conn.getInputStream(), MAX_MANIFEST_BYTES);
            if (body == null)
                return new LinkInfo(code, contentType, null, null, Boolean.FALSE, null);
            boolean valid;
            Long duration = null;
            if (dash) {
                valid = body.contains("<MPD");
                duration = parseDashDurationSec(body);
            } else {
                valid = body.contains("#EXTM3U");
                duration = parseHlsDurationSec(body);
            }
            return new LinkInfo(code, contentType, null, null, valid, duration);
        } catch (Exception e) {
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static HttpURLConnection open(String url, Map<String, String> headers,
                                          String method) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(CONNECT_TIMEOUT_MS);
        conn.setReadTimeout(READ_TIMEOUT_MS);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestMethod(method);
        if (headers != null) {
            for (Map.Entry<String, String> h : headers.entrySet()) {
                if (h.getKey() == null || h.getValue() == null) continue;
                conn.setRequestProperty(h.getKey(), h.getValue());
            }
        }
        return conn;
    }

    private static Boolean acceptsRanges(HttpURLConnection conn) {
        String v = conn.getHeaderField("Accept-Ranges");
        return v != null && v.toLowerCase(java.util.Locale.US).contains("bytes");
    }

    /** مجموع مدد #EXTINF لقائمة تشغيل وسائط؛ null لقائمة رئيسية (master). */
    static Long parseHlsDurationSec(String body) {
        if (body == null || !body.contains("#EXTM3U")) return null;
        if (body.contains("#EXT-X-STREAM-INF")) return null; // master — مدة مجهولة
        double total = 0;
        boolean any = false;
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("#EXTINF:([0-9]+(?:\\.[0-9]+)?)").matcher(body);
        while (m.find()) {
            try { total += Double.parseDouble(m.group(1)); any = true; }
            catch (NumberFormatException ignored) { }
        }
        return any ? (long) Math.round(total) : null;
    }

    /** mediaPresentationDuration="PT1H23M45.6S" من MPD؛ null عند غيابها. */
    static Long parseDashDurationSec(String body) {
        if (body == null) return null;
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("mediaPresentationDuration=\"PT(?:(\\d+)H)?(?:(\\d+)M)?(\\d+(?:\\.\\d+)?)?S\"")
                .matcher(body);
        if (!m.find()) return null;
        double seconds = 0;
        try {
            if (m.group(1) != null) seconds += Long.parseLong(m.group(1)) * 3600.0;
            if (m.group(2) != null) seconds += Long.parseLong(m.group(2)) * 60.0;
            if (m.group(3) != null) seconds += Double.parseDouble(m.group(3));
        } catch (NumberFormatException e) { return null; }
        return (long) Math.round(seconds);
    }
}

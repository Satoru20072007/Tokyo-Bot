package com.eve.cinema;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import com.eve.cinema.moviebox.MovieBoxModels;
import com.eve.cinema.playback.LanguageMatcher;
import com.eve.cinema.playback.ModeResolver;
import com.eve.cinema.playback.PlaybackMode;
import com.eve.cinema.playback.SourceChoice;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DetailActivity extends Activity {

    private static final String TMDB_TOKEN = Config.TMDB_BEARER_TOKEN;
    private static final String IMG_BASE_O  = "https://image.tmdb.org/t/p/original";
    private static final String IMG_BASE_W  = "https://image.tmdb.org/t/p/w500";
    private static final String IMG_BASE_F  = "https://image.tmdb.org/t/p/w185";

    // ── Colors ─────────────────────────────────────────────────────────
    private static final int C_VOID    = 0xFF08080F;
    private static final int C_CARD    = 0xFF111122;
    private static final int C_CARD2   = 0xFF1A1A2E;
    private static final int C_VIOLET  = 0xFF9B6FC4;
    private static final int C_VIOLET2 = 0xFF7C4FA0;
    private static final int C_LITE    = 0xFFC4A0E8;
    private static final int C_TEXT    = 0xFFFFFFFF;
    private static final int C_STAR    = 0xFFF5C518;
    private static final int C_BORDER  = 0xFF1E1E38;
    private static final int C_LABEL   = 0xFF4A4A68;
    private static final int C_MUTED   = 0xFF7070A0;
    private static final int C_GREEN   = 0xFF4CAF50;
    private static final int C_RED     = 0xFFEF5350;
    private static final int C_CARD_G  = 0xFF0D0D1F; // card gradient endpoint
    private static final int C_GLOW    = 0x1A9B6FC4; // subtle violet glow fill

    // ── State ──────────────────────────────────────────────────────────
    private JSONObject item;
    private String     mediaType;
    private String     tmdbId;
    private boolean    isMovie = true;
    private boolean    overviewExpanded = false;

    // ── Views ──────────────────────────────────────────────────────────
    private ImageView   detailBackdrop;
    private TextView    detailTypeBadge, detailTitle, detailRatingStar;
    private TextView    detailYear, detailLanguage, detailOverview, detailReadMore;
    private TextView    detailRating, detailYear2, detailLang2;
    private TextView    detailDirector, detailCast;
    private View        detailSoloBtn, detailPartyBtn, startWatchingBtn;
    private FrameLayout detailLoadingOverlay;

    // Cast photo row
    private LinearLayout castPhotoRow;

    // Box office views
    private TextView tvBudget, tvRevenue, tvRoi, tvRoiLabel;
    private View     roiBarFill;

    // Similar row
    private LinearLayout similarRow;
    private TextView     similarEmptyTv;

    // RecyclerView master
    private RecyclerView  masterRecyclerView;
    private MasterAdapter masterAdapter;

    // Pre-built section views
    private View hdrBackdrop, hdrActions, hdrOverview, hdrMeta;
    private View hdrCastCards, hdrBoxOffice, hdrSimilar;

    // Resolve overlay
    private FrameLayout resolveOverlay;
    private TextView    resolveMsgTv;

    // ── Source selector (details page; P5) ────────────────────────────
    private TextView     sourceChipTv;
    private TextView     sourceChipArrow;
    private volatile com.eve.cinema.playback.SourceChoice.Decision sourceDecision;
    private volatile com.eve.cinema.playback.ProbeOutcome sourceProbeOutcome;
    private volatile boolean sourceAuthRequired;
    private volatile boolean sourceProbeRunning = false;
    private final Object sourceProbeLock = new Object();
    private int selectedSource = 0; // 0 = auto (decision default)
    private int chooserGeneration = 0;

    private String sourceKey() { return tmdbId + "|" + mediaType; }

    private boolean hasStremioSource() {
        // Anime included: Stremio is its primary (and only) source now.
        String stremioType = "anime".equals(mediaType) ? "anime" : (isMovie ? "movie" : "series");
        return com.eve.cinema.stremio.StremioSourceResolver.hasEnabledStreamAddon(
                        this, stremioType,
                        com.eve.cinema.stremio.StremioSourceResolver.movieId(tmdbId));
    }

    private SourceChoice.Decision mergeCurrentStremioSource(SourceChoice.Decision decision) {
        if (decision == null) return null;
        return SourceChoice.compute(decision.exposes(SourceChoice.SOURCE_MOVIEBOX),
                decision.exposes(SourceChoice.SOURCE_CINEMABOX), hasStremioSource(),
                "anime".equals(mediaType));
    }

    // ViewHolder types
    private static final int VT_BACKDROP  = 0;
    private static final int VT_ACTIONS   = 1;
    private static final int VT_OVERVIEW  = 2;
    private static final int VT_META      = 3;
    private static final int VT_CAST      = 4;
    private static final int VT_BOXOFFICE = 5;
    private static final int VT_SIMILAR   = 6;

    // ── Lifecycle ──────────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MiuiBarFix.apply(this);

        String json = getIntent().getStringExtra("item_json");
        if (json == null) { finish(); return; }
        try { item = new JSONObject(json); }
        catch (Exception e) { finish(); return; }

        mediaType = item.optString("media_type", "movie");
        isMovie   = "movie".equals(mediaType);
        tmdbId    = String.valueOf(item.optInt("id"));

        buildUI();
        populateBasicInfo();
        loadExtraDetails();
        startPrefetch();
        startSourceProbe();
    }

    @Override public void onBackPressed() { navigateBack(); }

    private void navigateBack() {
        finish();
        overridePendingTransition(R.anim.enter_from_left, R.anim.exit_to_right);
    }

    // ── Build UI ──────────────────────────────────────────────────────

    private void buildUI() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(C_VOID);

        masterRecyclerView = new RecyclerView(this);
        masterRecyclerView.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        masterRecyclerView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        masterRecyclerView.setHasFixedSize(false);
        masterRecyclerView.setItemAnimator(null);
        masterRecyclerView.setPadding(0, 0, 0, dpToPx(40));
        masterRecyclerView.setClipToPadding(false);
        masterRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        buildAllHeaders();
        masterAdapter = new MasterAdapter();
        masterRecyclerView.setAdapter(masterAdapter);
        root.addView(masterRecyclerView);
        root.addView(buildBackButton());

        detailLoadingOverlay = new FrameLayout(this);
        detailLoadingOverlay.setBackgroundColor(0xAA06060F);
        detailLoadingOverlay.setVisibility(View.GONE);
        ProgressBar gs = new ProgressBar(this);
        FrameLayout.LayoutParams gsLp = new FrameLayout.LayoutParams(dpToPx(40), dpToPx(40));
        gsLp.gravity = Gravity.CENTER;
        detailLoadingOverlay.addView(gs, gsLp);
        root.addView(detailLoadingOverlay, new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        setContentView(root);

        masterRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override public void onScrolled(RecyclerView rv, int dx, int dy) { applyParallax(rv); }
        });
    }

    private void buildAllHeaders() {
        hdrBackdrop  = buildBackdropView();
        hdrActions   = isMovie ? buildMovieActions() : buildStartWatchingAction();
        hdrOverview  = buildOverviewView();
        hdrMeta      = buildMetaView();
        hdrCastCards = buildCastCardsView();
        hdrBoxOffice = buildBoxOfficeView();
        hdrSimilar   = buildSimilarView();
    }

    // ── Section: Backdrop ─────────────────────────────────────────────

    private View buildBackdropView() {
        FrameLayout frame = new FrameLayout(this);
        frame.setLayoutParams(new RecyclerView.LayoutParams(
            RecyclerView.LayoutParams.MATCH_PARENT, dpToPx(420)));

        detailBackdrop = new ImageView(this);
        detailBackdrop.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        detailBackdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);
        detailBackdrop.setBackgroundColor(0xFF10101E);
        frame.addView(detailBackdrop);

        View grad = new View(this);
        grad.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        grad.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
            new int[]{ C_VOID, 0xF806060F, 0xCC06060F, 0x7706060F, 0x2206060F, Color.TRANSPARENT }));
        frame.addView(grad);

        View topScrim = new View(this);
        FrameLayout.LayoutParams scrimLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, dpToPx(140));
        scrimLp.gravity = Gravity.TOP;
        topScrim.setLayoutParams(scrimLp);
        topScrim.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{ 0xBB000000, 0x55000000, Color.TRANSPARENT }));
        frame.addView(topScrim);

        LinearLayout titleArea = new LinearLayout(this);
        FrameLayout.LayoutParams taLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        taLp.gravity = Gravity.BOTTOM;
        titleArea.setLayoutParams(taLp);
        titleArea.setOrientation(LinearLayout.VERTICAL);
        titleArea.setPadding(dpToPx(18), 0, dpToPx(18), dpToPx(22));

        detailTypeBadge = new TextView(this);
        detailTypeBadge.setTextSize(10.5f);
        detailTypeBadge.setTextColor(C_LITE);
        detailTypeBadge.setTypeface(Typeface.DEFAULT_BOLD);
        detailTypeBadge.setLetterSpacing(0f);
        detailTypeBadge.setPadding(dpToPx(14), dpToPx(5), dpToPx(14), dpToPx(5));
        GradientDrawable tagBg = new GradientDrawable();
        tagBg.setCornerRadius(dpToPx(20));
        tagBg.setColors(new int[]{ 0x33C4A0E8, 0x1A9B6FC4 });
        tagBg.setOrientation(GradientDrawable.Orientation.TL_BR);
        tagBg.setStroke(1, 0x66C4A0E8);
        detailTypeBadge.setBackground(tagBg);
        LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        badgeLp.bottomMargin = dpToPx(12);
        detailTypeBadge.setLayoutParams(badgeLp);
        titleArea.addView(detailTypeBadge);

        detailTitle = new TextView(this);
        detailTitle.setTextSize(29f);
        detailTitle.setTextColor(C_TEXT);
        detailTitle.setTypeface(Typeface.DEFAULT_BOLD);
        detailTitle.setMaxLines(2);
        detailTitle.setLetterSpacing(0f);
        detailTitle.setShadowLayer(18, 0, 3, 0xCC000000);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        titleLp.bottomMargin = dpToPx(10);
        detailTitle.setLayoutParams(titleLp);
        titleArea.addView(detailTitle);

        LinearLayout metaRow = new LinearLayout(this);
        metaRow.setOrientation(LinearLayout.HORIZONTAL);
        metaRow.setGravity(Gravity.CENTER_VERTICAL);

        detailRatingStar = new TextView(this);
        detailRatingStar.setTextSize(12f);
        detailRatingStar.setTextColor(C_STAR);
        LinearLayout.LayoutParams srLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        srLp.rightMargin = dpToPx(14);
        detailRatingStar.setLayoutParams(srLp);
        metaRow.addView(detailRatingStar);

        detailYear = new TextView(this);
        detailYear.setTextSize(12f);
        detailYear.setTextColor(0xFF7070A0);
        LinearLayout.LayoutParams yrLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        yrLp.rightMargin = dpToPx(14);
        detailYear.setLayoutParams(yrLp);
        metaRow.addView(detailYear);

        detailLanguage = new TextView(this);
        detailLanguage.setTextSize(11f);
        detailLanguage.setTextColor(0xFF7070A0);
        metaRow.addView(detailLanguage);

        titleArea.addView(metaRow);
        frame.addView(titleArea);
        return frame;
    }

    // ── Section: Actions ──────────────────────────────────────────────

    private View buildMovieActions() {
        LinearLayout col = new LinearLayout(this);
        col.setLayoutParams(new RecyclerView.LayoutParams(
            RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT));
        col.setOrientation(LinearLayout.VERTICAL);

        LinearLayout row = new LinearLayout(this);
        row.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dpToPx(16), dpToPx(18), dpToPx(16), dpToPx(4));

        detailSoloBtn = buildActionButton("مشاهدة", true, 15f,
            new int[]{ 0xFFCB9AEF, 0xFFAA72D4, C_VIOLET2 }, 0, C_TEXT);
        LinearLayout.LayoutParams soloLp = new LinearLayout.LayoutParams(0, dpToPx(56), 1f);
        soloLp.rightMargin = dpToPx(10);
        detailSoloBtn.setLayoutParams(soloLp);
        detailSoloBtn.setElevation(dpToPx(8));
        applyPressEffect(detailSoloBtn, true);
        detailSoloBtn.setOnClickListener(v -> openPlayer(false));
        row.addView(detailSoloBtn);

        detailPartyBtn = buildActionButton("مشاهدة جماعية", false, 14f,
            new int[]{ 0xFF14142A, 0xFF0F0F22 }, 0x88C4A0E8, C_LITE);
        detailPartyBtn.setLayoutParams(new LinearLayout.LayoutParams(0, dpToPx(56), 1f));
        applyPressEffect(detailPartyBtn, false);
        detailPartyBtn.setOnClickListener(v -> openPlayer(true));
        row.addView(detailPartyBtn);

        col.addView(row);
        col.addView(buildSourceChip());
        return col;
    }

    // ── Source selector chip (P5): مصدر 1 (Stremio) / مصدر 2 — no provider names ──

    private View buildSourceChip() {
        LinearLayout chip = new LinearLayout(this);
        chip.setOrientation(LinearLayout.HORIZONTAL);
        chip.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, dpToPx(36));
        lp.leftMargin = dpToPx(20);
        lp.topMargin = dpToPx(10);
        chip.setLayoutParams(lp);
        chip.setPadding(dpToPx(14), 0, dpToPx(14), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dpToPx(18));
        bg.setColors(new int[]{ 0xFF181832, 0xFF101024 });
        bg.setOrientation(GradientDrawable.Orientation.TL_BR);
        bg.setStroke(dpToPx(1), 0x55C4A0E8);
        chip.setBackground(bg);
        chip.setVisibility(View.GONE); // shown when the probe finishes

        TextView cap = new TextView(this);
        cap.setText("المصدر:");
        cap.setTextColor(C_MUTED);
        cap.setTextSize(12f);
        chip.addView(cap);

        sourceChipTv = new TextView(this);
        sourceChipTv.setTextColor(C_LITE);
        sourceChipTv.setTextSize(13f);
        sourceChipTv.setTypeface(Typeface.DEFAULT_BOLD);
        sourceChipTv.setPadding(dpToPx(8), 0, 0, 0);
        chip.addView(sourceChipTv);

        sourceChipArrow = new TextView(this);
        sourceChipArrow.setText("▼");
        sourceChipArrow.setTextColor(C_MUTED);
        sourceChipArrow.setTextSize(10f);
        sourceChipArrow.setPadding(dpToPx(6), 0, 0, 0);
        chip.addView(sourceChipArrow);

        chip.setOnClickListener(v -> {
            if (sourceDecision == null) startSourceProbe();
            else showSourceSheet();
        });
        sourceChip = chip;
        return chip;
    }

    private View sourceChip;

    private void showSourceSheet() {
        com.eve.cinema.playback.SourceChoice.Decision d = sourceDecision;
        if (d == null || !d.showDropdown) return; // single source / checking: nothing to pick
        java.util.List<GlassChoiceSheet.Row> rows = new ArrayList<>();
        for (int id : d.choices) {
            rows.add(new GlassChoiceSheet.Row(
                    com.eve.cinema.playback.SourceChoice.label(id), null,
                    true, id == selectedSource));
        }
        new GlassChoiceSheet(this, "المصدر", rows, idx -> {
            if (idx >= 0 && idx < d.choices.length) {
                selectedSource = d.choices[idx];
                DiagnosticsRecorder.event("provider", "provider_switch", "selected", DiagnosticsRecorder.details("selectedSource", com.eve.cinema.playback.SourceChoice.label(selectedSource), "sourceId", selectedSource, "tmdbId", tmdbId, "mediaType", mediaType));
                updateSourceChip(d);
            }
        }).show();
    }

    private void updateSourceChip(com.eve.cinema.playback.SourceChoice.Decision d) {
        if (sourceChip == null || sourceChipTv == null) return;
        if (d == null) { sourceChip.setVisibility(View.GONE); return; }
        sourceChip.setVisibility(View.VISIBLE);
        if (d.noSource) {
            sourceChipTv.setText("anime".equals(mediaType) && !hasStremioSource()
                    ? getString(R.string.watch_anime_needs_addon_chip)
                    : "لا يوجد مصدر موثوق");
            sourceChipTv.setTextColor(C_RED);
            sourceChipArrow.setVisibility(View.GONE);
            sourceChip.setClickable(false);
            return;
        }
        sourceChip.setClickable(true);
        int shown = com.eve.cinema.playback.SourceChoice.isValid(selectedSource)
                && d.exposes(selectedSource) ? selectedSource : d.selected;
        selectedSource = shown;
        sourceChipTv.setText(com.eve.cinema.playback.SourceChoice.label(shown));
        sourceChipTv.setTextColor(C_LITE);
        sourceChipArrow.setVisibility(d.showDropdown ? View.VISIBLE : View.GONE);
    }

    /** Kicks off the async provider availability probe (deduplicated, cached). */
    private void startSourceProbe() {
        if (!PlaybackAuthorizationPolicy.hasAuthorizedSource(this)) {
            if (sourceChip != null && sourceChipTv != null) {
                sourceChip.setVisibility(View.VISIBLE);
                sourceChipTv.setText("لا يتوفر مصدر تشغيل مصرّح به حالياً");
                sourceChipTv.setTextColor(C_MUTED);
                sourceChip.setClickable(false);
                if (sourceChipArrow != null) sourceChipArrow.setVisibility(View.GONE);
            }
            return;
        }
        final String key = sourceKey();
        SourceChoice.Decision cached =
                com.eve.cinema.playback.SourceDecisionCache.get(key);
        if (cached != null) {
            cached = mergeCurrentStremioSource(cached);
            sourceDecision = cached;
            sourceProbeOutcome = cached.noSource
                    ? com.eve.cinema.playback.ProbeOutcome.NOT_FOUND_DEFINITIVE
                    : com.eve.cinema.playback.ProbeOutcome.VERIFIED;
            selectedSource = SourceChoice.coerceSelection(cached, selectedSource);
            updateSourceChip(cached);
            maybeWarmCinemaBox(cached);
            return;
        }
        synchronized (sourceProbeLock) {
            if (sourceProbeRunning) return;
            sourceProbeRunning = true;
        }
        if (sourceChip != null && sourceChipTv != null) {
            sourceChip.setVisibility(View.VISIBLE);
            sourceChipTv.setText("جارٍ فحص المصادر…");
            sourceChipTv.setTextColor(C_MUTED);
            if (sourceChipArrow != null) sourceChipArrow.setVisibility(View.GONE);
        }
        new Thread(() -> {
            SourceChoice.Decision d;
            com.eve.cinema.playback.ProbeOutcome outcome;
            boolean authRequired;
            try {
                ProbeResult pr = probeSourcesClassified();
                d = pr.decision;
                outcome = pr.outcome;
                authRequired = pr.authRequired;
            } catch (Throwable t) {
                // Total probe failure = honest no-source state, never a stuck overlay.
                // WP2: a transient failure is NEVER cached as a definitive negative.
                d = SourceChoice.compute(false, false, hasStremioSource(),
                        "anime".equals(mediaType));
                outcome = com.eve.cinema.playback.ProbeOutcome.UNRESOLVED_TRANSIENT;
                authRequired = false;
            }
            synchronized (sourceProbeLock) {
                sourceProbeOutcome = outcome;
                sourceAuthRequired = authRequired;
                // A transient miss is not a decision. Keep the state retryable so
                // pressing Play or tapping the chip can probe again in this session.
                sourceDecision = (!d.noSource || outcome.isResolved()) ? d : null;
                sourceProbeRunning = false;
                sourceProbeLock.notifyAll();
            }
            if (outcome.isResolved())
                com.eve.cinema.playback.SourceDecisionCache.put(key, d, outcome);
            final SourceChoice.Decision fd = d;
            final com.eve.cinema.playback.ProbeOutcome fo = outcome;
            final boolean fa = authRequired;
            runOnUiThread(() -> {
                if (isFinishing()) return;
                if (fo.isResolved() || !fd.noSource) {
                    selectedSource = com.eve.cinema.playback.SourceChoice.coerceSelection(fd, selectedSource);
                    updateSourceChip(fd);
                    maybeWarmCinemaBox(fd);
                } else {
                    if (fa) showCinemaBoxAuthRequired();
                    else showSourceProbeTransient();
                }
                boolean usableDecision = fo.isResolved() || !fd.noSource;
                DiagnosticsRecorder.event("provider", "provider_selection", fo.name(), DiagnosticsRecorder.details("selectedSource", usableDecision ? com.eve.cinema.playback.SourceChoice.label(selectedSource) : "", "sourceId", usableDecision ? selectedSource : 0, "choices", usableDecision ? java.util.Arrays.toString(fd.choices) : "unresolved", "noSource", fo.isResolved() && fd.noSource, "tmdbId", tmdbId, "mediaType", mediaType));
            });
        }).start();
    }

    private void showSourceProbeTransient() {
        if (sourceChip == null || sourceChipTv == null) return;
        sourceChip.setVisibility(View.VISIBLE);
        sourceChip.setClickable(true);
        sourceChipTv.setText("تعذر التحقق من المصادر — اضغط لإعادة المحاولة");
        sourceChipTv.setTextColor(C_MUTED);
        if (sourceChipArrow != null) sourceChipArrow.setVisibility(View.GONE);
    }

    private void showCinemaBoxAuthRequired() {
        if (isFinishing()) return;
        new android.app.AlertDialog.Builder(this)
                .setTitle("يلزم إعداد الحساب")
                .setMessage("لا يمكن التحقق من هذا الخيار دون حساب CinemaBox. يمكنك إضافة حسابك المصرح به من الإعدادات.")
                .setNegativeButton("لاحقاً", null)
                .setPositiveButton("فتح الإعدادات", (dialog, which) ->
                        startActivity(new android.content.Intent(
                                DetailActivity.this, SettingsActivity.class)))
                .show();
    }

    /**
     * Waits (on a background thread) for a running probe, then returns the
     * decision; runs the probe inline when it never started. Never called on
     * the UI thread.
     */
    private SourceChoice.Decision awaitDecision() {
        SourceChoice.Decision d = sourceDecision;
        if (d != null) return d;
        synchronized (sourceProbeLock) {
            long deadline = System.currentTimeMillis() + 25000L;
            while (sourceProbeRunning && sourceDecision == null) {
                long left = deadline - System.currentTimeMillis();
                if (left <= 0) break;
                try { sourceProbeLock.wait(left); } catch (InterruptedException e) { break; }
            }
            d = sourceDecision;
        }
        if (d == null) {
            com.eve.cinema.playback.ProbeOutcome outcome;
            try {
                ProbeResult pr = probeSourcesClassified(); // probe died/timed out — inline
                d = pr.decision;
                outcome = pr.outcome;
                sourceAuthRequired = pr.authRequired;
            } catch (Throwable t) {
                d = SourceChoice.compute(false, false, hasStremioSource(),
                        "anime".equals(mediaType));
                outcome = com.eve.cinema.playback.ProbeOutcome.UNRESOLVED_TRANSIENT;
                sourceAuthRequired = false;
            }
            sourceProbeOutcome = outcome;
            sourceDecision = (!d.noSource || outcome.isResolved()) ? d : null;
            if (outcome.isResolved())
                com.eve.cinema.playback.SourceDecisionCache.put(sourceKey(), d, outcome);
        }
        return d;
    }

    /** The decision plus whether it may be cached (never on a transient failure). */
    private static final class ProbeResult {
        final SourceChoice.Decision decision;
        final com.eve.cinema.playback.ProbeOutcome outcome;
        final boolean authRequired;
        ProbeResult(SourceChoice.Decision decision,
                    com.eve.cinema.playback.ProbeOutcome outcome,
                    boolean authRequired) {
            this.decision = decision;
            this.outcome = outcome;
            this.authRequired = authRequired;
        }
    }

    /**
     * Network probe: verified title/type/year match per provider. Anime → MovieBox only.
     * WP2: each provider's answer is CLASSIFIED — the combined decision is cached
     * only when no probe ended in a transient failure (I6).
     */
    private ProbeResult probeSourcesClassified() {
        final boolean anime = "anime".equals(mediaType);
        if (!PlaybackAuthorizationPolicy.hasAuthorizedSource(this))
            return new ProbeResult(SourceChoice.compute(false, false, hasStremioSource(), anime),
                    com.eve.cinema.playback.ProbeOutcome.UNRESOLVED_TRANSIENT, false);
        String title = item.optString("title", item.optString("name", ""));
        final String origTitle = item.optString("original_title",
                                     item.optString("original_name", null));
        final int year = extractYear(item.optString(
                isMovie ? "release_date" : "first_air_date",
                item.optString("release_date", "")));
        if (isNonLatinText(title)) {
            String en = fetchEnglishTitle();
            if (en != null && !en.isEmpty()) title = en;
        }
        final String probeTitle = title;

        // Providers are independent. The wave controller runs both concurrently
        // under soft/hard budgets, so a CinemaBox outage cannot serially hold
        // back a verified MovieBox result (early publish, plan §1.3).
        com.eve.cinema.providers.ProviderProbeGateway.Result probes =
                com.eve.cinema.providers.EveProviders.get(DetailActivity.this)
                        .probeSources(tmdbId, probeTitle, origTitle, year, !isMovie, anime);
        boolean mb = probes.movieBoxVerified();
        boolean cb = probes.cinemaBoxVerified();
        boolean stremio = hasStremioSource();
        com.eve.cinema.playback.ResolutionTrace.record("probe.details", probes.combined.name(),
                "mb=" + probes.movieBox + " cb="
                        + (anime ? "anime-skip" : String.valueOf(probes.cinemaBox)));
        return new ProbeResult(SourceChoice.compute(mb, cb, stremio, anime), probes.combined,
                probes.authRequired);
    }

    private boolean isNonLatinText(String s) {
        if (s == null || s.isEmpty()) return false;
        int latin = 0, total = 0;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (Character.isLetter(ch)) {
                total++;
                if (ch < 0x0370) latin++;
            }
        }
        return total > 0 && latin * 2 < total;
    }

    /** English display name from TMDB for non-Latin titles (provider search needs Latin). */
    private String fetchEnglishTitle() {
        try {
            String kind = isMovie ? "movie" : "tv";
            JSONObject en = fetchJson("https://api.themoviedb.org/3/" + kind + "/" + tmdbId + "?language=en-US");
            if (en == null) return null;
            String name = en.optString(isMovie ? "title" : "name", "").trim();
            if (!name.isEmpty() && !isNonLatinText(name)) return name;
            int c = name.indexOf(':');
            if (c > 2) {
                String base = name.substring(0, c).trim();
                if (!isNonLatinText(base)) return base;
            }
        } catch (Exception ignored) {}
        return null;
    }

    /** زر إجراء موحد: أيقونة تشغيل (vector) + نص — بلا محارف نصية رخيصة */
    private View buildActionButton(String label, boolean withPlayIcon, float textSp,
                                   int[] bgColors, int strokeColor, int textColor) {
        LinearLayout btn = new LinearLayout(this);
        btn.setOrientation(LinearLayout.HORIZONTAL);
        btn.setGravity(Gravity.CENTER);
        btn.setClickable(true);
        btn.setFocusable(true);

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dpToPx(16));
        bg.setColors(bgColors);
        bg.setOrientation(GradientDrawable.Orientation.TL_BR);
        if (strokeColor != 0) bg.setStroke(dpToPx(1), strokeColor);
        btn.setBackground(bg);

        if (withPlayIcon) {
            ImageView play = new ImageView(this);
            LinearLayout.LayoutParams pLp = new LinearLayout.LayoutParams(dpToPx(17), dpToPx(17));
            pLp.rightMargin = dpToPx(9);
            play.setLayoutParams(pLp);
            play.setImageResource(R.drawable.ic_play_filled);
            play.setColorFilter(C_TEXT);
            btn.addView(play);
        }

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(textColor);
        tv.setTextSize(textSp);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setLetterSpacing(0f);
        tv.setMaxLines(1);
        btn.addView(tv);

        return btn;
    }

    private View buildStartWatchingAction() {
        LinearLayout col = new LinearLayout(this);
        col.setLayoutParams(new RecyclerView.LayoutParams(
            RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT));
        col.setOrientation(LinearLayout.VERTICAL);

        FrameLayout container = new FrameLayout(this);
        container.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        startWatchingBtn = buildActionButton("ابدأ المشاهدة", true, 16f,
            new int[]{ 0xFFCDA0F0, 0xFF9B6FC4, 0xFF6630A0 }, 0, C_TEXT);
        FrameLayout.LayoutParams btnLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, dpToPx(58));
        btnLp.setMargins(dpToPx(20), dpToPx(18), dpToPx(20), dpToPx(8));
        startWatchingBtn.setLayoutParams(btnLp);
        ((GradientDrawable) startWatchingBtn.getBackground()).setCornerRadius(dpToPx(28));
        startWatchingBtn.setElevation(dpToPx(10));
        applyPressEffect(startWatchingBtn, true);
        startWatchingBtn.setOnClickListener(v -> openEpisodesScreen());
        container.addView(startWatchingBtn);
        col.addView(container);
        col.addView(buildSourceChip());
        return col;
    }

    // ── Section: Overview ─────────────────────────────────────────────

    private View buildOverviewView() {
        LinearLayout col = new LinearLayout(this);
        col.setLayoutParams(new RecyclerView.LayoutParams(
            RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT));
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dpToPx(18), dpToPx(20), dpToPx(18), dpToPx(4));

        detailOverview = new TextView(this);
        detailOverview.setTextSize(14f);
        detailOverview.setTextColor(0xFFB8B8D8);
        detailOverview.setLineSpacing(0, 1.80f);
        detailOverview.setMaxLines(4);
        detailOverview.setEllipsize(android.text.TextUtils.TruncateAt.END);
        col.addView(detailOverview);

        detailReadMore = new TextView(this);
        LinearLayout.LayoutParams rmLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rmLp.topMargin = dpToPx(6);
        detailReadMore.setLayoutParams(rmLp);
        detailReadMore.setText("اقرأ أكثر");
        setReadMoreChevron(detailReadMore, false);
        detailReadMore.setTextSize(12f);
        detailReadMore.setTextColor(C_VIOLET);
        detailReadMore.setLetterSpacing(0f);
        detailReadMore.setClickable(true);
        detailReadMore.setFocusable(true);
        detailReadMore.setVisibility(View.GONE);
        detailReadMore.setOnClickListener(v -> {
            overviewExpanded = !overviewExpanded;
            detailOverview.setMaxLines(overviewExpanded ? Integer.MAX_VALUE : 4);
            detailReadMore.setText(overviewExpanded ? "إخفاء" : "اقرأ أكثر");
            setReadMoreChevron(detailReadMore, overviewExpanded);
        });
        col.addView(detailReadMore);
        return col;
    }

    // سهم «اقرأ أكثر»: يشير لاتجاه النهاية عند التوسيع، ولأعلى عند الطيّ (يتعامل مع RTL)
    private void setReadMoreChevron(TextView tv, boolean expanded) {
        android.graphics.drawable.Drawable base = getDrawable(R.drawable.ic_chevron_end);
        if (base == null) return;
        android.graphics.drawable.Drawable d = base;
        if (expanded) {
            boolean rtl = getResources().getConfiguration().getLayoutDirection() == View.LAYOUT_DIRECTION_RTL;
            android.graphics.drawable.RotateDrawable rot = new android.graphics.drawable.RotateDrawable();
            rot.setDrawable(base);
            rot.setFromDegrees(0f);
            rot.setToDegrees(360f);
            rot.setLevel(rtl ? 2500 : 7500); // 90° من اليسار / 270° من اليمين = لأعلى
            d = rot;
        }
        int s = dpToPx(13);
        d.setBounds(0, 0, s, s);
        tv.setCompoundDrawablesRelative(null, null, d, null);
        tv.setCompoundDrawablePadding(dpToPx(6));
    }

    // ── Section: Meta cards (rating, year, lang, director, cast text) ─

    private View buildMetaView() {
        LinearLayout outer = new LinearLayout(this);
        outer.setLayoutParams(new RecyclerView.LayoutParams(
            RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT));
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dpToPx(16), dpToPx(18), dpToPx(16), dpToPx(4));

        // Row: Rating / Year / Language
        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams topRowLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        topRowLp.bottomMargin = dpToPx(10);
        topRow.setLayoutParams(topRowLp);

        LinearLayout ratingCard = makeSmallCard(true);
        ratingCard.addView(makeCardLabel("التقييم"));
        detailRating = makeCardValue(C_STAR, 16f, false);
        ratingCard.addView(detailRating);
        topRow.addView(ratingCard);

        LinearLayout yearCard = makeSmallCard(false);
        yearCard.addView(makeCardLabel("السنة"));
        detailYear2 = makeCardValue(0xFFC8C8E0, 16f, false);
        yearCard.addView(detailYear2);
        topRow.addView(yearCard);

        LinearLayout langCard = makeSmallCard(false);
        langCard.addView(makeCardLabel("اللغة"));
        detailLang2 = makeCardValue(0xFFC8C8E0, 14f, false);
        langCard.addView(detailLang2);
        topRow.addView(langCard);
        outer.addView(topRow);

        // Director card
        LinearLayout dirCard = makeFullCard(dpToPx(10));
        dirCard.addView(makeCardLabel("المخرج"));
        detailDirector = makeCardValue(0xFFB090D8, 13.5f, true);
        dirCard.addView(detailDirector);
        outer.addView(dirCard);

        // Cast text card
        LinearLayout castCard = makeFullCard(0);
        castCard.addView(makeCardLabel("أبرز الممثلين"));
        detailCast = makeCardValue(0xFF8888A8, 13f, true);
        castCard.addView(detailCast);
        outer.addView(castCard);

        return outer;
    }

    // ── Section: Cast photo cards ─────────────────────────────────────

    private View buildCastCardsView() {
        LinearLayout outer = new LinearLayout(this);
        outer.setLayoutParams(new RecyclerView.LayoutParams(
            RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT));
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(0, dpToPx(24), 0, dpToPx(4));

        // Section header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams hLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hLp.bottomMargin = dpToPx(16);
        header.setLayoutParams(hLp);
        header.setPadding(dpToPx(18), 0, dpToPx(18), 0);

        View accent = new View(this);
        LinearLayout.LayoutParams aLp = new LinearLayout.LayoutParams(dpToPx(4), dpToPx(26));
        aLp.rightMargin = dpToPx(12);
        accent.setLayoutParams(aLp);
        GradientDrawable accentBg = new GradientDrawable();
        accentBg.setCornerRadius(dpToPx(3));
        accentBg.setColors(new int[]{ 0xFFD4A0F8, C_VIOLET2, 0x449B6FC4 });
        accentBg.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
        accent.setBackground(accentBg);
        header.addView(accent);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setLayoutParams(new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView secTitle = new TextView(this);
        secTitle.setText("طاقم التمثيل");
        secTitle.setTextSize(17f);
        secTitle.setTextColor(C_TEXT);
        secTitle.setTypeface(Typeface.DEFAULT_BOLD);
        secTitle.setLetterSpacing(0f);
        titleCol.addView(secTitle);

        TextView secSub = new TextView(this);
        secSub.setText("Cast & Characters");
        secSub.setTextSize(11f);
        secSub.setTextColor(0xFF4E4E70);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        subLp.topMargin = dpToPx(2);
        secSub.setLayoutParams(subLp);
        titleCol.addView(secSub);
        header.addView(titleCol);
        outer.addView(header);

        // Horizontal scroll of cast photo cards
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.setOverScrollMode(View.OVER_SCROLL_NEVER);

        castPhotoRow = new LinearLayout(this);
        castPhotoRow.setOrientation(LinearLayout.HORIZONTAL);
        castPhotoRow.setPadding(dpToPx(14), 0, dpToPx(14), dpToPx(4));
        hsv.addView(castPhotoRow);
        outer.addView(hsv);
        return outer;
    }

    // ── Section: Box Office ───────────────────────────────────────────

    private View buildBoxOfficeView() {
        LinearLayout outer = new LinearLayout(this);
        outer.setLayoutParams(new RecyclerView.LayoutParams(
            RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT));
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(dpToPx(16), dpToPx(24), dpToPx(16), dpToPx(4));

        // Section header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams hLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hLp.bottomMargin = dpToPx(16);
        header.setLayoutParams(hLp);

        View accent = new View(this);
        LinearLayout.LayoutParams aLp = new LinearLayout.LayoutParams(dpToPx(4), dpToPx(26));
        aLp.rightMargin = dpToPx(12);
        accent.setLayoutParams(aLp);
        GradientDrawable accentBg = new GradientDrawable();
        accentBg.setCornerRadius(dpToPx(3));
        accentBg.setColors(new int[]{ 0xFFD4A0F8, C_VIOLET2, 0x449B6FC4 });
        accentBg.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
        accent.setBackground(accentBg);
        header.addView(accent);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setLayoutParams(new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView secTitle = new TextView(this);
        secTitle.setText("إيرادات الفيلم");
        secTitle.setTextSize(17f);
        secTitle.setTextColor(C_TEXT);
        secTitle.setTypeface(Typeface.DEFAULT_BOLD);
        secTitle.setLetterSpacing(0f);
        titleCol.addView(secTitle);

        TextView secSub = new TextView(this);
        secSub.setText("Box Office Performance");
        secSub.setTextSize(11f);
        secSub.setTextColor(0xFF4E4E70);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        subLp.topMargin = dpToPx(2);
        secSub.setLayoutParams(subLp);
        titleCol.addView(secSub);
        header.addView(titleCol);
        outer.addView(header);

        // Cards row: Budget | Revenue | ROI
        LinearLayout cardsRow = new LinearLayout(this);
        cardsRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams crLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        crLp.bottomMargin = dpToPx(14);
        cardsRow.setLayoutParams(crLp);

        // Budget card
        LinearLayout budgetCard = makeSmallCard(true);
        budgetCard.addView(makeCardLabel("الميزانية"));
        tvBudget = makeCardValue(0xFF80B0FF, 13f, false);
        tvBudget.setText("—");
        budgetCard.addView(tvBudget);
        cardsRow.addView(budgetCard);

        // Revenue card
        LinearLayout revenueCard = makeSmallCard(false);
        revenueCard.addView(makeCardLabel("الإيرادات"));
        tvRevenue = makeCardValue(0xFF80FFB0, 13f, false);
        tvRevenue.setText("—");
        revenueCard.addView(tvRevenue);
        cardsRow.addView(revenueCard);

        // ROI card
        LinearLayout roiCard = makeSmallCard(false);
        roiCard.addView(makeCardLabel("نسبة الربح"));
        tvRoi = makeCardValue(C_MUTED, 14f, false);
        tvRoi.setText("—");
        roiCard.addView(tvRoi);
        cardsRow.addView(roiCard);
        outer.addView(cardsRow);

        // ROI label and progress bar
        tvRoiLabel = new TextView(this);
        tvRoiLabel.setTextSize(11f);
        tvRoiLabel.setTextColor(C_LABEL);
        tvRoiLabel.setText("العائد على الاستثمار");
        LinearLayout.LayoutParams rlLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rlLp.bottomMargin = dpToPx(8);
        tvRoiLabel.setLayoutParams(rlLp);
        outer.addView(tvRoiLabel);

        // Progress bar background
        FrameLayout barBg = new FrameLayout(this);
        LinearLayout.LayoutParams barBgLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(8));
        barBgLp.bottomMargin = dpToPx(4);
        barBg.setLayoutParams(barBgLp);
        GradientDrawable barBgShape = new GradientDrawable();
        barBgShape.setCornerRadius(dpToPx(4));
        barBgShape.setColor(0xFF1A1A30);
        barBgShape.setStroke(1, 0xFF1E1E3A);
        barBg.setBackground(barBgShape);

        roiBarFill = new View(this);
        FrameLayout.LayoutParams fillLp = new FrameLayout.LayoutParams(0, dpToPx(8));
        fillLp.gravity = Gravity.START;
        roiBarFill.setLayoutParams(fillLp);
        GradientDrawable fillShape = new GradientDrawable();
        fillShape.setCornerRadius(dpToPx(4));
        fillShape.setColor(C_MUTED);
        roiBarFill.setBackground(fillShape);
        barBg.addView(roiBarFill);
        outer.addView(barBg);

        return outer;
    }

    // ── Section: Similar works ────────────────────────────────────────

    private View buildSimilarView() {
        LinearLayout outer = new LinearLayout(this);
        outer.setLayoutParams(new RecyclerView.LayoutParams(
            RecyclerView.LayoutParams.MATCH_PARENT, RecyclerView.LayoutParams.WRAP_CONTENT));
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setPadding(0, dpToPx(24), 0, dpToPx(16));

        // Section header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams hLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        hLp.bottomMargin = dpToPx(16);
        header.setLayoutParams(hLp);
        header.setPadding(dpToPx(18), 0, dpToPx(18), 0);

        View accent = new View(this);
        LinearLayout.LayoutParams aLp = new LinearLayout.LayoutParams(dpToPx(4), dpToPx(26));
        aLp.rightMargin = dpToPx(12);
        accent.setLayoutParams(aLp);
        GradientDrawable accentBg = new GradientDrawable();
        accentBg.setCornerRadius(dpToPx(3));
        accentBg.setColors(new int[]{ 0xFFD4A0F8, C_VIOLET2, 0x449B6FC4 });
        accentBg.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
        accent.setBackground(accentBg);
        header.addView(accent);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setLayoutParams(new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView secTitle = new TextView(this);
        secTitle.setText("أعمال مشابهة");
        secTitle.setTextSize(17f);
        secTitle.setTextColor(C_TEXT);
        secTitle.setTypeface(Typeface.DEFAULT_BOLD);
        secTitle.setLetterSpacing(0f);
        titleCol.addView(secTitle);

        TextView secSub = new TextView(this);
        secSub.setText("You might also like");
        secSub.setTextSize(11f);
        secSub.setTextColor(0xFF4E4E70);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        subLp.topMargin = dpToPx(2);
        secSub.setLayoutParams(subLp);
        titleCol.addView(secSub);
        header.addView(titleCol);
        outer.addView(header);

        // Horizontal scroll
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.setOverScrollMode(View.OVER_SCROLL_NEVER);

        similarRow = new LinearLayout(this);
        similarRow.setOrientation(LinearLayout.HORIZONTAL);
        similarRow.setPadding(dpToPx(14), 0, dpToPx(14), dpToPx(4));

        similarEmptyTv = new TextView(this);
        similarEmptyTv.setText("لا توجد أعمال مشابهة");
        similarEmptyTv.setTextSize(13f);
        similarEmptyTv.setTextColor(C_LABEL);
        similarEmptyTv.setPadding(dpToPx(4), dpToPx(10), 0, dpToPx(10));
        similarEmptyTv.setVisibility(View.GONE);
        similarRow.addView(similarEmptyTv);

        hsv.addView(similarRow);
        outer.addView(hsv);
        return outer;
    }

    // ── Helpers: card builders ────────────────────────────────────────

    private LinearLayout makeSmallCard(boolean first) {
        LinearLayout card = new LinearLayout(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        if (!first) lp.leftMargin = dpToPx(8);
        card.setLayoutParams(lp);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dpToPx(14), dpToPx(14), dpToPx(14), dpToPx(14));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dpToPx(14));
        bg.setColors(new int[]{ 0xFF151526, C_CARD });
        bg.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
        bg.setStroke(dpToPx(1), 0xFF1C1C36);
        card.setBackground(bg);
        return card;
    }

    private LinearLayout makeFullCard(int bottomMargin) {
        LinearLayout card = new LinearLayout(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = bottomMargin;
        card.setLayoutParams(lp);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dpToPx(16), dpToPx(15), dpToPx(16), dpToPx(15));
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dpToPx(14));
        bg.setColors(new int[]{ 0xFF151526, C_CARD });
        bg.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
        bg.setStroke(dpToPx(1), 0xFF1C1C36);
        card.setBackground(bg);
        return card;
    }

    private TextView makeCardLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(10.5f);
        tv.setTextColor(0xFF5A5A7A);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setLetterSpacing(0f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dpToPx(7);
        tv.setLayoutParams(lp);
        return tv;
    }

    private TextView makeCardValue(int color, float sizeSp, boolean multiline) {
        TextView tv = new TextView(this);
        tv.setTextSize(sizeSp);
        tv.setTextColor(color);
        if (multiline) { tv.setLineSpacing(0, 1.55f); }
        else           { tv.setTypeface(Typeface.DEFAULT_BOLD); }
        return tv;
    }

    // ── Back button ───────────────────────────────────────────────────

    private View buildBackButton() {
        FrameLayout container = new FrameLayout(this);
        container.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));

        FrameLayout btn = new FrameLayout(this);
        FrameLayout.LayoutParams btnLp = new FrameLayout.LayoutParams(dpToPx(44), dpToPx(44));
        btnLp.gravity    = Gravity.TOP | Gravity.START;
        btnLp.topMargin  = dpToPx(14);
        btnLp.leftMargin = dpToPx(14);
        btn.setLayoutParams(btnLp);
        btn.setClickable(true);
        btn.setFocusable(true);
        GradientDrawable btnBg = new GradientDrawable();
        btnBg.setShape(GradientDrawable.OVAL);
        btnBg.setColors(new int[]{ 0xEE0E0E22, 0xCC08080F });
        btnBg.setOrientation(GradientDrawable.Orientation.TL_BR);
        btnBg.setStroke(1, 0x44FFFFFF);
        btn.setBackground(btnBg);

        ImageView icon = new ImageView(this);
        FrameLayout.LayoutParams iconLp = new FrameLayout.LayoutParams(dpToPx(20), dpToPx(20));
        iconLp.gravity = Gravity.CENTER;
        icon.setLayoutParams(iconLp);
        icon.setImageResource(R.drawable.ic_back);
        icon.setColorFilter(Color.WHITE);
        btn.addView(icon);

        applyPressEffect(btn, false);
        btn.setOnClickListener(v -> navigateBack());
        container.addView(btn);
        return container;
    }

    // ── Populate basic info ───────────────────────────────────────────

    private void populateBasicInfo() {
        String title = item.optString("title", "");
        if (title.isEmpty()) title = item.optString("name", "");

        double rating = item.optDouble("vote_average", 0);
        String date   = item.optString("release_date", "");
        if (date.isEmpty()) date = item.optString("first_air_date", "");
        String year   = date.length() >= 4 ? date.substring(0, 4) : date;
        String lang   = item.optString("original_language", "").toUpperCase();
        String overview = item.optString("overview", "");

        String typeBadge = isMovie ? "فيلم" : "anime".equals(mediaType) ? "أنمي" : "مسلسل";
        detailTypeBadge.setText(typeBadge);
        detailTypeBadge.setLetterSpacing(0f); // letterSpacing يفكّك اتصال الحروف العربية
        animateFadeSlide(detailTypeBadge, 300, 40);

        detailTitle.setText(title);
        animateFadeSlide(detailTitle, 380, 80);

        detailRatingStar.setText(rating > 0
            ? "\u2605 " + String.format(Locale.US, "%.1f", rating) : "");
        detailRatingStar.setTextLocale(Locale.US);
        animateFadeSlide(detailRatingStar, 380, 140);

        detailYear.setText(year);
        animateFadeSlide(detailYear, 380, 160);
        detailLanguage.setText(lang);
        animateFadeSlide(detailLanguage, 380, 180);

        detailRating.setText(rating > 0
            ? String.format(Locale.US, "%.1f / 10", rating) : "\u2014");
        detailRating.setTextLocale(Locale.US);
        detailYear2.setText(year.isEmpty() ? "\u2014" : year);
        detailLang2.setText(lang.isEmpty() ? "\u2014" : lang);
        detailDirector.setText("\u2014");
        detailCast.setText("\u2014");

        final String ovText = overview.isEmpty() ? "لا يوجد وصف متاح لهذا العمل حالياً." : overview;
        detailOverview.setText(ovText);
        detailOverview.post(() -> {
            if (detailOverview.getLineCount() > 4)
                detailReadMore.setVisibility(View.VISIBLE);
        });

        if (!isMovie && startWatchingBtn != null)
            animateFadeSlide(startWatchingBtn, 500, 240);

        String backdrop = item.optString("backdrop_path", "");
        if (!backdrop.isEmpty()) {
            detailBackdrop.setScaleX(1.10f);
            detailBackdrop.setScaleY(1.10f);
            detailBackdrop.setAlpha(0f);
            com.bumptech.glide.Glide.with(this)
                .load(IMG_BASE_O + backdrop)
                .centerCrop()
                .transition(com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
                    .withCrossFade(500))
                .listener(new com.bumptech.glide.request.RequestListener<android.graphics.drawable.Drawable>() {
                    @Override
                    public boolean onResourceReady(android.graphics.drawable.Drawable r, Object m,
                        com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> t,
                        com.bumptech.glide.load.DataSource d, boolean f) {
                        detailBackdrop.animate().cancel();
                        detailBackdrop.animate().alpha(1f).scaleX(1f).scaleY(1f)
                            .setDuration(800).setInterpolator(new DecelerateInterpolator(2.5f)).start();
                        return false;
                    }
                    @Override
                    public boolean onLoadFailed(com.bumptech.glide.load.engine.GlideException e,
                        Object m, com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> t,
                        boolean f) {
                        detailBackdrop.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(300).start();
                        return false;
                    }
                }).into(detailBackdrop);
        }
    }

    // ── Load extra details (credits, box office, similar) ─────────────

    private void loadExtraDetails() {
        if (detailLoadingOverlay != null) detailLoadingOverlay.setVisibility(View.VISIBLE);
        new CreditsTask().execute();
        new ArabicOverviewTask().execute();
        if (isMovie) new BoxOfficeTask().execute();
        new SimilarTask().execute();
    }

    // ── AsyncTask: Credits ────────────────────────────────────────────

    private class CreditsTask extends AsyncTask<Void, Void, JSONObject> {
        @Override
        protected JSONObject doInBackground(Void... p) {
            try { return fetchJson("https://api.themoviedb.org/3/" + mediaType + "/" + tmdbId
                    + "/credits?language=en-US"); }
            catch (Exception e) { return null; }
        }
        @Override
        protected void onPostExecute(JSONObject credits) {
            if (detailLoadingOverlay != null) detailLoadingOverlay.setVisibility(View.GONE);
            if (credits == null) return;

            // Director text
            try {
                JSONArray crew = credits.optJSONArray("crew");
                if (crew != null) {
                    StringBuilder dirs = new StringBuilder();
                    for (int i = 0; i < crew.length(); i++) {
                        JSONObject m = crew.getJSONObject(i);
                        if ("Director".equals(m.optString("job", ""))) {
                            if (dirs.length() > 0) dirs.append("، ");
                            dirs.append(m.optString("name", ""));
                        }
                    }
                    if (detailDirector != null)
                        detailDirector.setText(dirs.length() > 0 ? dirs.toString() : "\u2014");
                }
            } catch (Exception ignored) {}

            // Cast text (short)
            try {
                JSONArray cast = credits.optJSONArray("cast");
                if (cast != null) {
                    StringBuilder sb = new StringBuilder();
                    int limit = Math.min(cast.length(), 5);
                    for (int i = 0; i < limit; i++) {
                        if (sb.length() > 0) sb.append("، ");
                        sb.append(cast.getJSONObject(i).optString("name", ""));
                    }
                    if (detailCast != null)
                        detailCast.setText(sb.length() > 0 ? sb.toString() : "\u2014");
                }
            } catch (Exception ignored) {}

            // Cast PHOTO cards
            try {
                JSONArray cast = credits.optJSONArray("cast");
                if (cast != null && castPhotoRow != null) {
                    castPhotoRow.removeAllViews();
                    int limit = Math.min(cast.length(), 12);
                    for (int i = 0; i < limit; i++) {
                        JSONObject actor = cast.getJSONObject(i);
                        String name      = actor.optString("name", "");
                        String character = actor.optString("character", "");
                        String profile   = actor.optString("profile_path", "");
                        int    actorId   = actor.optInt("id", 0);
                        castPhotoRow.addView(buildCastCard(name, character, profile, actorId));
                    }
                }
            } catch (Exception ignored) {}
        }
    }

    // ── Build a single cast photo card ────────────────────────────────

    private View buildCastCard(String name, String character, String profilePath, int actorId) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
            dpToPx(90), LinearLayout.LayoutParams.WRAP_CONTENT);
        cardLp.rightMargin = dpToPx(12);
        card.setLayoutParams(cardLp);
        card.setPadding(0, 0, 0, dpToPx(6));
        card.setClickable(true);
        card.setFocusable(true);
        if (actorId != 0) {
            final int fId = actorId;
            final String fName = name;
            final String fProfile = profilePath;
            card.setOnClickListener(v -> {
                android.content.Intent intent =
                    new android.content.Intent(this, ActorActivity.class);
                intent.putExtra("actor_id",      fId);
                intent.putExtra("actor_name",    fName);
                intent.putExtra("actor_profile", fProfile);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            });
        }

        // Circular photo
        FrameLayout photoFrame = new FrameLayout(this);
        LinearLayout.LayoutParams pfLp = new LinearLayout.LayoutParams(
            dpToPx(72), dpToPx(72));
        pfLp.bottomMargin = dpToPx(8);
        pfLp.gravity = Gravity.CENTER_HORIZONTAL;
        photoFrame.setLayoutParams(pfLp);

        ImageView photo = new ImageView(this);
        FrameLayout.LayoutParams photoLp = new FrameLayout.LayoutParams(
            dpToPx(72), dpToPx(72));
        photo.setLayoutParams(photoLp);
        photo.setScaleType(ImageView.ScaleType.CENTER_CROP);

        // Circular shape
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(C_CARD2);
        circle.setStroke(dpToPx(2), 0xFF6B4A8E);
        photo.setBackground(circle);
        photo.setClipToOutline(true);
        photo.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override
            public void getOutline(View view, android.graphics.Outline outline) {
                outline.setOval(0, 0, view.getWidth(), view.getHeight());
            }
        });

        if (!profilePath.isEmpty()) {
            com.bumptech.glide.Glide.with(this)
                .load(IMG_BASE_F + profilePath)
                .centerCrop()
                .circleCrop()
                .placeholder(circle)
                .into(photo);
        } else {
            // Placeholder: initials
            photo.setBackgroundColor(C_CARD2);
        }
        photoFrame.addView(photo);
        card.addView(photoFrame);

        // Name
        TextView nameTv = new TextView(this);
        nameTv.setText(name);
        nameTv.setTextSize(11f);
        nameTv.setTextColor(0xFFD0D0EE);
        nameTv.setTypeface(Typeface.DEFAULT_BOLD);
        nameTv.setGravity(Gravity.CENTER);
        nameTv.setMaxLines(2);
        nameTv.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams nameLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        nameTv.setLayoutParams(nameLp);
        card.addView(nameTv);

        // Character
        if (!character.isEmpty()) {
            TextView charTv = new TextView(this);
            // Strip "as " prefix if present
            String charText = character.startsWith("as ") ? character.substring(3) : character;
            charTv.setText(charText);
            charTv.setTextSize(10f);
            charTv.setTextColor(C_MUTED);
            charTv.setGravity(Gravity.CENTER);
            charTv.setMaxLines(1);
            charTv.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams charLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            charLp.topMargin = dpToPx(2);
            charTv.setLayoutParams(charLp);
            card.addView(charTv);
        }

        applyPressEffect(card, false);
        return card;
    }

    // ── AsyncTask: Box Office ─────────────────────────────────────────

    private class BoxOfficeTask extends AsyncTask<Void, Void, JSONObject> {
        @Override
        protected JSONObject doInBackground(Void... p) {
            try { return fetchJson("https://api.themoviedb.org/3/movie/" + tmdbId
                    + "?language=en-US"); }
            catch (Exception e) { return null; }
        }
        @Override
        protected void onPostExecute(JSONObject data) {
            if (data == null) return;
            long budget  = data.optLong("budget",  0);
            long revenue = data.optLong("revenue", 0);

            if (tvBudget  != null) tvBudget.setText(formatMoney(budget));
            if (tvRevenue != null) tvRevenue.setText(formatMoney(revenue));

            if (budget > 0 && revenue > 0) {
                double roi = ((double)(revenue - budget) / budget) * 100.0;
                String roiStr = (roi >= 0 ? "+" : "") + String.format(Locale.US, "%.0f%%", roi);
                if (tvRoi != null) {
                    tvRoi.setText(roiStr);
                    tvRoi.setTextColor(roi >= 0 ? C_GREEN : C_RED);
                    tvRoi.setTypeface(Typeface.DEFAULT_BOLD);
                }
                // Animate the bar
                if (roiBarFill != null && roiBarFill.getParent() != null) {
                    final double finalRoi = roi;
                    final int barColor    = roi >= 0 ? C_GREEN : C_RED;
                    roiBarFill.post(() -> {
                        View barContainer = (View) roiBarFill.getParent();
                        int  totalWidth   = barContainer.getWidth();
                        // Cap fill at 100% visual, handle negative as partial fill
                        double fillRatio = roi >= 0
                            ? Math.min(roi / 300.0, 1.0)          // cap at 300% ROI = full bar
                            : Math.max(1.0 + (roi / 100.0), 0.05); // loss: shrink bar
                        int fillWidth = (int)(totalWidth * fillRatio);
                        GradientDrawable fillBg = new GradientDrawable();
                        fillBg.setCornerRadius(dpToPx(4));
                        if (roi >= 0) {
                            fillBg.setColors(new int[]{ 0xFF56D364, barColor });
                            fillBg.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
                        } else {
                            fillBg.setColors(new int[]{ barColor, 0xFFFF8A80 });
                            fillBg.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
                        }
                        roiBarFill.setBackground(fillBg);

                        android.animation.ValueAnimator anim =
                            android.animation.ValueAnimator.ofInt(0, fillWidth);
                        anim.setDuration(900);
                        anim.setInterpolator(new DecelerateInterpolator(2f));
                        anim.addUpdateListener(a -> {
                            ViewGroup.LayoutParams lp = roiBarFill.getLayoutParams();
                            lp.width = (int) a.getAnimatedValue();
                            roiBarFill.setLayoutParams(lp);
                        });
                        anim.start();
                    });
                }
                if (tvRoiLabel != null) {
                    tvRoiLabel.setText(revenue >= budget
                        ? "الفيلم حقق أرباحاً" : "الفيلم لم يستعد ميزانيته");
                    tvRoiLabel.setTextColor(revenue >= budget ? 0xFF66BB6A : 0xFFEF5350);
                    tvRoiLabel.setTypeface(Typeface.DEFAULT_BOLD);
                }
            } else {
                if (tvRoi     != null) tvRoi.setText("N/A");
                if (tvRoiLabel != null) tvRoiLabel.setText("بيانات الإيرادات غير متاحة");
            }
        }
    }

    // ── AsyncTask: Similar ────────────────────────────────────────────

    private class SimilarTask extends AsyncTask<Void, Void, JSONArray> {
        @Override
        protected JSONArray doInBackground(Void... p) {
            try {
                String type = "anime".equals(mediaType) ? "tv" : mediaType;
                JSONObject res = fetchJson("https://api.themoviedb.org/3/" + type + "/" + tmdbId
                    + "/similar?language=ar&page=1");
                if (res != null) return res.optJSONArray("results");
            } catch (Exception ignored) {}
            return null;
        }
        @Override
        protected void onPostExecute(JSONArray results) {
            if (similarRow == null) return;
            similarRow.removeView(similarEmptyTv);

            if (results == null || results.length() == 0) {
                if (similarEmptyTv != null) {
                    similarEmptyTv.setVisibility(View.VISIBLE);
                    similarRow.addView(similarEmptyTv);
                }
                return;
            }

            int limit = Math.min(results.length(), 15);
            for (int i = 0; i < limit; i++) {
                try {
                    JSONObject it = results.getJSONObject(i);
                    similarRow.addView(buildSimilarCard(it));
                } catch (Exception ignored) {}
            }
        }
    }

    // ── Build a single similar card ───────────────────────────────────

    private View buildSimilarCard(JSONObject it) {
        final String simTitle = it.optString("title", it.optString("name", "Unknown"));
        final String poster   = it.optString("poster_path", "");
        final double rating   = it.optDouble("vote_average", 0);
        final String simType  = it.has("title") ? "movie" : mediaType;

        FrameLayout card = new FrameLayout(this);
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
            dpToPx(118), dpToPx(200));
        cardLp.rightMargin = dpToPx(10);
        card.setLayoutParams(cardLp);
        card.setClickable(true);
        card.setFocusable(true);

        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setCornerRadius(dpToPx(14));
        cardBg.setColors(new int[]{ 0xFF161628, C_CARD2 });
        cardBg.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
        card.setBackground(cardBg);
        card.setClipToOutline(true);
        card.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override
            public void getOutline(View view, android.graphics.Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dpToPx(14));
            }
        });

        // Poster image
        ImageView posterImg = new ImageView(this);
        posterImg.setLayoutParams(new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, dpToPx(162)));
        posterImg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        posterImg.setBackgroundColor(C_CARD2);
        card.addView(posterImg);

        if (!poster.isEmpty()) {
            com.bumptech.glide.Glide.with(this)
                .load(IMG_BASE_W + poster)
                .centerCrop()
                .into(posterImg);
        }

        // Bottom gradient
        View grad = new View(this);
        FrameLayout.LayoutParams gradLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, dpToPx(80));
        gradLp.gravity = Gravity.BOTTOM;
        grad.setLayoutParams(gradLp);
        grad.setBackground(new GradientDrawable(
            GradientDrawable.Orientation.BOTTOM_TOP,
            new int[]{ 0xFF111122, 0x88111122, Color.TRANSPARENT }));
        card.addView(grad);

        // Info overlay at bottom
        LinearLayout info = new LinearLayout(this);
        FrameLayout.LayoutParams infoLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT);
        infoLp.gravity = Gravity.BOTTOM;
        info.setLayoutParams(infoLp);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dpToPx(8), 0, dpToPx(8), dpToPx(8));

        // Rating badge
        if (rating > 0) {
            TextView ratingTv = new TextView(this);
            ratingTv.setText("\u2605 " + String.format(Locale.US, "%.1f", rating));
            ratingTv.setTextLocale(Locale.US);
            ratingTv.setTextSize(10f);
            ratingTv.setTextColor(C_STAR);
            ratingTv.setTypeface(Typeface.DEFAULT_BOLD);
            LinearLayout.LayoutParams rLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            rLp.bottomMargin = dpToPx(3);
            ratingTv.setLayoutParams(rLp);
            info.addView(ratingTv);
        }

        // Title
        TextView titleTv = new TextView(this);
        titleTv.setText(simTitle);
        titleTv.setTextSize(11.5f);
        titleTv.setTextColor(0xFFE0E0F8);
        titleTv.setTypeface(Typeface.DEFAULT_BOLD);
        titleTv.setMaxLines(2);
        titleTv.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleTv.setLineSpacing(0, 1.3f);
        info.addView(titleTv);
        card.addView(info);

        applyPressEffect(card, false);
        card.setOnClickListener(v -> {
            try {
                it.put("media_type", simType);
                Intent intent = new Intent(DetailActivity.this, DetailActivity.class);
                intent.putExtra("item_json", it.toString());
                startActivity(intent);
                overridePendingTransition(R.anim.enter_from_right, R.anim.exit_to_left);
            } catch (Exception ignored) {}
        });

        return card;
    }

    // ── AsyncTask: Arabic overview ────────────────────────────────────

    private class ArabicOverviewTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... p) {
            try {
                JSONObject d = fetchJson("https://api.themoviedb.org/3/" + mediaType + "/"
                    + tmdbId + "?language=ar");
                if (d != null) {
                    String ar = d.optString("overview", "");
                    if (!ar.isEmpty()) return ar;
                }
            } catch (Exception ignored) {}
            return "";
        }
        @Override
        protected void onPostExecute(String arOverview) {
            if (arOverview == null || arOverview.isEmpty()) return;
            if (detailOverview != null) {
                detailOverview.setText(arOverview);
                detailOverview.post(() -> {
                    if (detailOverview.getLineCount() > 4) {
                        if (detailReadMore != null) detailReadMore.setVisibility(View.VISIBLE);
                    } else {
                        if (detailReadMore != null) detailReadMore.setVisibility(View.GONE);
                    }
                });
            }
        }
    }

    // ── Master RecyclerView Adapter ───────────────────────────────────

    private class MasterAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

        MasterAdapter() { setHasStableIds(true); }

        @Override public long getItemId(int pos) { return -(pos + 1L); }

        @Override
        public int getItemCount() {
            // Positions: 0=Backdrop 1=Actions 2=Overview 3=Meta
            //            4=CastCards 5=BoxOffice(movie)/Similar(tv) 6=Similar(movie only)
            return isMovie ? 7 : 6;
        }

        @Override
        public int getItemViewType(int pos) {
            if (isMovie) {
                switch (pos) {
                    case 0: return VT_BACKDROP;
                    case 1: return VT_ACTIONS;
                    case 2: return VT_OVERVIEW;
                    case 3: return VT_META;
                    case 4: return VT_CAST;
                    case 5: return VT_BOXOFFICE;
                    default: return VT_SIMILAR;
                }
            } else {
                switch (pos) {
                    case 0: return VT_BACKDROP;
                    case 1: return VT_ACTIONS;
                    case 2: return VT_OVERVIEW;
                    case 3: return VT_META;
                    case 4: return VT_CAST;
                    default: return VT_SIMILAR;
                }
            }
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            switch (viewType) {
                case VT_BACKDROP:  return new SimpleVH(hdrBackdrop);
                case VT_ACTIONS:   return new SimpleVH(hdrActions);
                case VT_OVERVIEW:  return new SimpleVH(hdrOverview);
                case VT_META:      return new SimpleVH(hdrMeta);
                case VT_CAST:      return new SimpleVH(hdrCastCards);
                case VT_BOXOFFICE: return new SimpleVH(hdrBoxOffice);
                default:           return new SimpleVH(hdrSimilar);
            }
        }

        @Override
        public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {}

        class SimpleVH extends RecyclerView.ViewHolder {
            SimpleVH(View v) { super(v); }
        }
    }

    // ── Visual effects ────────────────────────────────────────────────

    private void applyParallax(RecyclerView rv) {
        if (detailBackdrop == null) return;
        LinearLayoutManager lm = (LinearLayoutManager) rv.getLayoutManager();
        if (lm == null) return;
        View first = lm.findViewByPosition(0);
        if (first == null) return;
        detailBackdrop.setTranslationY(-first.getTop() * 0.40f);
    }

    private void animateFadeSlide(View v, long dur, long delay) {
        if (v == null) return;
        v.setAlpha(0f); v.setTranslationY(18f);
        v.animate().cancel();
        v.animate().alpha(1f).translationY(0f)
            .setDuration(dur).setStartDelay(delay)
            .setInterpolator(new DecelerateInterpolator(2.2f)).start();
    }

    private void applyPressEffect(View v, boolean isPrimary) {
        v.setOnTouchListener((view, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().cancel();
                    view.animate()
                        .scaleX(isPrimary ? 0.96f : 0.94f)
                        .scaleY(isPrimary ? 0.96f : 0.94f)
                        .alpha(isPrimary ? 0.88f : 0.80f)
                        .setDuration(90).setInterpolator(new DecelerateInterpolator()).start();
                    break;
                case MotionEvent.ACTION_UP:
                    view.animate().cancel();
                    view.animate().scaleX(1.03f).scaleY(1.03f).alpha(1f)
                        .setDuration(130).setInterpolator(new DecelerateInterpolator())
                        .withEndAction(() ->
                            view.animate().scaleX(1f).scaleY(1f)
                                .setDuration(200).setInterpolator(new OvershootInterpolator(1.8f)).start()
                        ).start();
                    break;
                case MotionEvent.ACTION_CANCEL:
                    view.animate().cancel();
                    view.animate().scaleX(1f).scaleY(1f).alpha(1f)
                        .setDuration(200).setInterpolator(new OvershootInterpolator(1.5f)).start();
                    break;
            }
            return false;
        });
    }

    // ── Money formatter ───────────────────────────────────────────────

    private String formatMoney(long amount) {
        if (amount <= 0) return "N/A";
        if (amount >= 1_000_000_000L)
            return String.format(Locale.US, "$%.2fB", amount / 1_000_000_000.0);
        if (amount >= 1_000_000L)
            return String.format(Locale.US, "$%.1fM", amount / 1_000_000.0);
        if (amount >= 1_000L)
            return String.format(Locale.US, "$%.0fK", amount / 1_000.0);
        return "$" + amount;
    }

    // ── Pre-fetch ─────────────────────────────────────────────────────

    private void startPrefetch() {
        // Deferred: the source probe decides whether CinemaBox is worth warming
        // (see maybeWarmCinemaBox). Anime never reaches here (series-only), but
        // the guard stays explicit.
        if (!isMovie || "anime".equals(mediaType)) return;
    }

    /** Warms the CinemaBox cache only when source 2 is actually exposed. */
    private void maybeWarmCinemaBox(SourceChoice.Decision d) {
        if (!isMovie || d == null || !d.exposes(SourceChoice.SOURCE_CINEMABOX)) return;
        final String title     = item.optString("title", item.optString("name", ""));
        final String origTitle = item.optString("original_title",
                                     item.optString("original_name", null));
        final int    year      = extractYear(item.optString("release_date", ""));
        CinemaBoxCache.get().prefetchMovie(title, origTitle, year);
    }

    // ── Player / Episodes ─────────────────────────────────────────────

    private void openPlayer(boolean isParty) {
        if (!PlaybackAuthorizationPolicy.hasAuthorizedSource(this)) {
            android.widget.Toast.makeText(this, PlaybackAuthorizationPolicy.disabledMessage(),
                    android.widget.Toast.LENGTH_LONG).show();
            return;
        }
        final String movieTitle    = item.optString("title", item.optString("name", ""));
        final String originalTitle = item.optString("original_title",
                                         item.optString("original_name", null));
        final int    movieYear     = extractYear(item.optString("release_date", ""));
        srcSearchTitle = movieTitle; srcOriginalTitle = originalTitle; srcYear = movieYear;

        showResolveOverlay("جارٍ التحضير...");

        new Thread(() -> {
            // P5: the selected source decides the provider — no hard-coded order.
            final SourceChoice.Decision decision = awaitDecision();
            if (decision.noSource) {
                final boolean transientFailure = sourceProbeOutcome
                        == com.eve.cinema.playback.ProbeOutcome.UNRESOLVED_TRANSIENT;
                final boolean authRequired = sourceAuthRequired;
                final boolean animeNeedsAddon = "anime".equals(mediaType) && !transientFailure
                        && !authRequired && !hasStremioSource();
                runOnUiThread(() -> {
                    hideResolveOverlay();
                    if (authRequired) showCinemaBoxAuthRequired();
                    else showResolveError(transientFailure
                                ? "تعذر التحقق من المصادر مؤقتاً؛ أعد المحاولة بعد قليل"
                                : animeNeedsAddon ? getString(R.string.watch_anime_needs_addon)
                                : "لا يوجد مصدر موثوق لهذا العنوان");
                });
                return;
            }
            final int source = SourceChoice.coerceSelection(decision, selectedSource);
            final int gen = ++chooserGeneration;

            if (source == SourceChoice.SOURCE_MOVIEBOX) {
                resolveMovieViaMovieBox(movieTitle, originalTitle, movieYear, gen);
            } else if (source == SourceChoice.SOURCE_STREMIO) {
                resolveMovieViaStremio(gen);
            } else {
                resolveMovieViaCinemaBox(movieTitle, originalTitle, movieYear, gen);
            }
        }).start();
    }

    /** Source 1 — MovieBox: full resolve, then the pre-player mode chooser. */
    private void resolveMovieViaMovieBox(final String movieTitle, final String originalTitle,
                                         final int movieYear, final int gen) {
        String title = movieTitle;
        if (isNonLatinText(title)) {
            String en = fetchEnglishTitle();
            if (en != null && !en.isEmpty()) title = en;
        }
        try {
            final MovieBoxModels.Playback playback =
                    com.eve.cinema.moviebox.MovieBoxBridge
                        .get(DetailActivity.this)
                        .resolveMovie(title, originalTitle, movieYear);
            final ModeResolver.Availability a = evaluateMovieBoxModes(playback);
            runOnUiThread(() -> {
                if (isFinishing() || gen != chooserGeneration) return;
                hideResolveOverlay();
                offerModesAndLaunch(a, mode -> launchMovieBoxWithMode(playback, a, mode, gen));
            });
        } catch (final Exception mbError) {
            runOnUiThread(() -> {
                if (isFinishing() || gen != chooserGeneration) return;
                hideResolveOverlay();
                showResolveError("تعذّر التشغيل من " + SourceChoice.label(SourceChoice.SOURCE_MOVIEBOX)
                        + ": " + userMessage(mbError));
            });
        }
    }

    /** Source 2 — CinemaBox: resolve, then the pre-player mode chooser. */
    private void resolveMovieViaCinemaBox(final String movieTitle, final String originalTitle,
                                          final int movieYear, final int gen) {
        String title = movieTitle;
        if (isNonLatinText(title)) {
            String en = fetchEnglishTitle();
            if (en != null && !en.isEmpty()) title = en;
        }
        try {
            CinemaBoxBridge.ResolveResult result =
                    CinemaBoxCache.get().getMovie(title, originalTitle, movieYear);

            if (result == null || result.episodeId <= 0)
                throw new Exception("لم يُعثر على رابط بث لهذا الفيلم");

            final int    finalEpisodeId = result.episodeId;
            final String finalTitle     = movieTitle;
            final ModeResolver.Availability a = evaluateCinemaBoxModes(result.mediaResult);

            runOnUiThread(() -> {
                if (isFinishing() || gen != chooserGeneration) return;
                hideResolveOverlay();
                offerModesAndLaunch(a, mode -> launchPlayer(finalEpisodeId, finalTitle, mode));
            });
        } catch (final Exception e) {
            runOnUiThread(() -> {
                if (isFinishing() || gen != chooserGeneration) return;
                hideResolveOverlay();
                showResolveError("تعذّر التشغيل من " + SourceChoice.label(SourceChoice.SOURCE_CINEMABOX)
                        + ": " + userMessage(e));
            });
        }
    }

    /**
     * Source 3 — query every compatible add-on in parallel and show "اختر المشاهدة" at once: the
     * list fills in as add-ons answer. Nothing plays until the user picks a source and presses Play.
     */
    private void resolveMovieViaStremio(final int gen) {
        final String key = com.eve.cinema.stremio.StremioChooserSession.movieKey(tmdbId);
        final String title = item.optString("title", item.optString("name", ""));
        final com.eve.cinema.stremio.StremioChooserSession.Entry entry =
                com.eve.cinema.stremio.StremioChooserSession.begin(key, title, "movie", tmdbId, 1, 1);
        com.eve.cinema.stremio.StremioChooserLoader.start(this, entry);
        // Keep the resolving overlay up while the stream list and initial speed samples settle;
        // the bounded cap prevents a slow provider from blocking the chooser indefinitely.
        com.eve.cinema.stremio.StremioChooserWaiter.waitForReady(entry, 1800L, 7500L, () -> {
            if (isFinishing() || gen != chooserGeneration) { entry.cancelSearch(); return; }
            hideResolveOverlay();
            showWatchChooser(key);
        });
    }

    /** Shows the "اختر المشاهدة" sheet for this key (fresh search or return after a failed link). */
    private void showWatchChooser(final String key) {
        final com.eve.cinema.stremio.StremioChooserSession.Entry entry =
                com.eve.cinema.stremio.StremioChooserSession.get(key);
        if (entry == null || isFinishing()) return;
        // A user dismissal cancels work, but choosing a stream hands the same session to the player;
        // subtitle add-ons must be allowed to finish so file-specific captions can arrive later.
        final boolean[] handingOffToPlayer = {false};
        WatchChooserSheet sheet = WatchChooserSheet.forChoose(this, entry, new WatchChooserSheet.Listener() {
            @Override public void onPlay(com.eve.cinema.stremio.StremioStreamOption option,
                                         com.eve.cinema.stremio.StremioSubtitle subtitle) {
                handingOffToPlayer[0] = true;
                launchStremioPlayer(entry, option, subtitle);
            }
            @Override public void onRetrySearch() {
                com.eve.cinema.stremio.StremioChooserLoader.start(DetailActivity.this, entry);
            }
        });
        sheet.setOnDismissListener(d -> {
            if (!handingOffToPlayer[0]) entry.cancelSearch();
        });
        activeChooserSheet = sheet;
        sheet.show();
    }

    private WatchChooserSheet activeChooserSheet;

    /** A link that failed in the player brings the user back to the same list — never to another link. */
    private void reopenStremioChooserIfRequested() {
        String key = com.eve.cinema.stremio.StremioChooserSession.takeReopenKey(
                "movie|" + com.eve.cinema.stremio.StremioSourceResolver.movieId(tmdbId));
        if (key != null) showWatchChooser(key);
    }

    private static String userMessage(Exception e) {
        if (e instanceof com.eve.cinema.moviebox.MovieBoxException)
            return ((com.eve.cinema.moviebox.MovieBoxException) e).userMessage();
        String m = e.getMessage();
        return m != null ? m : "خطأ في الاستخراج";
    }

    // ── P4: pre-player mode chooser (portrait, before PlayerActivity) ──

    /**
     * Genuine-mode evidence for a MovieBox payload — shared implementation in
     * {@link ModeEvidence} (subtitles of the exact starting stream, manifest
     * audio languages, VERIFIED dub release). Runs on the resolve thread.
     */
    private ModeResolver.Availability evaluateMovieBoxModes(MovieBoxModels.Playback p) {
        return ModeEvidence.forMovieBox(
                com.eve.cinema.moviebox.MovieBoxBridge.get(DetailActivity.this), p);
    }

    /** CinemaBox: subtitles from the resolved media; dub is never claimed (no evidence source). */
    private ModeResolver.Availability evaluateCinemaBoxModes(
            com.eve.cinema.extractor.CinemaBoxExtractor.MediaResult media) {
        return ModeEvidence.forCinemaBox(media);
    }

    private interface ModeLaunch { void launch(PlaybackMode mode); }

    /**
     * Shows distinct Arabic dub, in-video-subtitle, and external-subtitle choices while the
     * details screen is still portrait; hands the chosen mode to the launcher.
     * With no Arabic mode: the verified English fallback (or honest original)
     * is applied automatically — the player announces it. Cancelling the sheet
     * cancels the launch.
     */
    private void offerModesAndLaunch(ModeResolver.Availability a, ModeLaunch launch) {
        final int gen = chooserGeneration;
        final java.util.List<PlaybackMode> options = ModeResolver.chooserOptions(a);
        if (options.isEmpty()) {
            PlaybackMode auto = ModeResolver.automaticMode(a);
            launch.launch(auto); // null → player applies its honest ORIGINAL fallback
            return;
        }
        java.util.List<GlassChoiceSheet.Row> rows = new ArrayList<>();
        for (PlaybackMode m : options) {
            String label = m == PlaybackMode.ARABIC_DUB
                    ? getString(R.string.player_mode_ar_dub)
                    : m == PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE
                    ? getString(R.string.player_mode_ar_video_subtitle)
                    : getString(R.string.player_mode_ar_sub);
            String description = m == PlaybackMode.ARABIC_DUB
                    ? "يغيّر مسار الصوت إلى دبلجة عربية متحققة"
                    : m == PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE
                    ? "يشغّل إصدار فيديو مصنّفًا كمترجم؛ قد لا يمكن تغيير حجم النص المضمّن"
                    : "ملف مستقل يمكن تكبيره وتصغيره وضبط إزاحته؛ تزامنه غير مثبت تلقائيًا";
            rows.add(new GlassChoiceSheet.Row(label, description, true, false));
        }
        new GlassChoiceSheet(this, "اختر طريقة المشاهدة", rows, idx -> {
            if (isFinishing() || gen != chooserGeneration) return;
            if (idx < 0 || idx >= options.size()) return;
            launch.launch(options.get(idx));
        }).show();
    }

    private String srcSearchTitle = "", srcOriginalTitle = null;
    private int srcYear = 0;

    private void putSourceExtras(Intent intent) {
        intent.putExtra("search_title", srcSearchTitle);
        intent.putExtra("original_title", srcOriginalTitle);
        intent.putExtra("year", srcYear);
    }

    /**
     * G: a chosen Arabic dub backed by a separate dub RELEASE is resolved to
     * that release before the player opens — the player receives the exact
     * dubbed payload, never the base release plus a hope. A manifest-verified
     * Arabic track plays the same payload with the mode applied.
     */
    private void launchMovieBoxWithMode(final MovieBoxModels.Playback base,
                                        final ModeResolver.Availability a,
                                        final PlaybackMode mode, final int gen) {
        if (mode == PlaybackMode.ARABIC_DUB && a.arabicDubFromRelease && !a.arabicDubFromManifest) {
            final MovieBoxModels.DubOption dub = base.arabicDub();
            if (dub != null) {
                showResolveOverlay("جارٍ تجهيز الدبلجة...");
                new Thread(() -> {
                    try {
                        final MovieBoxModels.Playback dubbed =
                                com.eve.cinema.moviebox.MovieBoxBridge.get(DetailActivity.this)
                                        .resolveDubRelease(base, dub, LanguageMatcher.AR);
                        runOnUiThread(() -> {
                            if (isFinishing() || gen != chooserGeneration) return;
                            hideResolveOverlay();
                            launchMovieBoxPlayer(dubbed, PlaybackMode.ARABIC_DUB);
                        });
                    } catch (final Exception e) {
                        runOnUiThread(() -> {
                            if (isFinishing() || gen != chooserGeneration) return;
                            hideResolveOverlay();
                            showResolveError("تعذّرت الدبلجة العربية — جرّب الترجمة");
                        });
                    }
                }).start();
                return;
            }
        }
        if (mode == PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE) {
            if (base.inVideoSubtitleRelease) {
                launchMovieBoxPlayer(base, mode);
                return;
            }
            final MovieBoxModels.DubOption release = base.arabicSubtitleRelease();
            if (release == null || !a.arabicInVideoSubtitleFromRelease) {
                showResolveError("تعذّر التحقق من نسخة الترجمة داخل الفيديو — جرّب الترجمة الخارجية");
                return;
            }
            showResolveOverlay("جارٍ تجهيز نسخة الترجمة داخل الفيديو...");
            new Thread(() -> {
                try {
                    final MovieBoxModels.Playback translated =
                            com.eve.cinema.moviebox.MovieBoxBridge.get(DetailActivity.this)
                                    .resolveArabicSubtitleRelease(base, release);
                    runOnUiThread(() -> {
                        if (isFinishing() || gen != chooserGeneration) return;
                        hideResolveOverlay();
                        launchMovieBoxPlayer(translated, PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE);
                    });
                } catch (final Exception e) {
                    runOnUiThread(() -> {
                        if (isFinishing() || gen != chooserGeneration) return;
                        hideResolveOverlay();
                        showResolveError("تعذّر تشغيل نسخة الترجمة داخل الفيديو — جرّب الترجمة الخارجية");
                    });
                }
            }).start();
            return;
        }
        launchMovieBoxPlayer(base, mode);
    }

    /** Launches the player with a fully-resolved MovieBox playback payload. */
    private void launchMovieBoxPlayer(com.eve.cinema.moviebox.MovieBoxModels.Playback playback,
                                      PlaybackMode mode) {
        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra("moviebox_payload", playback.toJson().toString());
        intent.putExtra("tmdb_id",       tmdbId);
        intent.putExtra("media_type",    mediaType);
        intent.putExtra("title",         playback.title != null && !playback.title.isEmpty()
                                         ? playback.title
                                         : item.optString("title", item.optString("name", "")));
        intent.putExtra("season",        playback.season);
        intent.putExtra("episode",       playback.episode);
        if (mode != null) intent.putExtra("requested_mode", mode.name());
        putSourceExtras(intent);
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    private void launchStremioPlayer(
            com.eve.cinema.stremio.StremioChooserSession.Entry entry,
            com.eve.cinema.stremio.StremioStreamOption option,
            com.eve.cinema.stremio.StremioSubtitle subtitle) {
        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra("stremio_url", option.url);
        intent.putExtra("stremio_headers", new JSONObject(option.headers).toString());
        intent.putExtra("stremio_addon_url", option.addonManifestUrl);
        intent.putExtra("stremio_session_key", entry.key);
        intent.putExtra("stremio_option_id", option.id);
        if (subtitle != null) intent.putExtra("stremio_subtitle_url", subtitle.url);
        intent.putExtra("tmdb_id", tmdbId);
        intent.putExtra("media_type", mediaType);
        intent.putExtra("title", entry.title);
        intent.putExtra("season", 1);
        intent.putExtra("episode", 1);
        putSourceExtras(intent);
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    private void launchPlayer(int episodeId, String title, PlaybackMode mode) {
        Intent intent = new Intent(this, PlayerActivity.class);
        intent.putExtra("episode_id",    episodeId);
        intent.putExtra("cinema_box_id", episodeId);
        intent.putExtra("tmdb_id",       tmdbId);
        intent.putExtra("media_type",    mediaType);
        intent.putExtra("title",         title);
        intent.putExtra("season",        1);
        intent.putExtra("episode",       1);
        if (mode != null) intent.putExtra("requested_mode", mode.name());
        putSourceExtras(intent);
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
    }

    private void openEpisodesScreen() {
        Intent intent = new Intent(this, EpisodesActivity.class);
        intent.putExtra("item_json",  item.toString());
        intent.putExtra("tmdb_id",    tmdbId);
        intent.putExtra("media_type", mediaType);
        // P5: the source picked on the details page governs episode playback.
        SourceChoice.Decision d = sourceDecision;
        int sel = SourceChoice.coerceSelection(d, selectedSource);
        if (sel == 0 && "anime".equals(mediaType)) sel = SourceChoice.SOURCE_STREMIO;
        if (sel != 0) intent.putExtra("selected_source", sel);
        startActivity(intent);
        overridePendingTransition(R.anim.enter_from_right, R.anim.exit_to_left);
    }

    // ── Resolve Overlay ───────────────────────────────────────────────

    private void showResolveOverlay(String msg) {
        if (resolveOverlay == null) {
            resolveOverlay = new FrameLayout(this);
            resolveOverlay.setLayoutParams(new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            resolveOverlay.setBackgroundColor(0xCC06060F);
            resolveOverlay.setClickable(true);

            // Glass card container
            LinearLayout glassCard = new LinearLayout(this);
            glassCard.setOrientation(LinearLayout.VERTICAL);
            glassCard.setGravity(Gravity.CENTER);
            glassCard.setPadding(dpToPx(36), dpToPx(30), dpToPx(36), dpToPx(30));
            FrameLayout.LayoutParams cardLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT);
            cardLp.gravity = Gravity.CENTER;
            glassCard.setLayoutParams(cardLp);
            GradientDrawable glassBg = new GradientDrawable();
            glassBg.setCornerRadius(dpToPx(20));
            glassBg.setColors(new int[]{ 0xFF151530, 0xFF0E0E22 });
            glassBg.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
            glassBg.setStroke(dpToPx(1), 0x44C4A0E8);
            glassCard.setBackground(glassBg);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER);
            col.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));

            ProgressBar pb = new ProgressBar(this);
            pb.setIndeterminate(true);
            col.addView(pb, new LinearLayout.LayoutParams(dpToPx(36), dpToPx(36)));

            resolveMsgTv = new TextView(this);
            resolveMsgTv.setTextColor(C_LITE);
            resolveMsgTv.setTextSize(13f);
            resolveMsgTv.setLetterSpacing(0f);
            resolveMsgTv.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams tvLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            tvLp.topMargin = dpToPx(14);
            resolveMsgTv.setLayoutParams(tvLp);
            col.addView(resolveMsgTv);

            glassCard.addView(col);
            resolveOverlay.addView(glassCard);
            ((FrameLayout) masterRecyclerView.getParent()).addView(resolveOverlay);
        }

        if (resolveMsgTv != null) resolveMsgTv.setText(msg);
        resolveOverlay.setVisibility(View.VISIBLE);
    }

    private void hideResolveOverlay() {
        if (resolveOverlay != null) resolveOverlay.setVisibility(View.GONE);
    }

    private void showResolveError(String msg) {
        if (resolveMsgTv != null) {
            resolveMsgTv.setText(msg);
            resolveMsgTv.setTextColor(0xFFFF6B6B);
        }
        if (resolveOverlay != null) resolveOverlay.setVisibility(View.VISIBLE);
        masterRecyclerView.postDelayed(() -> hideResolveOverlay(), 3000);
    }

    // ── Utils ─────────────────────────────────────────────────────────

    private int extractYear(String dateStr) {
        if (dateStr == null || dateStr.length() < 4) return 0;
        try { return Integer.parseInt(dateStr.substring(0, 4)); }
        catch (Exception e) { return 0; }
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    private JSONObject fetchJson(String urlStr) throws Exception {
        JSONObject cached = TmdbCache.getJson(urlStr);
        if (cached != null) {
            DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, 200, 0, null, cached.toString(), null, true);
            return cached;
        }
        long diagnosticStart = android.os.SystemClock.elapsedRealtime();
        int diagnosticStatus = -1;
        String diagnosticBody = null;
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            TmdbAuthorization.apply(conn, TMDB_TOKEN);
        DiagnosticsRecorder.headers("TMDB", "fetch_json", "GET", urlStr, conn.getRequestProperties());
            conn.setRequestProperty("accept", "application/json");
            diagnosticStatus = conn.getResponseCode();
            if (diagnosticStatus != 200) {
                DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, diagnosticStatus,
                        android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, null, null, false);
                return null;
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            diagnosticBody = sb.toString();
            DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, diagnosticStatus,
                    android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, diagnosticBody, null, false);
            JSONObject obj = new JSONObject(diagnosticBody);
            TmdbCache.putJson(urlStr, obj);
            return obj;
        } catch (Exception e) {
            DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, diagnosticStatus,
                    android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, diagnosticBody, e, false);
            throw e;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────

    @Override
    protected void onResume() {
        super.onResume();
        MiuiBarFix.apply(this);
        EveFloatingButton.attach(this);
        reopenStremioChooserIfRequested();
    }
    @Override
    protected void onPause() {
        super.onPause();
        EveFloatingButton.detach(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // A source list left open must not leak its window nor keep searching in the background.
        if (activeChooserSheet != null && activeChooserSheet.isShowing()) activeChooserSheet.dismiss();
        MiuiBarFix.release(this);
    }
}

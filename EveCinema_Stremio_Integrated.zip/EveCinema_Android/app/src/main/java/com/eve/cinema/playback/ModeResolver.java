package com.eve.cinema.playback;

import java.util.ArrayList;
import java.util.List;

/** Resolves availability and priority for three non-interchangeable Arabic paths. */
public final class ModeResolver {
    private ModeResolver() {}

    public static final class Availability {
        /** Downloaded/attached external caption. */
        public boolean arabicSubtitle;
        /** Arabic subtitle carried by a separate, provider-labelled video release. */
        public boolean arabicInVideoSubtitle;
        /** Audio Arabic is verified in manifest or by a resolved Arabic-dub release. */
        public boolean arabicDub;
        public boolean arabicDubFromManifest;
        public boolean arabicDubFromRelease;
        public boolean arabicInVideoSubtitleFromRelease;
        public int englishSubtitleIndex = -1;
        public boolean englishAudio;

        public boolean anyArabic() {
            return arabicSubtitle || arabicInVideoSubtitle || arabicDub;
        }

        public PlaybackMode fallbackMode() {
            if (englishSubtitleIndex >= 0 || englishAudio) return PlaybackMode.ENGLISH_FALLBACK;
            return PlaybackMode.ORIGINAL;
        }
    }

    /** Backward-compatible overload for callers with no separate in-video release evidence. */
    public static Availability evaluate(List<String> subtitleLanguages,
                                        List<String> audioLanguages,
                                        boolean hasArabicDubRelease) {
        return evaluate(subtitleLanguages, audioLanguages, hasArabicDubRelease, false);
    }

    public static Availability evaluate(List<String> subtitleLanguages,
                                        List<String> audioLanguages,
                                        boolean hasArabicDubRelease,
                                        boolean hasArabicInVideoSubtitleRelease) {
        Availability a = new Availability();
        a.arabicSubtitle = indexOfArabic(subtitleLanguages) >= 0;
        a.arabicInVideoSubtitleFromRelease = hasArabicInVideoSubtitleRelease;
        a.arabicInVideoSubtitle = hasArabicInVideoSubtitleRelease;
        a.englishSubtitleIndex = indexOfEnglish(subtitleLanguages);
        a.arabicDubFromManifest = indexOfArabic(audioLanguages) >= 0;
        a.arabicDubFromRelease = hasArabicDubRelease;
        a.arabicDub = a.arabicDubFromManifest || a.arabicDubFromRelease;
        a.englishAudio = indexOfEnglish(audioLanguages) >= 0;
        return a;
    }

    /**
     * Applies the requested distinct mode when available; otherwise uses the best
     * verified Arabic alternative, then English/original. An external SRT is never
     * treated as evidence for either an Arabic audio release or a subtitle video.
     */
    public static PlaybackMode effectiveMode(PlaybackMode requested, Availability a) {
        if (a == null) return PlaybackMode.ORIGINAL;
        if (requested == PlaybackMode.ARABIC_DUB && a.arabicDub) return requested;
        if (requested == PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE && a.arabicInVideoSubtitle)
            return requested;
        if (requested == PlaybackMode.ARABIC_SUBTITLE && a.arabicSubtitle) return requested;
        if (a.arabicDub) return PlaybackMode.ARABIC_DUB;
        if (a.arabicInVideoSubtitle) return PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE;
        if (a.arabicSubtitle) return PlaybackMode.ARABIC_SUBTITLE;
        return a.fallbackMode();
    }

    public static String audioLanguageFor(PlaybackMode mode, Availability a) {
        if (mode == PlaybackMode.ARABIC_DUB) return LanguageMatcher.AR;
        if (mode == PlaybackMode.ENGLISH_FALLBACK || mode == PlaybackMode.ORIGINAL)
            return a != null && a.englishAudio ? LanguageMatcher.EN : null;
        // The in-video subtitle release is a video-version switch, not a request
        // to relabel or force an audio language. Its own manifest remains authoritative.
        return null;
    }

    public static boolean audioMatches(String wanted, String selectedLangOrLabel) {
        return wanted == null || wanted.equals(LanguageMatcher.normalize(selectedLangOrLabel));
    }

    /** Index of an external subtitle to load, or -1 when no overlay should be loaded. */
    public static int subtitleIndexFor(PlaybackMode mode, List<String> subtitleLanguages) {
        if (mode == PlaybackMode.ARABIC_SUBTITLE) return indexOfArabic(subtitleLanguages);
        if (mode == PlaybackMode.ENGLISH_FALLBACK) return indexOfEnglish(subtitleLanguages);
        return -1;
    }

    public static int indexOfArabic(List<String> langs) {
        if (langs == null) return -1;
        for (int i = 0; i < langs.size(); i++)
            if (LanguageMatcher.isArabic(langs.get(i))) return i;
        return -1;
    }

    public static int indexOfEnglish(List<String> langs) {
        if (langs == null) return -1;
        for (int i = 0; i < langs.size(); i++)
            if (LanguageMatcher.isEnglish(langs.get(i))) return i;
        return -1;
    }

    /**
     * Rows of the pre-playback mode sheet, ordered by the user's requested priority:
     * dub audio, a video release carrying in-picture Arabic, then a controllable external file.
     */
    public static List<PlaybackMode> chooserOptions(Availability a) {
        List<PlaybackMode> out = new ArrayList<>();
        if (a != null && a.arabicDub) out.add(PlaybackMode.ARABIC_DUB);
        if (a != null && a.arabicInVideoSubtitle)
            out.add(PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE);
        if (a != null && a.arabicSubtitle) out.add(PlaybackMode.ARABIC_SUBTITLE);
        return out;
    }

    /**
     * Automatic mode is used only when no explicit selection is available (e.g. deep links).
     * Prefer Arabic dub, then the subtitle video release, then external subtitle, and only
     * then English. The explicit chooser always appears when an Arabic option exists.
     */
    public static PlaybackMode automaticMode(Availability a) {
        if (a == null) return null;
        if (a.arabicDub) return PlaybackMode.ARABIC_DUB;
        if (a.arabicInVideoSubtitle) return PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE;
        if (a.arabicSubtitle) return PlaybackMode.ARABIC_SUBTITLE;
        if (a.englishSubtitleIndex >= 0 || a.englishAudio) return PlaybackMode.ENGLISH_FALLBACK;
        return null;
    }
}

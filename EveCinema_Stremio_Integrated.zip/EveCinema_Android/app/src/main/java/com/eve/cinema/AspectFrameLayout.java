package com.eve.cinema;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

/**
 * إطار بنسبة ثابتة (ارتفاع = عرض × ratio). يعطي بوستر 2:3 مهما كان عرض البطاقة
 * (صف أفقي بعرض ثابت، أو شبكة بـ weight) بدل ارتفاعات dp مكتوبة يدويًا.
 */
public class AspectFrameLayout extends FrameLayout {

    private float ratio = 1.5f;

    public AspectFrameLayout(Context c)                        { super(c); }
    public AspectFrameLayout(Context c, AttributeSet a)        { super(c, a); }
    public AspectFrameLayout(Context c, AttributeSet a, int s) { super(c, a, s); }

    public void setRatio(float heightOverWidth) {
        if (heightOverWidth > 0f && heightOverWidth != ratio) { ratio = heightOverWidth; requestLayout(); }
    }

    @Override
    protected void onMeasure(int widthSpec, int heightSpec) {
        final int w = MeasureSpec.getSize(widthSpec);
        if (MeasureSpec.getMode(widthSpec) == MeasureSpec.UNSPECIFIED || w <= 0) {
            super.onMeasure(widthSpec, heightSpec);
            return;
        }
        super.onMeasure(
            MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(Math.round(w * ratio), MeasureSpec.EXACTLY));
    }
}

package com.eve.cinema;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.List;

/**
 * Eve v6.1 — Prompt Builder (PATCH)
 *
 * الإصلاح الجذري:
 * ─────────────────────────────────────────────────────────────────────
 * المشكلة القديمة:
 *   النموذج يكتب: "أنصحك بـ {{MOVIE:Parasite}} أو {{MOVIE:Arrival}}."
 *   بعد إزالة التاج: "أنصحك بـ  أو ." ← نص مكسور تماماً
 *
 * الإصلاح:
 *   النموذج يكتب: "أنصحك بـ باراسيت {{MOVIE:Parasite}} أو أرايفال {{MOVIE:Arrival}}."
 *   بعد إزالة التاج: "أنصحك بـ باراسيت أو أرايفال." ← نص سليم حتى بدون بطاقات
 *
 * القاعدة الذهبية: الاسم العربي/المُعرَّب أولاً في الجملة ← التاج مباشرةً بعده
 * ─────────────────────────────────────────────────────────────────────
 */
public class EvePromptBuilder {

    private static final String CORE_PERSONALITY =
        "أنتِ إيف — أوراكل السينما. هادئة، ذكية، مباشرة.\n"
        + "اللغة: العربية فقط. لا إيموجيات. لا مقدمات فارغة مثل 'بالطبع' أو 'حسناً'.\n"
        + "لا تتجاوزي 4 جمل. لا تُكرري كلام المستخدم. لا تُفصحي عن كونكِ نموذجاً.\n\n";

    // ─────────────────────────────────────────────────────────────────
    //  TEMPLATE 1 — CASUAL_CHAT
    // ─────────────────────────────────────────────────────────────────
    private static final String TEMPLATE_CASUAL =
        CORE_PERSONALITY
        + "الوضع: محادثة عادية أو تحية. ردّي بجملة أو جملتين — إنسانية ودافئة.\n"
        + "⛔ ممنوع تماماً: لا {{MOVIE:...}} ولا {{TV:...}} ولا {{ANIME:...}} في هذا الرد.\n";

    // ─────────────────────────────────────────────────────────────────
    //  TEMPLATE 2 — RECOMMENDATION / MOOD_BASED
    //
    //  ✅ القاعدة المُصلَحة:
    //     اكتبي الاسم العربي/المعرَّب في الجملة أولاً ← ثم التاج مباشرةً بعده
    //
    //  لماذا؟
    //     إذا فشل TMDB أو بطأ الاتصال → النص لا يزال سليماً ومفهوماً
    //     الاسم يظهر في الجملة + في البطاقة = تجربة مثالية
    // ─────────────────────────────────────────────────────────────────
    private static final String TEMPLATE_RECOMMEND =
        CORE_PERSONALITY
        + "الوضع: المستخدم يطلب توصية أو يعبّر عن مزاجه.\n"
        + "اقترحي 1-3 أعمال وطبّقي قاعدة الكتابة التالية بدقة.\n\n"
        + "✅ قاعدة الكتابة — مُلزِمة:\n"
        + "  اكتبي اسم العمل (بالعربية أو بالتعريب) في الجملة أولاً،\n"
        + "  ثم ضعي التاج فوراً بعده بلا فراغ زائد:\n\n"
        + "  الاسم_العربي {{MOVIE:EnglishTitle}}\n"
        + "  الاسم_العربي {{TV:EnglishTitle}}\n"
        + "  الاسم_العربي {{ANIME:EnglishTitle}}\n\n"
        + "  الاسم داخل {{}} هو الاسم الإنجليزي الرسمي الدقيق.\n\n"
        + "✓ أمثلة صحيحة:\n"
        + "  'جرّب باراسيت {{MOVIE:Parasite}} — فيلم كوري مشوّق.'\n"
        + "  'أنصح بـ بريكنغ باد {{TV:Breaking Bad}} إن أردت توتراً.'\n"
        + "  'كود غياس {{ANIME:Code Geass}} مناسب لليلة ممتازة.'\n"
        + "  'جرّب إنترستيلار {{MOVIE:Interstellar}} أو أرايفال {{MOVIE:Arrival}}.'\n\n"
        + "✗ أمثلة خاطئة (ممنوعة):\n"
        + "  'جرّب {{MOVIE:Parasite}}' ← الاسم العربي مفقود\n"
        + "  'أنصحك بـ {{TV:Breaking Bad}}' ← الاسم العربي مفقود\n";

    // ─────────────────────────────────────────────────────────────────
    //  TEMPLATE 3 — DIRECT_QUERY
    // ─────────────────────────────────────────────────────────────────
    private static final String TEMPLATE_QUERY =
        CORE_PERSONALITY
        + "الوضع: سؤال مباشر عن فيلم أو مسلسل أو شخص.\n"
        + "أجيبي بدقة واختصار.\n\n"
        + "✅ إذا ذكرتِ اسم عمل → اكتبيه أولاً في الجملة ثم ضعي التاج:\n"
        + "  'مخرج إنسبشن {{MOVIE:Inception}} هو كريستوفر نولان.'\n"
        + "  'دارك {{TV:Dark}} ألماني، 3 مواسم، من أفضل ما أُنتج.'\n";

    // ─────────────────────────────────────────────────────────────────
    //  TEMPLATE 4 — FOLLOW_UP
    // ─────────────────────────────────────────────────────────────────
    private static final String TEMPLATE_FOLLOWUP =
        CORE_PERSONALITY
        + "الوضع: متابعة محادثة سينمائية سابقة. اربطي إجابتك بما قيل.\n"
        + "✅ عند ذكر عمل: اكتبي اسمه أولاً في الجملة ثم التاج بعده.\n";

    // ─────────────────────────────────────────────────────────────────
    //  DNA Update System Prompt
    // ─────────────────────────────────────────────────────────────────
    public static final String DNA_SYSTEM =
        "أنت محلل ذوق سينمائي صامت. استخلص تفضيلات المستخدم من المحادثة.\n"
        + "أرجع JSON فقط — بلا نص خارجه، بلا markdown، بلا شرح:\n"
        + "{\"genre_likes\":\"\",\"genre_dislikes\":\"\",\"fav_directors\":\"\","
        + "\"fav_actors\":\"\",\"mood_tags\":\"\",\"emotional_pattern\":\"\","
        + "\"fav_decade\":\"\",\"summary\":\"\"}\n\n"
        + "القواعد الصارمة:\n"
        + "— genre_likes/dislikes: أنواع سينمائية، بحد أقصى 5 عناصر مفصولة بفاصلة\n"
        + "— mood_tags: نبضات مزاجية، بحد أقصى 6\n"
        + "— emotional_pattern: جملة واحدة عن نمطه العاطفي\n"
        + "— fav_decade: كـ'90s، 2000s'، بحد أقصى 3\n"
        + "— summary: جملة واحدة تصف ذوقه السينمائي\n"
        + "— إذا لم تجد معلومة → اتركها ''. لا تخترع ما لم يُصرَّح به.";

    // ─────────────────────────────────────────────────────────────────
    //  LLM Config
    // ─────────────────────────────────────────────────────────────────
    public static class LlmConfig {
        public final int   maxTokens;
        public final float temperature;
        LlmConfig(int t, float temp) { maxTokens = t; temperature = temp; }
    }

    public static LlmConfig configFor(EveIntentEngine.Intent intent) {
        switch (intent) {
            case CASUAL_CHAT:    return new LlmConfig(180, 0.60f);
            case MOOD_BASED:     return new LlmConfig(550, 0.78f);
            case RECOMMENDATION: return new LlmConfig(520, 0.72f);
            case DIRECT_QUERY:   return new LlmConfig(480, 0.52f);
            case FOLLOW_UP:      return new LlmConfig(450, 0.68f);
            default:             return new LlmConfig(500, 0.72f);
        }
    }

    // ─────────────────────────────────────────────────────────────────
    //  Public API
    // ─────────────────────────────────────────────────────────────────

    public static JSONArray buildMessages(
            EveIntentEngine.IntentSignal signal,
            EveMemoryDb.UserDna dna,
            List<JSONObject> history,
            String userMessage) {

        JSONArray messages = new JSONArray();
        try {
            String system = selectTemplate(signal.primary)
                          + buildDnaContext(dna, signal.primary)
                          + buildGenreHint(signal.detectedContext);

            JSONObject sys = new JSONObject();
            sys.put("role", "system");
            sys.put("content", system);
            messages.put(sys);

            int maxHistory = 12;
            int start = Math.max(0, history.size() - maxHistory);
            for (int i = start; i < history.size(); i++) {
                messages.put(history.get(i));
            }

            JSONObject user = new JSONObject();
            user.put("role", "user");
            user.put("content", userMessage);
            messages.put(user);

        } catch (Exception ignored) {}
        return messages;
    }

    // ─────────────────────────────────────────────────────────────────
    //  Private
    // ─────────────────────────────────────────────────────────────────

    private static String selectTemplate(EveIntentEngine.Intent intent) {
        switch (intent) {
            case CASUAL_CHAT:    return TEMPLATE_CASUAL;
            case MOOD_BASED:
            case RECOMMENDATION: return TEMPLATE_RECOMMEND;
            case DIRECT_QUERY:   return TEMPLATE_QUERY;
            case FOLLOW_UP:      return TEMPLATE_FOLLOWUP;
            default:             return TEMPLATE_RECOMMEND;
        }
    }

    private static String buildDnaContext(EveMemoryDb.UserDna dna, EveIntentEngine.Intent intent) {
        if (intent == EveIntentEngine.Intent.CASUAL_CHAT) return "";
        if (dna == null || dna.isEmpty()) return "";
        return dna.toPromptContext();
    }

    private static String buildGenreHint(String ctx) {
        if (ctx == null || ctx.isEmpty()) return "";
        return "\n[النوع المطلوب: " + ctx + "]";
    }
}

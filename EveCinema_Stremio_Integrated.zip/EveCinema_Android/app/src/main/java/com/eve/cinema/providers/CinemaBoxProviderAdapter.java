package com.eve.cinema.providers;

import com.eve.cinema.CinemaBoxBridge;
import com.eve.cinema.CinemaBoxCredentials;
import com.eve.cinema.playback.ProbeOutcome;
import com.eve.cinema.providercore.CanonicalMediaIdentity;
import com.eve.cinema.providercore.ProviderAdapter;
import com.eve.cinema.providercore.ProviderIds;
import com.eve.cinema.providercore.ProviderResultState;
import com.eve.cinema.providercore.NormalizedCandidate;
import java.util.Collections;
import java.util.List;

/**
 * CinemaBoxProviderAdapter — Adapter رفيع يغلّف CinemaBoxBridge الموجود
 * (الخطوة التالية في تقرير التنفيذ: ربط اختيار المصدر الحالي
 * بـSourceWaveController).
 *
 *  - يبقى الاتصال direct-from-phone كما هو (قرار رقم 1) — لا Proxy ولا Backend.
 *  - probe() = فحص التوفر المصنّف الموجود؛ لا يجلب روابط (خطة §5 الخطوة 2).
 *  - candidates()/refresh() مرحلة الروابط: تبقى في مسار التشغيل الحالي
 *    (QualityBottomSheet/PlayerActivity) حتى تُربط بمستوى المرشحين بعد
 *    اختبار جهاز — لا نكرر مسارين يؤديان الوظيفة نفسها.
 *  - بيانات الحساب تأتي من CinemaBoxCredentials (المحطة 0) — لا أسرار هنا.
 */
public final class CinemaBoxProviderAdapter implements ProviderAdapter {

    @Override public String id() { return ProviderIds.CINEMABOX; }

    @Override public Capabilities capabilities() {
        // الوصول مشروط بالشبكة (خدمة مزوّدي إنترنت عراقيين) — §6.2.
        return new Capabilities(true, true, true, true, true, true);
    }

    @Override public ProviderResultState preflight(CanonicalMediaIdentity identity) {
        return CinemaBoxCredentials.isConfigured() ? null : ProviderResultState.AUTH_REQUIRED;
    }

    @Override public ProbeResult probe(CanonicalMediaIdentity identity) {
        long t0 = System.currentTimeMillis();
        if (!com.eve.cinema.PlaybackAuthorizationPolicy.isProviderEnabled(id()))
            return new ProbeResult(ProviderResultState.UNKNOWN, null, 0L);
        if (!CinemaBoxCredentials.isConfigured())
            return new ProbeResult(ProviderResultState.AUTH_REQUIRED, null, 0L);
        ProbeOutcome outcome = CinemaBoxBridge.probeAvailabilityOutcome(
                identity.titleOriginal(),
                firstAlias(identity),
                identity.releaseYear(),
                identity.mediaType() == CanonicalMediaIdentity.MediaType.MOVIE ? "MOVIE" : "SERIES");
        return new ProbeResult(toState(outcome), null,
                System.currentTimeMillis() - t0);
    }

    @Override public List<NormalizedCandidate> candidates(CanonicalMediaIdentity identity) {
        // مرحلة الروابط لم تُربط بعد بمستوى المرشحين (محجوبة باختبار الجهاز)؛
        // مسار التشغيل الحالي يجلب الروابط عند الضغط كما كان.
        return Collections.emptyList();
    }

    @Override public NormalizedCandidate refresh(NormalizedCandidate stale) throws ProviderException {
        throw new ProviderException(ProviderResultState.FAILED,
                "link-level refresh not wired for cinemabox yet");
    }

    private static String firstAlias(CanonicalMediaIdentity identity) {
        List<String> aliases = identity.titleAliases();
        return aliases == null || aliases.isEmpty() ? null : aliases.get(0);
    }

    static ProviderResultState toState(ProbeOutcome outcome) {
        if (outcome == null) return ProviderResultState.FAILED;
        switch (outcome) {
            case VERIFIED:             return ProviderResultState.VERIFIED_PLAYABLE;
            case NOT_FOUND_DEFINITIVE: return ProviderResultState.NO_MATCH;
            case REJECTED_BY_IDENTITY: return ProviderResultState.NO_MATCH;
            case UNRESOLVED_TRANSIENT:
            default:                   return ProviderResultState.FAILED;
        }
    }
}

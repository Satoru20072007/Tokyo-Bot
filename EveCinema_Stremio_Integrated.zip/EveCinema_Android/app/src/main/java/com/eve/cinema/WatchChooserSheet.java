package com.eve.cinema;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import com.eve.cinema.stremio.StremioChooserData;
import com.eve.cinema.stremio.StremioChooserSession;
import com.eve.cinema.stremio.StremioOptionRanker;
import com.eve.cinema.stremio.StremioQuality;
import com.eve.cinema.stremio.StremioSelection;
import com.eve.cinema.stremio.StremioStreamOption;
import com.eve.cinema.stremio.StremioSubtitle;

import java.util.List;

/**
 * "اختر المشاهدة" — the Stremio source chooser, before playback and (in the two player modes)
 * from inside the player.
 *
 * <p>It renders {@link StremioChooserData} snapshots as they arrive (loading → partial → complete,
 * or empty / offline / failed) and keeps the user's choices in {@link StremioSelection}, so a list
 * that grows or re-ranks never moves them. Rules enforced here:
 * <ul>
 *   <li>Nothing is chosen for the user: Play stays disabled until a stream is tapped, and tapping a
 *       subtitle never picks a stream (or the other way round).</li>
 *   <li>Arabic subtitles are listed FIRST, then the streams in fixed quality groups.</li>
 *   <li>A subtitle is only called "matching" when it is tied to the chosen file; otherwise it is
 *       labelled unverified, and a subtitle tied to a different file blocks Play until resolved.</li>
 *   <li>Speed is shown only when measured, always as an estimate.</li>
 * </ul>
 */
public final class WatchChooserSheet extends Dialog {

    public enum Mode { CHOOSE, PLAYER_QUALITY, PLAYER_SUBTITLE }

    /** Override only what the mode needs. */
    public abstract static class Listener {
        /** CHOOSE: the user pressed Play. {@code subtitle} is null for "no subtitles". */
        public void onPlay(StremioStreamOption option, StremioSubtitle subtitle) { }
        /** PLAYER_QUALITY: the user picked another source. */
        public void onSwitchSource(StremioStreamOption option) { }
        /** PLAYER_SUBTITLE: {@code subtitle} null = turn subtitles off. */
        public void onSelectSubtitle(StremioSubtitle subtitle) { }
        /** Empty / offline / failed states: the user asked to search again. */
        public void onRetrySearch() { }
    }

    private static final int RENDER_INTERVAL_MS = 250;
    private static final int MAX_WIDTH_DP = 560;
    private static final int MIN_TOUCH_DP = 48;

    private final StremioChooserSession.Entry entry;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final StremioSelection selection = new StremioSelection();
    private final String currentOptionId;
    private final String currentSubtitleId;

    private Mode mode;
    private boolean onlyWithArabic;
    private boolean hasVisibleOptions;
    /** null means all available qualities; otherwise only that group is rendered in CHOOSE mode. */
    private StremioQuality.Bucket selectedQualityBucket;
    private boolean selectionLost;
    private java.util.Set<String> failedNow = java.util.Collections.emptySet();
    private StremioChooserData data;

    private LinearLayout content;
    private ScrollView scroll;
    private TextView titleView;
    private float density;
    private boolean renderScheduled;
    private long lastRenderAt;

    private final StremioChooserSession.Listener dataListener = new StremioChooserSession.Listener() {
        @Override public void onData(final StremioChooserData next) {
            main.post(new Runnable() {
                @Override public void run() {
                    if (!isShowing()) return;   // closed while the snapshot was in flight
                    data = next;
                    scheduleRender();
                }
            });
        }
    };
    private final Runnable renderRunnable = new Runnable() {
        @Override public void run() {
            renderScheduled = false;
            lastRenderAt = SystemClock.uptimeMillis();
            render();
        }
    };

    private WatchChooserSheet(Context context, StremioChooserSession.Entry entry, Mode mode,
                              String currentOptionId, String currentSubtitleId, Listener listener) {
        super(context, R.style.QualitySheetTheme);
        this.entry = entry;
        this.mode = mode;
        this.currentOptionId = currentOptionId == null ? "" : currentOptionId;
        this.currentSubtitleId = currentSubtitleId == null ? "" : currentSubtitleId;
        this.listener = listener;
        this.data = entry.data();
    }

    public static WatchChooserSheet forChoose(Context context, StremioChooserSession.Entry entry, Listener listener) {
        return new WatchChooserSheet(context, entry, Mode.CHOOSE, null, null, listener);
    }

    public static WatchChooserSheet forPlayerQuality(Context context, StremioChooserSession.Entry entry,
                                                     String currentOptionId, Listener listener) {
        return new WatchChooserSheet(context, entry, Mode.PLAYER_QUALITY, currentOptionId, null, listener);
    }

    public static WatchChooserSheet forPlayerSubtitle(Context context, StremioChooserSession.Entry entry,
                                                      String currentOptionId, String currentSubtitleId,
                                                      Listener listener) {
        return new WatchChooserSheet(context, entry, Mode.PLAYER_SUBTITLE, currentOptionId, currentSubtitleId, listener);
    }

    // ───────────────────────────── lifecycle ─────────────────────────────

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        density = getContext().getResources().getDisplayMetrics().density;
        setContentView(buildRoot());
        Window w = getWindow();
        if (w != null) {
            int screenW = getContext().getResources().getDisplayMetrics().widthPixels;
            w.setLayout(Math.min(screenW, dp(MAX_WIDTH_DP)), ViewGroup.LayoutParams.WRAP_CONTENT);
            w.setGravity(Gravity.BOTTOM);
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setWindowAnimations(R.style.QualitySheetAnim);
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        data = entry.data();
        entry.addListener(dataListener);
        render();
    }

    @Override
    protected void onStop() {
        entry.removeListener(dataListener);
        main.removeCallbacks(renderRunnable);
        renderScheduled = false;
        super.onStop();
    }

    private void scheduleRender() {
        if (renderScheduled) return;
        renderScheduled = true;
        long wait = Math.max(0L, RENDER_INTERVAL_MS - (SystemClock.uptimeMillis() - lastRenderAt));
        main.postDelayed(renderRunnable, wait);
    }

    // ───────────────────────────── layout ─────────────────────────────

    private View buildRoot() {
        final Context ctx = getContext();
        final LinearLayout root = new LinearLayout(ctx);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(ctx.getDrawable(R.drawable.bg_quality_sheet));
        final int padH = dp(20), padTop = dp(16), padBottom = dp(16);
        root.setPadding(padH, padTop, padH, padBottom);
        // Keep the last row and the close button clear of the navigation bar / gesture area.
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                v.setPadding(padH, padTop, padH, padBottom + insets.getSystemWindowInsetBottom());
                return insets;
            }
        });

        View handle = new View(ctx);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(dp(40), dp(4));
        hlp.gravity = Gravity.CENTER_HORIZONTAL;
        hlp.bottomMargin = dp(14);
        handle.setLayoutParams(hlp);
        handle.setBackground(ctx.getDrawable(R.drawable.bg_handle));
        root.addView(handle);

        TextView title = text(titleFor(mode), 17, color(R.color.text_primary), true);
        title.setAccessibilityHeading(true);
        titleView = title;
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tlp.bottomMargin = dp(4);
        root.addView(title, tlp);

        // What is being searched: the title (and the episode for series).
        StringBuilder what = new StringBuilder(entry.title);
        if (("series".equals(entry.type) || "anime".equals(entry.type)) && entry.episode > 0) {
            if (what.length() > 0) what.append("  ·  ");
            what.append(ctx.getString(R.string.watch_episode_line, entry.season, entry.episode));
        }
        if (what.length() > 0) {
            TextView subject = text(what.toString(), 13, color(R.color.text_secondary), false);
            subject.setSingleLine(true);
            subject.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            slp.bottomMargin = dp(10);
            root.addView(subject, slp);
        }

        scroll = new MaxHeightScrollView(ctx, (int) (ctx.getResources().getDisplayMetrics().heightPixels * 0.62f));
        scroll.setVerticalScrollBarEnabled(false);
        content = new LinearLayout(ctx);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return root;
    }

    private String titleFor(Mode m) {
        Context ctx = getContext();
        switch (m) {
            case PLAYER_QUALITY: return ctx.getString(R.string.watch_player_quality_title);
            case PLAYER_SUBTITLE: return ctx.getString(R.string.watch_player_subtitle_title);
            default: return ctx.getString(R.string.watch_choose_title);
        }
    }

    // ───────────────────────────── rendering ─────────────────────────────

    private void render() {
        if (content == null) return;
        final int keepScroll = scroll.getScrollY();
        titleView.setText(titleFor(mode));
        failedNow = entry.failedIds();
        StremioSelection.Change change = selection.reconcile(data);
        if (change.optionLost) selectionLost = true;
        content.removeAllViews();

        addStatus(data);
        if (mode == Mode.PLAYER_SUBTITLE) renderPlayerSubtitles();
        else {
            // Stremio subtitles are chosen automatically for each file. The first-run chooser only
            // asks the user for quality/source; the manual subtitle list lives inside the player.
            renderStreams();
        }
        renderFooter();
        if (keepScroll > 0) scroll.post(new Runnable() {
            @Override public void run() { scroll.scrollTo(0, keepScroll); }
        });
    }

    // ── status block ─────────────────────────────────────────────────────────

    private void addStatus(StremioChooserData d) {
        Context ctx = getContext();
        // Do not keep a progress counter above a usable list. The activity waits briefly before
        // opening this sheet; if the network is unusually slow, only the empty/loading state is shown.
        if (!d.options.isEmpty()) return;
        switch (d.state) {
            case LOADING:
                addProgressLine(ctx.getString(R.string.watch_loading));
                break;
            case OFFLINE:
                addMessage(ctx.getString(R.string.watch_offline), true);
                break;
            case FAILED:
                addMessage(ctx.getString(R.string.watch_failed_all), true);
                break;
            case EMPTY:
                switch (d.emptyReason) {
                    case NO_COMPATIBLE_ADDON: addMessage(ctx.getString(R.string.watch_empty_no_addon), false); break;
                    case ID_UNAVAILABLE: addMessage(ctx.getString(R.string.watch_empty_no_imdb), true); break;
                    case ONLY_UNSUPPORTED:
                        addMessage(ctx.getString(R.string.watch_empty_only_unsupported, d.progress.unsupportedStreams), true);
                        break;
                    default: addMessage(ctx.getString(R.string.watch_empty_no_streams), true);
                }
                break;
            case PARTIAL:
            case COMPLETE:
                break;
        }
    }

    private void addProgressLine(String message) {
        Context ctx = getContext();
        LinearLayout line = new LinearLayout(ctx);
        line.setOrientation(LinearLayout.HORIZONTAL);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setMinimumHeight(dp(MIN_TOUCH_DP));
        ProgressBar spinner = new ProgressBar(ctx, null, android.R.attr.progressBarStyleSmall);
        spinner.setIndeterminate(true);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(dp(18), dp(18));
        slp.setMarginEnd(dp(10));
        line.addView(spinner, slp);
        TextView label = text(message, 13, color(R.color.text_secondary), false);
        line.addView(label, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        line.setContentDescription(message);
        content.addView(line, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
    }

    private void addNote(String message, int color) {
        TextView note = text(message, 12, color, false);
        note.setPadding(0, dp(2), 0, dp(6));
        content.addView(note);
    }

    /** A full-width message; when {@code retry} a "try again" button follows it. */
    private void addMessage(String message, boolean retry) {
        TextView view = text(message, 14, color(R.color.text_primary), false);
        view.setPadding(dp(4), dp(10), dp(4), dp(10));
        view.setLineSpacing(0f, 1.15f);
        content.addView(view);
        if (retry) {
            TextView button = button(getContext().getString(R.string.watch_retry), true);
            button.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { listener.onRetrySearch(); }
            });
            content.addView(button, rowParams(dp(8)));
        }
    }

    // ── subtitle status labels shared with the in-player subtitle picker ──────

    /** How this subtitle relates to the chosen stream (or to the streams in general before one is chosen). */
    private String[] matchLabel(StremioChooserData d, StremioSubtitle s, StremioStreamOption chosen) {
        Context ctx = getContext();
        if (chosen != null) {
            switch (d.match(s, chosen)) {
                case EXACT: return new String[]{ctx.getString(R.string.watch_subtitle_exact), "ok"};
                case UNVERIFIED: return new String[]{ctx.getString(R.string.watch_subtitle_unverified), "warn"};
                default: return new String[]{ctx.getString(R.string.watch_subtitle_other_file), "dim"};
            }
        }
        if (s.generic) return new String[]{ctx.getString(R.string.watch_subtitle_unverified), "warn"};
        int tied = d.optionsFor(s).size();
        return new String[]{ctx.getString(R.string.watch_subtitle_bound_n, Math.max(1, tied)), "ok"};
    }

    private void addSubtitleChoiceRow(String label, boolean active, String[] badge, View.OnClickListener click) {
        Context ctx = getContext();
        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setMinimumHeight(dp(MIN_TOUCH_DP));
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(8), dp(14), dp(8));
        row.setBackground(ctx.getDrawable(active ? R.drawable.bg_quality_row_active : R.drawable.bg_quality_row));
        TextView main = text(active ? label + "  ✓" : label, 14, active ? color(R.color.violet_core) : color(R.color.text_primary), active);
        row.addView(main);
        String description = label;
        if (badge != null) {
            TextView b = text(badge[0], 11, badgeColor(badge[1]), false);
            row.addView(b);
            description = label + "، " + badge[0];
        }
        row.setContentDescription(active ? description + "، ✓" : description);
        row.setSelected(active);
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(click);
        content.addView(row, rowParams(dp(6)));
    }

    // ── streams ──────────────────────────────────────────────────────────────

    private static final int MAX_LINKS_PER_QUALITY = 5;

    private void renderStreams() {
        Context ctx = getContext();
        StremioChooserData d = data;
        List<StremioOptionRanker.Group> groups = d.groups();
        if (mode == Mode.CHOOSE) renderQualityFilters(groups);
        boolean any = false;
        hasVisibleOptions = false;
        for (StremioOptionRanker.Group g : groups) {
            if (mode == Mode.CHOOSE && selectedQualityBucket != null && g.bucket != selectedQualityBucket) continue;
            StremioStreamOption[] rows = visibleIn(g);
            if (rows.length == 0) continue;
            any = true;
            hasVisibleOptions = true;
            String label = qualityLabel(g.bucket);
            // Every quality heading groups at most five Arabic-subtitled options, ranked by measured speed.
            content.addView(sectionHeader(label, null));
            for (StremioStreamOption o : rows) content.addView(optionRow(o), rowParams(dp(5)));
        }
        if (!any && !d.options.isEmpty() && (mode == Mode.CHOOSE || (mode == Mode.PLAYER_QUALITY && onlyWithArabic))) {
            if (d.progress.searching)
                addProgressLine(ctx.getString(R.string.watch_loading));
            else
                addNote(ctx.getString(R.string.watch_no_arabic_anywhere), color(R.color.text_tertiary));
        }
        if (mode == Mode.PLAYER_QUALITY && !d.options.isEmpty()) {
            final boolean showingFiltered = onlyWithArabic;
            TextView toggle = button(ctx.getString(showingFiltered ? R.string.watch_player_show_all
                    : R.string.watch_player_show_sources_with_subs), false);
            toggle.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { onlyWithArabic = !showingFiltered; render(); }
            });
            content.addView(toggle, rowParams(dp(6)));
        }
    }

    private void renderQualityFilters(List<StremioOptionRanker.Group> groups) {
        final Context ctx = getContext();
        List<StremioOptionRanker.Group> available = new java.util.ArrayList<>();
        for (StremioOptionRanker.Group group : groups) {
            if (visibleIn(group).length > 0) available.add(group);
        }
        if (selectedQualityBucket != null) {
            boolean stillAvailable = false;
            for (StremioOptionRanker.Group group : available) {
                if (group.bucket == selectedQualityBucket) { stillAvailable = true; break; }
            }
            if (!stillAvailable) selectedQualityBucket = null;
        }
        if (available.size() < 2) return;

        TextView heading = text(ctx.getString(R.string.watch_available_qualities), 12,
                color(R.color.text_secondary), false);
        heading.setPadding(dp(2), dp(4), dp(2), dp(4));
        content.addView(heading, rowParams(dp(2)));

        HorizontalScrollView horizontal = new HorizontalScrollView(ctx);
        horizontal.setHorizontalScrollBarEnabled(false);
        horizontal.setFillViewport(false);
        LinearLayout chips = new LinearLayout(ctx);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        addQualityChip(chips, ctx.getString(R.string.watch_quality_all), selectedQualityBucket == null,
                new View.OnClickListener() {
                    @Override public void onClick(View v) { selectedQualityBucket = null; render(); }
                });
        for (final StremioOptionRanker.Group group : available) {
            addQualityChip(chips, qualityLabel(group.bucket), selectedQualityBucket == group.bucket,
                    new View.OnClickListener() {
                        @Override public void onClick(View v) { selectedQualityBucket = group.bucket; render(); }
                    });
        }
        horizontal.addView(chips, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        content.addView(horizontal, rowParams(dp(3)));
    }

    private void addQualityChip(LinearLayout parent, String label, boolean active, View.OnClickListener click) {
        TextView chip = text(active ? label + "  ✓" : label, 12,
                color(active ? R.color.violet_core : R.color.text_primary), active);
        chip.setGravity(Gravity.CENTER);
        chip.setMinHeight(dp(38));
        chip.setPadding(dp(12), dp(7), dp(12), dp(7));
        chip.setBackground(getContext().getDrawable(active ? R.drawable.bg_quality_row_active : R.drawable.bg_quality_row));
        chip.setContentDescription(label);
        chip.setSelected(active);
        chip.setClickable(true);
        chip.setFocusable(true);
        chip.setOnClickListener(click);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMarginEnd(dp(6));
        parent.addView(chip, lp);
    }

    private String qualityLabel(StremioQuality.Bucket bucket) {
        return bucket == StremioQuality.Bucket.UNKNOWN
                ? getContext().getString(R.string.watch_quality_unknown) : bucket.label;
    }

    private StremioStreamOption[] visibleIn(StremioOptionRanker.Group g) {
        java.util.ArrayList<StremioStreamOption> out = new java.util.ArrayList<>();
        for (StremioStreamOption o : g.options) {
            // First-run selection is intentionally strict: a source without a usable Arabic subtitle
            // never reaches the user. The in-player quality panel can still reveal all sources manually.
            boolean mustHaveArabic = mode == Mode.CHOOSE || (mode == Mode.PLAYER_QUALITY && onlyWithArabic);
            if (mustHaveArabic && data.recommendedSubtitleFor(o) == null) continue;
            out.add(o);
            if (out.size() >= MAX_LINKS_PER_QUALITY) break;
        }
        return out.toArray(new StremioStreamOption[0]);
    }

    private View optionRow(final StremioStreamOption o) {
        Context ctx = getContext();
        StremioChooserData d = data;
        boolean selected = mode == Mode.CHOOSE && o.id.equals(selection.optionId());
        boolean playingNow = mode == Mode.PLAYER_QUALITY && o.id.equals(currentOptionId);
        boolean failed = failedNow.contains(o.id);

        LinearLayout row = new LinearLayout(ctx);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(dp(54));
        row.setPadding(dp(14), dp(9), dp(14), dp(9));
        row.setBackground(ctx.getDrawable(selected || playingNow
                ? R.drawable.bg_quality_row_active : R.drawable.bg_quality_row));
        row.setAlpha(failed ? 0.62f : 1f);

        String speed = o.hasKnownSpeed()
                ? ctx.getString(R.string.watch_speed_format, StremioStreamOption.formatMbps(o.speedMbps))
                : ctx.getString(R.string.watch_speed_unknown);
        TextView speedView = text(speed, 13, color(R.color.text_secondary), false);
        speedView.setSingleLine(true);
        speedView.setEllipsize(TextUtils.TruncateAt.END);
        speedView.setTextDirection(View.TEXT_DIRECTION_LTR);
        speedView.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        row.addView(speedView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        StremioSubtitle recommended = d.recommendedSubtitleFor(o);
        String compatibility;
        int compatibilityColor;
        if (recommended == null) {
            compatibility = ctx.getString(R.string.watch_subtitle_none_short);
            compatibilityColor = color(R.color.text_tertiary);
        } else if (d.match(recommended, o) == StremioChooserData.Match.EXACT) {
            compatibility = ctx.getString(R.string.watch_subtitle_exact_short);
            compatibilityColor = color(R.color.green_ok);
        } else {
            compatibility = ctx.getString(R.string.watch_subtitle_unverified_short);
            compatibilityColor = color(R.color.amber_warn);
        }
        TextView subtitleView = text(compatibility, 12, compatibilityColor, selected || playingNow);
        subtitleView.setSingleLine(true);
        subtitleView.setEllipsize(TextUtils.TruncateAt.END);
        subtitleView.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        subtitleView.setMaxWidth(dp(190));
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        subLp.setMarginStart(dp(8));
        row.addView(subtitleView, subLp);

        String selectedMark = selected || playingNow ? " ✓" : "";
        row.setContentDescription((o.bucket() == StremioQuality.Bucket.UNKNOWN
                ? ctx.getString(R.string.watch_quality_unknown) : o.bucket().label)
                + "، " + speed + "، " + compatibility + selectedMark);
        row.setSelected(selected || playingNow);
        row.setClickable(true);
        row.setFocusable(true);
        row.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { onOptionTapped(o); }
        });
        return row;
    }

    private void onOptionTapped(StremioStreamOption o) {
        switch (mode) {
            case PLAYER_QUALITY:
                if (!o.id.equals(currentOptionId)) listener.onSwitchSource(o);
                dismiss();
                break;
            case CHOOSE:
                selectionLost = false;
                selection.selectOption(o.id);
                render();
                break;
            default:
                break;
        }
    }

    // ── player subtitle panel ────────────────────────────────────────────────

    private void renderPlayerSubtitles() {
        Context ctx = getContext();
        final StremioChooserData d = data;
        StremioStreamOption current = d.find(currentOptionId);
        addSubtitleChoiceRow(ctx.getString(R.string.watch_player_sub_off), currentSubtitleId.isEmpty(), null,
                new View.OnClickListener() {
                    @Override public void onClick(View v) { listener.onSelectSubtitle(null); dismiss(); }
                });
        if (current == null) {
            addNote(ctx.getString(R.string.watch_player_session_expired), color(R.color.amber_warn));
            return;
        }
        List<StremioSubtitle> offered = d.subtitlesFor(current);
        int number = 0;
        for (final StremioSubtitle s : offered) {
            number++;
            boolean active = s.id.equals(currentSubtitleId);
            addSubtitleChoiceRow(ctx.getString(R.string.watch_subtitle_n, number), active,
                    matchLabel(d, s, current), new View.OnClickListener() {
                        @Override public void onClick(View v) { listener.onSelectSubtitle(s); dismiss(); }
                    });
        }
        if (offered.isEmpty()) {
            addMessage(ctx.getString(R.string.watch_player_no_subs), false);
            TextView other = button(ctx.getString(R.string.watch_player_show_sources_with_subs), false);
            other.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    mode = Mode.PLAYER_QUALITY;
                    onlyWithArabic = true;
                    render();
                }
            });
            content.addView(other, rowParams(dp(8)));
        }
    }

    // ── footer ───────────────────────────────────────────────────────────────

    private void renderFooter() {
        Context ctx = getContext();
        final StremioChooserData d = data;
        if (mode == Mode.CHOOSE) {
            StremioStreamOption selectedOption = selection.option(d);
            boolean hasArabic = selectedOption != null && d.recommendedSubtitleFor(selectedOption) != null;
            boolean can = selection.canPlay(d) && hasArabic;
            if (selection.option(d) == null && hasVisibleOptions)
                addNote(ctx.getString(R.string.watch_pick_source_first), color(R.color.text_tertiary));
            TextView play = button(ctx.getString(R.string.watch_play), true);
            play.setEnabled(can);
            play.setAlpha(can ? 1f : 0.4f);
            if (can) {
                play.setOnClickListener(new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        StremioStreamOption o = selection.option(data);
                        if (o == null || !selection.canPlay(data)) return;
                        // The user chooses only a source. Subtitle selection is automatic and
                        // ranked against this exact stream; PlayerActivity retries the next match
                        // when a candidate is invalid, unavailable, or does not parse.
                        StremioSubtitle automatic = selection.subtitleMode() == StremioSelection.SubtitleMode.SUBTITLE
                                ? selection.subtitle(data) : data.recommendedSubtitleFor(o);
                        listener.onPlay(o, automatic);
                        dismiss();
                    }
                });
            }
            content.addView(play, rowParams(dp(10)));
        }
        TextView close = button(ctx.getString(R.string.watch_close), false);
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { dismiss(); }
        });
        content.addView(close, rowParams(dp(4)));
    }

    // ───────────────────────────── view helpers ─────────────────────────────

    private View sectionHeader(String label, String count) {
        TextView header = text(count == null ? label : label + "  ·  " + count, 13, color(R.color.violet_core), true);
        header.setPadding(dp(4), dp(10), dp(4), dp(6));
        header.setAccessibilityHeading(true);
        return header;
    }

    /** A 48dp-high button-like row (primary = filled, otherwise a quiet text row). */
    private TextView button(String label, boolean primary) {
        Context ctx = getContext();
        TextView b = text(label, primary ? 16 : 14, primary ? color(R.color.text_primary) : color(R.color.text_secondary), primary);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(dp(MIN_TOUCH_DP));
        b.setPadding(dp(14), dp(10), dp(14), dp(10));
        if (primary) b.setBackground(ctx.getDrawable(R.drawable.bg_btn_primary_rounded));
        b.setClickable(true);
        b.setFocusable(true);
        return b;
    }

    private LinearLayout.LayoutParams rowParams(int topMargin) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = topMargin;
        return lp;
    }

    private int badgeColor(String kind) {
        if ("ok".equals(kind)) return color(R.color.green_ok);
        if ("warn".equals(kind)) return color(R.color.amber_warn);
        return color(R.color.text_tertiary);
    }

    private static void append(StringBuilder sb, String part) {
        if (part == null || part.isEmpty()) return;
        if (sb.length() > 0) sb.append("  ·  ");
        sb.append(part);
    }

    private int color(int resId) { return getContext().getColor(resId); }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView view = new TextView(getContext());
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private int dp(int value) { return (int) (value * density + 0.5f); }

    /** ScrollView that never grows past a maximum height, so Play and Close stay on screen. */
    private static final class MaxHeightScrollView extends ScrollView {
        private final int maxHeightPx;
        MaxHeightScrollView(Context context, int maxHeightPx) {
            super(context);
            this.maxHeightPx = maxHeightPx;
        }
        @Override protected void onMeasure(int widthSpec, int heightSpec) {
            super.onMeasure(widthSpec, View.MeasureSpec.makeMeasureSpec(maxHeightPx, View.MeasureSpec.AT_MOST));
        }
    }
}

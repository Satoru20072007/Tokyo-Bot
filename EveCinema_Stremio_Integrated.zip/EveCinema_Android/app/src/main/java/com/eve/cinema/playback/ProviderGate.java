package com.eve.cinema.playback;

/**
 * Small per-provider circuit breaker. Two consecutive transient failures open the
 * gate for a bounded cooldown; after cooldown exactly one caller gets a half-open
 * trial. Definitive positive/negative answers both prove the provider is reachable.
 * Pure Java and clock-injectable for deterministic tests.
 */
public final class ProviderGate {
    public interface Clock { long nowMillis(); }
    public enum State { CLOSED, OPEN, HALF_OPEN }

    private final int failureThreshold;
    private final long openDurationMs;
    private final Clock clock;
    private int consecutiveTransientFailures;
    private long openUntilMs;
    private State state = State.CLOSED;
    private boolean halfOpenInFlight;

    public ProviderGate() {
        this(2, 120_000L, System::currentTimeMillis);
    }

    public ProviderGate(int failureThreshold, long openDurationMs, Clock clock) {
        this.failureThreshold = Math.max(1, failureThreshold);
        this.openDurationMs = Math.max(1L, openDurationMs);
        this.clock = clock == null ? System::currentTimeMillis : clock;
    }

    /** True means a network attempt may start; false means fail fast as transient. */
    public synchronized boolean tryAcquire() {
        long now = clock.nowMillis();
        if (state == State.OPEN) {
            if (now < openUntilMs) return false;
            state = State.HALF_OPEN;
            halfOpenInFlight = false;
        }
        if (state == State.HALF_OPEN) {
            if (halfOpenInFlight) return false;
            halfOpenInFlight = true;
        }
        return true;
    }

    public synchronized void record(ProbeOutcome outcome) {
        if (outcome == ProbeOutcome.UNRESOLVED_TRANSIENT) {
            if (state == State.HALF_OPEN || ++consecutiveTransientFailures >= failureThreshold) {
                state = State.OPEN;
                openUntilMs = clock.nowMillis() + openDurationMs;
                halfOpenInFlight = false;
            }
            return;
        }
        consecutiveTransientFailures = 0;
        openUntilMs = 0;
        halfOpenInFlight = false;
        state = State.CLOSED;
    }

    public synchronized State state() { return state; }
    public synchronized int consecutiveTransientFailures() { return consecutiveTransientFailures; }
    public synchronized long openUntilMillis() { return openUntilMs; }
}

package com.eve.cinema.stremio;

import com.eve.cinema.playback.LanguageMatcher;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Bounded Stremio add-on client. Never logs URLs or response bodies; every failure is a
 * {@link StremioException} whose text carries no URL.
 *
 * <p>Network rules live in {@link StremioNetPolicy} / {@link StremioHttp}; this class only knows the
 * Stremio protocol: which extras a resource may carry, how a stream object is read
 * ({@code url} vs {@code infoHash}/{@code externalUrl}/{@code ytId}, {@code behaviorHints.filename|
 * videoSize|videoHash|proxyHeaders}) and how a subtitle object is read.
 */
public final class StremioAddonClient {
    public static final int MAX_RESPONSE_BYTES = StremioHttp.RESOURCE_LIMITS.maxBytes;
    /** Upper bounds on what is scanned/kept from one answer. */
    static final int MAX_STREAMS_SCANNED = 200;
    static final int MAX_PLAYABLE_PER_RESPONSE = 100;
    static final int MAX_SUBTITLES_SCANNED = 200;
    static final int MAX_ARABIC_SUBTITLES = 200;
    private static final String[] SUBTITLE_EXTRAS = {"videoHash", "videoSize", "filename"};

    /** A stream the add-on offers with a direct {@code url}. */
    public static final class StreamCandidate {
        public final String url;
        public final String name;
        public final String description;
        /** File name for display/quality: behaviorHints.filename, else a legacy top-level one. */
        public final String filename;
        /** behaviorHints.filename only: the sole file name used for identity matching. */
        public final String hintFilename;
        public final long videoSize;
        public final String videoHash;
        public final String streamType;
        public final Map<String, String> headers;
        /** Arabic subtitles the add-on attached to this very stream (already URL-validated). */
        public final List<StremioSubtitle> arabicSubtitles;

        StreamCandidate(String url, String name, String description, String filename,
                        String hintFilename, long videoSize, String videoHash, String streamType,
                        Map<String, String> headers, List<StremioSubtitle> arabicSubtitles) {
            this.url = url; this.name = name; this.description = description;
            this.filename = filename; this.hintFilename = hintFilename;
            this.videoSize = videoSize; this.videoHash = videoHash; this.streamType = streamType;
            this.headers = Collections.unmodifiableMap(headers);
            this.arabicSubtitles = Collections.unmodifiableList(arabicSubtitles);
        }

        public StremioFileIdentity identity() {
            return StremioFileIdentity.of(videoHash, videoSize, hintFilename);
        }
    }

    /** What one stream answer contained; nothing is silently dropped. */
    public static final class StreamBatch {
        public final List<StreamCandidate> playable;
        /** Torrent-only entries ({@code infoHash} without {@code url}); the app has no torrent engine. */
        public final int torrentOnly;
        /** {@code externalUrl} / {@code playerFrameUrl}: pages to open elsewhere, not media. */
        public final int externalOnly;
        public final int youtubeOnly;
        /** Had a {@code url} that violates the public-URL policy. */
        public final int unsafeUrl;
        public final int otherUnsupported;
        public final int scanned;

        StreamBatch(List<StreamCandidate> playable, int torrentOnly, int externalOnly, int youtubeOnly,
                    int unsafeUrl, int otherUnsupported, int scanned) {
            this.playable = Collections.unmodifiableList(playable);
            this.torrentOnly = torrentOnly; this.externalOnly = externalOnly;
            this.youtubeOnly = youtubeOnly; this.unsafeUrl = unsafeUrl;
            this.otherUnsupported = otherUnsupported; this.scanned = scanned;
        }

        public int unsupportedTotal() { return torrentOnly + externalOnly + youtubeOnly + otherUnsupported; }

        static StreamBatch empty() {
            return new StreamBatch(new ArrayList<StreamCandidate>(), 0, 0, 0, 0, 0, 0);
        }
    }

    public static final class SubtitleBatch {
        public final List<StremioSubtitle> arabic;
        public final int nonArabic;
        public final int ignoredFormat;
        public final int unsafeUrl;
        SubtitleBatch(List<StremioSubtitle> arabic, int nonArabic, int ignoredFormat, int unsafeUrl) {
            this.arabic = Collections.unmodifiableList(arabic);
            this.nonArabic = nonArabic; this.ignoredFormat = ignoredFormat; this.unsafeUrl = unsafeUrl;
        }
        static SubtitleBatch empty() { return new SubtitleBatch(new ArrayList<StremioSubtitle>(), 0, 0, 0); }
    }

    public static final class Response {
        public final int statusCode;
        public final JSONObject json;
        Response(int statusCode, JSONObject json) { this.statusCode = statusCode; this.json = json; }
    }

    private final StremioNetPolicy.Policy addonPolicy;
    private final StremioNetPolicy.Policy mediaPolicy;
    private final StremioHttp http;

    public StremioAddonClient() {
        this(StremioNetPolicy.Policy.addon(), StremioNetPolicy.Policy.media());
    }

    /** Test seam: inject policies (and thereby the transport rules). */
    public StremioAddonClient(StremioNetPolicy.Policy addonPolicy, StremioNetPolicy.Policy mediaPolicy) {
        this.addonPolicy = addonPolicy;
        this.mediaPolicy = mediaPolicy;
        this.http = new StremioHttp(addonPolicy);
    }

    // ───────────────────────────── manifest ─────────────────────────────

    public JSONObject fetchManifest(String manifestUrl) throws IOException, JSONException {
        return fetchManifest(manifestUrl, StremioHttp.MANIFEST_LIMITS.totalTimeoutMs);
    }

    /** Manifest fetch with a caller-owned bounded deadline (used for first-run parallel setup). */
    public JSONObject fetchManifest(String manifestUrl, int timeoutMs) throws IOException, JSONException {
        String normalized = StremioUrls.normalizeManifestUrl(manifestUrl, addonPolicy);
        int boundedTimeout = Math.max(1, Math.min(StremioHttp.MANIFEST_LIMITS.totalTimeoutMs, timeoutMs));
        return http.getJson(normalized, StremioHttp.MANIFEST_LIMITS.withTotalTimeout(boundedTimeout),
                StremioUrls.carriesCredential(normalized));
    }

    // ───────────────────────────── generic resource request ─────────────────────────────

    public Response request(StremioAddonStore.Addon addon, String resource, String type, String id,
                            Map<String, String> extraArgs) throws IOException, JSONException {
        return new Response(200, requestJson(addon.manifestUrl, addon.manifest, resource, type, id,
                extraArgs, StremioHttp.RESOURCE_LIMITS.totalTimeoutMs));
    }

    /**
     * One add-on resource call. Extras are filtered by what the protocol allows for that resource:
     * none for stream/meta, {@code videoHash|videoSize|filename} for subtitles, only the
     * manifest-declared (and satisfiable) ones for catalogs.
     */
    JSONObject requestJson(String manifestUrl, StremioManifest manifest, String resource, String type,
                           String id, Map<String, String> extras, int totalTimeoutMs)
            throws StremioException {
        if (manifest.configurationRequired) throw new StremioException(StremioException.Kind.CONFIG_REQUIRED);
        if (!manifest.supports(resource, type, id)) throw new StremioException(StremioException.Kind.UNSUPPORTED);
        Map<String, String> allowed = sanitizeExtras(manifest, resource, type, id, extras);
        String url = StremioUrls.resourceUrl(manifestUrl, resource, type, id, allowed, addonPolicy);
        StremioHttp.Limits limits = StremioHttp.RESOURCE_LIMITS.withTotalTimeout(totalTimeoutMs);
        return http.getJson(url, limits, StremioUrls.carriesCredential(manifestUrl));
    }

    static Map<String, String> sanitizeExtras(StremioManifest manifest, String resource, String type,
                                              String id, Map<String, String> extras) throws StremioException {
        if (StremioManifest.CATALOG.equals(resource))
            return manifest.sanitizeCatalogExtras(type, id, extras);
        if (!StremioManifest.SUBTITLES.equals(resource) || extras == null || extras.isEmpty())
            return Collections.emptyMap();
        Map<String, String> out = new LinkedHashMap<>();
        for (String key : SUBTITLE_EXTRAS) {
            String value = extras.get(key);
            if (value != null && !value.trim().isEmpty()) out.put(key, value.trim());
        }
        return out;
    }

    // ───────────────────────────── streams ─────────────────────────────

    public List<StreamCandidate> streamCandidates(StremioAddonStore.Addon addon, String type, String id)
            throws IOException, JSONException {
        return fetchStreams(addon.manifestUrl, addon.manifest, type, id,
                StremioHttp.RESOURCE_LIMITS.totalTimeoutMs).playable;
    }

    /** Compatibility overload: stream requests carry no extra arguments in the protocol. */
    public List<StreamCandidate> streamCandidates(StremioAddonStore.Addon addon, String type, String id,
                                                  Map<String, String> ignoredExtraArgs)
            throws IOException, JSONException {
        return streamCandidates(addon, type, id);
    }

    public StreamBatch fetchStreams(String manifestUrl, StremioManifest manifest, String type, String id,
                                    int totalTimeoutMs) throws StremioException {
        JSONObject json = requestJson(manifestUrl, manifest, StremioManifest.STREAM, type, id, null, totalTimeoutMs);
        return parseStreams(json, manifestUrl, mediaPolicy);
    }

    static StreamBatch parseStreams(JSONObject json, String manifestUrl, StremioNetPolicy.Policy media) {
        JSONArray streams = json == null ? null : json.optJSONArray("streams");
        if (streams == null) return StreamBatch.empty();
        List<StreamCandidate> playable = new ArrayList<>();
        int torrent = 0, external = 0, youtube = 0, unsafe = 0, other = 0, scanned = 0;
        for (int i = 0; i < streams.length() && i < MAX_STREAMS_SCANNED; i++) {
            JSONObject stream = streams.optJSONObject(i);
            if (stream == null) continue;
            scanned++;
            String url = rawText(stream, "url");
            if (url.length() > MAX_URL_CHARS) { unsafe++; continue; }   // truncating would change the URL
            if (url.isEmpty()) {
                if (!text(stream, "infoHash", 128).isEmpty()) torrent++;
                else if (!text(stream, "externalUrl", 4096).isEmpty()
                        || !text(stream, "playerFrameUrl", 4096).isEmpty()) external++;
                else if (!text(stream, "ytId", 64).isEmpty()) youtube++;
                else other++;
                continue;
            }
            if (!media.isSyntaxSafe(url)) { unsafe++; continue; }
            if (playable.size() >= MAX_PLAYABLE_PER_RESPONSE) continue;
            JSONObject hints = stream.optJSONObject("behaviorHints");
            String hintFile = hints == null ? "" : text(hints, "filename", 512);
            String legacyFile = text(stream, "filename", 512);
            String hash = hints == null ? "" : text(hints, "videoHash", 64);
            long size = hints == null ? -1L : positiveLong(hints, "videoSize");
            String description = text(stream, "description", 2000);
            if (description.isEmpty()) description = text(stream, "title", 2000);
            JSONObject proxy = hints == null ? null : hints.optJSONObject("proxyHeaders");
            Map<String, String> headers = safeHeaders(proxy == null ? null : proxy.optJSONObject("request"),
                    url, manifestUrl);
            List<StremioSubtitle> embedded = parseSubtitleArray(stream.optJSONArray("subtitles"), media).arabic;
            playable.add(new StreamCandidate(url, text(stream, "name", 500), description,
                    hintFile.isEmpty() ? legacyFile : hintFile, hintFile, size, hash, inferType(url),
                    headers, embedded));
        }
        return new StreamBatch(playable, torrent, external, youtube, unsafe, other, scanned);
    }

    // ───────────────────────────── subtitles ─────────────────────────────

    public List<StremioSubtitle> subtitleCandidates(StremioAddonStore.Addon addon, String type, String id)
            throws IOException, JSONException {
        return fetchSubtitles(addon.manifestUrl, addon.manifest, type, id, null,
                StremioHttp.RESOURCE_LIMITS.totalTimeoutMs).arabic;
    }

    /** {@code identityExtras} (videoHash / videoSize / filename) make the answer file-specific. */
    public SubtitleBatch fetchSubtitles(String manifestUrl, StremioManifest manifest, String type,
                                        String id, Map<String, String> identityExtras, int totalTimeoutMs)
            throws StremioException {
        JSONObject json = requestJson(manifestUrl, manifest, StremioManifest.SUBTITLES, type, id,
                identityExtras, totalTimeoutMs);
        return parseSubtitleArray(json.optJSONArray("subtitles"), mediaPolicy);
    }

    /**
     * Keeps only Arabic entries with a public URL in a format the in-app parser reads. The language
     * comes from the add-on's own {@code lang} field — never from a file name — and its confidence
     * (code vs name) is recorded on the subtitle.
     */
    static SubtitleBatch parseSubtitleArray(JSONArray array, StremioNetPolicy.Policy media) {
        if (array == null) return SubtitleBatch.empty();
        List<StremioSubtitle> out = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        int nonArabic = 0, ignored = 0, unsafe = 0;
        for (int i = 0; i < array.length() && i < MAX_SUBTITLES_SCANNED; i++) {
            JSONObject item = array.optJSONObject(i);
            if (item == null) continue;
            String lang = text(item, "lang", 64);
            if (!LanguageMatcher.isArabic(lang)) { nonArabic++; continue; }
            String url = rawText(item, "url");
            if (url.isEmpty()) continue;
            if (url.length() > MAX_URL_CHARS || !media.isSyntaxSafe(url)) { unsafe++; continue; }
            if (StremioSubtitle.hasUnsupportedFormatExtension(url)) { ignored++; continue; }
            if (out.size() < MAX_ARABIC_SUBTITLES && seen.add(url)) out.add(new StremioSubtitle(url, lang));
        }
        return new SubtitleBatch(out, nonArabic, ignored, unsafe);
    }

    // ───────────────────────────── URL helpers (public API kept) ─────────────────────────────

    public static String normalizeManifestUrl(String value) throws IOException {
        return StremioUrls.normalizeManifestUrl(value);
    }

    public static boolean isSafePublicHttpsUrl(String value) {
        return StremioNetPolicy.Policy.addon().isSafe(value);
    }

    public static boolean isSafePublicMediaUrl(String value) {
        return StremioNetPolicy.Policy.media().isSafe(value);
    }

    // ───────────────────────────── parsing helpers ─────────────────────────────

    private static final String[] PROXY_HEADERS = {"User-Agent", "Referer", "Origin", "Cookie", "Authorization"};

    /**
     * Only a short allow-list of request headers is forwarded to the player, matched
     * case-insensitively. Cookie and Authorization are forwarded only over HTTPS to the add-on's
     * own host: a stream URL on another host never receives them.
     */
    static Map<String, String> safeHeaders(JSONObject object, String streamUrl, String addonUrl) {
        if (object == null) return Collections.emptyMap();
        Map<String, String> result = new LinkedHashMap<>();
        String urlHost = host(streamUrl), addonHost = host(addonUrl);
        boolean secureTransport = streamUrl != null && streamUrl.regionMatches(true, 0, "https://", 0, 8);
        for (String wanted : PROXY_HEADERS) {
            String value = "";
            java.util.Iterator<String> keys = object.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                if (wanted.equalsIgnoreCase(key) && !object.isNull(key)) { value = bounded(object.optString(key, ""), 2048); break; }
            }
            if (value.isEmpty() || value.indexOf('\r') >= 0 || value.indexOf('\n') >= 0) continue;
            if (("Cookie".equals(wanted) || "Authorization".equals(wanted))
                    && (!secureTransport || urlHost == null || !urlHost.equalsIgnoreCase(addonHost))) continue;
            result.put(wanted, value);
        }
        return result;
    }

    private static String host(String value) {
        try { return URI.create(value).getHost(); } catch (Exception ex) { return null; }
    }

    static String inferType(String url) {
        String path;
        try { path = URI.create(url).getPath().toLowerCase(Locale.US); }
        catch (Exception ex) { return "OTHER"; }
        if (path.endsWith(".m3u8")) return "HLS";
        if (path.endsWith(".mpd")) return "DASH";
        if (path.endsWith(".mp4") || path.endsWith(".m4v") || path.endsWith(".mkv")
                || path.endsWith(".webm") || path.endsWith(".mov") || path.endsWith(".ts")) return "PROGRESSIVE";
        return "UNKNOWN";
    }

    private static final int MAX_URL_CHARS = 4096;

    /** Trimmed string field without any length cut (a JSON null is "", not the text "null"). */
    private static String rawText(JSONObject object, String key) {
        if (object == null || object.isNull(key)) return "";
        return object.optString(key, "").replace('\u0000', ' ').trim();
    }

    /** Null-safe string field (a JSON null is "", not the text "null"). */
    private static String text(JSONObject object, String key, int max) {
        if (object == null || object.isNull(key)) return "";
        return bounded(object.optString(key, ""), max);
    }

    private static long positiveLong(JSONObject object, String key) {
        if (object.isNull(key)) return -1L;
        long value = object.optLong(key, -1L);
        return value > 0 && value < 10_000_000_000_000L ? value : -1L;
    }

    private static String bounded(String value, int max) {
        if (value == null) return "";
        String clean = value.replace('\u0000', ' ').trim();
        return clean.length() <= max ? clean : clean.substring(0, max);
    }
}

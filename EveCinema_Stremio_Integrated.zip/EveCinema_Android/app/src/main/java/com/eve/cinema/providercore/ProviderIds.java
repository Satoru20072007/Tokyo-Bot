package com.eve.cinema.providercore;

/** معرّفات داخلية ثابتة للمصادر — لا تُعرض في واجهة المستخدم أبداً. */
public final class ProviderIds {
    public static final String CINEMABOX = "cinemabox";
    public static final String MOVIEBOX  = "moviebox";
    public static final String VODU      = "vodu";
    public static final String SINEMANA  = "sinemana";

    private ProviderIds() {}
}

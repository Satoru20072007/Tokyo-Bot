package com.eve.cinema.providercore;

import com.eve.cinema.playback.PlaybackMode;

/**
 * CapabilityEvidence — دليل نوع العربية لمرشح واحد (خطة §3 ووحدة §4.1).
 *
 * لكل نوع عربي دليل مستقل: وجود صوت عربي لا يعني وجود ترجمة والعكس. اللغة
 * دليل لا تسمية (قرار رقم 10): لا يُعلن نوع إلا بمستوى دليل VERIFIED.
 *
 * Pure Java, no Android deps — unit-tested on the JVM.
 */
public final class CapabilityEvidence {

    /** مستوى الدليل لنوع واحد. الترتيب تصاعدي قوةً. */
    public enum Level {
        /** لم يُفحص أو لا دليل. */
        UNKNOWN,
        /** إشارة ضعيفة (وصف عام/اسم إصدار) — لا تكفي وحدها لإظهار زر. */
        HINTED,
        /** فشل فحص النوع — لا يعني غيابه (قاعدة §3 رقم 4). */
        FAILED,
        /** فُحص وثبت غيابه لهذا العنصر. */
        ABSENT,
        /** دليل مثبت حسب جدول §3 (مسار صوت موثّق / إصدار مربوط بالرابط / ملف مطابق متزامن). */
        VERIFIED
    }

    private final Level dub;
    private final Level inVideoSubtitle;
    private final Level externalSubtitle;
    private final String notes; // داخلية فقط، لا تعرض للمستخدم؛ nullable

    private CapabilityEvidence(Level dub, Level inVideo, Level external, String notes) {
        this.dub = dub == null ? Level.UNKNOWN : dub;
        this.inVideoSubtitle = inVideo == null ? Level.UNKNOWN : inVideo;
        this.externalSubtitle = external == null ? Level.UNKNOWN : external;
        this.notes = notes;
    }

    public static CapabilityEvidence none() {
        return new CapabilityEvidence(Level.UNKNOWN, Level.UNKNOWN, Level.UNKNOWN, null);
    }

    public static CapabilityEvidence of(Level dub, Level inVideo, Level external) {
        return new CapabilityEvidence(dub, inVideo, external, null);
    }

    public CapabilityEvidence withDub(Level l) {
        return new CapabilityEvidence(l, inVideoSubtitle, externalSubtitle, notes);
    }

    public CapabilityEvidence withInVideoSubtitle(Level l) {
        return new CapabilityEvidence(dub, l, externalSubtitle, notes);
    }

    public CapabilityEvidence withExternalSubtitle(Level l) {
        return new CapabilityEvidence(dub, inVideoSubtitle, l, notes);
    }

    public CapabilityEvidence note(String n) {
        return new CapabilityEvidence(dub, inVideoSubtitle, externalSubtitle, n);
    }

    public Level forMode(PlaybackMode mode) {
        if (mode == null) return Level.UNKNOWN;
        switch (mode) {
            case ARABIC_DUB: return dub;
            case ARABIC_IN_VIDEO_SUBTITLE: return inVideoSubtitle;
            case ARABIC_SUBTITLE: return externalSubtitle;
            default: return Level.UNKNOWN;
        }
    }

    /** هل أثبت هذا النوع بمستوى يسمح بإنشاء زر؟ */
    public boolean isVerified(PlaybackMode mode) {
        return forMode(mode) == Level.VERIFIED;
    }

    /** الأنواع العربية الثلاثة المثبتة — الواجهة تبني أزرارها من هذه فقط. */
    public java.util.EnumSet<PlaybackMode> verifiedModes() {
        java.util.EnumSet<PlaybackMode> out = java.util.EnumSet.noneOf(PlaybackMode.class);
        if (dub == Level.VERIFIED) out.add(PlaybackMode.ARABIC_DUB);
        if (inVideoSubtitle == Level.VERIFIED) out.add(PlaybackMode.ARABIC_IN_VIDEO_SUBTITLE);
        if (externalSubtitle == Level.VERIFIED) out.add(PlaybackMode.ARABIC_SUBTITLE);
        return out;
    }

    public Level dub() { return dub; }
    public Level inVideoSubtitle() { return inVideoSubtitle; }
    public Level externalSubtitle() { return externalSubtitle; }
    public String notes() { return notes; }
}

package com.eve.cinema.stremio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Immutable snapshot of one "choose how to watch" search. The engine publishes a new snapshot
 * every time something arrives (a stream batch, a subtitle answer, a speed measurement); the UI
 * only renders snapshots and never mutates them. Selection (which stream, which subtitle) is NOT
 * part of the data: it belongs to the user and survives every update.
 */
public final class StremioChooserData {
    public static final int MAX_SUBTITLES_PER_OPTION = 12;

    public enum State {
        /** Searching, nothing playable yet. */
        LOADING,
        /** Searching, at least one playable option is already listed. */
        PARTIAL,
        /** Search finished with at least one option. */
        COMPLETE,
        /** Search finished without any playable option (see {@link EmptyReason}). */
        EMPTY,
        /** Every add-on failed and the failures look like a lost connection. */
        OFFLINE,
        /** Every add-on failed for another reason (timeout, HTTP error, bad answer). */
        FAILED
    }

    public enum EmptyReason {
        NONE, NO_COMPATIBLE_ADDON, NO_STREAMS, ONLY_UNSUPPORTED, ALL_FAILED,
        /** Usable add-ons exist but need an IMDb id that could not be obtained (TMDB unreachable / no such id). */
        ID_UNAVAILABLE
    }

    public enum Match {
        /** Attached to this stream by the add-on, or requested with this file's identity. */
        EXACT,
        /** Title-level answer: nothing proves it belongs to this release. */
        UNVERIFIED,
        /** Bound to a different file. */
        INCOMPATIBLE
    }

    /** Counters shown by the UI and written to diagnostics; none of them contains a URL. */
    public static final class Progress {
        public static final Progress NONE = new Progress(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, false, false);
        public final int addonsTotal, addonsFinished, addonsFailed, addonsTimedOut;
        public final int unsupportedStreams, unsafeStreams, deadLinks, unsupportedSubtitleFormats;
        public final int subtitleRequestsTotal, subtitleRequestsFinished;
        /** Distinct file identities that were NOT searched for subtitles because of the request cap. */
        public final int identitiesUnchecked;
        public final boolean searching, measuring;

        public Progress(int addonsTotal, int addonsFinished, int addonsFailed, int addonsTimedOut,
                        int unsupportedStreams, int unsafeStreams, int deadLinks,
                        int unsupportedSubtitleFormats, int subtitleRequestsTotal,
                        int subtitleRequestsFinished, int identitiesUnchecked,
                        boolean searching, boolean measuring) {
            this.addonsTotal = addonsTotal; this.addonsFinished = addonsFinished;
            this.addonsFailed = addonsFailed; this.addonsTimedOut = addonsTimedOut;
            this.unsupportedStreams = unsupportedStreams; this.unsafeStreams = unsafeStreams;
            this.deadLinks = deadLinks; this.unsupportedSubtitleFormats = unsupportedSubtitleFormats;
            this.subtitleRequestsTotal = subtitleRequestsTotal;
            this.subtitleRequestsFinished = subtitleRequestsFinished;
            this.identitiesUnchecked = identitiesUnchecked;
            this.searching = searching; this.measuring = measuring;
        }
    }

    public final long version;
    public final State state;
    public final EmptyReason emptyReason;
    /** Options in display order (quality groups, arrival order inside a group). */
    public final List<StremioStreamOption> options;
    /** Arabic subtitle candidates, de-duplicated by URL, in arrival order. */
    public final List<StremioSubtitle> subtitles;
    public final Progress progress;
    /** Id of the fastest MEASURED option; null when fewer than two options were measured. */
    public final String fastestId;

    public StremioChooserData(long version, State state, EmptyReason emptyReason,
                              List<StremioStreamOption> orderedOptions, List<StremioSubtitle> subtitles,
                              Progress progress) {
        this.version = version;
        this.state = state;
        this.emptyReason = emptyReason == null ? EmptyReason.NONE : emptyReason;
        this.options = Collections.unmodifiableList(new ArrayList<>(orderedOptions));
        this.subtitles = Collections.unmodifiableList(new ArrayList<>(subtitles));
        this.progress = progress == null ? Progress.NONE : progress;
        int measured = 0;
        StremioStreamOption fastest = null;
        for (StremioStreamOption o : this.options) {
            if (!o.hasKnownSpeed()) continue;
            measured++;
            if (fastest == null || o.speedMbps > fastest.speedMbps) fastest = o;
        }
        this.fastestId = measured >= 2 && fastest != null ? fastest.id : null;
    }

    /** Compatibility constructor: a finished list with title-level (unverified) subtitles. */
    public StremioChooserData(List<StremioStreamOption> orderedOptions, List<StremioSubtitle> titleSubtitles) {
        this(0L, orderedOptions.isEmpty() ? State.EMPTY : State.COMPLETE,
                orderedOptions.isEmpty() ? EmptyReason.NO_STREAMS : EmptyReason.NONE,
                orderedOptions, titleSubtitles, Progress.NONE);
    }

    public static StremioChooserData empty() {
        return new StremioChooserData(Collections.<StremioStreamOption>emptyList(),
                Collections.<StremioSubtitle>emptyList());
    }

    public static StremioChooserData loading() {
        return new StremioChooserData(0L, State.LOADING, EmptyReason.NONE,
                Collections.<StremioStreamOption>emptyList(), Collections.<StremioSubtitle>emptyList(),
                new Progress(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, true, false));
    }

    /**
     * The same data frozen as final: used when a search is stopped half-way. Nothing is searching
     * or measuring any more; with options it reads COMPLETE, without any it reads EMPTY/NO_STREAMS.
     */
    public StremioChooserData settled() {
        if (isFinal()) return this;
        Progress p = progress;
        Progress frozen = new Progress(p.addonsTotal, p.addonsFinished, p.addonsFailed, p.addonsTimedOut,
                p.unsupportedStreams, p.unsafeStreams, p.deadLinks, p.unsupportedSubtitleFormats,
                p.subtitleRequestsTotal, p.subtitleRequestsFinished, p.identitiesUnchecked, false, false);
        boolean any = !options.isEmpty();
        return new StremioChooserData(version + 1, any ? State.COMPLETE : State.EMPTY,
                any ? EmptyReason.NONE : EmptyReason.NO_STREAMS, options, subtitles, frozen);
    }

    /** No more results will arrive from the add-on search. */
    public boolean isFinal() {
        return state == State.COMPLETE || state == State.EMPTY || state == State.OFFLINE || state == State.FAILED;
    }

    public List<StremioOptionRanker.Group> groups() { return StremioOptionRanker.group(options); }

    public Match match(StremioSubtitle subtitle, StremioStreamOption option) {
        if (subtitle.boundOptionIds.contains(option.id)) return Match.EXACT;
        for (String key : option.fileKeys) if (subtitle.boundFileKeys.contains(key)) return Match.EXACT;
        return subtitle.generic ? Match.UNVERIFIED : Match.INCOMPATIBLE;
    }

    /**
     * All subtitles that may belong to this option, best match first. Exact file/stream bindings
     * always outrank title-level results; subtitles bound to another file are excluded. This list
     * is for automatic selection and fallback, not direct rendering in the UI.
     */
    public List<StremioSubtitle> allSubtitlesFor(final StremioStreamOption option) {
        if (option == null) return Collections.emptyList();
        List<StremioSubtitle> exact = new ArrayList<>();
        List<StremioSubtitle> generic = new ArrayList<>();
        for (StremioSubtitle s : subtitles) {
            Match m = match(s, option);
            if (m == Match.EXACT) exact.add(s);
            else if (m == Match.UNVERIFIED) generic.add(s);
        }
        java.util.Comparator<StremioSubtitle> bestFirst = new java.util.Comparator<StremioSubtitle>() {
            @Override public int compare(StremioSubtitle a, StremioSubtitle b) {
                int direct = Boolean.compare(b.boundOptionIds.contains(option.id), a.boundOptionIds.contains(option.id));
                if (direct != 0) return direct;
                int language = Integer.compare(b.languageConfidence, a.languageConfidence);
                if (language != 0) return language;
                return 0; // stable sort preserves add-on order when evidence is equal
            }
        };
        Collections.sort(exact, bestFirst);
        Collections.sort(generic, bestFirst);
        List<StremioSubtitle> out = new ArrayList<>(exact.size() + generic.size());
        out.addAll(exact);
        out.addAll(generic);
        return out;
    }

    /** One best automatic choice for the selected file, or null when nothing is compatible. */
    public StremioSubtitle recommendedSubtitleFor(StremioStreamOption option) {
        List<StremioSubtitle> candidates = allSubtitlesFor(option);
        return candidates.isEmpty() ? null : candidates.get(0);
    }

    /**
     * Short list for the manual in-player subtitle panel. Playback fallback uses allSubtitlesFor()
     * so a long add-on result is ranked once and tried one-by-one without showing 200 rows.
     */
    public List<StremioSubtitle> subtitlesFor(StremioStreamOption option) {
        List<StremioSubtitle> all = allSubtitlesFor(option);
        if (all.size() <= MAX_SUBTITLES_PER_OPTION) return all;
        return new ArrayList<>(all.subList(0, MAX_SUBTITLES_PER_OPTION));
    }

    public boolean hasExactArabic(StremioStreamOption option) {
        if (option == null) return false;
        for (StremioSubtitle s : subtitles) if (match(s, option) == Match.EXACT) return true;
        return false;
    }

    public int countWithExactArabic() {
        int n = 0;
        for (StremioStreamOption o : options) if (hasExactArabic(o)) n++;
        return n;
    }

    /** Options for which this subtitle is not incompatible (exact first). */
    public List<StremioStreamOption> optionsFor(StremioSubtitle subtitle) {
        List<StremioStreamOption> exact = new ArrayList<>();
        List<StremioStreamOption> other = new ArrayList<>();
        for (StremioStreamOption o : options) {
            Match m = match(subtitle, o);
            if (m == Match.EXACT) exact.add(o);
            else if (m == Match.UNVERIFIED) other.add(o);
        }
        exact.addAll(other);
        return exact;
    }

    public StremioStreamOption find(String id) {
        if (id == null) return null;
        for (StremioStreamOption o : options) if (id.equals(o.id)) return o;
        return null;
    }

    public StremioSubtitle findSubtitle(String id) {
        if (id == null || id.isEmpty()) return null;
        for (StremioSubtitle s : subtitles) if (id.equals(s.id)) return s;
        return null;
    }
}

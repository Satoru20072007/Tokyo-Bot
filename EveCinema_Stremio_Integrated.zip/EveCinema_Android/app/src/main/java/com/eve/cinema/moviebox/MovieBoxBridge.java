/*
 * Derived from MovieBox-Tui (Rust) — upstream dual-licensed MIT / Apache-2.0.
 * Upstream copyright retained. See NOTICE at the project root for the full
 * license texts and attribution scope.
 */
package com.eve.cinema.moviebox;

/*
 * High-level MovieBox resolver for Eve. Orchestrates:
 *   visitor session → search → confident title pick → details/season check →
 *   play-info/v2 (+ resource fallback) → ext-captions → Playback payload.
 *
 * Blocking API — call from a background thread (Eve's DetailActivity /
 * EpisodesActivity already resolve off the main thread).
 */

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.util.Log;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.eve.cinema.moviebox.MovieBoxModels.Playback;
import com.eve.cinema.moviebox.MovieBoxModels.DubOption;
import com.eve.cinema.moviebox.MovieBoxModels.SeasonInfo;
import com.eve.cinema.moviebox.MovieBoxModels.StreamSource;
import com.eve.cinema.moviebox.MovieBoxModels.SubjectItem;
import com.eve.cinema.moviebox.MovieBoxModels.SubtitleOption;

public final class MovieBoxBridge {

    private static final String TAG = "MovieBoxBridge";
    private static MovieBoxBridge INSTANCE;
    private static boolean networkCallbackRegistered;
    private static ConnectivityManager.NetworkCallback networkCallback;

    private final MovieBoxClient client;
    private final MovieBoxHostSelector selector;
    private final boolean contextConfigured;
    private static final long SUBJECT_DETAILS_TTL_MS = 5L * 60L * 1000L;
    private static final int MAX_SUBJECT_DETAILS_CACHE = 64;
    private static final class CachedSubjectDetails {
        final JSONObject value;
        final long createdAtMs;
        CachedSubjectDetails(JSONObject value, long createdAtMs) {
            this.value = value;
            this.createdAtMs = createdAtMs;
        }
    }
    private final LinkedHashMap<String, CachedSubjectDetails> subjectDetailsCache =
            new LinkedHashMap<String, CachedSubjectDetails>(32, 0.75f, true);

    MovieBoxBridge(MovieBoxClient client, MovieBoxHostSelector selector,
                   boolean contextConfigured) {
        this.client = client;
        this.selector = selector;
        this.contextConfigured = contextConfigured;
        this.client.setFallbackListener(new MovieBoxClient.FallbackListener() {
            @Override public void onFallback(String base, String diagnostics) {
                Log.d(TAG, "API host fallback " + base + " " + diagnostics);
            }
        });
    }

    public static synchronized MovieBoxBridge get() {
        if (INSTANCE == null) {
            MovieBoxHostSelector selector = new MovieBoxHostSelector();
            INSTANCE = new MovieBoxBridge(new MovieBoxClient(
                    MovieBoxIdentity.build("", "", "", "", "", "", "", "", "", ""),
                    selector, new HttpUrlTransport()), selector, false);
        }
        return INSTANCE;
    }

    /** Enables SharedPreferences-backed session persistence (30-day TTL). */
    public static synchronized MovieBoxBridge get(Context ctx) {
        Context appContext = ctx.getApplicationContext();
        if (INSTANCE == null || !INSTANCE.contextConfigured) {
            MovieBoxHostSelector selector = new MovieBoxHostSelector(null,
                    new PrefsMetricsStore(appContext), null);
            MovieBoxClient client = new MovieBoxClient(
                    MovieBoxIdentity.fromDevice(appContext), selector, new HttpUrlTransport());
            INSTANCE = new MovieBoxBridge(client, selector, true);
        }
        INSTANCE.client.setSessionStore(new PrefsSessionStore(appContext));
        registerNetworkCallback(appContext, INSTANCE.selector);
        return INSTANCE;
    }

    public String hostDiagnostics() {
        return selector.snapshot().toString();
    }

    private static void registerNetworkCallback(Context context,
                                               final MovieBoxHostSelector selector) {
        if (networkCallbackRegistered) return;
        final ConnectivityManager manager = (ConnectivityManager) context.getSystemService(
                Context.CONNECTIVITY_SERVICE);
        if (manager == null) return;
        try {
            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) {
                    updateNetworkKey(manager, selector, network);
                }

                @Override public void onCapabilitiesChanged(Network network,
                                                            NetworkCapabilities capabilities) {
                    selector.onNetworkChanged(networkKey(capabilities));
                }

                @Override public void onLost(Network network) {
                    Network active = manager.getActiveNetwork();
                    updateNetworkKey(manager, selector, active);
                }
            };
            manager.registerDefaultNetworkCallback(networkCallback);
            networkCallbackRegistered = true;
            updateNetworkKey(manager, selector, manager.getActiveNetwork());
        } catch (SecurityException | IllegalArgumentException ignored) {}
    }

    private static void updateNetworkKey(ConnectivityManager manager,
                                        MovieBoxHostSelector selector, Network network) {
        NetworkCapabilities capabilities = network == null ? null
                : manager.getNetworkCapabilities(network);
        selector.onNetworkChanged(networkKey(capabilities));
    }

    private static String networkKey(NetworkCapabilities capabilities) {
        if (capabilities == null) return "unknown";
        if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return "vpn";
        if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "wifi";
        if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "cellular";
        if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "ethernet";
        return "unknown";
    }

    // ── Session persistence ──────────────────────────────────

    private static final class PrefsSessionStore implements MovieBoxClient.SessionStore {
        private static final String PREFS = "eve_moviebox_session";
        private static final String KEY = "session_json";
        private static final String KEY_SAVED_AT = "saved_at";
        private static final long MAX_AGE_MS = 30L * 24 * 3600 * 1000;

        private final SharedPreferences prefs;

        PrefsSessionStore(Context ctx) {
            this.prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        }

        @Override public MovieBoxSession load() {
            try {
                long savedAt = prefs.getLong(KEY_SAVED_AT, 0);
                if (savedAt <= 0 || System.currentTimeMillis() - savedAt > MAX_AGE_MS) return null;
                String json = prefs.getString(KEY, null);
                if (json == null) return null;
                return MovieBoxSession.fromJson(new JSONObject(json));
            } catch (Exception e) {
                return null;
            }
        }

        @Override public void save(MovieBoxSession session) {
            prefs.edit()
                    .putString(KEY, session.toJson().toString())
                    .putLong(KEY_SAVED_AT, System.currentTimeMillis())
                    .apply();
        }

        @Override public void clear() {
            prefs.edit().remove(KEY).remove(KEY_SAVED_AT).apply();
        }
    }

    private static final class PrefsMetricsStore implements MovieBoxHostSelector.MetricsStore {
        private static final String PREFS = "eve_moviebox_hosts";
        private static final String KEY = "metrics_json";

        private final SharedPreferences prefs;

        PrefsMetricsStore(Context context) {
            this.prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        }

        @Override public String load() {
            return prefs.getString(KEY, null);
        }

        @Override public void save(String json) {
            prefs.edit().putString(KEY, json).apply();
        }
    }

    // ── Public resolution API ────────────────────────────────

    /** Resolves a TMDB movie to playable MovieBox streams. */
    public Playback resolveMovie(String title, String originalTitle, int year)
            throws MovieBoxException {
        List<MovieBoxTitleMatcher.ReleaseCandidate> candidates =
                findReleaseCandidates(title, originalTitle, year, 0, false);
        MovieBoxException firstError = null;
        MovieBoxTitleMatcher.ReleaseCandidate subtitleFallback = null;
        int examined = 0;
        for (MovieBoxTitleMatcher.ReleaseCandidate candidate : candidates) {
            if (candidate.tag != null && candidate.tag.isArabicSubtitleHint()) {
                if (subtitleFallback == null) subtitleFallback = candidate;
                continue; // A translated video is selectable, never the implicit base.
            }
            if (examined++ >= MAX_RELEASE_EVALUATIONS) break;
            // A movie title may return a dubbed subject before its original
            // counterpart. Never silently make a language-labelled release the
            // base video: it prevents the pre-playback chooser from comparing
            // modes on the same canonical work.
            if (!isSafeDefaultMovieRelease(candidate.tag)) continue;
            try {
                JSONObject details = detailsOrThrow(candidate.item.subjectId);
                String actualId = MovieBoxParser.optId(details, "subjectId", "id");
                if (!candidate.item.subjectId.equals(actualId)
                        || !MovieBoxSubtitleReleaseResolver.sameIdentity(candidate.tag.baseTitle, false,
                                details.optString("title", candidate.tag.baseTitle),
                                MovieBoxParser.detailsIsSeries(details))) {
                    continue;
                }
                List<DubOption> dubs = MovieBoxParser.parseDubs(details);
                Playback playback = buildPlayback(candidate.item.subjectId,
                        candidate.tag.baseTitle, false, 0, 0, dubs);
                playback.canonicalSubjectId = candidate.item.subjectId;
                addRelatedReleaseSearchCandidates(playback, candidates);
                return playback;
            } catch (MovieBoxException e) {
                if (firstError == null) firstError = e;
                if (isTransportFailure(e)) continue;
            }
        }
        if (firstError != null) throw firstError;
        if (subtitleFallback != null) {
            JSONObject details = detailsOrThrow(subtitleFallback.item.subjectId);
            String actualId = MovieBoxParser.optId(details, "subjectId", "id");
            if (!subtitleFallback.item.subjectId.equals(actualId)
                    || !MovieBoxSubtitleReleaseResolver.sameIdentity(
                            subtitleFallback.tag.baseTitle, false,
                            details.optString("title", subtitleFallback.tag.rawTitle),
                            MovieBoxParser.detailsIsSeries(details))) {
                throw new MovieBoxException(MovieBoxException.Kind.NO_SOURCE,
                        "Subtitle-labelled subject did not match the requested movie");
            }
            Playback onlyVideoSubtitle = buildPlayback(subtitleFallback.item.subjectId,
                    subtitleFallback.tag.baseTitle, false, 0, 0,
                    MovieBoxParser.parseDubs(details));
            if (onlyVideoSubtitle.streams.isEmpty())
                throw new MovieBoxException(MovieBoxException.Kind.NO_SOURCE,
                        "Subtitle-labelled movie has no playable stream");
            onlyVideoSubtitle.canonicalSubjectId = subtitleFallback.item.subjectId;
            onlyVideoSubtitle.inVideoSubtitleRelease = true;
            onlyVideoSubtitle.releaseEvidence = "only available candidate is provider-labelled Arabic subtitle video; pixels not inspected";
            addRelatedReleaseSearchCandidates(onlyVideoSubtitle, candidates);
            return onlyVideoSubtitle;
        }
        throw new MovieBoxException(MovieBoxException.Kind.NO_SOURCE,
                "No safe original MovieBox release; refusing automatic language-labelled playback");
    }

    private static boolean isSafeDefaultMovieRelease(MovieBoxReleaseTag tag) {
        return tag != null && !tag.dubLabelled && !tag.isArabicDubHint()
                && !tag.isArabicSubtitleHint()
                && tag.markerKind != MovieBoxReleaseClassifier.Kind.ARABIC_AMBIGUOUS;
    }

    /** Search-only release variants are hints, never silently made the base video. */
    private static void addRelatedReleaseSearchCandidates(Playback playback,
            List<MovieBoxTitleMatcher.ReleaseCandidate> candidates) {
        if (playback == null || candidates == null) return;
        for (MovieBoxTitleMatcher.ReleaseCandidate candidate : candidates) {
            if (candidate == null || candidate.item == null || candidate.tag == null
                    || candidate.item.subjectId == null
                    || candidate.item.subjectId.equals(playback.subjectId)) continue;
            MovieBoxReleaseClassifier.Kind kind = candidate.tag.markerKind;
            if (kind != MovieBoxReleaseClassifier.Kind.ARABIC_DUB
                    && kind != MovieBoxReleaseClassifier.Kind.ARABIC_SUBTITLE) continue;
            boolean exists = false;
            for (DubOption prior : playback.dubs)
                if (prior != null && candidate.item.subjectId.equals(prior.subjectId)) {
                    exists = true; break;
                }
            if (exists) continue;
            DubOption option = new DubOption();
            option.subjectId = candidate.item.subjectId;
            option.language = kind == MovieBoxReleaseClassifier.Kind.ARABIC_SUBTITLE
                    ? "Arabic sub" : "Arabic dub";
            option.lanCode = "ar";
            option.rawType = kind == MovieBoxReleaseClassifier.Kind.ARABIC_SUBTITLE ? "1" : "0";
            option.label = candidate.item.title;
            playback.dubs.add(option);
        }
    }

    /** Resolves one episode of a TMDB series to playable MovieBox streams. */
    public Playback resolveEpisode(String title, String originalTitle, int year,
                                   int season, int episode) throws MovieBoxException {
        return resolveEpisode(title, originalTitle, year, season, episode, null);
    }

    /**
     * Resolves TMDB S/E through {@link MovieBoxEpisodeMapper}; TMDB numbering is
     * never sent to MovieBox blindly. {@code tmdbSeasonCounts} (TMDB
     * episode_count per season) enables absolute/split-cour mapping for anime.
     */
    public Playback resolveEpisode(String title, String originalTitle, int year,
                                   int season, int episode,
                                   Map<Integer, Integer> tmdbSeasonCounts)
            throws MovieBoxException {
        Map<Integer, Integer> counts = copySeasonCounts(tmdbSeasonCounts);
        List<MovieBoxTitleMatcher.ReleaseCandidate> candidates =
                findReleaseCandidates(title, originalTitle, year, season, true);
        if (candidates.isEmpty()) {
            throw new MovieBoxException(MovieBoxException.Kind.TITLE_NOT_FOUND,
                    "No confident MovieBox match for \"" + title + "\"");
        }

        // Evaluate the top identity-passing candidates (bounded) and pick by the
        // explicit lexicographic comparator (WP3): identity ≻ coverage ≻ stream
        // resolves ≻ verified Arabic subtitle ≻ verified Arabic audio ≻ verified
        // English fallback ≻ exact-season release ≻ stable id. Language evidence
        // can never beat a failed identity or coverage check (I1).
        List<ReleaseRanker.Evidence> table = new ArrayList<>();
        List<Playback> playables = new ArrayList<>();
        MovieBoxException firstError = null;
        MovieBoxTitleMatcher.ReleaseCandidate subtitleFallback = null;
        int evaluated = 0;
        for (MovieBoxTitleMatcher.ReleaseCandidate cand : candidates) {
            if (cand.tag != null && cand.tag.isArabicSubtitleHint()) {
                if (subtitleFallback == null) subtitleFallback = cand;
                continue; // Resolve only after explicit user selection (or as last-only fallback).
            }
            if (evaluated >= MAX_RELEASE_EVALUATIONS) break;
            evaluated++;
            ReleaseRanker.Evidence ev = new ReleaseRanker.Evidence();
            ev.identityOk = true; // every candidate passed the matcher gates upstream
            ev.subjectId = cand.item.subjectId == null ? "" : cand.item.subjectId;
            ev.coversRequestedEpisode = cand.tag.coversSeason(season);
            ev.exactSeasonRelease = cand.tag.seasonFrom > 0
                    && cand.tag.seasonFrom == season && cand.tag.seasonTo == season;
            Playback p;
            try {
                p = resolveEpisodeOnRelease(cand.item, season, episode, counts);
            } catch (MovieBoxException e) {
                if (isTransportFailure(e)) throw e;
                if (firstError == null) firstError = e;
                ev.coversRequestedEpisode = false;
                table.add(ev);
                playables.add(null);
                continue;
            }
            boolean ownSubs = p.hasOwnSelectableSubtitles();
            p.releaseEvidence = describeRelease(cand, candidates.size(), ownSubs);
            ev.streamResolves = true;
            ev.arabicSubtitle = hasSelectableSubtitle(p, true);
            ev.englishFallback = hasSelectableSubtitle(p, false)
                    || com.eve.cinema.playback.LanguageMatcher.isEnglish(p.audioLanguage);
            ev.arabicAudio = com.eve.cinema.playback.LanguageMatcher.isArabic(p.audioLanguage);
            table.add(ev);
            playables.add(p);
        }
        int bestIdx = ReleaseRanker.indexOfBest(table);
        if (bestIdx >= 0 && table.get(bestIdx).streamResolves) {
            Playback chosen = playables.get(bestIdx);
            if (chosen != null) {
                if (!chosen.hasOwnSelectableSubtitles()) {
                    // Honest absence on the chosen release — never fake tracks,
                    // never claim another release's captions as its own.
                    chosen.releaseEvidence +=
                            "; chosen release exposes no selectable subtitles";
                }
                com.eve.cinema.playback.ResolutionTrace.record("mb.release", "CHOSEN",
                        "subject=" + chosen.activeSubjectId() + " arSub="
                                + table.get(bestIdx).arabicSubtitle + " enFb="
                                + table.get(bestIdx).englishFallback);
                addRelatedReleaseSearchCandidates(chosen, candidates);
                return chosen;
            }
        }
        if (firstError == null && subtitleFallback != null) {
            Playback onlyVideoSubtitle = resolveEpisodeOnRelease(
                    subtitleFallback.item, season, episode, counts);
            if (!hasExactNumberedEpisodeStream(onlyVideoSubtitle.streams, season, episode))
                throw new MovieBoxException(MovieBoxException.Kind.EPISODE_MAPPING_UNVERIFIED,
                        "Translated video did not explicitly confirm S" + season + "E" + episode);
            onlyVideoSubtitle.inVideoSubtitleRelease = true;
            onlyVideoSubtitle.canonicalSubjectId = subtitleFallback.item.subjectId;
            onlyVideoSubtitle.releaseEvidence = "only playable candidate is provider-labelled Arabic subtitle video; pixels not inspected";
            addRelatedReleaseSearchCandidates(onlyVideoSubtitle, candidates);
            return onlyVideoSubtitle;
        }
        throw firstError != null ? firstError : new MovieBoxException(
                MovieBoxException.Kind.NO_SOURCE, "No playable MovieBox release");
    }

    /** A selectable caption in the wanted language that provably belongs to a stream. */
    private static boolean hasSelectableSubtitle(Playback p, boolean arabic) {
        for (StreamSource s : p.streams) {
            if (s == null) continue;
            for (SubtitleOption o : p.subtitlesFor(s)) {
                if (o == null || o.url == null || o.url.isEmpty()) continue;
                if (!MovieBoxModels.Playback.belongsTo(o, s, p)) continue;
                String evidence = o.languageEvidence();
                if (arabic ? com.eve.cinema.playback.LanguageMatcher.isArabic(evidence)
                           : com.eve.cinema.playback.LanguageMatcher.isEnglish(evidence))
                    return true;
            }
        }
        return false;
    }

    private static boolean isTransportFailure(MovieBoxException e) {
        switch (e.kind) {
            case NETWORK: case API_STATUS: case REGION_UNAVAILABLE: case SESSION: return true;
            default: return false;
        }
    }

    private static String describeRelease(MovieBoxTitleMatcher.ReleaseCandidate cand,
                                          int candidateCount, boolean ownSubs) {
        MovieBoxReleaseTag t = cand.tag;
        StringBuilder sb = new StringBuilder("release ").append(cand.item.subjectId)
                .append(" \"").append(t.rawTitle).append("\"")
                .append(" label=").append(t.languageTag == null ? "none" : t.languageTag)
                .append(t.dubLabelled ? " (dub-labelled)" : "");
        if (t.seasonFrom > 0) sb.append(" claims S").append(t.seasonFrom).append("-S").append(t.seasonTo);
        sb.append("; candidates=").append(candidateCount)
          .append("; ownSubtitles=").append(ownSubs);
        return sb.toString();
    }

    /** Resolves S/E on ONE chosen release (everything the old resolveEpisode did). */
    private Playback resolveEpisodeOnRelease(SubjectItem subject, int season, int episode,
                                             Map<Integer, Integer> counts)
            throws MovieBoxException {
        JSONObject details = detailsOrThrow(subject.subjectId);
        List<SeasonInfo> seasons = MovieBoxParser.parseSeasons(details);

        MovieBoxEpisodeMapper.Mapping m;
        try {
            m = MovieBoxEpisodeMapper.map(season, episode, seasons, counts);
        } catch (MovieBoxEpisodeMapper.MappingException e) {
            if (e.reason == MovieBoxEpisodeMapper.MappingException.Reason.NO_SEASON_EVIDENCE) {
                return buildVerifiedEpisode(subject.subjectId, subject.title,
                        season, episode, counts, MovieBoxParser.parseDubs(details));
            }
            throw mappingFailure(season, episode, e);
        }
        List<DubOption> dubs = MovieBoxParser.parseDubs(details);
        Playback p = buildPlayback(subject.subjectId, subject.title, true, m.season, m.episode,
                dubs);
        p.tmdbSeason = season;
        p.tmdbEpisode = episode;
        p.tmdbSeasonCounts = counts;
        p.mappingConfidence = m.confidence.name();
        p.mappingEvidence = m.evidence;
        return p;
    }

    /**
     * Resolves a documented dub release (subject.dubs entry) for the same
     * title/episode. Its episode mapping is derived from logical TMDB numbering.
     */
    public Playback resolveDubRelease(Playback base, MovieBoxModels.DubOption dub,
                                      String audioLanguage) throws MovieBoxException {
        if (base == null || dub == null || dub.subjectId == null || dub.subjectId.isEmpty())
            throw new MovieBoxException(MovieBoxException.Kind.NO_SOURCE, "No dub release");
        int s = base.season, e = base.episode;
        MovieBoxEpisodeMapper.Mapping mapping = null;
        if (base.isSeries) {
            int tmdbSeason = base.tmdbSeason;
            int tmdbEpisode = base.tmdbEpisode;
            Map<Integer, Integer> counts = copySeasonCounts(base.tmdbSeasonCounts);
            JSONObject details = detailsOrThrow(dub.subjectId);
            List<SeasonInfo> seasons = MovieBoxParser.parseSeasons(details);
            try {
                mapping = MovieBoxEpisodeMapper.map(tmdbSeason, tmdbEpisode, seasons, counts);
            } catch (MovieBoxEpisodeMapper.MappingException mappingError) {
                if (mappingError.reason
                        == MovieBoxEpisodeMapper.MappingException.Reason.NO_SEASON_EVIDENCE) {
                    Playback verified = buildVerifiedEpisode(dub.subjectId, base.title,
                            tmdbSeason, tmdbEpisode, counts,
                            base.dubsResolved ? base.dubs : null, base.canonicalSubjectId());
                    // Canonical identity stays the base work; the ACTIVE release
                    // is the dub subject. Never overwrite one with the other.
                    verified.canonicalSubjectId = base.canonicalSubjectId();
                    verified.audioLanguage = audioLanguage;
                    for (StreamSource st : verified.streams) {
                        st.audioLanguage = audioLanguage;
                        st.releaseSubjectId = dub.subjectId;
                    }
                    return verified;
                }
                throw mappingFailure(tmdbSeason, tmdbEpisode, mappingError);
            }
            s = mapping.season;
            e = mapping.episode;
        }
        Playback p = buildPlayback(dub.subjectId, base.title, base.isSeries, s, e,
                base.dubsResolved ? base.dubs : null, base.canonicalSubjectId());
        p.canonicalSubjectId = base.canonicalSubjectId();
        p.tmdbSeason = base.tmdbSeason;
        p.tmdbEpisode = base.tmdbEpisode;
        p.tmdbSeasonCounts = copySeasonCounts(base.tmdbSeasonCounts);
        if (mapping != null) {
            p.mappingConfidence = mapping.confidence.name();
            p.mappingEvidence = mapping.evidence;
        } else {
            p.mappingConfidence = base.mappingConfidence;
            p.mappingEvidence = base.mappingEvidence;
        }
        p.dubs = base.dubs;
        p.audioLanguage = audioLanguage;
        for (StreamSource st : p.streams) {
            st.audioLanguage = audioLanguage;
            st.releaseSubjectId = dub.subjectId;
        }
        return p;
    }

    /**
     * Resolves the separate MovieBox video subject classified as Arabic-subtitled.
     * This is a video-release switch, not a get-ext-captions download. The actual
     * pixels are not inspected; callers keep the external overlay disabled by default.
     */
    public Playback resolveArabicSubtitleRelease(Playback base, MovieBoxModels.DubOption release)
            throws MovieBoxException {
        if (base == null || release == null || release.subjectId == null
                || release.subjectId.isEmpty()
                || release.classification().kind != MovieBoxReleaseClassifier.Kind.ARABIC_SUBTITLE)
            throw new MovieBoxException(MovieBoxException.Kind.NO_SOURCE,
                    "No verified Arabic subtitle video release");
        if (!verifyArabicSubtitleRelease(base, release))
            throw new MovieBoxException(MovieBoxException.Kind.EPISODE_MAPPING_UNVERIFIED,
                    "Arabic subtitle release did not resolve to this title and episode");

        int s = base.season, e = base.episode;
        MovieBoxEpisodeMapper.Mapping mapping = null;
        if (base.isSeries) {
            int tmdbSeason = base.tmdbSeason > 0 ? base.tmdbSeason : base.season;
            int tmdbEpisode = base.tmdbEpisode > 0 ? base.tmdbEpisode : base.episode;
            Map<Integer, Integer> counts = copySeasonCounts(base.tmdbSeasonCounts);
            JSONObject details = detailsOrThrow(release.subjectId);
            List<SeasonInfo> seasons = MovieBoxParser.parseSeasons(details);
            try {
                mapping = MovieBoxEpisodeMapper.map(tmdbSeason, tmdbEpisode, seasons, counts);
            } catch (MovieBoxEpisodeMapper.MappingException mappingError) {
                if (mappingError.reason
                        != MovieBoxEpisodeMapper.MappingException.Reason.NO_SEASON_EVIDENCE)
                    throw mappingFailure(tmdbSeason, tmdbEpisode, mappingError);
                Playback verified = buildVerifiedEpisode(release.subjectId, base.title,
                        tmdbSeason, tmdbEpisode, counts,
                        base.dubsResolved ? base.dubs : null, base.canonicalSubjectId());
                verified.canonicalSubjectId = base.canonicalSubjectId();
                verified.inVideoSubtitleRelease = true;
                verified.dubs = base.dubs;
                verified.releaseEvidence = "provider-labelled Arabic subtitle release; pixels not inspected";
                for (StreamSource stream : verified.streams)
                    stream.releaseSubjectId = release.subjectId;
                return verified;
            }
            s = mapping.season;
            e = mapping.episode;
        }
        Playback p = buildPlayback(release.subjectId, base.title, base.isSeries, s, e,
                base.dubsResolved ? base.dubs : null, base.canonicalSubjectId());
        if (base.isSeries && !hasExactNumberedEpisodeStream(p.streams, s, e))
            throw new MovieBoxException(MovieBoxException.Kind.EPISODE_MAPPING_UNVERIFIED,
                    "Translated video did not explicitly confirm S" + s + "E" + e);
        p.canonicalSubjectId = base.canonicalSubjectId();
        p.tmdbSeason = base.tmdbSeason;
        p.tmdbEpisode = base.tmdbEpisode;
        p.tmdbSeasonCounts = copySeasonCounts(base.tmdbSeasonCounts);
        p.dubs = base.dubs;
        p.inVideoSubtitleRelease = true;
        p.releaseEvidence = mapping == null
                ? "provider-labelled Arabic subtitle release; pixels not inspected"
                : "provider-labelled Arabic subtitle release; " + mapping.confidence.name()
                        + "; pixels not inspected";
        if (mapping != null) {
            p.mappingConfidence = mapping.confidence.name();
            p.mappingEvidence = mapping.evidence;
        } else {
            p.mappingConfidence = base.mappingConfidence;
            p.mappingEvidence = base.mappingEvidence;
        }
        for (StreamSource stream : p.streams) stream.releaseSubjectId = release.subjectId;
        return p;
    }

    /**
     * Availability probe for the details-page source selector: returns the
     * confidently matched subject (title/type/year gates applied), or null.
     * Never throws — a network failure is indistinguishable from "no match"
     * for UI purposes and is reported through the result's null-ness only.
     * New code should use {@link #matchSubjectOutcome} so a transient failure
     * is never confused with a definitive "not found".
     */
    public SubjectItem matchSubjectOrNull(String title, String originalTitle, int year,
                                          boolean wantSeries) {
        return matchSubjectOutcome(title, originalTitle, year, wantSeries).item;
    }

    /** Classified availability probe result (WP2): the outcome plus the subject when VERIFIED. */
    public static final class SubjectProbe {
        public final com.eve.cinema.playback.ProbeOutcome outcome;
        public final SubjectItem item;
        SubjectProbe(com.eve.cinema.playback.ProbeOutcome outcome, SubjectItem item) {
            this.outcome = outcome;
            this.item = item;
        }
    }

    /** Total probe attempts: the first try plus at most two retries (WP2). */
    private static final int MAX_PROBE_ATTEMPTS = 3;

    /**
     * Classified availability probe: a completed search yields VERIFIED or
     * NOT_FOUND_DEFINITIVE; transport/session/parse failures are retried at
     * most twice with backoff and then reported as UNRESOLVED_TRANSIENT —
     * never as "the title does not exist" (I6).
     */
    public SubjectProbe matchSubjectOutcome(String title, String originalTitle, int year,
                                            boolean wantSeries) {
        int attempt = 0;
        while (true) {
            attempt++;
            try {
                SubjectItem item = findSubject(title, originalTitle, year, wantSeries);
                com.eve.cinema.playback.ResolutionTrace.record("mb.probe", "VERIFIED",
                        "subject=" + (item == null ? "-" : item.subjectId));
                return new SubjectProbe(com.eve.cinema.playback.ProbeOutcome.VERIFIED, item);
            } catch (MovieBoxException e) {
                if (e.kind == MovieBoxException.Kind.TITLE_NOT_FOUND) {
                    com.eve.cinema.playback.ResolutionTrace.record(
                            "mb.probe", "NOT_FOUND", "search completed");
                    return new SubjectProbe(
                            com.eve.cinema.playback.ProbeOutcome.NOT_FOUND_DEFINITIVE, null);
                }
                if (attempt >= MAX_PROBE_ATTEMPTS || !probeBackoff(attempt)) {
                    com.eve.cinema.playback.ResolutionTrace.record(
                            "mb.probe", "TRANSIENT", e.kind.name());
                    return new SubjectProbe(
                            com.eve.cinema.playback.ProbeOutcome.UNRESOLVED_TRANSIENT, null);
                }
            } catch (RuntimeException e) {
                if (attempt >= MAX_PROBE_ATTEMPTS || !probeBackoff(attempt)) {
                    com.eve.cinema.playback.ResolutionTrace.record(
                            "mb.probe", "TRANSIENT", e.getClass().getSimpleName());
                    return new SubjectProbe(
                            com.eve.cinema.playback.ProbeOutcome.UNRESOLVED_TRANSIENT, null);
                }
            }
        }
    }

    /** Interruptible backoff between probe retries; false when interrupted. */
    private static boolean probeBackoff(int attempt) {
        try {
            Thread.sleep(400L * attempt);
            return true;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return false;
        }
    }

    /**
     * Phase-3 evidence rule: an Arabic dub option is only "available" when the
     * documented dub subject actually resolves and exposes a playable stream
     * for the exact target episode. A label in subject.dubs alone is never
     * enough.
     */
    public boolean verifyDubRelease(Playback base, MovieBoxModels.DubOption dub) {
        if (base == null || dub == null || dub.subjectId == null || dub.subjectId.isEmpty())
            return false;
        try {
            int s = base.season, e = base.episode;
            JSONObject details = detailsOrThrow(dub.subjectId);
            String actualId = MovieBoxParser.optId(details, "subjectId", "id");
            if (!dub.subjectId.equals(actualId)
                    || !MovieBoxSubtitleReleaseResolver.sameIdentity(base.title, base.isSeries,
                            details.optString("title", ""),
                            MovieBoxParser.detailsIsSeries(details))) return false;
            if (base.isSeries) {
                List<SeasonInfo> seasons = MovieBoxParser.parseSeasons(details);
                Map<Integer, Integer> counts = copySeasonCounts(base.tmdbSeasonCounts);
                try {
                    MovieBoxEpisodeMapper.Mapping m = MovieBoxEpisodeMapper.map(
                            base.tmdbSeason > 0 ? base.tmdbSeason : base.season,
                            base.tmdbEpisode > 0 ? base.tmdbEpisode : base.episode,
                            seasons, counts);
                    s = m.season;
                    e = m.episode;
                } catch (MovieBoxEpisodeMapper.MappingException mappingError) {
                    if (mappingError.reason
                            != MovieBoxEpisodeMapper.MappingException.Reason.NO_SEASON_EVIDENCE)
                        return false;
                    // no season metadata: fall through to a direct play-info probe
                }
            }
            JSONObject playInfo = client.getPlayInfo(dub.subjectId, s, e);
            List<StreamSource> streams = MovieBoxParser.playInfoToStreams(
                    playInfo, s, e, client.userAgent());
            if (!streams.isEmpty()) return true;
            int page = e > 0 ? (e - 1) / 20 + 1 : 1;
            JSONObject resources = client.getResources(dub.subjectId, s, e, page, null, 20);
            return !MovieBoxParser.resourceToStreams(resources, s, e, client.userAgent())
                    .isEmpty();
        } catch (Exception e2) {
            return false;
        }
    }

    /** Separate availability probe for a provider-labelled Arabic subtitle video release. */
    public boolean verifyArabicSubtitleRelease(Playback base, MovieBoxModels.DubOption release) {
        if (base == null || release == null || release.subjectId == null
                || release.subjectId.isEmpty()
                || release.classification().kind != MovieBoxReleaseClassifier.Kind.ARABIC_SUBTITLE)
            return false;
        try {
            JSONObject details = detailsOrThrow(release.subjectId);
            String actualId = MovieBoxParser.optId(details, "subjectId", "id");
            if (!release.subjectId.equals(actualId)
                    || !MovieBoxSubtitleReleaseResolver.sameIdentity(base.title, base.isSeries,
                            details.optString("title", ""),
                            MovieBoxParser.detailsIsSeries(details))) return false;

            int s = base.season, e = base.episode;
            if (base.isSeries) {
                List<SeasonInfo> seasons = MovieBoxParser.parseSeasons(details);
                Map<Integer, Integer> counts = copySeasonCounts(base.tmdbSeasonCounts);
                try {
                    MovieBoxEpisodeMapper.Mapping m = MovieBoxEpisodeMapper.map(
                            base.tmdbSeason > 0 ? base.tmdbSeason : base.season,
                            base.tmdbEpisode > 0 ? base.tmdbEpisode : base.episode,
                            seasons, counts);
                    s = m.season;
                    e = m.episode;
                } catch (MovieBoxEpisodeMapper.MappingException mappingError) {
                    if (mappingError.reason
                            != MovieBoxEpisodeMapper.MappingException.Reason.NO_SEASON_EVIDENCE)
                        return false;
                }
            }
            JSONObject playInfo = client.getPlayInfo(release.subjectId, s, e);
            List<StreamSource> playInfoStreams = MovieBoxParser.playInfoToStreams(
                    playInfo, s, e, client.userAgent());
            if (!base.isSeries && !playInfoStreams.isEmpty()) return true;
            if (base.isSeries && hasExactNumberedEpisodeStream(playInfoStreams, s, e)) return true;
            for (int page : MovieBoxSubtitleResourcePlanner.pageOrder(e)) {
                JSONObject resources = client.getResources(release.subjectId, s, e, page, null, 20);
                List<StreamSource> resourceStreams = MovieBoxParser.resourceToStreams(
                        resources, s, e, client.userAgent());
                if (!base.isSeries && !resourceStreams.isEmpty()) return true;
                if (base.isSeries && hasExactNumberedEpisodeStream(resourceStreams, s, e)) return true;
            }
            return false;
        } catch (Exception e2) {
            return false;
        }
    }

    /** Series evidence must carry S/E from MovieBox itself, not requested-number defaults. */
    private static boolean hasExactNumberedEpisodeStream(List<StreamSource> streams,
                                                          int season, int episode) {
        if (streams == null) return false;
        for (StreamSource stream : streams) {
            if (stream != null && stream.numberingFromResponse
                    && stream.season == season && stream.episode == episode) return true;
        }
        return false;
    }

    private JSONObject detailsOrThrow(String subjectId) throws MovieBoxException {
        if (!hasText(subjectId))
            throw new MovieBoxException(MovieBoxException.Kind.INVALID_SOURCE,
                    "Missing MovieBox subject id");
        long now = System.currentTimeMillis();
        synchronized (subjectDetailsCache) {
            CachedSubjectDetails cached = subjectDetailsCache.get(subjectId);
            if (cached != null && now - cached.createdAtMs < SUBJECT_DETAILS_TTL_MS)
                return cached.value;
            if (cached != null) subjectDetailsCache.remove(subjectId);
        }
        JSONObject payload = client.getDetails(subjectId);
        try {
            if (payload == null) throw new IllegalArgumentException("Missing details payload");
            JSONObject subject = MovieBoxParser.detailsSubject(payload);
            if (subject == null) throw new IllegalArgumentException("Missing details subject");
            String actualId = MovieBoxParser.optId(subject, "subjectId", "id");
            if (!subjectId.equals(actualId))
                throw new MovieBoxException(MovieBoxException.Kind.PARSE,
                        "MovieBox details subject identity mismatch");
            synchronized (subjectDetailsCache) {
                subjectDetailsCache.put(subjectId, new CachedSubjectDetails(subject, now));
                while (subjectDetailsCache.size() > MAX_SUBJECT_DETAILS_CACHE) {
                    String oldest = subjectDetailsCache.keySet().iterator().next();
                    subjectDetailsCache.remove(oldest);
                }
            }
            return subject;
        } catch (RuntimeException e) {
            throw new MovieBoxException(MovieBoxException.Kind.PARSE,
                    "Could not parse MovieBox details", e);
        }
    }

    private static MovieBoxException mappingFailure(int season, int episode,
            MovieBoxEpisodeMapper.MappingException e) {
        MovieBoxException.Kind kind = e.reason
                == MovieBoxEpisodeMapper.MappingException.Reason.EPISODE_NOT_LISTED
                ? MovieBoxException.Kind.EPISODE_UNAVAILABLE
                : MovieBoxException.Kind.EPISODE_MAPPING_UNVERIFIED;
        return new MovieBoxException(kind,
                "TMDB S" + season + "E" + episode + " mapping failed (" + e.reason + "): "
                        + e.getMessage(), e);
    }

    private Playback buildVerifiedEpisode(String subjectId, String title, int tmdbSeason,
            int tmdbEpisode, Map<Integer, Integer> tmdbSeasonCounts, List<DubOption> dubs)
            throws MovieBoxException {
        return buildVerifiedEpisode(subjectId, title, tmdbSeason, tmdbEpisode,
                tmdbSeasonCounts, dubs, null);
    }

    private Playback buildVerifiedEpisode(String subjectId, String title, int tmdbSeason,
            int tmdbEpisode, Map<Integer, Integer> tmdbSeasonCounts, List<DubOption> dubs,
            String canonicalSubjectId) throws MovieBoxException {
        JSONObject playInfo = client.getPlayInfo(subjectId, tmdbSeason, tmdbEpisode);
        List<StreamSource> streams = MovieBoxParser.playInfoToStreams(
                playInfo, tmdbSeason, tmdbEpisode, client.userAgent());
        boolean verified = false;
        for (StreamSource stream : streams) {
            if (stream.numberingFromResponse) {
                verified = true;
                break;
            }
        }
        if (!verified) {
            throw new MovieBoxException(MovieBoxException.Kind.EPISODE_MAPPING_UNVERIFIED,
                    "Play-info did not explicitly confirm S" + tmdbSeason + "E" + tmdbEpisode);
        }
        Playback p = buildPlaybackFromStreams(subjectId, title, true, tmdbSeason,
                tmdbEpisode, streams, dubs, canonicalSubjectId);
        p.tmdbSeason = tmdbSeason;
        p.tmdbEpisode = tmdbEpisode;
        p.tmdbSeasonCounts = copySeasonCounts(tmdbSeasonCounts);
        p.mappingConfidence = MovieBoxEpisodeMapper.Confidence.VERIFIED_BY_STREAM.name();
        p.mappingEvidence = "Play-info explicitly lists S" + tmdbSeason + "E" + tmdbEpisode;
        return p;
    }

    // ── Internals ────────────────────────────────────────────

    /** Bounded discovery: at most this many search pages per query (WP3). */
    private static final int MAX_SEARCH_PAGES = 3;
    /** MovieBox search page size (MovieBoxClient.search hardcodes perPage=15). */
    private static final int SEARCH_PAGE_SIZE = 15;

    private SubjectItem findSubject(String title, String originalTitle, int year,
                                    boolean wantSeries) throws MovieBoxException {
        // Try the primary title, then the original (e.g. English) title —
        // each is a separate search because MovieBox indexes both variants.
        // Each query paginates (bounded) while a page is full and nothing is
        // verified yet, so a one-word title lost among page-1 noise ("From")
        // is still discovered without unbounded fan-out (WP3).
        MovieBoxTitleMatcher.Pick pick = null;

        if (title != null && !title.trim().isEmpty()) {
            pick = searchAndPick(title.trim(), title, originalTitle, year, wantSeries, null);
        }

        if (pick == null && originalTitle != null && !originalTitle.trim().isEmpty()
                && !originalTitle.trim().equalsIgnoreCase(title == null ? "" : title.trim())) {
            pick = searchAndPick(originalTitle.trim(), title, originalTitle, year, wantSeries, null);
        }

        if (pick == null) {
            com.eve.cinema.playback.ResolutionTrace.record("mb.search", "NO_MATCH",
                    "wantSeries=" + wantSeries + " y=" + year);
            throw new MovieBoxException(MovieBoxException.Kind.TITLE_NOT_FOUND,
                    "No confident MovieBox match for \"" + title + "\"");
        }
        return pick.item;
    }

    /**
     * Pages one query (deduped by subject id) until a confident pick exists,
     * the page is not full, or {@link #MAX_SEARCH_PAGES} is reached. Page-1
     * errors propagate; later-page errors end the search best-effort.
     * {@code pool}/{@code seen} accumulate across queries when provided.
     */
    private MovieBoxTitleMatcher.Pick searchAndPick(String query, String title,
            String originalTitle, int year, boolean wantSeries,
            List<SubjectItem> pool) throws MovieBoxException {
        List<SubjectItem> acc = pool != null ? pool : new ArrayList<>();
        Set<String> seen = new HashSet<>();
        for (SubjectItem it : acc)
            if (it != null && it.subjectId != null) seen.add(it.subjectId);
        MovieBoxTitleMatcher.Pick pick = null;
        for (int page = 1; page <= MAX_SEARCH_PAGES; page++) {
            List<SubjectItem> items;
            try {
                items = MovieBoxParser.searchToItems(client.search(query, page));
            } catch (MovieBoxException e) {
                if (page == 1) throw e;
                break; // later pages are best-effort enrichment
            }
            for (SubjectItem it : items) {
                if (it != null && it.subjectId != null && seen.add(it.subjectId)) acc.add(it);
            }
            pick = MovieBoxTitleMatcher.pickBest(acc, title, originalTitle, year, wantSeries);
            if (pick != null || items.size() < SEARCH_PAGE_SIZE) break;
        }
        return pick;
    }

    /** Max releases fully resolved when the best one is a dub without subtitles. */
    private static final int MAX_RELEASE_EVALUATIONS = 3;

    private static boolean hasText(String s) {
        return s != null && !s.trim().isEmpty();
    }

    private static boolean hasOriginalRelease(List<MovieBoxTitleMatcher.ReleaseCandidate> list,
                                               boolean wantSeries) {
        for (MovieBoxTitleMatcher.ReleaseCandidate c : list) {
            if (wantSeries) {
                // A provider-labelled subtitle video is an alternate version, not
                // evidence that the plain/original series candidate was found.
                if (c.tag != null && !c.tag.dubLabelled
                        && !c.tag.isArabicSubtitleHint()
                        && c.tag.markerKind != MovieBoxReleaseClassifier.Kind.ARABIC_AMBIGUOUS)
                    return true;
            } else if (c.tag != null && !c.tag.dubLabelled && c.tag.languageTag == null
                    && c.tag.markerKind != MovieBoxReleaseClassifier.Kind.ARABIC_AMBIGUOUS) {
                return true;
            }
        }
        return false;
    }

    /**
     * Ranked releases for a movie or series. Search pagination remains bounded;
     * series keep their prior stop rule, while movies continue until a plain
     * original-labelled candidate is present. Page-1 errors propagate as before.
     */
    private List<MovieBoxTitleMatcher.ReleaseCandidate> findReleaseCandidates(String title,
            String originalTitle, int year, int tmdbSeason, boolean wantSeries)
            throws MovieBoxException {
        List<SubjectItem> pool = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        List<MovieBoxTitleMatcher.ReleaseCandidate> ranked = new ArrayList<>();

        if (hasText(title)) {
            ranked = accumulateReleases(title.trim(), title, originalTitle, year,
                    tmdbSeason, wantSeries, pool, seen, true);
        }
        if ((ranked.isEmpty() || !hasOriginalRelease(ranked, wantSeries)) && hasText(originalTitle)
                && !originalTitle.trim().equalsIgnoreCase(title == null ? "" : title.trim())) {
            try {
                ranked = accumulateReleases(originalTitle.trim(), title, originalTitle,
                        year, tmdbSeason, wantSeries, pool, seen, false);
            } catch (MovieBoxException e) {
                if (ranked.isEmpty()) throw e; // nothing found at all: surface the real error
            }
        }
        return ranked;
    }

    /** Accumulates bounded release pages until the applicable default release is found. */
    private List<MovieBoxTitleMatcher.ReleaseCandidate> accumulateReleases(String query,
            String title, String originalTitle, int year, int tmdbSeason, boolean wantSeries,
            List<SubjectItem> pool, Set<String> seen, boolean failOnFirstPage)
            throws MovieBoxException {
        List<MovieBoxTitleMatcher.ReleaseCandidate> ranked = new ArrayList<>();
        for (int page = 1; page <= MAX_SEARCH_PAGES; page++) {
            List<SubjectItem> items;
            try {
                items = MovieBoxParser.searchToItems(client.search(query, page));
            } catch (MovieBoxException e) {
                if (page == 1 && failOnFirstPage) throw e;
                break;
            }
            for (SubjectItem it : items) {
                if (it != null && it.subjectId != null && seen.add(it.subjectId)) pool.add(it);
            }
            ranked = MovieBoxTitleMatcher.rankReleases(pool, title, originalTitle,
                    year, wantSeries, tmdbSeason);
            if ((!ranked.isEmpty() && hasOriginalRelease(ranked, wantSeries))
                    || items.size() < SEARCH_PAGE_SIZE) break;
        }
        return ranked;
    }

    /** Per-stream primary lookups during buildPlayback (unchanged behaviour). */
    private static final int MAX_CAPTION_LOOKUPS = 3;
    /** Hard cap on caption/resource API requests per stream, including resource pagination. */
    private static final int MAX_CAPTION_API_REQUESTS = 12;
    private static final int MAX_DETECTOR_CAPTION_LOOKUPS = 3;
    private static final int MAX_RESOURCE_PAGES = 5;
    private static final int MAX_RESOURCE_ROWS_PER_SUBJECT = 60;
    private static final int MAX_RESOURCE_CAPTION_LOOKUPS = 5;
    /** Hard cap on subtitle downloads/parse validations per stream. */
    private static final int MAX_CAPTION_VALIDATIONS = 6;

    /**
     * Re-resolves the currently active MovieBox release after a signed stream URL
     * expires. It intentionally uses the active provider subject ID rather than a
     * fresh title search, so a selected dub/subtitle release cannot silently switch.
     */
    public Playback refreshPlayback(Playback current) throws MovieBoxException {
        if (current == null || !hasText(current.activeSubjectId()))
            throw new MovieBoxException(MovieBoxException.Kind.INVALID_SOURCE,
                    "Missing active MovieBox release for refresh");
        List<DubOption> dubs = current.dubsResolved ? current.dubs : null;
        Playback refreshed = buildPlayback(current.activeSubjectId(), current.title,
                current.isSeries, current.season, current.episode, dubs,
                current.canonicalSubjectId());
        // Keep the TMDB↔MovieBox mapping and the chosen release-mode evidence;
        // buildPlayback's local numbering is not a replacement for the original map.
        refreshed.tmdbSeason = current.tmdbSeason;
        refreshed.tmdbEpisode = current.tmdbEpisode;
        refreshed.tmdbSeasonCounts.putAll(current.tmdbSeasonCounts);
        refreshed.mappingConfidence = current.mappingConfidence;
        refreshed.mappingEvidence = current.mappingEvidence;
        refreshed.audioLanguage = current.audioLanguage;
        refreshed.inVideoSubtitleRelease = current.inVideoSubtitleRelease;
        refreshed.releaseEvidence = current.releaseEvidence;
        return refreshed;
    }

    private Playback buildPlayback(String subjectId, String title, boolean isSeries,
                                   int season, int episode, List<DubOption> dubs)
            throws MovieBoxException {
        return buildPlayback(subjectId, title, isSeries, season, episode, dubs, null);
    }

    private Playback buildPlayback(String subjectId, String title, boolean isSeries,
                                   int season, int episode, List<DubOption> dubs,
                                   String canonicalSubjectId) throws MovieBoxException {
        JSONObject playInfo = client.getPlayInfo(subjectId, season, episode);
        List<StreamSource> streams = MovieBoxParser.playInfoToStreams(
                playInfo, season, episode, client.userAgent());

        if (streams.isEmpty()) {
            // Fallback: probe the expected global page and the safe page-1 fallback.
            for (int page : MovieBoxSubtitleResourcePlanner.pageOrder(episode)) {
                try {
                    JSONObject resources = client.getResources(
                            subjectId, season, episode, page, null, 20);
                    streams = MovieBoxParser.resourceToStreams(
                            resources, season, episode, client.userAgent());
                } catch (MovieBoxException ignored) {}
                if (!streams.isEmpty()) break;
            }
        }

        if (streams.isEmpty()) {
            throw new MovieBoxException(MovieBoxException.Kind.NO_SOURCE,
                    "No playable MovieBox streams");
        }

        return buildPlaybackFromStreams(subjectId, title, isSeries, season, episode, streams,
                dubs, canonicalSubjectId);
    }

    private Playback buildPlaybackFromStreams(String subjectId, String title, boolean isSeries,
            int season, int episode, List<StreamSource> streams, List<DubOption> dubs,
            String canonicalSubjectId)
            throws MovieBoxException {
        if (streams.isEmpty())
            throw new MovieBoxException(MovieBoxException.Kind.NO_SOURCE,
                    "No playable MovieBox streams");
        if (isSeries) {
            // A stream is built with the REQUESTED numbering unless the response states
            // its own; a differing value is explicit evidence it is another episode.
            List<StreamSource> consistent = new ArrayList<>();
            for (StreamSource st : streams) {
                if (st.season == season && st.episode == episode) consistent.add(st);
            }
            if (consistent.isEmpty())
                throw new MovieBoxException(MovieBoxException.Kind.EPISODE_MAPPING_UNVERIFIED,
                        "Play-info numbering contradicts the mapped S" + season + "E" + episode);
            streams = consistent;
        }
        MovieBoxParser.sortStreamsBestFirst(streams);

        Playback playback = new Playback();
        playback.subjectId = subjectId;
        playback.canonicalSubjectId = canonicalSubjectId;
        playback.title = title;
        playback.isSeries = isSeries;
        playback.season = season;
        playback.episode = episode;
        playback.tmdbSeason = season;
        playback.tmdbEpisode = episode;
        playback.streams = streams;
        playback.dubsResolved = dubs != null;
        playback.dubs = dubs == null ? new ArrayList<DubOption>() : new ArrayList<>(dubs);

        // Captions belong to a specific resource id — fetch them per stream so
        // the subtitle always matches the release actually being played.
        Map<String, CaptionsFetchResult> byResource = new HashMap<>();
        StringBuilder errors = new StringBuilder();
        for (StreamSource st : streams) {
            st.releaseSubjectId = subjectId;
            String rid = st.streamId;
            if (rid == null || rid.isEmpty()) continue;
            CaptionsFetchResult result = byResource.get(rid);
            if (result == null) {
                if (byResource.size() >= MAX_CAPTION_LOOKUPS) continue;
                st.captionsResolved = false;
                try {
                    result = fetchCaptions(playback, st);
                } catch (MovieBoxException e) {
                    result = new CaptionsFetchResult();
                    result.requestFailure = true;
                    result.exhausted = false;
                    if (errors.length() > 0) errors.append("; ");
                    errors.append(e.kind);
                }
                byResource.put(rid, result);
            } else {
                // The same upload resource shares the same validated result.
            }
            st.subtitles = result.options;
            st.captionsResolved = result.resolved();
            if (!"ARABIC_CAPTION_READY".equals(result.status())) {
                if (errors.length() > 0) errors.append("; ");
                errors.append(result.status());
            }
        }
        playback.captionsError = errors.length() > 0 ? errors.toString() : null;
        return playback;
    }

    public synchronized List<SubtitleOption> captionsFor(Playback playback, StreamSource stream)
            throws MovieBoxException {
        if (playback == null || stream == null)
            throw new MovieBoxException(MovieBoxException.Kind.INVALID_SOURCE,
                    "Missing playback stream for captions");
        if (stream.captionsResolved) return playback.subtitlesFor(stream);
        if (stream.streamId == null || stream.streamId.isEmpty()) return stream.subtitles;
        CaptionsFetchResult result = fetchCaptions(playback, stream);
        stream.subtitles = result.options;
        stream.captionsResolved = result.resolved();
        if (!"ARABIC_CAPTION_READY".equals(result.status()))
            appendCaptionStatus(playback, result.status());
        return result.options;
    }

    private static final class CaptionsFetchResult {
        final List<SubtitleOption> options = new ArrayList<>();
        boolean requestFailure;
        boolean validationFailure;
        boolean arabicValidationFailure;
        boolean exhausted = true;
        boolean candidateRejected;
        boolean hasArabic;
        int apiRequests;

        boolean resolved() {
            return hasArabic || MovieBoxSubtitleReleaseResolver.mayMarkResolved(
                    exhausted, requestFailure, validationFailure);
        }

        String status() {
            if (hasArabic) return "ARABIC_CAPTION_READY";
            if (requestFailure) return "ARABIC_SUBTITLE_REQUEST_FAILED";
            if (arabicValidationFailure) return "ARABIC_CAPTION_DOWNLOAD_OR_PARSE_FAILED";
            if (!exhausted) return "ARABIC_CANDIDATE_SEARCH_LIMIT_REACHED";
            if (validationFailure) return "CAPTION_DOWNLOAD_OR_PARSE_FAILED";
            if (candidateRejected) return "ARABIC_CANDIDATE_NOT_VERIFIED";
            return "NO_ARABIC_CAPTION_VERIFIED";
        }
    }

    private static final class CaptionValidationState {
        int attempts;
        final Set<String> validUrls = new HashSet<>();
        final Set<String> invalidUrls = new HashSet<>();
    }

    private static final class SubtitleSiblingCandidate {
        final String subjectId;
        SubtitleSiblingCandidate(String subjectId) { this.subjectId = subjectId; }
    }

    /**
     * Caption discovery is separate from video selection. It keeps valid active
     * captions, then checks every bounded exact-episode resource row; when Arabic
     * is still absent it examines Arabic-subtitle-labelled sibling subjects only.
     * Active-release caption rows are queried by resourceId only after exact
     * subject/title/episode/runtime checks. Cross-release borrowing remains disabled
     * until cue synchronization can be proven independently.
     */
    private CaptionsFetchResult fetchCaptions(Playback playback, StreamSource stream)
            throws MovieBoxException {
        String subjectId = stream.releaseSubjectId != null
                ? stream.releaseSubjectId : playback.subjectId;
        if (subjectId == null || subjectId.isEmpty())
            throw new MovieBoxException(MovieBoxException.Kind.INVALID_SOURCE,
                    "Missing MovieBox caption subject");

        int season = stream.season;
        int episode = stream.episode;
        List<SubtitleOption> all = new ArrayList<>();
        Set<String> seenUrls = new HashSet<>();
        Set<String> attemptedIds = new HashSet<>();
        CaptionValidationState validation = new CaptionValidationState();
        CaptionsFetchResult result = new CaptionsFetchResult();
        List<String> detectorIds = new ArrayList<>();
        try {
            JSONObject details = detailsOrThrow(subjectId);
            String actualId = MovieBoxParser.optId(details, "subjectId", "id");
            boolean identityVerified = subjectId.equals(actualId)
                    && MovieBoxSubtitleReleaseResolver.sameIdentity(playback.title,
                            playback.isSeries, details.optString("title", ""),
                            MovieBoxParser.detailsIsSeries(details));
            if (identityVerified) {
                detectorIds = MovieBoxParser.resourceDetectorIds(details, season, episode);
                if (!playback.dubsResolved) {
                    playback.dubs = MovieBoxParser.parseDubs(details);
                    playback.dubsResolved = true;
                }
            } else {
                playback.dubsResolved = true;
                result.candidateRejected = true;
                com.eve.cinema.playback.ResolutionTrace.record("captions",
                        "ACTIVE_DETAILS_REJECTED", "subject/title/type identity did not match");
            }
        } catch (MovieBoxException e) {
            result.requestFailure = true;
            result.exhausted = false;
        }

        // Primary id can contain only English or other non-Arabic captions. Do
        // not treat a non-empty response as proof that Arabic is unavailable.
        if (stream.streamId != null && !stream.streamId.isEmpty()) {
            attemptedIds.add(subjectId + ":" + stream.streamId);
            result.apiRequests++;
            try {
                appendUnique(all, seenUrls, captionsAt(subjectId, stream.streamId,
                        season, episode, true));
            } catch (MovieBoxException e) {
                result.requestFailure = true;
            }
            if (validateArabicCandidates(all, validation, result)) return finishCaptions(
                    all, validation, result);
        }

        // Resource detector ids and their resolution-list ids are a separate
        // namespace from play-info stream ids. Search them before /resource rows,
        // but only after the active subject identity has been verified.
        int detectorLookups = 0;
        for (String rid : detectorIds) {
            if (!hasText(rid) || !attemptedIds.add(subjectId + ":" + rid)) continue;
            if (detectorLookups >= MAX_DETECTOR_CAPTION_LOOKUPS
                    || result.apiRequests >= MAX_CAPTION_API_REQUESTS) {
                result.exhausted = false;
                break;
            }
            detectorLookups++;
            result.apiRequests++;
            try {
                appendUnique(all, seenUrls, captionsAt(subjectId, rid, season, episode, false));
            } catch (MovieBoxException e) {
                result.requestFailure = true;
            }
            // Detector ids are only hints. Even a parseable Arabic file is not
            // advertised until its id is matched to exact active-resource metadata.
            validateArabicCandidates(all, validation, result);
        }
        com.eve.cinema.playback.ResolutionTrace.record("captions", "DETECTOR_RESOURCE_LOOKUPS",
                "ids=" + detectorIds.size() + " attempted=" + detectorLookups
                        + " apiRequests=" + result.apiRequests + "/" + MAX_CAPTION_API_REQUESTS);

        // Inspect all exact resource rows on the active release, not just the
        // first row; their URLs/IDs are never emitted to diagnostic text.
        List<JSONObject> activeRows = resourceRows(subjectId, season, episode, result);
        if (stream.durationSeconds <= 0) {
            long corroboratedRuntime = MovieBoxParser.unanimousActiveResourceDuration(
                    activeRows, playback.title, playback.isSeries, season, episode);
            if (corroboratedRuntime > 0) {
                stream.durationSeconds = corroboratedRuntime;
                com.eve.cinema.playback.ResolutionTrace.record("captions",
                        "ACTIVE_RUNTIME_CORROBORATED", "seconds=" + corroboratedRuntime
                                + " rows=" + activeRows.size());
            } else {
                com.eve.cinema.playback.ResolutionTrace.record("captions",
                        "ACTIVE_RUNTIME_UNKNOWN", "resource rows did not agree on exact identity/runtime");
            }
        }
        int activeRowLookups = 0;
        for (JSONObject row : activeRows) {
            String rid = MovieBoxParser.resourceIdOf(row);
            if (!hasText(rid)) continue;
            Integer rowSeason = MovieBoxParser.optIntLooseOrNull(row, "se");
            Integer rowEpisode = MovieBoxParser.optIntLooseOrNull(row, "ep");
            String resourceTitle = row.optString("title", "");
            long candidateDuration = MovieBoxParser.optLongLoose(row, "duration", 0);
            // Caption lookup is keyed by resourceId, not by resourceLink. The provider
            // sometimes puts the same dummy /other/ URL on every row, so link playability
            // must not block a caption query; exact subject/title/episode/runtime still gate it.
            if (!MovieBoxSubtitleReleaseResolver.compatibleCaptionResource(playback.title,
                    playback.isSeries, resourceTitle, season, episode, rowSeason, rowEpisode,
                    stream.durationSeconds, candidateDuration)) {
                result.candidateRejected = true;
                com.eve.cinema.playback.ResolutionTrace.record("captions",
                        "ACTIVE_RESOURCE_REJECTED", "identity/runtime/episode/playability not verified");
                continue;
            }
            // A detector id is only a lookup hint. Promote its captions to verified
            // ownership only after a matching active /resource row proves exact
            // title/episode/runtime. This keeps a same-subject alternate cut from
            // bypassing the runtime gate merely because its id came from details.
            boolean alreadyAttempted = !attemptedIds.add(subjectId + ":" + rid);
            if (alreadyAttempted) {
                for (SubtitleOption option : all) {
                    if (subjectId.equals(option.subjectId) && rid.equals(option.resourceId)
                            && option.season == season && option.episode == episode)
                        option.resourceIdentityVerified = true;
                }
                if (hasVerifiedArabicCaption(all, validation)) break;
                continue;
            }
            if (hasVerifiedArabicCaption(all, validation)) break;
            if (activeRowLookups >= MAX_RESOURCE_CAPTION_LOOKUPS
                    || result.apiRequests >= MAX_CAPTION_API_REQUESTS) {
                result.exhausted = false;
                break;
            }
            activeRowLookups++;
            result.apiRequests++;
            try {
                appendUnique(all, seenUrls, captionsAt(subjectId, rid, season, episode, true));
            } catch (MovieBoxException e) {
                result.requestFailure = true;
            }
            if (validateArabicCandidates(all, validation, result)) break;
        }
        if (!hasVerifiedArabicCaption(all, validation) && activeRows.size() > activeRowLookups
                && activeRowLookups >= MAX_RESOURCE_CAPTION_LOOKUPS) {
            result.exhausted = false;
        }
        if (!hasVerifiedArabicCaption(all, validation)) {
            // Never borrow an external caption from a different MovieBox subject/release.
            // Equal title/runtime cannot prove the exact cut or audio mix (e.g. a dub
            // and its canonical original). The player must use captions belonging to
            // the active release; otherwise report absence rather than attach a guess.
            List<SubtitleSiblingCandidate> siblings = subtitleSiblingCandidates(playback,
                    subjectId);
            if (!siblings.isEmpty()) {
                result.candidateRejected = true;
                com.eve.cinema.playback.ResolutionTrace.record("captions",
                        "ARABIC_CROSS_RELEASE_CAPTIONS_SKIPPED",
                        "same title/runtime cannot prove cut or audio timing across releases");
            }
        }

        return finishCaptions(all, validation, result);
    }

    private CaptionsFetchResult finishCaptions(List<SubtitleOption> all,
            CaptionValidationState validation, CaptionsFetchResult result) {
        // This resolver determines Arabic playback capabilities, not a general
        // subtitle catalogue. Only advertise Arabic files that were downloaded
        // and parsed successfully; never spend pre-chooser time validating every
        // English/Spanish/French caption the provider happens to return.
        result.options.clear();
        Set<String> added = new HashSet<>();
        for (SubtitleOption option : all) {
            if (option == null || !hasText(option.url) || !added.add(option.url)) continue;
            if (!MovieBoxSubtitleReleaseResolver.isArabicCaption(
                    option.languageCode, option.languageEvidence())) continue;
            if (!option.resourceIdentityVerified) continue;
            if (validation.validUrls.contains(option.url)) result.options.add(option);
        }
        result.hasArabic = !result.options.isEmpty();
        if (result.hasArabic) {
            com.eve.cinema.playback.ResolutionTrace.record("captions",
                    "ARABIC_CAPTION_READY", "active-release metadata and parseability only; timing unverified");
        } else {
            com.eve.cinema.playback.ResolutionTrace.record("captions", result.status(),
                    result.resolved() ? "Arabic candidate search exhausted" : "retryable failure or limit");
        }
        return result;
    }

    private static boolean hasVerifiedArabicCaption(List<SubtitleOption> options,
            CaptionValidationState validation) {
        for (SubtitleOption option : options) {
            if (option != null && option.resourceIdentityVerified
                    && MovieBoxSubtitleReleaseResolver.isArabicCaption(
                            option.languageCode, option.languageEvidence())
                    && validation.validUrls.contains(option.url)) return true;
        }
        return false;
    }

    /** Valid Arabic captions are tested immediately so another candidate is tried after a bad file. */
    private boolean validateArabicCandidates(List<SubtitleOption> all,
            CaptionValidationState validation, CaptionsFetchResult result) {
        for (SubtitleOption option : all) {
            if (!MovieBoxSubtitleReleaseResolver.isArabicCaption(
                    option.languageCode, option.languageEvidence())) continue;
            if (validation.validUrls.contains(option.url)) {
                result.hasArabic = true;
                if (option.resourceIdentityVerified) return true;
                continue;
            }
            if (validation.invalidUrls.contains(option.url)) continue;
            if (validation.attempts >= MAX_CAPTION_VALIDATIONS) {
                result.exhausted = false;
                continue;
            }
            validation.attempts++;
            if (validateCaption(option)) {
                validation.validUrls.add(option.url);
                result.hasArabic = true;
                if (option.resourceIdentityVerified) return true;
                continue;
            }
            validation.invalidUrls.add(option.url);
            result.validationFailure = true;
            result.arabicValidationFailure = true;
            com.eve.cinema.playback.ResolutionTrace.record("captions",
                    "ARABIC_CAPTION_DOWNLOAD_OR_PARSE_FAILED", "retrying candidate search");
        }
        return false;
    }


    private static void appendCaptionStatus(Playback playback, String status) {
        if (playback == null || status == null || status.isEmpty()) return;
        if (playback.captionsError == null || playback.captionsError.isEmpty())
            playback.captionsError = status;
        else if (!playback.captionsError.contains(status))
            playback.captionsError += "; " + status;
    }

    /** Parseability check only; this does not establish work identity, cut, or synchronization. */
    private static boolean validateCaption(SubtitleOption c) {
        if (c == null || c.url == null || c.url.isEmpty()) return false;
        try {
            String content = new com.eve.cinema.playback.SubtitleFetcher(10_000)
                    .fetch(c.url, c.headers, null);
            return !com.eve.cinema.playback.SubtitleParser.parse(content).isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    private List<SubtitleOption> captionsAt(String subjectId, String resourceId,
            int season, int episode, boolean resourceIdentityVerified) throws MovieBoxException {
        List<SubtitleOption> captions = MovieBoxParser.captionsToOptions(
                client.getExtCaptions(subjectId, resourceId));
        for (SubtitleOption caption : captions) {
            caption.subjectId = subjectId;
            caption.resourceId = resourceId;
            caption.season = season;
            caption.episode = episode;
            caption.resourceIdentityVerified = resourceIdentityVerified;
            caption.headers.putAll(subtitleHeaders());
        }
        return captions;
    }

    /** All bounded resource rows that exactly belong to this movie/episode. */
    private List<JSONObject> resourceRows(String subjectId, int season, int episode,
                                           CaptionsFetchResult result) {
        List<JSONObject> rows = new ArrayList<>();
        Set<String> seenIds = new HashSet<>();
        Set<Integer> visitedPages = new HashSet<>();
        java.util.LinkedHashSet<Integer> pendingPages = new java.util.LinkedHashSet<>();
        for (int planned : MovieBoxSubtitleResourcePlanner.pageOrder(episode))
            pendingPages.add(planned);
        boolean unresolvedMore = false;
        for (int count = 0; count < MAX_RESOURCE_PAGES && !pendingPages.isEmpty(); count++) {
            int page = pendingPages.iterator().next();
            pendingPages.remove(page);
            if (!visitedPages.add(page)) continue;
            if (result.apiRequests >= MAX_CAPTION_API_REQUESTS) {
                result.exhausted = false;
                break;
            }
            JSONObject payload;
            try {
                result.apiRequests++;
                payload = client.getResources(subjectId, season, episode, page, null, 20);
            } catch (MovieBoxException e) {
                result.requestFailure = true;
                result.exhausted = false;
                break;
            }
            org.json.JSONArray items = MovieBoxParser.resourceItems(payload);
            if (items != null) {
                for (int i = 0; i < items.length(); i++) {
                    JSONObject item = items.optJSONObject(i);
                    if (!MovieBoxParser.resourceMatchesEpisode(item, season, episode)) continue;
                    String id = MovieBoxParser.resourceIdOf(item);
                    if (id == null || id.isEmpty() || seenIds.add(id)) rows.add(item);
                    if (rows.size() >= MAX_RESOURCE_ROWS_PER_SUBJECT) {
                        result.exhausted = false;
                        return rows;
                    }
                }
            }
            boolean more = MovieBoxParser.resourceHasMore(payload);
            if (more) {
                int next = page + 1;
                if (!visitedPages.contains(next)) pendingPages.add(next);
                else unresolvedMore = true; // cyclic pager: do not claim a complete search
            }
        }
        if (!pendingPages.isEmpty() || unresolvedMore) result.exhausted = false;
        return rows;
    }

    /**
     * Pages to try for an episode's resource row. The upstream page math
     * ((episode-1)/20+1) is right when the server paginates the whole list, but the
     * request also carries se/ep: if the server filters BEFORE paginating, the row for
     * episode 21+ sits on page 1 and the computed page is empty. Trying page 1 as well is
     * safe because a row is only accepted on an EXACT season+episode match.
     */
    /**
     * The sibling release's OWN season/episode for the same logical (TMDB) episode,
     * mapped from that sibling's season-info. null when it cannot be verified — a
     * sibling is never queried with another release's numbering.
     */
    private int[] numberingForSibling(Playback playback, String siblingSubjectId,
                                      int season, int episode, JSONObject details) {
        if (!playback.isSeries) return new int[]{season, episode};
        if (playback.tmdbEpisode <= 0) return null;
        try {
            List<SeasonInfo> seasons = MovieBoxParser.parseSeasons(details);
            MovieBoxEpisodeMapper.Mapping m = MovieBoxEpisodeMapper.map(playback.tmdbSeason,
                    playback.tmdbEpisode, seasons, copySeasonCounts(playback.tmdbSeasonCounts));
            return new int[]{m.season, m.episode};
        } catch (MovieBoxEpisodeMapper.MappingException e) {
            return null;
        }
    }

    /** Only Arabic-subtitle-labelled siblings plus the canonical work are candidates. */
    private static List<SubtitleSiblingCandidate> subtitleSiblingCandidates(
            Playback playback, String activeSubjectId) {
        List<SubtitleSiblingCandidate> out = new ArrayList<>();
        if (playback.dubs != null) {
            for (MovieBoxModels.DubOption d : playback.dubs) {
                if (d == null || !hasText(d.subjectId) || d.subjectId.equals(activeSubjectId)
                        || !MovieBoxSubtitleReleaseResolver.isArabicSubtitleHint(
                                d.lanCode, d.language, d.label)) continue;
                boolean duplicate = false;
                for (SubtitleSiblingCandidate old : out)
                    if (old.subjectId.equals(d.subjectId)) { duplicate = true; break; }
                if (!duplicate) out.add(new SubtitleSiblingCandidate(d.subjectId));
            }
        }
        String canonical = playback.canonicalSubjectId();
        if (hasText(canonical) && !canonical.equals(activeSubjectId)) {
            boolean duplicate = false;
            for (SubtitleSiblingCandidate old : out)
                if (old.subjectId.equals(canonical)) { duplicate = true; break; }
            if (!duplicate) out.add(new SubtitleSiblingCandidate(canonical));
        }
        return out;
    }

    private static void appendUnique(List<SubtitleOption> target, Set<String> seenUrls,
                                     List<SubtitleOption> options) {
        for (SubtitleOption o : options) {
            if (o == null || o.url == null) continue;
            if (seenUrls.add(o.url)) target.add(o);
        }
    }

    private static Map<Integer, Integer> copySeasonCounts(Map<Integer, Integer> counts) {
        return counts == null ? new HashMap<Integer, Integer>()
                : new HashMap<Integer, Integer>(counts);
    }

    /** Headers for MovieBox caption CDN downloads (same client identity as playback). */
    public Map<String, String> subtitleHeaders() {
        Map<String, String> h = new LinkedHashMap<>();
        h.put("User-Agent", client.userAgent());
        h.put("Referer", MovieBoxParser.STREAM_REFERER);
        return h;
    }
}

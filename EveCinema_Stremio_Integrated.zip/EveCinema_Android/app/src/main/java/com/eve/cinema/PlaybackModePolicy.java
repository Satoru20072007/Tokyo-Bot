package com.eve.cinema;

/** Pure capability policy shared by preflight decisions and JVM tests. */
public final class PlaybackModePolicy {
    public static final int NONE = 0;
    public static final int ARABIC_SUBTITLES = 1;
    public static final int ARABIC_DUB = 2;
    public static final int ENGLISH_FALLBACK = 3;
    public static final int ENGLISH_SUBTITLE_FALLBACK = 4;
    private PlaybackModePolicy() {}

    public static boolean hasArabic(boolean arabicAudio, boolean arabicSubtitles) {
        return arabicAudio || arabicSubtitles;
    }
    public static boolean hasEnglishFallback(boolean englishAudio, boolean englishSubtitles) {
        return englishAudio || englishSubtitles;
    }
    public static boolean requiresArabicAudioVerification(boolean manifestDeclaresArabic,
                                                            boolean linkedArabicRelease) {
        return manifestDeclaresArabic || linkedArabicRelease;
    }
    public static int bestArabicMode(int preferredMode, boolean arabicAudio, boolean arabicSubtitles) {
        if (preferredMode == ARABIC_SUBTITLES && arabicSubtitles) return ARABIC_SUBTITLES;
        if (preferredMode == ARABIC_DUB && arabicAudio) return ARABIC_DUB;
        if (arabicSubtitles) return ARABIC_SUBTITLES;
        if (arabicAudio) return ARABIC_DUB;
        return NONE;
    }
    public static int recoveryModeAfterArabicAudioFailure(boolean alternativeCandidate,
                                                          boolean fallbackDirectArabicAudio,
                                                          boolean fallbackArabicSubtitles,
                                                          boolean englishAudio,
                                                          boolean englishSubtitles) {
        int arabicMode = alternativeCandidate
                ? bestArabicMode(ARABIC_DUB, fallbackDirectArabicAudio, fallbackArabicSubtitles)
                : (fallbackArabicSubtitles ? ARABIC_SUBTITLES : NONE);
        if (arabicMode != NONE) return arabicMode;
        return hasEnglishFallback(englishAudio, englishSubtitles) ? ENGLISH_FALLBACK : NONE;
    }
    public static int fallbackMode(boolean arabicAudio, boolean arabicSubtitles,
                                   boolean englishAudio, boolean englishSubtitles) {
        if (hasArabic(arabicAudio, arabicSubtitles)) return NONE;
        return hasEnglishFallback(englishAudio, englishSubtitles) ? ENGLISH_FALLBACK : NONE;
    }
    public static boolean supports(int requestedMode, boolean arabicAudio, boolean arabicSubtitles,
                                   boolean englishAudio, boolean englishSubtitles) {
        switch (requestedMode) {
            case ARABIC_SUBTITLES: return arabicSubtitles;
            case ARABIC_DUB: return arabicAudio;
            case ENGLISH_FALLBACK: return hasEnglishFallback(englishAudio, englishSubtitles);
            case ENGLISH_SUBTITLE_FALLBACK: return englishSubtitles;
            default: return false;
        }
    }
    public static int recoveryModeAfterEnglishAudioFailure(boolean englishSubtitles) {
        return englishSubtitles ? ENGLISH_SUBTITLE_FALLBACK : NONE;
    }
}

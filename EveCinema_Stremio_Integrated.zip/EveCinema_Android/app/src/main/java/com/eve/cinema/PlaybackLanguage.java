package com.eve.cinema;

import java.util.Locale;

/** Conservative language-tag matching for provider metadata and Media3 Format.language. */
public final class PlaybackLanguage {
    private PlaybackLanguage() {}

    public static boolean isArabic(String value) { return matches(value, "ar", "ara", "arabic", "العربية", "عربي"); }
    public static boolean isEnglish(String value) { return matches(value, "en", "eng", "english"); }

    private static boolean matches(String value, String... roots) {
        if (value == null) return false;
        String s = value.trim().toLowerCase(Locale.ROOT).replace('_', '-');
        if (s.isEmpty()) return false;
        for (String root : roots) {
            if (s.equals(root) || s.startsWith(root + "-") || s.startsWith(root + " ")) return true;
            // Provider names sometimes add a display suffix, e.g. "Arabic (forced)".
            if (("arabic".equals(root) || "english".equals(root) || "العربية".equals(root) || "عربي".equals(root))
                    && s.startsWith(root + " (")) return true;
        }
        return false;
    }

    public static String canonical(String value) {
        if (isArabic(value)) return "ar";
        if (isEnglish(value)) return "en";
        return "";
    }
}

package com.eve.cinema.providercore;

/** Central, conservative defaults; ranking weights remain disabled pending measurements. */
public final class Tuning {
    public static final long SOURCE_SOFT_TIMEOUT_MS = 1_800L;
    public static final long SOURCE_HARD_BUDGET_MS = 8_000L;
    public static final int SOURCE_MAX_CONCURRENCY = 6;
    public static final long CANDIDATE_VALIDATION_TIMEOUT_MS = 3_000L;
    public static final int MAX_CANDIDATES_PER_MODE = 3;
    public static final long VERIFIED_DECISION_TTL_MS = 10 * 60 * 1_000L;
    public static final long NEGATIVE_DECISION_TTL_MS = 2 * 60 * 1_000L;
    public static final int PLAYBACK_SESSION_CAPACITY = 200;
    public static final int DEBUG_RECENT_SESSIONS = 20;

    /** Experimental six-signal score is not used until measured data justifies it. */
    public static final boolean RANKER_WEIGHTS_ENABLED = false;

    private Tuning() {}
}

package com.eve.cinema.moviebox;

import java.util.Locale;
import java.util.regex.Pattern;

import com.eve.cinema.playback.LanguageMatcher;

/** Conservative evidence checks for a related Arabic-subtitle release. */
public final class MovieBoxSubtitleReleaseResolver {
    private static final Pattern TRAILER = Pattern.compile(
            "(?i)(^|[^\\p{L}\\p{N}])trailer([^\\p{L}\\p{N}]|$)");

    private MovieBoxSubtitleReleaseResolver() {}

    /** The hint is only a subtitle-release signal; raw provider type is not consulted. */
    public static boolean isArabicSubtitleHint(String lanCode, String language, String label) {
        return MovieBoxReleaseClassifier.classify(lanCode, language, label).kind
                == MovieBoxReleaseClassifier.Kind.ARABIC_SUBTITLE;
    }

    /** Requires same media type and exact normalized base title after release markers. */
    public static boolean sameIdentity(String expectedTitle, boolean expectedSeries,
                                       String candidateTitle, boolean candidateSeries) {
        if (expectedSeries != candidateSeries) return false;
        String expected = normalizedBase(expectedTitle);
        String actual = normalizedBase(candidateTitle);
        return !expected.isEmpty() && expected.equals(actual);
    }

    /** A resource is eligible only if directly playable and metadata identifies the same item. */
    public static boolean compatibleResource(String expectedTitle, boolean series,
            String resourceTitle, int wantedSeason, int wantedEpisode,
            Integer resourceSeason, Integer resourceEpisode,
            long activeDurationSeconds, long candidateDurationSeconds,
            boolean directlyPlayable) {
        if (!directlyPlayable || isTrailerLabel(resourceTitle)
                || !runtimeCompatible(activeDurationSeconds, candidateDurationSeconds)) return false;
        if (series) {
            return wantedSeason > 0 && wantedEpisode > 0
                    && resourceSeason != null && resourceEpisode != null
                    && resourceSeason.intValue() == wantedSeason
                    && resourceEpisode.intValue() == wantedEpisode;
        }
        return sameIdentity(expectedTitle, false, resourceTitle, false);
    }

    /**
     * A caption lookup row is not required to have a playable resourceLink: MovieBox
     * can expose the update-video placeholder there while its resourceId still owns
     * extCaptions. The row must still match exact title/episode and exact corroborated
     * runtime. This method is for caption association only, never for source playback.
     */
    public static boolean compatibleCaptionResource(String expectedTitle, boolean series,
            String resourceTitle, int wantedSeason, int wantedEpisode,
            Integer resourceSeason, Integer resourceEpisode,
            long activeDurationSeconds, long candidateDurationSeconds) {
        if (isTrailerLabel(resourceTitle)
                || !runtimeCompatible(activeDurationSeconds, candidateDurationSeconds)) return false;
        if (series) {
            return wantedSeason > 0 && wantedEpisode > 0
                    && resourceSeason != null && resourceEpisode != null
                    && resourceSeason.intValue() == wantedSeason
                    && resourceEpisode.intValue() == wantedEpisode;
        }
        return sameIdentity(expectedTitle, false, resourceTitle, false);
    }

    /**
     * Runtime equality is only a necessary metadata filter, never proof of cue alignment.
     * The former 60-second/1% tolerance had no provider or reference-timeline basis and could
     * admit visibly different cuts; unknown or merely-near runtimes are rejected instead.
     */
    public static boolean runtimeCompatible(long activeSeconds, long candidateSeconds) {
        return activeSeconds > 0 && candidateSeconds > 0 && activeSeconds == candidateSeconds;
    }

    public static boolean isTrailerLabel(String title) {
        return title != null && TRAILER.matcher(title.trim()).find();
    }

    /** Resolve code/name metadata conservatively; contradictory evidence is not Arabic. */
    public static boolean isArabicCaption(String languageCode, String languageName) {
        String codeSignal = captionLanguageSignal(languageCode, true);
        String nameSignal = captionLanguageSignal(languageName, false);
        if ("!conflict".equals(codeSignal) || "!conflict".equals(nameSignal)) return false;
        if (codeSignal != null && nameSignal != null && !codeSignal.equals(nameSignal)) return false;
        return LanguageMatcher.AR.equals(codeSignal) || LanguageMatcher.AR.equals(nameSignal);
    }

    private static String captionLanguageSignal(String raw, boolean allowIsoCode) {
        if (raw == null || raw.trim().isEmpty()) return null;
        String lower = raw.toLowerCase(Locale.ROOT);
        boolean arabic = lower.contains("arabic") || lower.contains("عرب");
        boolean english = lower.contains("english") || lower.contains("انجليز") || lower.contains("إنجليز");
        if (arabic && english) return "!conflict";
        if (arabic) return LanguageMatcher.AR;
        if (english) return LanguageMatcher.EN;
        if (!allowIsoCode && raw.trim().matches("(?i)[a-z]{2,3}([-_][a-z0-9]{2,8})?"))
            return null; // an abbreviation in a display-name field is not a language name
        String normalized = LanguageMatcher.normalize(raw);
        if (normalized != null) return normalized;
        return MovieBoxTitleCleaner.languageToCode(raw.trim());
    }

    /** Failures keep the stream eligible for a later retry; only exhaustion is a resolved absence. */
    public static boolean mayMarkResolved(boolean candidatesExhausted,
                                          boolean requestFailure,
                                          boolean downloadOrParseFailure) {
        return candidatesExhausted && !requestFailure && !downloadOrParseFailure;
    }

    private static String normalizedBase(String title) {
        if (title == null) return "";
        String base = MovieBoxReleaseTag.parse(title).baseTitle;
        String lower = base.toLowerCase(Locale.ROOT);
        StringBuilder normalized = new StringBuilder(lower.length());
        boolean lastSpace = true;
        for (int i = 0; i < lower.length(); i++) {
            char c = lower.charAt(i);
            if (Character.isLetterOrDigit(c)) {
                normalized.append(c);
                lastSpace = false;
            } else if (!lastSpace) {
                normalized.append(' ');
                lastSpace = true;
            }
        }
        return normalized.toString().trim();
    }
}

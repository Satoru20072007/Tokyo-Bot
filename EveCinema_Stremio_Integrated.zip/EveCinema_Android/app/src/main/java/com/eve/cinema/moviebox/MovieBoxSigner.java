/*
 * Derived from MovieBox-Tui (Rust) — upstream dual-licensed MIT / Apache-2.0.
 * Upstream copyright retained. See NOTICE at the project root for the full
 * license texts and attribution scope.
 */
package com.eve.cinema.moviebox;

/*
 * Ported from MovieBox-Tui (src/providers/moviebox/crypto.rs).
 * MovieBox-Tui is dual-licensed MIT / Apache-2.0; see NOTICE in the project
 * root. This file preserves the request-signing semantics required for
 * compatibility with the public MovieBox mobile BFF API.
 */

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Request signing for the MovieBox wefeed-mobile-bff API.
 *
 * Mirrors crypto.rs exactly:
 *  - x-client-token = "{tsMillis},{md5(reversed tsMillis)}"
 *  - x-tr-signature = "{tsMillis}|2|{base64(HMAC-MD5(canonicalString))}"
 *  - canonicalString = METHOD\nACCEPT\nCONTENT_TYPE\nBODY_LEN\nTS\nBODY_MD5\nCANONICAL_URL
 *    where CANONICAL_URL = path + '?' + query params sorted by key (decoded values).
 */
public final class MovieBoxSigner {

    private static final byte[] DEFAULT_SECRET_BYTES = new byte[] {
        (byte)0xef, (byte)0xa8, (byte)0x91, (byte)0x97, 0x4e, (byte)0xec, (byte)0xd3, 0x14,
        (byte)0x8d, (byte)0xf6, 0x3a, (byte)0xa6, 0x11, 0x60, 0x2d, (byte)0xef,
        (byte)0xd1, 0x01, 0x25, (byte)0x9b, (byte)0xa5, 0x21, 0x02, 0x2c,
        0x57, (byte)0xae, 0x05, 0x66, (byte)0xbd, (byte)0x8e
    };

    private static final int SIGNATURE_BODY_MAX_BYTES = 102_400;

    private MovieBoxSigner() {}

    // ── Hashing ──────────────────────────────────────────────

    static String md5Hex(byte[] data) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] digest = md.digest(data);
            StringBuilder sb = new StringBuilder(digest.length * 2);
            for (byte b : digest) sb.append(String.format("%02x", b & 0xFF));
            return sb.toString();
        } catch (Exception e) {
            throw new IllegalStateException("MD5 unavailable", e);
        }
    }

    /** "ts,md5(reverse(ts))" — ts in milliseconds. */
    public static String generateXClientToken(long tsMillis) {
        String ts = Long.toString(tsMillis);
        String reversed = new StringBuilder(ts).reverse().toString();
        return ts + "," + md5Hex(reversed.getBytes(java.nio.charset.StandardCharsets.UTF_8));
    }

    // ── Canonical query ──────────────────────────────────────

    /**
     * Query parameters sorted by key, values percent-decoded (form semantics,
     * '+' → space), joined as k=v&k=v. Returns "" when there is no query.
     */
    static String sortedQueryString(String url) {
        String rawQuery;
        try {
            rawQuery = new java.net.URI(url).getRawQuery();
        } catch (Exception e) {
            return "";
        }
        if (rawQuery == null || rawQuery.isEmpty()) return "";

        TreeMap<String, List<String>> params = new TreeMap<>();
        for (String pair : rawQuery.split("&", -1)) {
            if (pair.isEmpty()) continue;
            int eq = pair.indexOf('=');
            String k = eq >= 0 ? pair.substring(0, eq) : pair;
            String v = eq >= 0 ? pair.substring(eq + 1) : "";
            k = urlDecode(k);
            v = urlDecode(v);
            params.computeIfAbsent(k, key -> new ArrayList<>()).add(v);
        }
        if (params.isEmpty()) return "";

        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, List<String>> e : params.entrySet()) {
            for (String v : e.getValue()) {
                if (sb.length() > 0) sb.append('&');
                sb.append(e.getKey()).append('=').append(v);
            }
        }
        return sb.toString();
    }

    private static String urlDecode(String s) {
        try {
            return java.net.URLDecoder.decode(s, "UTF-8");
        } catch (Exception e) {
            return s;
        }
    }

    // ── Canonical string & signature ─────────────────────────

    public static String buildCanonicalString(String method, String accept, String contentType,
                                              String url, String body, long timestampMs) {
        String canonicalUrl;
        try {
            java.net.URI parsed = new java.net.URI(url);
            String path = parsed.getPath();
            String query = sortedQueryString(url);
            canonicalUrl = (path == null ? "" : path) + (query.isEmpty() ? "" : "?" + query);
        } catch (Exception e) {
            canonicalUrl = url;
        }

        String bodyHash = "";
        String bodyLength = "";
        if (body != null) {
            byte[] bytes = body.getBytes(java.nio.charset.StandardCharsets.UTF_8);
            bodyLength = Integer.toString(bytes.length);
            byte[] hashed = bytes.length > SIGNATURE_BODY_MAX_BYTES
                    ? java.util.Arrays.copyOf(bytes, SIGNATURE_BODY_MAX_BYTES)
                    : bytes;
            bodyHash = md5Hex(hashed);
        }

        return method.toUpperCase(java.util.Locale.US) + "\n"
                + (accept == null ? "" : accept) + "\n"
                + (contentType == null ? "" : contentType) + "\n"
                + bodyLength + "\n"
                + timestampMs + "\n"
                + bodyHash + "\n"
                + canonicalUrl;
    }

    public static String generateXTrSignature(String method, String accept, String contentType,
                                              String url, String body, long timestampMs) {
        String canonical = buildCanonicalString(method, accept, contentType, url, body, timestampMs);
        try {
            Mac mac = Mac.getInstance("HmacMD5");
            mac.init(new SecretKeySpec(DEFAULT_SECRET_BYTES, "HmacMD5"));
            byte[] sig = mac.doFinal(canonical.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            return timestampMs + "|2|" + MovieBoxBase64.encode(sig);
        } catch (Exception e) {
            // Mirrors the Rust fallback when HMAC key material is rejected.
            return timestampMs + "|2|";
        }
    }

    // ── Full signed header set ───────────────────────────────

    /**
     * Builds the complete signed header map for one request.
     * Header names match crypto.rs build_signed_headers().
     */
    public static Map<String, String> buildSignedHeaders(String method, String url, String body,
                                                         String authToken, String userAgent,
                                                         String clientInfo) {
        long ts = System.currentTimeMillis();
        String accept = "application/json";
        String contentType = "application/json";

        Map<String, String> headers = new java.util.LinkedHashMap<>();
        headers.put("User-Agent", userAgent);
        headers.put("Accept", accept);
        headers.put("Content-Type", contentType);
        headers.put("Connection", "keep-alive");
        headers.put("x-client-token", generateXClientToken(ts));
        headers.put("x-tr-signature",
                generateXTrSignature(method, accept, contentType, url, body, ts));
        headers.put("x-client-info", clientInfo);
        headers.put("x-client-status", "0");
        if (authToken != null && !authToken.isEmpty()) {
            headers.put("Authorization", "Bearer " + authToken);
        }
        return headers;
    }
}

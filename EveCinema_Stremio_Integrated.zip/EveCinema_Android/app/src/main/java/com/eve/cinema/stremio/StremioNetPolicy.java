package com.eve.cinema.stremio;

import java.net.InetAddress;
import java.net.URI;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Network safety rules for everything that leaves the device because of a Stremio add-on.
 *
 * <ul>
 *   <li>Host <b>forms</b> are whitelisted (plain DNS names with an alphabetic TLD, or canonical
 *       dotted-quad IPv4). Alternative IP spellings such as {@code 2130706433}, {@code 0x7f.1},
 *       {@code 127.1} or octal parts, IPv6 literals and single-label names never get as far as
 *       the resolver.</li>
 *   <li>Every resolved address must be public: loopback, private, link-local, CGNAT
 *       ({@code 100.64.0.0/10}), documentation/benchmark/reserved ranges, multicast, IPv6
 *       ULA ({@code fc00::/7}), IPv4-mapped and 6to4/NAT64-embedded private addresses are rejected.</li>
 * </ul>
 *
 * <b>Known limit:</b> this class validates the addresses a name resolves to <i>before</i> the
 * connection is opened. {@code HttpURLConnection} resolves the name again by itself, so an attacker
 * controlling DNS could still answer differently the second time (DNS rebinding). Closing that gap
 * needs a transport that connects to the already-validated address (for example an OkHttp
 * {@code Dns} hook); see STREMIO_AGENT_REPORT.md.
 */
public final class StremioNetPolicy {
    private StremioNetPolicy() {}

    /** DNS seam: production uses the system resolver, tests inject doubles. */
    public interface Resolver {
        InetAddress[] resolve(String host) throws UnknownHostException;
    }

    public static final Resolver SYSTEM_RESOLVER = new Resolver() {
        @Override public InetAddress[] resolve(String host) throws UnknownHostException {
            return InetAddress.getAllByName(host);
        }
    };

    private static final Pattern DNS_NAME = Pattern.compile(
            "^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z](?:[a-z0-9-]{0,61}[a-z0-9])?$");
    private static final Pattern IPV4_CANONICAL = Pattern.compile(
            "^(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)(?:\\.(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)){3}$");
    private static final String[] BLOCKED_SUFFIXES = {
            "localhost", "local", "internal", "home", "lan", "localdomain", "intranet",
            "corp", "private", "home.arpa", "in-addr.arpa", "ip6.arpa"
    };

    /** An immutable rule set. */
    public static final class Policy {
        private final boolean allowHttp;
        private final boolean allowNonPublic;
        private final Resolver resolver;
        private final java.util.Set<String> deniedAuthorities;

        private Policy(boolean allowHttp, boolean allowNonPublic, Resolver resolver) {
            this(allowHttp, allowNonPublic, resolver, java.util.Collections.<String>emptySet());
        }

        private Policy(boolean allowHttp, boolean allowNonPublic, Resolver resolver,
                       java.util.Set<String> deniedAuthorities) {
            this.allowHttp = allowHttp;
            this.allowNonPublic = allowNonPublic;
            this.resolver = resolver;
            this.deniedAuthorities = deniedAuthorities;
        }

        /**
         * TEST ONLY: like {@link #forTests()} but refuses the listed {@code host:port} authorities,
         * which stands in for "this redirect hop points at a private address".
         */
        public static Policy forTestsDenying(String... authorities) {
            return new Policy(true, true, SYSTEM_RESOLVER,
                    new java.util.HashSet<String>(java.util.Arrays.asList(authorities)));
        }

        /** Manifest / resource requests to an add-on: public HTTPS only. */
        public static Policy addon() { return new Policy(false, false, SYSTEM_RESOLVER); }
        public static Policy addon(Resolver resolver) { return new Policy(false, false, resolver); }

        /** Media and subtitle files named by an add-on: public HTTP(S). */
        public static Policy media() { return new Policy(true, false, SYSTEM_RESOLVER); }
        public static Policy media(Resolver resolver) { return new Policy(true, false, resolver); }

        /** TEST ONLY: accepts http and loopback so a local fake server can be used. */
        public static Policy forTests() { return new Policy(true, true, SYSTEM_RESOLVER); }

        public boolean allowsHttp() { return allowHttp; }

        /** Syntax-only check (no DNS): scheme, user-info, fragment, port and host form. */
        public void checkSyntax(URI uri) throws StremioException {
            if (uri == null) throw unsafe();
            String scheme = uri.getScheme();
            boolean https = "https".equalsIgnoreCase(scheme);
            boolean http = "http".equalsIgnoreCase(scheme);
            if (!(https || (http && allowHttp))) throw unsafe();
            if (uri.getRawUserInfo() != null || uri.getRawFragment() != null) throw unsafe();
            String host = uri.getHost();
            if (host == null) throw unsafe();
            if (!deniedAuthorities.isEmpty()
                    && deniedAuthorities.contains(host + (uri.getPort() == -1 ? "" : ":" + uri.getPort()))) throw unsafe();
            int port = uri.getPort();
            if (port != -1 && (port < 1 || port > 65535)) throw unsafe();
            if (allowNonPublic) return;

            host = normalizeHost(host);
            if (host.indexOf(':') >= 0 || host.startsWith("[")) throw unsafe();   // IPv6 literals unsupported
            if (IPV4_CANONICAL.matcher(host).matches()) {
                if (!isPublicIpv4(parseIpv4(host))) throw unsafe();
                return;
            }
            if (!DNS_NAME.matcher(host).matches()) throw unsafe();
            for (String suffix : BLOCKED_SUFFIXES) {
                if (host.equals(suffix) || host.endsWith("." + suffix)) throw unsafe();
            }
        }

        /** Syntax check plus DNS: every address the host resolves to must be public. */
        public void check(URI uri) throws StremioException {
            checkSyntax(uri);
            if (allowNonPublic) return;
            String host = normalizeHost(uri.getHost());
            if (IPV4_CANONICAL.matcher(host).matches()) return;   // literal already classified
            InetAddress[] addresses;
            try {
                addresses = resolver.resolve(host);
            } catch (UnknownHostException ex) {
                throw new StremioException(StremioException.Kind.NETWORK);
            } catch (RuntimeException ex) {
                throw new StremioException(StremioException.Kind.NETWORK);
            }
            if (addresses == null || addresses.length == 0)
                throw new StremioException(StremioException.Kind.NETWORK);
            for (InetAddress address : addresses) {
                if (address == null || !isPublicAddress(address)) throw unsafe();
            }
        }

        public boolean isSafe(String url) {
            try { check(URI.create(url)); return true; } catch (Exception ex) { return false; }
        }

        public boolean isSyntaxSafe(String url) {
            try { checkSyntax(URI.create(url)); return true; } catch (Exception ex) { return false; }
        }
    }

    private static StremioException unsafe() {
        return new StremioException(StremioException.Kind.UNSAFE_URL);
    }

    static String normalizeHost(String host) {
        String h = host.toLowerCase(Locale.ROOT);
        return h.endsWith(".") ? h.substring(0, h.length() - 1) : h;
    }

    // ───────────────────────────── address classification ─────────────────────────────

    public static boolean isPublicAddress(InetAddress address) {
        byte[] b = address.getAddress();
        if (b.length == 4) return isPublicIpv4(b);
        if (b.length == 16) return isPublicIpv6(b);
        return false;
    }

    static boolean isPublicIpv4(byte[] b) {
        int o0 = b[0] & 0xFF, o1 = b[1] & 0xFF, o2 = b[2] & 0xFF;
        if (o0 == 0) return false;                                  // 0.0.0.0/8 "this network"
        if (o0 == 10) return false;                                 // 10.0.0.0/8
        if (o0 == 100 && (o1 & 0xC0) == 64) return false;           // 100.64.0.0/10 CGNAT
        if (o0 == 127) return false;                                // loopback
        if (o0 == 169 && o1 == 254) return false;                   // link-local
        if (o0 == 172 && (o1 & 0xF0) == 16) return false;           // 172.16.0.0/12
        if (o0 == 192 && o1 == 0 && (o2 == 0 || o2 == 2)) return false; // 192.0.0.0/24, 192.0.2.0/24
        if (o0 == 192 && o1 == 88 && o2 == 99) return false;        // deprecated 6to4 relay anycast
        if (o0 == 192 && o1 == 168) return false;                   // 192.168.0.0/16
        if (o0 == 198 && (o1 == 18 || o1 == 19)) return false;      // 198.18.0.0/15 benchmarking
        if (o0 == 198 && o1 == 51 && o2 == 100) return false;       // TEST-NET-2
        if (o0 == 203 && o1 == 0 && o2 == 113) return false;        // TEST-NET-3
        if (o0 >= 224) return false;                                // multicast, reserved, broadcast
        return true;
    }

    static boolean isPublicIpv6(byte[] b) {
        // ::ffff:a.b.c.d (IPv4-mapped): the embedded IPv4 decides.
        if (isZero(b, 0, 10) && (b[10] & 0xFF) == 0xFF && (b[11] & 0xFF) == 0xFF)
            return isPublicIpv4(Arrays.copyOfRange(b, 12, 16));
        // ::/96 covers unspecified (::), loopback (::1) and deprecated IPv4-compatible addresses.
        if (isZero(b, 0, 12)) return false;
        // 64:ff9b::/96 (NAT64 well-known prefix, used by IPv6-only mobile networks): embedded IPv4 decides.
        if (b[0] == 0x00 && b[1] == 0x64 && (b[2] & 0xFF) == 0xFF && (b[3] & 0xFF) == 0x9B && isZero(b, 4, 12))
            return isPublicIpv4(Arrays.copyOfRange(b, 12, 16));
        int first = b[0] & 0xFF, second = b[1] & 0xFF, third = b[2] & 0xFF, fourth = b[3] & 0xFF;
        if ((first & 0xE0) != 0x20) return false;                   // only 2000::/3 global unicast is routable
        if (first == 0x20 && second == 0x02)                        // 2002::/16 6to4: embedded IPv4 decides
            return isPublicIpv4(Arrays.copyOfRange(b, 2, 6));
        if (first == 0x20 && second == 0x01) {
            if (third == 0x00 && fourth == 0x00) return false;      // 2001::/32 Teredo
            if (third == 0x0D && fourth == 0xB8) return false;      // 2001:db8::/32 documentation
            if (third == 0x00 && fourth == 0x02 && (b[4] | b[5]) == 0) return false; // 2001:2::/48 benchmarking
            if (third == 0x00 && (fourth & 0xF0) == 0x10) return false; // 2001:10::/28 ORCHID
            if (third == 0x00 && (fourth & 0xF0) == 0x20) return false; // 2001:20::/28 ORCHIDv2
        }
        if (first == 0x3F && second == 0xFF && (third & 0xF0) == 0x00) return false; // 3fff::/20 documentation
        return true;
    }

    private static boolean isZero(byte[] b, int from, int to) {
        for (int i = from; i < to; i++) if (b[i] != 0) return false;
        return true;
    }

    static byte[] parseIpv4(String canonical) {
        String[] parts = canonical.split("\\.");
        byte[] out = new byte[4];
        for (int i = 0; i < 4; i++) out[i] = (byte) Integer.parseInt(parts[i]);
        return out;
    }

    // ───────────────────────────── log redaction ─────────────────────────────

    private static final String[] STRUCTURAL = {
            "manifest.json", "stream", "subtitles", "catalog", "meta", "movie", "series", "anime",
            "tv", "channel", "other"
    };

    /**
     * Log-safe rendering of a URL: {@code scheme://host/…/manifest.json}. Credentials can live in
     * the path, so dropping the query is not enough: only well-known structural segments survive,
     * every other path segment collapses into a single "…" and the query becomes "?…".
     */
    public static String redactUrlForLogs(String url) {
        if (url == null) return "[none]";
        URI uri;
        try { uri = URI.create(url.trim()); } catch (RuntimeException ex) { return "[invalid-url]"; }
        String scheme = uri.getScheme();
        String host = uri.getHost();
        if (scheme == null || host == null) return "[invalid-url]";
        StringBuilder out = new StringBuilder(scheme.toLowerCase(Locale.ROOT)).append("://")
                .append(host.toLowerCase(Locale.ROOT));
        String path = uri.getRawPath();
        if (path != null && !path.isEmpty() && !"/".equals(path)) {
            boolean collapsed = false;
            for (String segment : path.split("/")) {
                if (segment.isEmpty()) continue;
                String name = segment;
                if (name.toLowerCase(Locale.ROOT).endsWith(".json") && !"manifest.json".equalsIgnoreCase(name))
                    name = "x.json";                       // "<id>.json" resource tail: the id is not logged
                boolean keep = false;
                for (String known : STRUCTURAL) if (known.equalsIgnoreCase(name)) { keep = true; break; }
                if (keep) { out.append('/').append(segment.toLowerCase(Locale.ROOT)); collapsed = false; }
                else if (!collapsed) { out.append("/…"); collapsed = true; }
            }
        }
        if (uri.getRawQuery() != null) out.append("?…");
        return out.toString();
    }

    /** UTF-8 byte length helper shared by size checks. */
    static int utf8Length(String s) { return s.getBytes(StandardCharsets.UTF_8).length; }
}

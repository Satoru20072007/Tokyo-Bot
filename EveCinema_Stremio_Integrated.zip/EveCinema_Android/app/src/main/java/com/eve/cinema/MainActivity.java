package com.eve.cinema;

import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {

    private static final String TMDB_TOKEN = Config.TMDB_BEARER_TOKEN;
    private static final String IMG_BASE_W = "https://image.tmdb.org/t/p/w342";
    // w1280 للـ backdrop بدل original (كان يفك ضغط صور 3000px+ على أجهزة ضعيفة)
    private static final String IMG_BASE_B = "https://image.tmdb.org/t/p/w1280";
    private static final String GRID_PAD   = "grid_pad";

    // ── Cached interpolators — allocated once per process lifetime ────
    // Creating new interpolator instances during scroll/touch is a common
    // allocation hotspot that triggers GC pauses on mid-range devices.
    private static final DecelerateInterpolator      DECEL_2      = new DecelerateInterpolator(2.0f);
    private static final DecelerateInterpolator      DECEL_25     = new DecelerateInterpolator(2.5f);
    private static final DecelerateInterpolator      DECEL_15     = new DecelerateInterpolator(1.5f);
    private static final AccelerateInterpolator      ACCEL_2      = new AccelerateInterpolator(2.0f);
    private static final AccelerateDecelerateInterpolator ACCEL_DECEL = new AccelerateDecelerateInterpolator();
    private static final OvershootInterpolator       OVERSHOOT_28 = new OvershootInterpolator(2.8f);
    private static final OvershootInterpolator       OVERSHOOT_18 = new OvershootInterpolator(1.8f);
    private static final OvershootInterpolator       OVERSHOOT_14 = new OvershootInterpolator(1.4f);

    private UserSession session;
    private float       screenDensity;

    // Views
    private LinearLayout rowTrending, rowNew, rowAction, rowDrama, rowScifi,
                         rowHorror, rowComedy, rowAsian, rowAnime,
                         rowNowPlaying, rowTopRated, rowDocumentary,
                         rowRomance, rowAdventure, rowThriller, rowFamily, rowHistory;
    private LinearLayout searchResultsSection, searchResultsGrid;
    private ImageView    navAvatar;
    private android.graphics.Typeface bebasTypeface = null;

    // ── Hero (carousel) ──
    private RecyclerView        heroPager;
    private LinearLayoutManager heroLm;
    private PagerSnapHelper     heroSnap;
    private HeroPagerAdapter    heroAdapter;
    private SegmentedIndicator  heroIndicator;
    private final ImageView[]   heroBg    = new ImageView[2];
    private final int[]         heroBgIdx = {-1, -1};
    private View heroSection, heroContent, heroDim, heroLoading, heroError;
    private View navbarBg, navbarScrim;
    private final List<JSONObject> heroItems = new ArrayList<>();
    private int     heroHeightPx  = 0;
    private int     heroPage      = 0;
    private boolean heroTouching  = false;
    private boolean heroOffscreen = false;
    private boolean activityResumed = false;
    private boolean reducedMotion   = false;
    private final Handler heroHandler = new Handler(Looper.getMainLooper());
    private ProgressBar  mainLoading;
    private LinearLayout searchBar;
    private EditText     searchInput;
    private ScrollView   mainScroll;
    private View         offlineBanner;
    private View         topNavbar;

    private LinearLayout btnHome, btnMovies, btnSeries, btnAnime, btnSettings;

    private int        currentTabIndex   = 0;
    private final int[] tabScrollY       = new int[]{0, 0, 0, 0};

    private String  currentCategoryMediaType = null;
    private String  currentCategoryListType  = null;
    private String  currentCategoryGenre     = null;
    private int     currentCategoryPage      = 1;
    private boolean categoryLoadingMore      = false;
    private boolean categoryHasMore          = true;
    private boolean isShowingCategory        = false;

    private String  currentSearchQuery = null;
    private int     currentSearchPage  = 1;
    private boolean searchLoadingMore  = false;
    private boolean searchHasMore      = true;

    private final Map<Integer, RowState> rowStates = new HashMap<>();

    private float   swipeTouchStartX  = 0f;
    private float   swipeTouchStartY  = 0f;
    private boolean swipeDownReceived = false;
    private boolean swipeLockedInHSV  = false;
    private static final int SWIPE_MIN_DISTANCE = 80;
    private static final int SWIPE_MAX_OFF_PATH = 80;

    private int     lastScrollY   = 0;
    private boolean navbarVisible = true;

    private ViewTreeObserver.OnScrollChangedListener mainScrollNavListener;
    private ViewTreeObserver.OnScrollChangedListener mainScrollInfiniteListener;

    private final Handler batchHandler  = new Handler();
    private final Handler settleHandler = new Handler(); // stub

    private final Map<Integer, CinematicScrollView> cinemaScrollViews = new HashMap<>();

    private static class RowState {
        String  mediaType, listType, genre;
        int     nextPage = 2;
        boolean loading  = false;
        boolean done     = false;
    }

    // ══════════════════════════════════════════════════════════════
    // onCreate
    // ══════════════════════════════════════════════════════════════
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MiuiBarFix.apply(this);

        session = new UserSession(this);
        if (!session.isLoggedIn()) {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        screenDensity = getResources().getDisplayMetrics().density;
        setContentView(R.layout.activity_main);
        bindViews();
        setupHero();
        loadBebasNeue();
        setupTopBar();
        setupBottomNav();
        setupSeeAllButtons();
        setupSearch();
        setupInfiniteScroll();
        setupSwipeNavigation();
        setupNavbarScrollBehavior();
        showHomeContent(true);
        checkConnectionAndLoad();
    }

    @Override
    protected void onResume() {
        super.onResume();
        MiuiBarFix.apply(this);
        applyAvatarToNav();
        EveFloatingButton.attach(this);
        activityResumed = true;
        reducedMotion   = isMotionReduced();
        if (heroIndicator != null) heroIndicator.setStaticFill(reducedMotion);
        Shimmer.resume();
        scheduleHero();
    }

    @Override
    protected void onPause() {
        super.onPause();
        EveFloatingButton.detach(this);
        activityResumed = false;
        heroHandler.removeCallbacks(heroTick);
        if (heroIndicator != null) heroIndicator.pause();
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Pause shared shimmer when app is not visible — saves CPU/GPU
        Shimmer.pause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        MiuiBarFix.release(this);
        batchHandler.removeCallbacksAndMessages(null);
        settleHandler.removeCallbacksAndMessages(null);
        if (mainScroll != null) {
            ViewTreeObserver vto = mainScroll.getViewTreeObserver();
            if (vto.isAlive()) {
                if (mainScrollNavListener    != null) vto.removeOnScrollChangedListener(mainScrollNavListener);
                if (mainScrollInfiniteListener != null) vto.removeOnScrollChangedListener(mainScrollInfiniteListener);
            }
        }
        cinemaScrollViews.clear();
        // Stop shimmer on destroy to release animator memory
        Shimmer.stopAll();
        heroHandler.removeCallbacksAndMessages(null);
    }

    // ══════════════════════════════════════════════════════════════
    // bindViews
    // ══════════════════════════════════════════════════════════════
    private void bindViews() {
        rowTrending    = (LinearLayout) findViewById(R.id.row_trending);
        rowNew         = (LinearLayout) findViewById(R.id.row_new);
        rowAction      = (LinearLayout) findViewById(R.id.row_action);
        rowDrama       = (LinearLayout) findViewById(R.id.row_drama);
        rowScifi       = (LinearLayout) findViewById(R.id.row_scifi);
        rowHorror      = (LinearLayout) findViewById(R.id.row_horror);
        rowComedy      = (LinearLayout) findViewById(R.id.row_comedy);
        rowAsian       = (LinearLayout) findViewById(R.id.row_asian);
        rowAnime       = (LinearLayout) findViewById(R.id.row_anime);
        rowNowPlaying  = (LinearLayout) findViewById(R.id.row_nowplaying);
        rowTopRated    = (LinearLayout) findViewById(R.id.row_toprated);
        rowDocumentary = (LinearLayout) findViewById(R.id.row_documentary);
        rowRomance     = (LinearLayout) findViewById(R.id.row_romance);
        rowAdventure   = (LinearLayout) findViewById(R.id.row_adventure);
        rowThriller    = (LinearLayout) findViewById(R.id.row_thriller);
        rowFamily      = (LinearLayout) findViewById(R.id.row_family);
        rowHistory     = (LinearLayout) findViewById(R.id.row_history);

        searchResultsSection = (LinearLayout) findViewById(R.id.search_results_section);
        searchResultsGrid    = (LinearLayout) findViewById(R.id.search_results_grid);
        navAvatar   = (ImageView)   findViewById(R.id.nav_avatar);
        heroSection   = findViewById(R.id.hero_section);
        heroContent   = findViewById(R.id.hero_content);
        heroBg[0]     = (ImageView) findViewById(R.id.hero_bg_even);
        heroBg[1]     = (ImageView) findViewById(R.id.hero_bg_odd);
        heroPager     = (RecyclerView) findViewById(R.id.hero_pager);
        heroIndicator = (SegmentedIndicator) findViewById(R.id.hero_indicator);
        heroLoading   = findViewById(R.id.hero_loading);
        heroError     = findViewById(R.id.hero_error);
        heroDim       = findViewById(R.id.hero_dim);
        navbarBg      = findViewById(R.id.navbar_bg);
        navbarScrim   = findViewById(R.id.navbar_scrim);
        mainLoading = (ProgressBar) findViewById(R.id.main_loading);
        searchBar   = (LinearLayout)findViewById(R.id.search_bar);
        searchInput = (EditText)    findViewById(R.id.search_input);
        mainScroll  = (ScrollView)  findViewById(R.id.main_scroll);
        offlineBanner = findViewById(R.id.offline_banner);
        topNavbar   = findViewById(R.id.top_navbar);

        btnHome     = (LinearLayout) findViewById(R.id.bnav_home);
        btnMovies   = (LinearLayout) findViewById(R.id.bnav_movies);
        btnSeries   = (LinearLayout) findViewById(R.id.bnav_series);
        btnAnime    = (LinearLayout) findViewById(R.id.bnav_anime);
        btnSettings = (LinearLayout) findViewById(R.id.bnav_settings);
    }

    // ══════════════════════════════════════════════════════════════
    // Bebas Neue Font
    // ══════════════════════════════════════════════════════════════
    private void loadBebasNeue() {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            try {
                android.graphics.Typeface tf = getResources().getFont(R.font.bebas_neue);
                if (tf != null) {
                    bebasTypeface = tf;
                    applyBebasToHero();
                    return;
                }
            } catch (Exception ignored) {}
        }
        // Fallback: استخدام androidx FontsContractCompat
        androidx.core.provider.FontRequest req = new androidx.core.provider.FontRequest(
            "com.google.android.gms.fonts",
            "com.google.android.gms",
            "Bebas Neue",
            R.array.com_google_android_gms_fonts_certs
        );
        androidx.core.provider.FontsContractCompat.FontRequestCallback cb =
            new androidx.core.provider.FontsContractCompat.FontRequestCallback() {
                @Override
                public void onTypefaceRetrieved(android.graphics.Typeface tf) {
                    bebasTypeface = tf;
                    runOnUiThread(() -> applyBebasToHero());
                }
                @Override public void onTypefaceRequestFailed(int reason) {}
            };
        androidx.core.provider.FontsContractCompat.requestFont(
            this, req, cb, new android.os.Handler());
    }

    private void applyBebasToHero() {
        if (heroAdapter != null && bebasTypeface != null)
            heroAdapter.setDisplayTypeface(bebasTypeface);
    }

    // ══════════════════════════════════════════════════════════════
    // Top Bar
    // ══════════════════════════════════════════════════════════════
    private void setupTopBar() {
        applyAvatarToNav();
        FrameLayout searchIcon = (FrameLayout) findViewById(R.id.nav_search_icon);
        if (searchIcon != null) searchIcon.setOnClickListener(v -> {
            Intent searchIntent = new Intent(MainActivity.this, SearchActivity.class);
            startActivity(searchIntent);
            overridePendingTransition(R.anim.fade_in_fast, 0);
        });
        if (navAvatar != null) navAvatar.setOnClickListener(v -> {
            navAvatar.animate().cancel();
            navAvatar.animate().scaleX(0.88f).scaleY(0.88f).setDuration(80)
                .setInterpolator(ACCEL_2)
                .withEndAction(() -> {
                    navAvatar.animate().scaleX(1f).scaleY(1f).setDuration(160)
                        .setInterpolator(OVERSHOOT_18).start();
                    startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                    overridePendingTransition(R.anim.enter_from_right, R.anim.exit_to_left);
                }).start();
        });
    }

    private void applyAvatarToNav() {
        if (navAvatar == null) return;
        String uri = session.getAvatarUri();
        if (uri != null && (uri.startsWith("http://") || uri.startsWith("https://"))) {
            // صورة Google — تحميل في الخلفية
            new Thread(() -> {
                Bitmap bmp = loadCurrentAvatarBitmap(96);
                if (bmp != null) {
                    Bitmap circular = makeCircular(bmp);
                    runOnUiThread(() -> { if (navAvatar != null) navAvatar.setImageBitmap(circular); });
                }
            }).start();
        } else {
            Bitmap bmp = loadCurrentAvatarBitmap(96);
            if (bmp != null) navAvatar.setImageBitmap(makeCircular(bmp));
        }
    }

    private Bitmap loadCurrentAvatarBitmap(int size) {
        String uri = session.getAvatarUri();
        if (uri != null && !uri.isEmpty()) {
            try {
                Bitmap raw;
                if (uri.startsWith("http://") || uri.startsWith("https://")) {
                    // صورة Google (URL) — يُحمَّل في الخلفية
                    raw = loadBitmapFromUrl(uri);
                } else if (uri.startsWith("/")) {
                    // ملف محلي
                    raw = BitmapFactory.decodeFile(uri);
                } else {
                    // content:// URI
                    InputStream is = getContentResolver()
                        .openInputStream(android.net.Uri.parse(uri));
                    raw = BitmapFactory.decodeStream(is);
                }
                if (raw != null) return Bitmap.createScaledBitmap(raw, size, size, true);
            } catch (Exception e) { /* fallthrough */ }
        }
        return RegisterActivity.makeAvatarBitmap(session.getAvatarIndex(), size);
    }

    private Bitmap loadBitmapFromUrl(String url) {
        try {
            java.net.HttpURLConnection conn =
                (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(8000);
            conn.setDoInput(true);
            conn.connect();
            InputStream is = conn.getInputStream();
            return BitmapFactory.decodeStream(is);
        } catch (Exception e) {
            return null;
        }
    }

    // ══════════════════════════════════════════════════════════════
    // Navbar hide / show
    // ══════════════════════════════════════════════════════════════
    private void setupNavbarScrollBehavior() {
        if (mainScroll == null || topNavbar == null) return;
        mainScrollNavListener = this::onMainScrolled;
        mainScroll.getViewTreeObserver().addOnScrollChangedListener(mainScrollNavListener);
        updateNavbarSurface();
    }

    /** مستمع تمرير واحد: إخفاء/إظهار الـ navbar + سطحه + parallax الـ Hero. */
    private void onMainScrolled() {
        if (mainScroll == null || topNavbar == null) return;
        final int scrollY = mainScroll.getScrollY();
        if (scrollY == lastScrollY) return;     // الـ listener يُستدعى أيضًا عند تمرير الصفوف الأفقية
        final int dy = scrollY - lastScrollY;
        lastScrollY = scrollY;

        if (dy > 20 && navbarVisible && scrollY > 80) {
            navbarVisible = false;
            topNavbar.animate().cancel();
            topNavbar.animate()
                .translationY(-topNavbar.getHeight()).alpha(0f)
                .setDuration(200).setInterpolator(ACCEL_2).start();
        } else if ((dy < -14 || scrollY <= 0) && !navbarVisible) {
            navbarVisible = true;
            topNavbar.animate().cancel();
            topNavbar.animate()
                .translationY(0f).alpha(1f)
                .setDuration(280).setInterpolator(DECEL_25).start();
        }

        if (heroSection != null && heroSection.getVisibility() == View.VISIBLE) applyHeroScrollEffects(scrollY);
        updateNavbarSurface();
    }

    // ══════════════════════════════════════════════════════════════
    // Bottom Navigation
    // ══════════════════════════════════════════════════════════════
    private void setupBottomNav() {
        if (btnHome     != null) btnHome.setOnClickListener(v -> { int o = currentTabIndex; currentTabIndex = 0; navigateToTab(0, o); });
        if (btnMovies   != null) btnMovies.setOnClickListener(v -> { int o = currentTabIndex; currentTabIndex = 1; navigateToTab(1, o); });
        if (btnSeries   != null) btnSeries.setOnClickListener(v -> { int o = currentTabIndex; currentTabIndex = 2; navigateToTab(2, o); });
        if (btnAnime    != null) btnAnime.setOnClickListener(v -> { int o = currentTabIndex; currentTabIndex = 3; navigateToTab(3, o); });
        if (btnSettings != null) btnSettings.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            overridePendingTransition(R.anim.enter_from_right, R.anim.exit_to_left);
        });
    }

    private void highlightBnav(LinearLayout active) {
        LinearLayout[] all    = { btnHome, btnMovies, btnSeries, btnAnime, btnSettings };
        int[]          dotIds = { R.id.bnav_home_dot, R.id.bnav_movies_dot,
                                   R.id.bnav_series_dot, R.id.bnav_anime_dot, R.id.bnav_settings_dot };
        for (int i = 0; i < all.length; i++) {
            LinearLayout ll = all[i];
            if (ll == null) continue;
            boolean isActive = (ll == active);
            View dot = findViewById(dotIds[i]);
            if (dot != null) {
                if (isActive) {
                    dot.setVisibility(View.VISIBLE);
                    dot.setAlpha(0f); dot.setScaleX(0.2f); dot.setScaleY(0.2f);
                    dot.animate().cancel();
                    dot.animate().alpha(1f).scaleX(1f).scaleY(1f)
                        .setDuration(260).setInterpolator(OVERSHOOT_28).start();
                } else {
                    dot.animate().cancel();
                    dot.animate().alpha(0f).scaleX(0.2f).scaleY(0.2f)
                        .setDuration(120).withEndAction(() -> dot.setVisibility(View.GONE)).start();
                }
            }
            if (ll.getChildCount() >= 3) {
                View iv = ll.getChildAt(1);
                View tv = ll.getChildAt(2);
                int  c  = isActive ? 0xFF9B6FC4 : 0xFF7A7A92;
                if (iv instanceof ImageView) ((ImageView) iv).setColorFilter(c);
                if (tv instanceof TextView)  ((TextView)  tv).setTextColor(c);
            }
            if (isActive) {
                ll.animate().cancel();
                ll.animate().alpha(1f).setDuration(180).setInterpolator(DECEL_2).start();
            }
        }
    }

    // ══════════════════════════════════════════════════════════════
    // See All Buttons
    // ══════════════════════════════════════════════════════════════
    private void setupSeeAllButtons() {
        bindSeeAll(R.id.see_all_trending,    0, "trending", "all",         null,    0);
        bindSeeAll(R.id.see_all_nowplaying,  1, "movie",    "now_playing", null,    1);
        bindSeeAll(R.id.see_all_toprated,    1, "movie",    "top_rated",   null,    1);
        bindSeeAll(R.id.see_all_new,         1, "movie",    "upcoming",    null,    1);
        bindSeeAll(R.id.see_all_anime,       3, "anime",    "popular",     null,    3);
        bindSeeAll(R.id.see_all_action,      1, "movie",    "popular",     "28",    1);
        bindSeeAll(R.id.see_all_drama,       2, "tv",       "popular",     "18",    2);
        bindSeeAll(R.id.see_all_scifi,       1, "movie",    "popular",     "878",   1);
        bindSeeAll(R.id.see_all_horror,      1, "movie",    "popular",     "27",    1);
        bindSeeAll(R.id.see_all_comedy,      1, "movie",    "popular",     "35",    1);
        bindSeeAll(R.id.see_all_romance,     1, "movie",    "popular",     "10749", 1);
        bindSeeAll(R.id.see_all_adventure,   1, "movie",    "popular",     "12",    1);
        bindSeeAll(R.id.see_all_thriller,    1, "movie",    "popular",     "53",    1);
        bindSeeAll(R.id.see_all_documentary, 1, "movie",    "popular",     "99",    1);
        bindSeeAll(R.id.see_all_family,      1, "movie",    "popular",     "10751", 1);
        bindSeeAll(R.id.see_all_asian,       2, "tv",       "popular",     "10759", 2);
        bindSeeAll(R.id.see_all_history,     1, "movie",    "popular",     "36",    1);
    }

    private void bindSeeAll(int viewId, final int tabIndex, final String mediaType,
                             final String listType, final String genre, final int bnavIndex) {
        View btn = findViewById(viewId);
        if (btn == null) return;
        UiMotion.pressSubtle(btn);
        btn.setOnClickListener(v -> {
            toggleSearch(false);
            currentTabIndex = tabIndex;
            switch (tabIndex) {
                case 1: highlightBnav(btnMovies); break;
                case 2: highlightBnav(btnSeries); break;
                case 3: highlightBnav(btnAnime);  break;
                default: highlightBnav(btnHome);  break;
            }
            openCategoryFull(mediaType, listType, genre);
        });
    }

    // ══════════════════════════════════════════════════════════════
    // Category
    // ══════════════════════════════════════════════════════════════
    private void openCategoryFull(String mediaType, String listType, String genre) {
        toggleSearch(false);
        isShowingCategory = true;
        showHomeContent(false);
        if (searchResultsGrid != null) searchResultsGrid.removeAllViews();
        if (searchResultsSection != null) {
            searchResultsSection.setAlpha(0f);
            searchResultsSection.setTranslationY(20f);
            searchResultsSection.setScaleX(0.97f);
            searchResultsSection.setVisibility(View.VISIBLE);
            searchResultsSection.animate().cancel();
            searchResultsSection.animate()
                .alpha(1f).translationY(0f).scaleX(1f)
                .setDuration(300).setStartDelay(40).setInterpolator(DECEL_25).start();
        }
        if (mainLoading != null) mainLoading.setVisibility(View.VISIBLE);
        currentCategoryMediaType = mediaType;
        currentCategoryListType  = listType;
        currentCategoryGenre     = genre;
        currentCategoryPage      = 1;
        categoryHasMore          = true;
        categoryLoadingMore      = false;
        new CategoryTask(this).execute(mediaType, listType, genre != null ? genre : "null", "1");
    }

    // ══════════════════════════════════════════════════════════════
    // Search
    // ══════════════════════════════════════════════════════════════
    private void setupSearch() {
        if (searchInput != null) {
            searchInput.setOnEditorActionListener((v, actionId, event) -> {
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    String q = searchInput.getText().toString().trim();
                    if (!q.isEmpty()) doSearch(q);
                    hideKeyboard();
                    return true;
                }
                return false;
            });
        }
        FrameLayout searchClose = (FrameLayout) findViewById(R.id.search_close);
        if (searchClose != null) searchClose.setOnClickListener(v -> {
            toggleSearch(false);
            if (!isShowingCategory) showHomeContent(true);
        });
    }

    private void toggleSearch(boolean show) {
        if (searchBar == null) return;
        if (show) {
            searchBar.setVisibility(View.VISIBLE);
            searchBar.setAlpha(0f);
            searchBar.setTranslationY(-22f);
            searchBar.setScaleX(0.97f);
            searchBar.setScaleY(0.94f);
            searchBar.animate().cancel();
            searchBar.animate()
                .alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setDuration(260).setInterpolator(DECEL_25).start();
            if (searchInput != null) {
                searchInput.requestFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT);
            }
        } else {
            searchBar.animate().cancel();
            searchBar.animate()
                .alpha(0f).translationY(-14f).scaleY(0.94f)
                .setDuration(160).setInterpolator(ACCEL_2)
                .withEndAction(() -> {
                    searchBar.setVisibility(View.GONE);
                    searchBar.setScaleY(1f);
                    searchBar.setTranslationY(0f);
                }).start();
        }
    }

    // ══════════════════════════════════════════════════════════════
    // showHomeContent — إظهار/إخفاء أقسام الـ Home (بدون stagger؛ الأقسام لها skeleton خاص)
    // ══════════════════════════════════════════════════════════════
    private void showHomeContent(boolean show) {
        if (searchResultsSection != null)
            searchResultsSection.setVisibility(show ? View.GONE : View.VISIBLE);
        int[] sectionIds = {
            R.id.hero_section,        R.id.section_trending,    R.id.section_new,
            R.id.section_action,      R.id.section_drama,       R.id.section_scifi,
            R.id.section_horror,      R.id.section_comedy,      R.id.section_asian,
            R.id.section_anime,       R.id.section_nowplaying,  R.id.section_toprated,
            R.id.section_documentary, R.id.section_romance,     R.id.section_adventure,
            R.id.section_thriller,    R.id.section_family,      R.id.section_history
        };
        for (int id : sectionIds) {
            View v = findViewById(id);
            if (v == null) continue;
            v.animate().cancel();
            v.setVisibility(show ? View.VISIBLE : View.GONE);
            v.setAlpha(1f); v.setTranslationY(0f); v.setScaleX(1f);
        }
        if (show) {
            heroOffscreen = false;
            if (heroContent != null) heroContent.setTranslationY(0f);
            if (heroDim != null) heroDim.setAlpha(0f);
        }
        updateNavbarSurface();
        scheduleHero();
    }

    private void doSearch(String query) {
        isShowingCategory = false;
        showHomeContent(false);
        if (searchResultsGrid != null) searchResultsGrid.removeAllViews();
        if (searchResultsSection != null) searchResultsSection.setVisibility(View.VISIBLE);
        if (mainLoading != null) mainLoading.setVisibility(View.VISIBLE);
        currentSearchQuery = query;
        currentSearchPage  = 1;
        searchHasMore      = true;
        new SearchTask(this).execute(query, "1");
    }

    // ══════════════════════════════════════════════════════════════
    // Internet check
    // ══════════════════════════════════════════════════════════════
    private void checkConnectionAndLoad() {
        if (!NetworkUtil.hasInternet(this)) {
            if (offlineBanner != null) offlineBanner.setVisibility(View.VISIBLE);
            new AlertDialog.Builder(this)
                .setTitle(R.string.dlg_no_internet_title)
                .setMessage(R.string.dlg_no_internet_msg)
                .setCancelable(false)
                .setPositiveButton(R.string.state_retry, (d, w) -> { d.dismiss(); checkConnectionAndLoad(); })
                .show();
            return;
        }
        if (NetworkUtil.isVpnActive(this)) {
            new AlertDialog.Builder(this)
                .setTitle(R.string.dlg_vpn_title)
                .setMessage(R.string.dlg_vpn_msg)
                .setPositiveButton(R.string.dlg_continue, (d, w) -> {
                    d.dismiss();
                    if (offlineBanner != null) offlineBanner.setVisibility(View.GONE);
                    loadAllContent();
                })
                .setNegativeButton(R.string.dialog_cancel, (d, w) -> { d.dismiss(); finish(); })
                .show();
            return;
        }
        if (offlineBanner != null) offlineBanner.setVisibility(View.GONE);
        loadAllContent();
    }

    // ══════════════════════════════════════════════════════════════
    // loadAllContent
    // ══════════════════════════════════════════════════════════════
    private void loadAllContent() {
        startRow(rowTrending,    "trending", "all",         null,    true);
        startRow(rowNowPlaying,  "movie",    "now_playing", null,    false);
        startRow(rowTopRated,    "movie",    "top_rated",   null,    false);
        startRow(rowNew,         "movie",    "upcoming",    null,    false);
        startRow(rowAnime,       "anime",    "popular",     null,    false);
        startRow(rowAction,      "movie",    "popular",     "28",    false);
        startRow(rowDocumentary, "movie",    "popular",     "99",    false);
        startRow(rowDrama,       "tv",       "popular",     "18",    false);
        startRow(rowRomance,     "movie",    "popular",     "10749", false);
        startRow(rowAdventure,   "movie",    "popular",     "12",    false);
        startRow(rowScifi,       "movie",    "popular",     "878",   false);
        startRow(rowThriller,    "movie",    "popular",     "53",    false);
        startRow(rowHorror,      "movie",    "popular",     "27",    false);
        startRow(rowComedy,      "movie",    "popular",     "35",    false);
        startRow(rowFamily,      "movie",    "popular",     "10751", false);
        startRow(rowAsian,       "asian",    "popular",     null,    false);
        startRow(rowHistory,     "movie",    "popular",     "36",    false);
    }

    private void startRow(LinearLayout row, String mediaType, String listType,
                          String genre, boolean isHero) {
        if (row == null) return;
        RowState st = new RowState();
        st.mediaType = mediaType; st.listType = listType; st.genre = genre;
        rowStates.put(row.getId(), st);
        showRowSkeleton(row);
        if (isHero) showHeroState(HERO_LOADING);
        new ContentLoader(this).execute(
            mediaType, listType, "1",
            genre != null ? genre : "null",
            String.valueOf(row.getId()),
            isHero ? "1" : "0", "1");
    }

    // ══════════════════════════════════════════════════════════════
    // ContentLoader
    // ══════════════════════════════════════════════════════════════
    private static class ContentLoader extends AsyncTask<String, Void, JSONArray> {
        private final WeakReference<MainActivity> actRef;
        private String  mediaType, listType, genre;
        private int     page, rowId;
        private boolean isHero, replace;

        ContentLoader(MainActivity act) { actRef = new WeakReference<>(act); }

        @Override
        protected JSONArray doInBackground(String... p) {
            MainActivity act = actRef.get();
            if (act == null || act.isFinishing()) return null;
            try {
                mediaType = p[0]; listType = p[1];
                page      = Integer.parseInt(p[2]);
                genre     = "null".equals(p[3]) ? null : p[3];
                rowId     = Integer.parseInt(p[4]);
                isHero    = "1".equals(p[5]);
                replace   = "1".equals(p[6]);
                JSONObject root = act.fetchJson(act.buildUrl(mediaType, listType, genre, page));
                if (root == null) return null;
                JSONArray results = root.optJSONArray("results");
                if (results == null) return null;
                // "anime" تبقى "anime" — لا تُحوَّل لـ "tv"
                String mt = "trending".equals(mediaType) ? "movie" : mediaType;
                JSONArray out = new JSONArray();
                for (int i = 0; i < results.length(); i++) {
                    JSONObject item = results.getJSONObject(i);
                    if (!item.has("media_type")) item.put("media_type", mt);
                    // اجبر media_type على "anime" لكل بطاقة من قسم الأنمي
                    if ("anime".equals(mediaType)) item.put("media_type", "anime");
                    // trending/all يحتوي أشخاصًا (person) بلا بوستر — لا مكان لهم بين بطاقات الأفلام
                    if ("trending".equals(mediaType) && "person".equals(item.optString("media_type"))) continue;
                    out.put(item);
                }
                return out;
            } catch (Exception e) { return null; }
        }

        @Override
        protected void onPostExecute(JSONArray results) {
            MainActivity act = actRef.get();
            if (act == null || act.isFinishing()) return;
            if (act.mainLoading != null) act.mainLoading.setVisibility(View.GONE);
            RowState st = act.rowStates.get(rowId);
            if (st != null) st.loading = false;
            if (results == null || results.length() == 0) {
                if (st != null) st.done = true;
                if (isHero && act.heroItems.isEmpty()) act.showHeroState(HERO_ERROR);
                if (replace) {
                    LinearLayout failedRow = act.findViewById(rowId);
                    if (failedRow != null) act.showRowState(failedRow, results == null);
                }
                return;
            }
            if (isHero && act.heroItems.isEmpty()) act.setHeroItems(results);
            LinearLayout targetRow = act.findViewById(rowId);
            if (targetRow == null) return;

            ViewGroup par = (ViewGroup) targetRow.getParent();
            final CinematicScrollView csv =
                (par instanceof CinematicScrollView) ? (CinematicScrollView) par : null;

            if (replace) {
                targetRow.removeAllViews();
                final Integer rowToken = Integer.valueOf(rowId);
                act.batchHandler.removeCallbacksAndMessages(rowToken);
                final int       total     = results.length();
                final int       batchSize = 4;
                final JSONArray res       = results;
                final LinearLayout row    = targetRow;
                final long baseTime = android.os.SystemClock.uptimeMillis();
                for (int batch = 0; batch * batchSize < total; batch++) {
                    final int start = batch * batchSize;
                    final int end   = Math.min(start + batchSize, total);
                    act.batchHandler.postAtTime(() -> {
                        MainActivity a = actRef.get();
                        if (a == null || a.isFinishing()) return;
                        for (int i = start; i < end; i++) {
                            try { row.addView(a.buildPosterCard(res.getJSONObject(i))); }
                            catch (Exception ignored) {}
                        }
                    }, rowToken, baseTime + batch * 40L);
                }
                targetRow.setAlpha(0f);
                targetRow.animate()
                    .alpha(1f).setDuration(320).setStartDelay(20)
                    .setInterpolator(DECEL_2)
                    .withEndAction(() -> { if (csv != null) csv.refreshFocus(); })
                    .start();
            } else {
                final int savedScrollX = csv != null ? csv.getScrollX() : 0;
                for (int i = 0; i < results.length(); i++) {
                    try { targetRow.addView(act.buildPosterCard(results.getJSONObject(i))); }
                    catch (Exception ignored) {}
                }
                if (csv != null && savedScrollX > 0) csv.post(() -> csv.scrollTo(savedScrollX, 0));
                if (csv != null) csv.refreshFocus();
            }
        }
    }

    // ══════════════════════════════════════════════════════════════
    // CategoryTask
    // ══════════════════════════════════════════════════════════════
    private static class CategoryTask extends AsyncTask<String, Void, JSONArray> {
        private final WeakReference<MainActivity> actRef;
        private int page;
        CategoryTask(MainActivity act) { actRef = new WeakReference<>(act); }

        @Override
        protected JSONArray doInBackground(String... p) {
            MainActivity act = actRef.get();
            if (act == null || act.isFinishing()) return null;
            try {
                String mt    = p[0], lt = p[1];
                String genre = "null".equals(p[2]) ? null : p[2];
                page         = Integer.parseInt(p[3]);
                JSONObject root = act.fetchJson(act.buildUrl(mt, lt, genre, page));
                if (root == null) return null;
                JSONArray results = root.optJSONArray("results");
                if (results == null) return null;
                // "anime" تبقى "anime" — لا تُحوَّل لـ "tv"
                String attr = "trending".equals(mt) ? "movie" : mt;
                for (int i = 0; i < results.length(); i++) {
                    JSONObject item = results.getJSONObject(i);
                    if (!item.has("media_type")) item.put("media_type", attr);
                    if ("anime".equals(mt)) item.put("media_type", "anime");
                }
                return results;
            } catch (Exception e) { return null; }
        }

        @Override
        protected void onPostExecute(JSONArray results) {
            MainActivity act = actRef.get();
            if (act == null || act.isFinishing()) return;
            if (act.mainLoading != null) act.mainLoading.setVisibility(View.GONE);
            act.categoryLoadingMore = false;
            if (results == null || results.length() == 0) {
                act.categoryHasMore = false;
                if (page <= 1) {
                    act.showGridState(results == null, () -> act.openCategoryFull(
                        act.currentCategoryMediaType, act.currentCategoryListType, act.currentCategoryGenre));
                }
                return;
            }
            if (act.searchResultsGrid != null) {
                act.addToGrid(results);
                if (act.searchResultsSection != null)
                    act.searchResultsSection.setVisibility(View.VISIBLE);
                if (page == 1) {
                    act.searchResultsGrid.setAlpha(0f);
                    act.searchResultsGrid.animate().alpha(1f).setDuration(320)
                        .setInterpolator(DECEL_2).start();
                }
            }
        }
    }

    // ══════════════════════════════════════════════════════════════
    // SearchTask
    // ══════════════════════════════════════════════════════════════
    private static class SearchTask extends AsyncTask<String, Void, JSONArray> {
        private final WeakReference<MainActivity> actRef;
        private int page;
        SearchTask(MainActivity act) { actRef = new WeakReference<>(act); }

        @Override
        protected JSONArray doInBackground(String... p) {
            MainActivity act = actRef.get();
            if (act == null || act.isFinishing()) return null;
            try {
                String enc = java.net.URLEncoder.encode(p[0], "UTF-8");
                page = Integer.parseInt(p[1]);
                final JSONArray[] mv = {null}, tv = {null};
                Thread t1 = new Thread(() -> {
                    try {
                        JSONObject r = act.fetchJson("https://api.themoviedb.org/3/search/movie?query="
                            + enc + "&language=en-US&page=" + page);
                        if (r != null) mv[0] = r.optJSONArray("results");
                    } catch (Exception ignored) {}
                });
                Thread t2 = new Thread(() -> {
                    try {
                        JSONObject r = act.fetchJson("https://api.themoviedb.org/3/search/tv?query="
                            + enc + "&language=en-US&page=" + page);
                        if (r != null) tv[0] = r.optJSONArray("results");
                    } catch (Exception ignored) {}
                });
                t1.start(); t2.start(); t1.join(); t2.join();
                JSONArray combined = new JSONArray();
                if (mv[0] != null) for (int i = 0; i < mv[0].length(); i++) {
                    mv[0].getJSONObject(i).put("media_type", "movie");
                    combined.put(mv[0].getJSONObject(i));
                }
                if (tv[0] != null) for (int i = 0; i < tv[0].length(); i++) {
                    tv[0].getJSONObject(i).put("media_type", "tv");
                    combined.put(tv[0].getJSONObject(i));
                }
                return combined;
            } catch (Exception e) { return null; }
        }

        @Override
        protected void onPostExecute(JSONArray results) {
            MainActivity act = actRef.get();
            if (act == null || act.isFinishing()) return;
            if (act.mainLoading != null) act.mainLoading.setVisibility(View.GONE);
            act.searchLoadingMore = false;
            if (results == null || results.length() == 0) {
                act.searchHasMore = false;
                if (page <= 1) {
                    act.showGridState(results == null, () -> {
                        if (act.currentSearchQuery != null) act.doSearch(act.currentSearchQuery);
                    });
                }
                return;
            }
            if (act.searchResultsGrid != null) {
                act.addToGrid(results);
                if (act.searchResultsSection != null)
                    act.searchResultsSection.setVisibility(View.VISIBLE);
                if (page == 1) {
                    act.searchResultsGrid.setAlpha(0f);
                    act.searchResultsGrid.animate().alpha(1f).setDuration(320)
                        .setInterpolator(DECEL_2).start();
                }
            }
        }
    }

    // ══════════════════════════════════════════════════════════════
    // URL Builder
    // ══════════════════════════════════════════════════════════════
    private String buildUrl(String mediaType, String listType, String genre, int page) {
        if ("trending".equals(mediaType))
            return "https://api.themoviedb.org/3/trending/all/week?language=en-US&page=" + page;
        if ("anime".equals(mediaType))
            return "https://api.themoviedb.org/3/discover/tv?language=en-US&with_genres=16"
                 + "&with_original_language=ja&sort_by=popularity.desc&page=" + page;
        if ("asian".equals(mediaType))
            return "https://api.themoviedb.org/3/discover/tv?language=en-US"
                 + "&with_original_language=ko|zh&sort_by=popularity.desc&page=" + page;
        if (genre != null && !genre.isEmpty())
            return "https://api.themoviedb.org/3/discover/" + mediaType
                 + "?language=en-US&with_genres=" + genre + "&sort_by=popularity.desc&page=" + page;
        return "https://api.themoviedb.org/3/" + mediaType + "/" + listType
             + "?language=en-US&page=" + page;
    }

    // ══════════════════════════════════════════════════════════════
    // Hero — carousel
    //   • الخلفية: طبقتان (even/odd) بينهما crossfade مستمر مرتبط بموضع السحب
    //   • الواجهة الأمامية (glass): RecyclerView + PagerSnapHelper مع parallax وخفوت خفيف
    //   • المؤشر: SegmentedIndicator = الوقت المتبقي للشريحة التالية
    // ══════════════════════════════════════════════════════════════
    private static final int  HERO_LOADING = 0, HERO_READY = 1, HERO_ERROR = 2;
    private static final int  HERO_MAX = 5;
    private static final long HERO_INTERVAL = 7000L;

    private void setupHero() {
        if (heroSection == null || heroPager == null) return;
        reducedMotion = isMotionReduced();

        // ارتفاع متجاوب: ~66% من الشاشة بين 440dp و 600dp (لا أرقام ثابتة)
        final int screenH = getResources().getDisplayMetrics().heightPixels;
        heroHeightPx = Math.round(Math.max(dpToPx(440), Math.min(dpToPx(600), screenH * 0.66f)));
        ViewGroup.LayoutParams lp = heroSection.getLayoutParams();
        lp.height = heroHeightPx;
        heroSection.setLayoutParams(lp);

        heroAdapter = new HeroPagerAdapter(new HeroPagerAdapter.HeroActionListener() {
            @Override public void onPlay(JSONObject item) {
                openPlayer(String.valueOf(item.optInt("id")),
                           item.optString("media_type", "movie"), "", 1, false, 1, 1);
            }
            @Override public void onInfo(JSONObject item) { openDetail(item); }
        });
        heroLm = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        heroPager.setLayoutManager(heroLm);
        heroPager.setAdapter(heroAdapter);
        heroPager.setItemAnimator(null);
        heroPager.setHasFixedSize(true);
        heroSnap = new PagerSnapHelper();
        heroSnap.attachToRecyclerView(heroPager);

        heroPager.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override public void onScrolled(RecyclerView rv, int dx, int dy) { onHeroScrolled(); }
            @Override public void onScrollStateChanged(RecyclerView rv, int state) {
                if (state == RecyclerView.SCROLL_STATE_DRAGGING) {
                    heroHandler.removeCallbacks(heroTick);
                    if (heroIndicator != null) heroIndicator.pause();
                } else if (state == RecyclerView.SCROLL_STATE_IDLE) {
                    settleHeroPage();
                }
            }
        });
        heroPager.addOnItemTouchListener(new RecyclerView.SimpleOnItemTouchListener() {
            @Override public boolean onInterceptTouchEvent(RecyclerView rv, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        swipeLockedInHSV = true;   // لا يتحول السحب الأفقي هنا إلى تبديل تبويب
                        heroTouching = true;
                        heroHandler.removeCallbacks(heroTick);
                        if (heroIndicator != null) heroIndicator.pause();
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        swipeLockedInHSV = false;
                        heroTouching = false;
                        scheduleHero();
                        break;
                }
                return false;
            }
        });

        if (heroIndicator != null) heroIndicator.setStaticFill(reducedMotion);
        showHeroState(HERO_LOADING);
    }

    private boolean isMotionReduced() {
        // إعداد المستخدم (Settings → Playback → تقليل الحركة) له الأولوية،
        // ثم إعداد النظام (Animator duration scale = 0)
        if (SettingsStore.isReduceMotion(this)) return true;
        try {
            return Settings.Global.getFloat(getContentResolver(),
                    Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f;
        } catch (Exception e) { return false; }
    }

    private void showHeroState(int state) {
        if (heroLoading == null) return;
        heroLoading.animate().cancel();
        if (state == HERO_LOADING) {
            heroLoading.setAlpha(1f);
            heroLoading.setVisibility(View.VISIBLE);
            Shimmer.attachTagged(heroLoading);
            if (heroError != null) heroError.setVisibility(View.GONE);
            return;
        }
        Shimmer.detachTagged(heroLoading);
        if (state == HERO_ERROR) {
            heroLoading.setVisibility(View.GONE);
            if (heroPager != null) heroPager.setVisibility(View.INVISIBLE);
            if (heroIndicator != null) heroIndicator.setVisibility(View.GONE);
            if (heroError != null) {
                bindState(heroError, R.drawable.ic_refresh, R.string.state_hero_error,
                          R.string.state_row_error_msg, this::retryHero);
                heroError.setVisibility(View.VISIBLE);
            }
        } else {
            if (heroError != null) heroError.setVisibility(View.GONE);
            heroLoading.animate().alpha(0f).setDuration(240)
                .withEndAction(() -> heroLoading.setVisibility(View.GONE)).start();
        }
    }

    private void retryHero() {
        startRow(rowTrending, "trending", "all", null, true);
    }

    /** يملأ الـ Hero من نتائج trending: أول HERO_MAX عناصر (فيلم/مسلسل) لها backdrop. */
    private void setHeroItems(JSONArray results) {
        heroItems.clear();
        for (int i = 0; i < results.length() && heroItems.size() < HERO_MAX; i++) {
            final JSONObject it = results.optJSONObject(i);
            if (it == null) continue;
            final String mt = it.optString("media_type", "movie");
            if (!"movie".equals(mt) && !"tv".equals(mt)) continue;
            if (MediaText.str(it, "backdrop_path").isEmpty()) continue;
            heroItems.add(it);
        }
        if (heroItems.isEmpty()) { showHeroState(HERO_ERROR); return; }

        heroAdapter.submitList(heroItems);
        if (bebasTypeface != null) heroAdapter.setDisplayTypeface(bebasTypeface);
        heroBgIdx[0] = -1; heroBgIdx[1] = -1;
        heroPage = 0;
        if (heroIndicator != null) {
            heroIndicator.setCount(heroItems.size());
            heroIndicator.setActive(0, false);
            heroIndicator.setStaticFill(reducedMotion);
        }
        heroPager.scrollToPosition(0);
        heroPager.setVisibility(View.VISIBLE);
        heroPager.setAlpha(0f);
        heroPager.animate().alpha(1f).setDuration(380).setInterpolator(DECEL_2).start();
        syncHeroBackdrop(0f);
        showHeroState(HERO_READY);
        scheduleHero();
    }

    // ── Backdrop crossfade ────────────────────────────────────────
    // الصفحة p تعيش دائمًا في الطبقة (p & 1): لا تبديل أدوار ولا إعادة تحميل عند السحب.
    // الطبقة الزوجية (أسفل) alpha=1 دائمًا، والفردية (أعلى) تتحكم بالـ crossfade:
    //   i زوجي: الفردية تحمل i+1 → alpha = f   |   i فردي: الفردية تحمل i → alpha = 1-f
    private void syncHeroBackdrop(float pos) {
        final int n = heroAdapter == null ? 0 : heroAdapter.getItemCount();
        if (n == 0 || heroBg[0] == null || heroBg[1] == null) return;
        int i = (int) Math.floor(pos);
        i = Math.max(0, Math.min(n - 1, i));
        final int j = Math.min(i + 1, n - 1);
        float f = (j == i) ? 0f : Math.max(0f, Math.min(1f, pos - i));
        ensureBackdrop(i);
        if (j != i) ensureBackdrop(j);
        heroBg[0].setAlpha(1f);
        heroBg[1].setAlpha((i & 1) == 0 ? f : 1f - f);
    }

    private void ensureBackdrop(int page) {
        final int slot = page & 1;
        if (heroBgIdx[slot] == page) return;
        heroBgIdx[slot] = page;
        final ImageView target = heroBg[slot];
        final JSONObject it = heroAdapter.getItem(page);
        final String path = it == null ? "" : MediaText.str(it, "backdrop_path");
        if (path.isEmpty()) {
            Glide.with(this).clear(target);
            target.setImageDrawable(null);
            return;
        }
        Glide.with(this).load(IMG_BASE_B + path).centerCrop()
            .transition(DrawableTransitionOptions.withCrossFade(260))
            .into(target);
    }

    // ── Scroll → backdrop + parallax الواجهة الأمامية + المؤشر ───────
    private void onHeroScrolled() {
        final int n = heroAdapter == null ? 0 : heroAdapter.getItemCount();
        if (n == 0 || heroLm == null) return;
        final int first = heroLm.findFirstVisibleItemPosition();
        if (first < 0) return;
        final View fv = heroLm.findViewByPosition(first);
        if (fv == null || fv.getWidth() == 0) return;
        final float w = fv.getWidth();
        final float pos = Math.max(0f, Math.min(n - 1, first + (-fv.getLeft() / w)));

        syncHeroBackdrop(pos);

        final int nearest = Math.round(pos);
        if (nearest != heroPage) {
            heroPage = nearest;
            if (heroIndicator != null) heroIndicator.setActive(nearest, true);
        }

        // الواجهة الزجاجية: تتحرك أبطأ قليلًا من الإصبع وتخفت قبل أن تغادر
        for (int k = 0; k < heroPager.getChildCount(); k++) {
            final View c = heroPager.getChildAt(k);
            final RecyclerView.ViewHolder vh = heroPager.getChildViewHolder(c);
            if (!(vh instanceof HeroPagerAdapter.VH)) continue;
            final float t = Math.min(1f, Math.abs(c.getLeft()) / w);
            final View info = ((HeroPagerAdapter.VH) vh).info;
            info.setAlpha(1f - Math.min(1f, t * 1.6f));
            info.setTranslationX(-0.18f * c.getLeft());
        }
    }

    private void settleHeroPage() {
        if (heroAdapter == null || heroAdapter.getItemCount() == 0 || heroSnap == null) return;
        final View snap = heroSnap.findSnapView(heroLm);
        if (snap != null) {
            final int p = heroLm.getPosition(snap);
            if (p != heroPage) {
                heroPage = p;
                if (heroIndicator != null) heroIndicator.setActive(p, true);
            }
        }
        scheduleHero();
    }

    // ── Autoplay ──────────────────────────────────────────────────
    private boolean heroAutoplayAllowed() {
        return heroAdapter != null && heroAdapter.getItemCount() > 1
            && activityResumed && !reducedMotion && !heroTouching && !heroOffscreen
            && heroSection != null && heroSection.getVisibility() == View.VISIBLE
            && heroPager != null && heroPager.getScrollState() == RecyclerView.SCROLL_STATE_IDLE;
    }

    private void scheduleHero() {
        heroHandler.removeCallbacks(heroTick);
        if (heroIndicator == null) return;
        if (heroAutoplayAllowed()) {
            heroIndicator.restart(HERO_INTERVAL, true);
            heroHandler.postDelayed(heroTick, HERO_INTERVAL);
        } else {
            heroIndicator.restart(HERO_INTERVAL, false);
        }
    }

    private final Runnable heroTick = new Runnable() {
        @Override public void run() {
            if (!heroAutoplayAllowed()) { scheduleHero(); return; }
            final int n = heroAdapter.getItemCount();
            final int w = heroPager.getWidth();
            if (n < 2 || w <= 0) return;
            if (heroPage < n - 1) heroPager.smoothScrollBy(w, 0, UiMotion.EMPHASIZED);
            else                  heroPager.smoothScrollBy(-w * (n - 1), 0, UiMotion.EMPHASIZED);
        }
    };

    // ── Navbar surface + Hero parallax (يُستدعى من مستمع التمرير) ──
    private void updateNavbarSurface() {
        if (navbarBg == null || navbarScrim == null) return;
        float solid = 1f;
        if (heroSection != null && heroSection.getVisibility() == View.VISIBLE && heroHeightPx > 0) {
            final float y = mainScroll != null ? mainScroll.getScrollY() : 0f;
            solid = Math.max(0f, Math.min(1f, (y - heroHeightPx * 0.45f) / (heroHeightPx * 0.40f)));
        }
        navbarBg.setAlpha(solid);
        navbarScrim.setAlpha(1f - solid);
    }

    private void applyHeroScrollEffects(int scrollY) {
        if (heroContent == null || heroDim == null || heroHeightPx <= 0) return;
        final float y = Math.max(0, scrollY);
        heroContent.setTranslationY(y * 0.30f);
        heroDim.setAlpha(Math.min(1f, y / (heroHeightPx * 0.85f)) * 0.9f);
        final boolean off = y > heroHeightPx * 0.55f;
        if (off != heroOffscreen) { heroOffscreen = off; scheduleHero(); }
    }

    // ══════════════════════════════════════════════════════════════
    // Row states: skeleton / error / empty
    // ══════════════════════════════════════════════════════════════
    private LinearLayout.LayoutParams cardParams() {
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
            dpToPx(128), LinearLayout.LayoutParams.WRAP_CONTENT);
        cp.setMargins(dpToPx(5), dpToPx(6), dpToPx(5), dpToPx(8));
        return cp;
    }

    private void showRowSkeleton(LinearLayout row) {
        row.removeAllViews();
        for (int i = 0; i < 5; i++) {
            final View sk = getLayoutInflater().inflate(R.layout.item_poster_skeleton, null);
            sk.setLayoutParams(cardParams());
            row.addView(sk);
            Shimmer.attachTagged(sk);
        }
    }

    private void showRowState(final LinearLayout row, boolean error) {
        row.removeAllViews();
        final View s = getLayoutInflater().inflate(R.layout.item_state, null);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dpToPx(300), dpToPx(190));
        lp.setMargins(dpToPx(5), dpToPx(6), dpToPx(5), dpToPx(8));
        s.setLayoutParams(lp);
        if (error) {
            bindState(s, R.drawable.ic_refresh, R.string.state_row_error,
                      R.string.state_row_error_msg, () -> retryRow(row));
        } else {
            bindState(s, R.drawable.ic_movies, R.string.state_empty_title,
                      R.string.state_empty_msg, null);
        }
        row.addView(s);
    }

    private void retryRow(LinearLayout row) {
        final RowState st = rowStates.get(row.getId());
        if (st == null) return;
        startRow(row, st.mediaType, st.listType, st.genre, row == rowTrending);
    }

    private void showGridState(boolean error, Runnable retry) {
        if (searchResultsGrid == null) return;
        searchResultsGrid.removeAllViews();
        final View s = getLayoutInflater().inflate(R.layout.item_state, searchResultsGrid, false);
        if (s.getLayoutParams() instanceof LinearLayout.LayoutParams)
            ((LinearLayout.LayoutParams) s.getLayoutParams()).topMargin = dpToPx(24);
        if (error) {
            bindState(s, R.drawable.ic_refresh, R.string.state_row_error,
                      R.string.state_row_error_msg, retry);
        } else {
            bindState(s, R.drawable.ic_movies, R.string.state_empty_title,
                      R.string.state_empty_msg, retry);
        }
        searchResultsGrid.addView(s);
        if (searchResultsSection != null) searchResultsSection.setVisibility(View.VISIBLE);
    }

    private void bindState(View s, int iconRes, int titleRes, int msgRes, final Runnable action) {
        final ImageView icon = (ImageView) s.findViewById(R.id.state_icon);
        final TextView  t    = (TextView)  s.findViewById(R.id.state_title);
        final TextView  m    = (TextView)  s.findViewById(R.id.state_msg);
        final TextView  a    = (TextView)  s.findViewById(R.id.state_action);
        if (icon != null) icon.setImageResource(iconRes);
        if (t != null) t.setText(titleRes);
        if (m != null) m.setText(msgRes);
        if (a != null) {
            if (action == null) {
                a.setVisibility(View.GONE);
            } else {
                a.setVisibility(View.VISIBLE);
                a.setText(R.string.state_retry);
                UiMotion.pressSubtle(a);
                a.setOnClickListener(v -> action.run());
            }
        }
    }

    // ══════════════════════════════════════════════════════════════
    // Poster card — Poster + depth + metadata خارج الصورة
    //   الصف الأفقي والشبكة يستخدمان نفس الـ layout (item_poster_card).
    //   الضغط على الـ poster_frame (وليس على البطاقة) لأن CinematicScrollView
    //   يملك scale البطاقة نفسها — لا تعارض ولا jitter.
    // ══════════════════════════════════════════════════════════════
    private View buildPosterCard(final JSONObject item) {
        final View card = getLayoutInflater().inflate(R.layout.item_poster_card, null);
        card.setLayoutParams(cardParams());
        bindPosterCard(card, item);
        return card;
    }

    private void bindPosterCard(final View card, final JSONObject item) {
        final AspectFrameLayout frame = (AspectFrameLayout) card.findViewById(R.id.poster_frame);
        final View      skeleton   = card.findViewById(R.id.poster_skeleton);
        final ImageView poster     = (ImageView) card.findViewById(R.id.poster_image);
        final View      fallback   = card.findViewById(R.id.poster_fallback);
        final View      ratingChip = card.findViewById(R.id.poster_rating_chip);
        final TextView  ratingTv   = (TextView) card.findViewById(R.id.poster_rating);
        final View      press      = card.findViewById(R.id.poster_press);
        final TextView  titleTv    = (TextView) card.findViewById(R.id.card_title);
        final TextView  yearTv     = (TextView) card.findViewById(R.id.card_year);

        RoundOutline.apply(frame, getResources().getDimension(R.dimen.card_radius));

        // ── Text (محاذاة حسب لغة النص نفسه) ──
        final String  title = MediaText.title(item);
        final boolean rtl   = MediaText.isRtl(title);
        titleTv.setText(title);
        MediaText.align(titleTv, rtl);
        yearTv.setText(MediaText.year(item));
        MediaText.align(yearTv, rtl);
        card.setContentDescription(title);

        // ── Rating ──
        final double rating = item.optDouble("vote_average", 0);
        if (rating > 0) {
            ratingChip.setVisibility(View.VISIBLE);
            ratingTv.setText(String.format(java.util.Locale.US, "%.1f", rating));
        }

        // ── Poster ──
        final String path = MediaText.str(item, "poster_path");
        if (path.isEmpty()) {
            skeleton.setVisibility(View.GONE);
            fallback.setVisibility(View.VISIBLE);
        } else {
            Shimmer.attach(skeleton);
            Glide.with(this).load(IMG_BASE_W + path).centerCrop()
                .transition(DrawableTransitionOptions.withCrossFade(160))
                .listener(new RequestListener<Drawable>() {
                    @Override public boolean onResourceReady(Drawable r, Object m, Target<Drawable> t,
                                                             DataSource d, boolean first) {
                        Shimmer.detach(skeleton);
                        skeleton.animate().alpha(0f).setDuration(200).start();
                        return false;
                    }
                    @Override public boolean onLoadFailed(GlideException e, Object m,
                                                          Target<Drawable> t, boolean first) {
                        Shimmer.detach(skeleton);
                        skeleton.setVisibility(View.GONE);
                        fallback.setVisibility(View.VISIBLE);
                        return false;
                    }
                }).into(poster);
        }

        // ── Press: scale صغير على الـ poster + highlight (بدون overshoot) ──
        card.setOnTouchListener((v, ev) -> {
            switch (ev.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    frame.animate().cancel();
                    frame.animate().scaleX(0.965f).scaleY(0.965f)
                        .setDuration(90).setInterpolator(DECEL_15).start();
                    press.animate().cancel();
                    press.animate().alpha(1f).setDuration(90).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    frame.animate().cancel();
                    frame.animate().scaleX(1f).scaleY(1f)
                        .setDuration(180).setInterpolator(DECEL_2).start();
                    press.animate().cancel();
                    press.animate().alpha(0f).setDuration(200).start();
                    break;
            }
            return false;
        });
        card.setOnClickListener(v -> openDetail(item));
    }

    private String getTitle(JSONObject item) {
        String t = item.optString("title","");
        if (t.isEmpty()) t = item.optString("name","");
        if (t.isEmpty()) t = item.optString("original_title","");
        if (t.isEmpty()) t = item.optString("original_name","");
        return t;
    }

    private void openDetail(JSONObject item) {
        Intent i = new Intent(this, DetailActivity.class);
        i.putExtra("item_json", item.toString());
        startActivity(i);
        overridePendingTransition(R.anim.enter_from_right, R.anim.exit_to_left);
    }

    private void openPlayer(String tmdbId, String type, String title,
                            int seasons, boolean isParty, int season, int episode) {
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra("tmdb_id", tmdbId); i.putExtra("media_type", type);
        i.putExtra("title", title);    i.putExtra("seasons", seasons);
        i.putExtra("is_party", isParty); i.putExtra("season", season);
        i.putExtra("episode", episode);
        startActivity(i);
    }

    private void addToGrid(JSONArray results) {
        if (searchResultsGrid == null) return;
        final int existing = searchResultsGrid.getChildCount();
        LinearLayout row = null;
        int inRow = 0;
        if (existing > 0) {
            final View last = searchResultsGrid.getChildAt(existing - 1);
            if (last instanceof LinearLayout) {
                final LinearLayout l = (LinearLayout) last;
                // أزل الحشوات الشفافة من الصف غير المكتمل قبل متابعة الملء
                for (int k = l.getChildCount() - 1; k >= 0; k--) {
                    if (GRID_PAD.equals(l.getChildAt(k).getTag())) l.removeViewAt(k);
                }
                if (l.getChildCount() > 0 && l.getChildCount() < 3) { row = l; inRow = l.getChildCount(); }
            }
        }
        for (int i = 0; i < results.length(); i++) {
            try {
                if (row == null || inRow >= 3) {
                    row = new LinearLayout(this);
                    row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setLayoutParams(new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                    searchResultsGrid.addView(row);
                    inRow = 0;
                }
                row.addView(buildGridCard(results.getJSONObject(i)));
                inRow++;
            } catch (Exception ignored) {}
        }
        // الصف الأخير الناقص: حشوات غير مرئية كي لا تتمدد البطاقات على عرض الصف كله
        if (row != null && row.getChildCount() > 0 && row.getChildCount() < 3) {
            for (int k = row.getChildCount(); k < 3; k++) {
                final View pad = new View(this);
                pad.setTag(GRID_PAD);
                final LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0, 1, 1f);
                pp.setMargins(dpToPx(5), 0, dpToPx(5), 0);
                pad.setLayoutParams(pp);
                row.addView(pad);
            }
        }
    }

    private View buildGridCard(final JSONObject item) {
        final View card = getLayoutInflater().inflate(R.layout.item_poster_card, null);
        final LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dpToPx(5), dpToPx(5), dpToPx(5), dpToPx(10));
        card.setLayoutParams(p);
        bindPosterCard(card, item);
        return card;
    }

    // ══════════════════════════════════════════════════════════════
    // Infinite Scroll + Carousel attachment
    // ══════════════════════════════════════════════════════════════
    private void setupInfiniteScroll() {
        if (mainScroll == null) return;
        mainScrollInfiniteListener = () -> {
            View child = mainScroll.getChildAt(0);
            if (child == null) return;
            int diff = child.getBottom() - (mainScroll.getHeight() + mainScroll.getScrollY());
            if (diff < dpToPx(400)) {
                if (!isShowingCategory && searchResultsSection != null
                        && searchResultsSection.getVisibility() == View.VISIBLE
                        && !searchLoadingMore && searchHasMore && currentSearchQuery != null) {
                    searchLoadingMore = true;
                    currentSearchPage++;
                    new SearchTask(this).execute(currentSearchQuery, String.valueOf(currentSearchPage));
                }
                if (isShowingCategory && !categoryLoadingMore && categoryHasMore
                        && currentCategoryMediaType != null) {
                    categoryLoadingMore = true;
                    currentCategoryPage++;
                    new CategoryTask(this).execute(
                        currentCategoryMediaType, currentCategoryListType,
                        currentCategoryGenre != null ? currentCategoryGenre : "null",
                        String.valueOf(currentCategoryPage));
                }
            }
        };
        mainScroll.getViewTreeObserver().addOnScrollChangedListener(mainScrollInfiniteListener);

        LinearLayout[] rows = {
            rowTrending, rowNew,       rowNowPlaying, rowTopRated,
            rowAction,   rowDrama,     rowScifi,      rowHorror,
            rowComedy,   rowAsian,     rowAnime,      rowDocumentary,
            rowRomance,  rowAdventure, rowThriller,   rowFamily, rowHistory
        };
        for (LinearLayout row : rows) attachCinematicRow(row);
    }

    private void attachCinematicRow(final LinearLayout row) {
        if (row == null) return;
        ViewGroup parent = (ViewGroup) row.getParent();
        if (!(parent instanceof CinematicScrollView)) return;
        final CinematicScrollView csv = (CinematicScrollView) parent;
        if (Boolean.TRUE.equals(csv.getTag())) return;
        csv.setTag(true);
        csv.setInnerRow(row);
        csv.setOnTouchListener((v, ev) -> {
            switch (ev.getAction()) {
                // لا نستدعي requestDisallowInterceptTouchEvent(true) عند DOWN: كان يمنع
                // الـ ScrollView من التمرير عموديًا عند بدء السحب من فوق أي صف.
                // HorizontalScrollView نفسه يطلب ذلك تلقائيًا عند بدء سحب أفقي فعلي.
                case MotionEvent.ACTION_DOWN:
                    swipeLockedInHSV = true;
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    swipeLockedInHSV = false;
                    break;
            }
            return false;
        });
        csv.setOnNearEndListener(() -> {
            RowState st = rowStates.get(row.getId());
            if (st == null || st.loading || st.done) return;
            st.loading = true;
            new ContentLoader(this).execute(
                st.mediaType, st.listType, String.valueOf(st.nextPage),
                st.genre != null ? st.genre : "null",
                String.valueOf(row.getId()), "0", "0");
            st.nextPage++;
        });
        cinemaScrollViews.put(row.getId(), csv);
    }

    // ══════════════════════════════════════════════════════════════
    // Swipe Navigation
    // ══════════════════════════════════════════════════════════════
    private void setupSwipeNavigation() {
        if (mainScroll == null) return;
        mainScroll.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        mainScroll.setOnTouchListener((v, event) -> {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    swipeTouchStartX = event.getX();
                    swipeTouchStartY = event.getY();
                    swipeDownReceived = true;
                    swipeLockedInHSV  = false;
                    break;
                case MotionEvent.ACTION_CANCEL:
                    swipeDownReceived = false;
                    swipeLockedInHSV  = false;
                    break;
                case MotionEvent.ACTION_UP:
                    if (!swipeDownReceived) break;
                    swipeDownReceived = false;
                    if (swipeLockedInHSV) { swipeLockedInHSV = false; break; }
                    float dx = event.getX() - swipeTouchStartX;
                    float dy = event.getY() - swipeTouchStartY;
                    int minD = dpToPx(SWIPE_MIN_DISTANCE), maxO = dpToPx(SWIPE_MAX_OFF_PATH);
                    if (Math.abs(dx) > minD && Math.abs(dy) < maxO) {
                        if (dx < 0) handleSwipeForward(); else handleSwipeBack();
                    }
                    break;
            }
            return false;
        });
    }

    private void handleSwipeForward() {
        if (currentTabIndex < 3) { int o = currentTabIndex; currentTabIndex++; navigateToTab(currentTabIndex, o); }
    }
    private void handleSwipeBack() {
        if (currentTabIndex > 0) { int o = currentTabIndex; currentTabIndex--; navigateToTab(currentTabIndex, o); }
    }

    private void navigateToTab(int index) { navigateToTab(index, index); }

    private void navigateToTab(int index, int oldIndex) {
        if (mainScroll != null && oldIndex >= 0 && oldIndex < tabScrollY.length && oldIndex != index)
            tabScrollY[oldIndex] = mainScroll.getScrollY();
        toggleSearch(false);
        if (mainScroll != null && oldIndex != index) {
            mainScroll.animate().cancel();
            mainScroll.animate()
                .alpha(0f).translationY(-10f)
                .setDuration(120).setInterpolator(ACCEL_2)
                .withEndAction(() -> {
                    performTabSwitch(index, oldIndex);
                    mainScroll.setTranslationY(16f);
                    mainScroll.animate().cancel();
                    mainScroll.animate()
                        .alpha(1f).translationY(0f)
                        .setDuration(280).setStartDelay(15).setInterpolator(DECEL_25).start();
                }).start();
        } else {
            if (mainScroll != null) { mainScroll.setAlpha(1f); mainScroll.setTranslationY(0f); }
            performTabSwitch(index, oldIndex);
        }
        final int saved = (index >= 0 && index < tabScrollY.length) ? tabScrollY[index] : 0;
        if (mainScroll != null && saved > 0) mainScroll.post(() -> mainScroll.scrollTo(0, saved));
    }

    private void performTabSwitch(int index, int oldIndex) {
        switch (index) {
            case 0: highlightBnav(btnHome); isShowingCategory = false; showHomeContent(true); break;
            case 1: highlightBnav(btnMovies); openCategoryFull("movie", "popular", null); break;
            case 2: highlightBnav(btnSeries); openCategoryFull("tv",    "popular", null); break;
            case 3: highlightBnav(btnAnime);  openCategoryFull("anime", "popular", null); break;
        }
    }

    // ══════════════════════════════════════════════════════════════
    // Network / Utils
    // ══════════════════════════════════════════════════════════════
    private JSONObject fetchJson(String urlStr) throws Exception {
        JSONObject cached = TmdbCache.getJson(urlStr);
        if (cached != null) {
            DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, 200, 0, null, cached.toString(), null, true);
            return cached;
        }
        long diagnosticStart = android.os.SystemClock.elapsedRealtime();
        int diagnosticStatus = -1;
        String diagnosticBody = null;
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlStr);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            TmdbAuthorization.apply(conn, TMDB_TOKEN);
            DiagnosticsRecorder.headers("TMDB", "fetch_json", "GET", urlStr, conn.getRequestProperties());
            conn.setRequestProperty("accept", "application/json");
            diagnosticStatus = conn.getResponseCode();
            if (diagnosticStatus != 200) {
                DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, diagnosticStatus,
                        android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, null, null, false);
                return null;
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close();
            diagnosticBody = sb.toString();
            DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, diagnosticStatus,
                    android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, diagnosticBody, null, false);
            JSONObject obj = new JSONObject(diagnosticBody);
            TmdbCache.putJson(urlStr, obj);
            return obj;
        } catch (Exception e) {
            DiagnosticsRecorder.network("TMDB", "fetch_json", "GET", urlStr, diagnosticStatus,
                    android.os.SystemClock.elapsedRealtime() - diagnosticStart, null, diagnosticBody, e, false);
            throw e;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private int dpToPx(int dp) { return (int)(dp * screenDensity); }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        View focus = getCurrentFocus();
        if (imm != null && focus != null) imm.hideSoftInputFromWindow(focus.getWindowToken(), 0);
    }

    public static Bitmap makeCircular(Bitmap src) {
        if (src == null) return null;
        int size = Math.min(src.getWidth(), src.getHeight());
        Bitmap output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        BitmapShader shader = new BitmapShader(
            Bitmap.createScaledBitmap(src, size, size, true),
            Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
        paint.setShader(shader);
        canvas.drawCircle(size / 2f, size / 2f, size / 2f, paint);
        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(size * 0.04f);
        stroke.setColor(0x559B6FC4);
        canvas.drawCircle(size / 2f, size / 2f, size / 2f - stroke.getStrokeWidth() / 2f, stroke);
        return output;
    }
}

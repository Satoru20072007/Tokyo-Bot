package com.eve.cinema;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * EveFirebaseSync — v2
 *
 * تغييرات من v1:
 * [FIX-WARN]  استبدال AsyncTask المهجور بـ ExecutorService + Handler
 * [FIX-SEC]   sanitize() يستخدم SHA-256 بدلاً من replaceAll — يمنع تصادم المفاتيح
 * [FIX-LEAK]  try-finally لضمان conn.disconnect() دائماً
 * [FIX-PERF]  نفس thread pool لـ upload و download
 */
public class EveFirebaseSync {

    private static final String DB_BASE =
        "https://eve-cinema-app-default-rtdb.firebaseio.com/user_dna/";

    private static final ExecutorService IO   = Executors.newFixedThreadPool(2);
    private static final Handler         MAIN = new Handler(Looper.getMainLooper());

    // ── Callbacks ──────────────────────────────────────────────────────
    public interface SyncCallback     { void onComplete(boolean success); }
    public interface DownloadCallback { void onResult(EveMemoryDb.UserDna dna); }

    // ══════════════════════════════════════════════════════════════════
    //  UPLOAD DNA — PUT request
    // ══════════════════════════════════════════════════════════════════
    public static void uploadDna(final String userId,
                                  final EveMemoryDb.UserDna dna,
                                  final SyncCallback callback) {
        if (userId == null || dna == null) {
            if (callback != null) callback.onComplete(false);
            return;
        }
        IO.submit(() -> {
            boolean ok = false;
            HttpURLConnection conn = null;
            try {
                JSONObject data = new JSONObject();
                data.put("genre_likes",       dna.genreLikes);
                data.put("genre_dislikes",    dna.genreDislikes);
                data.put("fav_directors",     dna.favDirectors);
                data.put("fav_actors",        dna.favActors);
                data.put("mood_tags",         dna.moodTags);
                data.put("watch_history",     dna.watchHistory);
                data.put("dna_summary",       dna.summary);
                data.put("emotional_pattern", dna.emotionalPattern);
                data.put("fav_decade",        dna.favDecade);
                data.put("last_updated",      System.currentTimeMillis() / 1000L);

                String endpoint = DB_BASE + sanitize(userId) + ".json";
                conn = (HttpURLConnection) new URL(endpoint).openConnection();
                conn.setRequestMethod("PUT");
                conn.setDoOutput(true);
                conn.setConnectTimeout(8000);
                conn.setReadTimeout(8000);
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

                byte[] body = data.toString().getBytes(StandardCharsets.UTF_8);
                conn.setFixedLengthStreamingMode(body.length);
                try (OutputStream os = conn.getOutputStream()) { os.write(body); }

                int code = conn.getResponseCode();
                ok = (code >= 200 && code < 300);
            } catch (Exception ignored) {
            } finally {
                // [FIX-LEAK] disconnect دائماً بغض النظر عن النتيجة
                if (conn != null) conn.disconnect();
            }
            final boolean result = ok;
            if (callback != null) MAIN.post(() -> callback.onComplete(result));
        });
    }

    // ══════════════════════════════════════════════════════════════════
    //  DOWNLOAD DNA — GET request
    // ══════════════════════════════════════════════════════════════════
    public static void downloadDna(final String userId, final DownloadCallback callback) {
        if (userId == null) {
            if (callback != null) callback.onResult(null);
            return;
        }
        IO.submit(() -> {
            EveMemoryDb.UserDna dna = null;
            HttpURLConnection conn = null;
            try {
                String endpoint = DB_BASE + sanitize(userId) + ".json";
                conn = (HttpURLConnection) new URL(endpoint).openConnection();
                conn.setRequestMethod("GET");
                conn.setConnectTimeout(8000);
                conn.setReadTimeout(8000);

                int code = conn.getResponseCode();
                if (code == 200) {
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader br = new BufferedReader(
                            new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = br.readLine()) != null) sb.append(line);
                    }
                    String body = sb.toString().trim();
                    // Firebase يُرجع "null" إذا لم يكن السجل موجوداً
                    if (!body.equals("null") && !body.isEmpty()) {
                        JSONObject json = new JSONObject(body);
                        dna = new EveMemoryDb.UserDna(userId);
                        dna.genreLikes       = safe(json, "genre_likes");
                        dna.genreDislikes    = safe(json, "genre_dislikes");
                        dna.favDirectors     = safe(json, "fav_directors");
                        dna.favActors        = safe(json, "fav_actors");
                        dna.moodTags         = safe(json, "mood_tags");
                        dna.watchHistory     = safeDef(json, "watch_history", "[]");
                        dna.summary          = safe(json, "dna_summary");
                        dna.emotionalPattern = safe(json, "emotional_pattern");
                        dna.favDecade        = safe(json, "fav_decade");
                    }
                }
            } catch (Exception ignored) {
            } finally {
                // [FIX-LEAK] disconnect دائماً
                if (conn != null) conn.disconnect();
            }
            final EveMemoryDb.UserDna result = dna;
            if (callback != null) MAIN.post(() -> callback.onResult(result));
        });
    }

    // ── Helpers ────────────────────────────────────────────────────────

    /**
     * [FIX-SEC] SHA-256 بدلاً من replaceAll لمنع تصادم المفاتيح.
     * user@a.com و user_a_com كانا يُعطيان نفس المفتاح "user_a_com".
     * الآن كل userId له hash فريد.
     * Firebase يقبل hex strings (0-9, a-f) بدون مشكلة.
     */
    private static String sanitize(String userId) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(userId.getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) hex.append(String.format("%02x", b));
            // Firebase مسار: أول 40 حرف كافٍ (160 بت) + prefix للوضوح
            return "u_" + hex.substring(0, 40);
        } catch (Exception e) {
            // Fallback: replaceAll الأصلي إن فشل SHA-256 (مستحيل عملياً)
            return userId.replaceAll("[^a-zA-Z0-9_\\-]", "_");
        }
    }

    private static String safe(JSONObject json, String key) {
        String v = json.optString(key, "");
        return v == null ? "" : v;
    }

    private static String safeDef(JSONObject json, String key, String def) {
        String v = safe(json, key);
        return v.isEmpty() ? def : v;
    }
}

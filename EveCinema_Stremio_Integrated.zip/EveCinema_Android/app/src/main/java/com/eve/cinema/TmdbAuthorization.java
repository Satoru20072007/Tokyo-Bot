package com.eve.cinema;

/** Normalizes configured TMDB credentials into exactly one HTTP Bearer scheme. */
public final class TmdbAuthorization {
    private static final String SCHEME = "Bearer ";

    private TmdbAuthorization() {}

    /** true إذا كان اعتماد TMDB مضبوطاً وقت البناء (وإلا كل الطلبات ستُرفض 401). */
    public static boolean isConfigured(String configuredValue) {
        return !headerValue(configuredValue).isEmpty();
    }

    /** يضبط ترويسة Authorization مرة واحدة وبشكل موحّد؛ لا يرسل ترويسة فارغة. */
    public static void apply(java.net.HttpURLConnection conn, String configuredValue) {
        String v = headerValue(configuredValue);
        if (!v.isEmpty()) conn.setRequestProperty("Authorization", v);
    }

    /**
     * Accepts either a raw access token or a value already prefixed with Bearer.
     * Returns an empty string for missing, blank, or header-injection input.
     */
    public static String headerValue(String configuredValue) {
        if (configuredValue == null) return "";
        String token = configuredValue.trim();
        if (token.isEmpty() || token.equalsIgnoreCase("Bearer")) return "";

        if (token.regionMatches(true, 0, SCHEME, 0, SCHEME.length())) {
            token = token.substring(SCHEME.length()).trim();
        }
        if (token.isEmpty()) return "";

        for (int i = 0; i < token.length(); i++) {
            char c = token.charAt(i);
            if (c <= 0x1f || c == 0x7f) return "";
        }
        return SCHEME + token;
    }
}

package com.eve.cinema.stremio;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Estimates link speed from a SMALL bounded sample, never by downloading the title.
 *
 * <ul>
 *   <li>Progressive files: one Range request, at most {@link #SAMPLE_BYTES} read.</li>
 *   <li>HLS: the playlist(s) plus at most {@link #MAX_HLS_SEGMENTS} segment prefixes, same byte cap.</li>
 *   <li>DASH: only the manifest is read; speed stays unknown (no honest sample without a player).</li>
 * </ul>
 * Timing starts after the first bytes arrive, so connection latency is excluded. The number is
 * an estimate that depends on the network and the moment of the check, not a playback guarantee.
 * Every request (and every redirect hop) must pass the injected {@link UrlPolicy}.
 */
public final class StremioSpeedProbe {
    public static final int SAMPLE_BYTES = 256 * 1024;
    public static final int MIN_MEASURABLE_BYTES = 64 * 1024;
    public static final int MAX_HLS_SEGMENTS = 4;
    private static final int PLAYLIST_LIMIT = 256 * 1024;
    private static final int CONNECT_TIMEOUT_MS = 4000;
    private static final int READ_TIMEOUT_MS = 4000;
    private static final int MAX_REDIRECTS = 3;
    private static final long PER_LINK_BUDGET_NANOS = 6_000_000_000L;
    private static final double MAX_REPORTED_MBPS = 2000d;
    private static final String DEFAULT_USER_AGENT = "EveCinema-Stremio/1.0 (Android; Media3)";

    private static final Pattern HLS_RESOLUTION = Pattern.compile(
            "RESOLUTION=(\\d+)x(\\d+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern HLS_BANDWIDTH = Pattern.compile(
            "(?<![A-Z-])BANDWIDTH=(\\d+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern DASH_TAG = Pattern.compile(
            "<(?:Representation|AdaptationSet)\\b[^>]*>");
    private static final Pattern DASH_WIDTH = Pattern.compile("\\bwidth=\"(\\d{3,4})\"");
    private static final Pattern DASH_HEIGHT = Pattern.compile("\\bheight=\"(\\d{3,4})\"");

    /** Decides whether a URL may be contacted (public host, allowed scheme). */
    public interface UrlPolicy { boolean allows(String url); }

    /** Raised when the {@link UrlPolicy} refuses a link or a redirect hop. */
    private static final class BlockedException extends IOException {
        BlockedException() { super("blocked"); }
    }

    public static final class Result {
        /** True only for definitive proof the link is unusable (HTTP 404/410 or an HTML page). */
        public final boolean dead;
        /** Estimated Mbps, or {@link StremioStreamOption#SPEED_UNKNOWN}. */
        public final double mbps;
        /** Highest resolution the manifest itself declares, or 0. */
        public final int manifestHeight;

        /** The URL policy refused the link or one of its redirect hops (private/unsafe target). */
        public final boolean blocked;

        Result(boolean dead, double mbps, int manifestHeight) {
            this(dead, false, mbps, manifestHeight);
        }

        Result(boolean dead, boolean blocked, double mbps, int manifestHeight) {
            this.dead = dead;
            this.blocked = blocked;
            this.mbps = mbps;
            this.manifestHeight = manifestHeight;
        }

        static Result dead() { return new Result(true, StremioStreamOption.SPEED_UNKNOWN, 0); }
        static Result blocked() { return new Result(false, true, StremioStreamOption.SPEED_UNKNOWN, 0); }
        static Result unknown() { return new Result(false, StremioStreamOption.SPEED_UNKNOWN, 0); }
    }

    private final UrlPolicy policy;

    public StremioSpeedProbe(UrlPolicy policy) {
        if (policy == null) throw new IllegalArgumentException("policy");
        this.policy = policy;
    }

    /** Production policy: public hosts only, HTTP(S) media URLs as already validated for playback. */
    public static StremioSpeedProbe forProduction() {
        return new StremioSpeedProbe(new UrlPolicy() {
            @Override public boolean allows(String url) {
                return StremioAddonClient.isSafePublicMediaUrl(url);
            }
        });
    }

    /** Blocking; run off the UI thread. Never throws; failures become an unknown result. */
    public Result probe(String url, Map<String, String> headers, String streamType) {
        long deadline = System.nanoTime() + PER_LINK_BUDGET_NANOS;
        try {
            return probeFirstRequest(url, headers, streamType, deadline);
        } catch (BlockedException ex) {
            return Result.blocked();
        } catch (IOException | RuntimeException ex) {
            return Result.unknown();
        }
    }

    // ───────────────────────── first request: detect the real kind ─────────────────────────

    private Result probeFirstRequest(String url, Map<String, String> headers, String hint,
                                     long deadline) throws IOException {
        Conn conn = open(url, headers, "bytes=0-" + (SAMPLE_BYTES - 1), deadline);
        try {
            int status = conn.status;
            if (status == 404 || status == 410) return Result.dead();
            if (status != 200 && status != 206) return Result.unknown();
            String type = conn.contentType == null ? "" : conn.contentType.toLowerCase(Locale.US);
            if (type.contains("text/html")) return Result.dead();

            InputStream in = conn.connection.getInputStream();
            byte[] head = new byte[16 * 1024];
            int first = readQuietly(in, head);
            if (first <= 0) return Result.unknown();
            String start = new String(head, 0, Math.min(first, 64), StandardCharsets.UTF_8).trim();

            boolean hls = start.startsWith("#EXTM3U");
            boolean dash = !hls && (type.contains("dash+xml")
                    || new String(head, 0, first, StandardCharsets.UTF_8).contains("<MPD"));
            if (hls || dash) {
                String text = readText(in, head, first, PLAYLIST_LIMIT);
                return hls ? probeHls(text, conn.finalUrl, headers, deadline)
                           : new Result(false, StremioStreamOption.SPEED_UNKNOWN, dashMaxHeight(text));
            }
            // A hinted manifest that is not actually one cannot be measured as video.
            if ("HLS".equals(hint) || "DASH".equals(hint)) return Result.unknown();
            return measureProgressive(in, first, deadline);
        } finally {
            conn.close();
        }
    }

    private Result measureProgressive(InputStream in, int firstChunk, long deadline) {
        Measure m = new Measure();
        m.begin(firstChunk);
        readRemaining(in, m, SAMPLE_BYTES, deadline);
        return new Result(false, m.mbps(), 0);
    }

    // ─────────────────────────────────── HLS ───────────────────────────────────

    private Result probeHls(String playlist, String playlistUrl, Map<String, String> headers,
                            long deadline) throws IOException {
        int manifestHeight = 0;
        String mediaPlaylist = playlist;
        String mediaUrl = playlistUrl;

        if (playlist.contains("#EXT-X-STREAM-INF")) {
            String bestUri = null;
            long bestBandwidth = -1;
            String[] lines = playlist.split("\\r?\\n");
            for (int i = 0; i < lines.length; i++) {
                String line = lines[i].trim();
                if (!line.startsWith("#EXT-X-STREAM-INF")) continue;
                Matcher res = HLS_RESOLUTION.matcher(line);
                if (res.find()) {
                    manifestHeight = Math.max(manifestHeight, StremioQuality.fromDimensions(
                            parseInt(res.group(1)), parseInt(res.group(2))));
                }
                long bandwidth = 0;
                Matcher bw = HLS_BANDWIDTH.matcher(line);
                if (bw.find()) bandwidth = parseLong(bw.group(1));
                for (int j = i + 1; j < lines.length; j++) {
                    String next = lines[j].trim();
                    if (next.isEmpty() || next.startsWith("#")) continue;
                    if (bandwidth > bestBandwidth) { bestBandwidth = bandwidth; bestUri = next; }
                    break;
                }
            }
            if (bestUri == null) return new Result(false, StremioStreamOption.SPEED_UNKNOWN, manifestHeight);
            mediaUrl = resolve(playlistUrl, bestUri);
            if (mediaUrl == null) return new Result(false, StremioStreamOption.SPEED_UNKNOWN, manifestHeight);
            mediaPlaylist = fetchText(mediaUrl, headers, deadline);
            if (mediaPlaylist == null) return new Result(false, StremioStreamOption.SPEED_UNKNOWN, manifestHeight);
        }

        List<String> segments = new ArrayList<>();
        boolean byteRanges = false;
        String[] lines = mediaPlaylist.split("\\r?\\n");
        boolean expectUri = false;
        for (String raw : lines) {
            String line = raw.trim();
            if (line.startsWith("#EXT-X-BYTERANGE")) byteRanges = true;
            if (line.startsWith("#EXTINF")) { expectUri = true; continue; }
            if (expectUri && !line.isEmpty() && !line.startsWith("#")) {
                String abs = resolve(mediaUrl, line);
                if (abs != null) segments.add(abs);
                expectUri = false;
                if (segments.size() >= MAX_HLS_SEGMENTS) break;
            }
        }
        if (segments.isEmpty() || byteRanges)
            return new Result(false, StremioStreamOption.SPEED_UNKNOWN, manifestHeight);

        Measure total = new Measure();
        long budgetLeft = SAMPLE_BYTES;
        for (String segment : segments) {
            if (budgetLeft < MIN_MEASURABLE_BYTES / 2 || System.nanoTime() > deadline) break;
            Conn seg = null;
            try {
                seg = open(segment, headers, "bytes=0-" + (budgetLeft - 1), deadline);
                if (seg.status != 200 && seg.status != 206) continue;
                InputStream in = seg.connection.getInputStream();
                byte[] head = new byte[16 * 1024];
                int first = readQuietly(in, head);
                if (first <= 0) continue;
                Measure one = new Measure();
                one.begin(first);
                readRemaining(in, one, (int) budgetLeft, deadline);
                total.merge(one);
                budgetLeft -= one.totalBytes;
            } catch (IOException ignored) {
                break;
            } finally {
                if (seg != null) seg.close();
            }
        }
        return new Result(false, total.mbps(), manifestHeight);
    }

    private String fetchText(String url, Map<String, String> headers, long deadline) {
        Conn conn = null;
        try {
            conn = open(url, headers, "bytes=0-" + (PLAYLIST_LIMIT - 1), deadline);
            if (conn.status != 200 && conn.status != 206) return null;
            InputStream in = conn.connection.getInputStream();
            byte[] head = new byte[16 * 1024];
            int first = readQuietly(in, head);
            if (first <= 0) return null;
            String text = readText(in, head, first, PLAYLIST_LIMIT);
            return text.startsWith("#EXTM3U") ? text : null;
        } catch (IOException ex) {
            return null;
        } finally {
            if (conn != null) conn.close();
        }
    }

    // ─────────────────────────────────── DASH / text helpers ───────────────────────────────────

    private static int dashMaxHeight(String manifest) {
        int max = 0;
        Matcher tag = DASH_TAG.matcher(manifest);
        while (tag.find()) {
            String text = tag.group();
            Matcher h = DASH_HEIGHT.matcher(text);
            if (!h.find()) continue;
            Matcher w = DASH_WIDTH.matcher(text);
            int width = w.find() ? parseInt(w.group(1)) : 0;
            max = Math.max(max, StremioQuality.fromDimensions(width, parseInt(h.group(1))));
        }
        return max;
    }

    private static String readText(InputStream in, byte[] head, int headLength, int limit) {
        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(headLength, 4096));
        out.write(head, 0, headLength);
        byte[] buf = new byte[8192];
        try {
            while (out.size() < limit) {
                int r = in.read(buf, 0, Math.min(buf.length, limit - out.size()));
                if (r < 0) break;
                out.write(buf, 0, r);
            }
        } catch (IOException ignored) { /* partial text is still useful */ }
        return new String(out.toByteArray(), StandardCharsets.UTF_8).trim();
    }

    private static String resolve(String base, String reference) {
        try {
            return new URL(new URL(base), reference).toString();
        } catch (IOException | RuntimeException ex) {
            return null;
        }
    }

    // ─────────────────────────────────── transport ───────────────────────────────────

    private static final class Conn {
        final HttpURLConnection connection;
        final int status;
        final String contentType;
        final String finalUrl;
        Conn(HttpURLConnection c, int status, String finalUrl) {
            this.connection = c;
            this.status = status;
            this.contentType = c.getContentType();
            this.finalUrl = finalUrl;
        }
        void close() { connection.disconnect(); }
    }

    private Conn open(String url, Map<String, String> headers, String range, long deadline)
            throws IOException {
        String current = url;
        String originHost = hostOf(url);
        for (int hop = 0; hop <= MAX_REDIRECTS; hop++) {
            if (!policy.allows(current)) throw new BlockedException();
            long remainingMs = (deadline - System.nanoTime()) / 1_000_000L;
            if (remainingMs <= 0) throw new IOException("deadline");
            HttpURLConnection c = (HttpURLConnection) new URL(current).openConnection();
            c.setInstanceFollowRedirects(false);
            c.setRequestMethod("GET");
            c.setConnectTimeout((int) Math.min(CONNECT_TIMEOUT_MS, remainingMs));
            c.setReadTimeout((int) Math.min(READ_TIMEOUT_MS, remainingMs));
            c.setRequestProperty("Accept", "*/*");
            c.setRequestProperty("Accept-Encoding", "identity");
            c.setRequestProperty("Range", range);
            boolean sameHost = originHost != null && originHost.equalsIgnoreCase(hostOf(current));
            boolean hasUserAgent = false;
            if (headers != null) {
                for (Map.Entry<String, String> e : headers.entrySet()) {
                    String key = e.getKey();
                    String value = e.getValue();
                    if (key == null || value == null || value.isEmpty()) continue;
                    if (value.indexOf('\r') >= 0 || value.indexOf('\n') >= 0) continue;
                    if (!sameHost && ("Cookie".equalsIgnoreCase(key)
                            || "Authorization".equalsIgnoreCase(key))) continue;
                    if ("User-Agent".equalsIgnoreCase(key)) hasUserAgent = true;
                    c.setRequestProperty(key, value);
                }
            }
            if (!hasUserAgent) c.setRequestProperty("User-Agent", DEFAULT_USER_AGENT);

            int status;
            try {
                status = c.getResponseCode();
            } catch (IOException ex) {
                c.disconnect();
                throw ex;
            }
            if (status == 301 || status == 302 || status == 303 || status == 307 || status == 308) {
                String location = c.getHeaderField("Location");
                c.disconnect();
                if (location == null || location.trim().isEmpty()) throw new IOException("redirect");
                String next = resolve(current, location.trim());
                if (next == null) throw new IOException("redirect");
                if (current.regionMatches(true, 0, "https://", 0, 8)
                        && !next.regionMatches(true, 0, "https://", 0, 8))
                    throw new IOException("downgrade");
                current = next;
                continue;
            }
            return new Conn(c, status, current);
        }
        throw new IOException("redirects");
    }

    private static String hostOf(String url) {
        try { return new URL(url).getHost(); } catch (IOException ex) { return null; }
    }

    // ─────────────────────────────────── measurement ───────────────────────────────────

    /** Accumulates bytes read after the first chunk and the time that took. */
    private static final class Measure {
        long totalBytes;
        long measuredBytes;
        long measuredNanos;
        private long startNanos;

        /** Timing starts once the first chunk is in hand, so connect/TTFB latency is excluded. */
        void begin(int firstChunk) {
            this.startNanos = System.nanoTime();
            this.totalBytes += firstChunk;
        }
        void finish(long endNanos) { measuredNanos += Math.max(0L, endNanos - startNanos); }
        void merge(Measure other) {
            totalBytes += other.totalBytes;
            measuredBytes += other.measuredBytes;
            measuredNanos += other.measuredNanos;
        }
        double mbps() {
            if (totalBytes < MIN_MEASURABLE_BYTES || measuredBytes < MIN_MEASURABLE_BYTES / 2)
                return StremioStreamOption.SPEED_UNKNOWN;
            double seconds = Math.max(measuredNanos, 2_000_000L) / 1e9;
            double mbps = measuredBytes * 8.0 / seconds / 1e6;
            return Math.min(mbps, MAX_REPORTED_MBPS);
        }
    }

    private static void readRemaining(InputStream in, Measure m, int cap, long deadline) {
        byte[] buf = new byte[16 * 1024];
        try {
            while (m.totalBytes < cap && System.nanoTime() < deadline) {
                int want = (int) Math.min(buf.length, cap - m.totalBytes);
                int r = in.read(buf, 0, want);
                if (r < 0) break;
                m.totalBytes += r;
                m.measuredBytes += r;
            }
        } catch (SocketTimeoutException ignored) {
            // a stalled link: keep whatever was measured so far
        } catch (IOException ignored) {
            // connection dropped mid-sample
        }
        m.finish(System.nanoTime());
    }

    private static int readQuietly(InputStream in, byte[] buffer) {
        try { return in.read(buffer); } catch (IOException ex) { return -1; }
    }

    private static int parseInt(String s) {
        try { return Integer.parseInt(s); } catch (NumberFormatException ex) { return 0; }
    }

    private static long parseLong(String s) {
        try { return Long.parseLong(s); } catch (NumberFormatException ex) { return 0L; }
    }
}

package com.eve.cinema;

import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.media3.common.TrackGroup;

import java.util.List;

/** Shows only supported video formats discovered by Media3 for the prepared item. */
public final class DashQualitySheet extends Dialog {
    public static final class Option {
        public final TrackGroup group; public final int index, height, bitrate; public final boolean selected;
        public Option(TrackGroup group, int index, int height, int bitrate, boolean selected) {
            this.group=group;this.index=index;this.height=height;this.bitrate=bitrate;this.selected=selected;
        }
        public String label() { return height > 0 ? height + "p" : (bitrate > 0 ? (bitrate/1000)+" kbps" : "دقة غير معروفة"); }
    }
    public interface Listener { void onAuto(); void onSelected(Option option); }
    private final List<Option> options; private final Listener listener;
    public DashQualitySheet(Context context, List<Option> options, Listener listener) {
        super(context, R.style.QualitySheetTheme); this.options=options; this.listener=listener;
    }
    @Override protected void onCreate(android.os.Bundle state) {
        super.onCreate(state);requestWindowFeature(Window.FEATURE_NO_TITLE);float d=getContext().getResources().getDisplayMetrics().density;
        LinearLayout root=new LinearLayout(getContext());root.setOrientation(LinearLayout.VERTICAL);root.setPadding(px(d,22),px(d,18),px(d,22),px(d,20));
        GradientDrawable bg=new GradientDrawable();bg.setColor(0xF21B1925);bg.setCornerRadius(px(d,24));bg.setStroke(px(d,1),0x557D63A6);root.setBackground(bg);
        TextView title=text("جودة الفيديو",17,0xFFFFFFFF,true);root.addView(title,lp(-1,-2,0,0,0,px(d,12)));
        addRow(root,"تلقائي","اختيار تكيفي من Media3",true,d,()->{dismiss();if(listener!=null)listener.onAuto();});
        for(Option option:options) addRow(root,option.label(),option.bitrate>0?(option.bitrate/1000)+" kbps":"مسار فيديو مدعوم",option.selected,d,()->{dismiss();if(listener!=null)listener.onSelected(option);});
        setContentView(root);Window w=getWindow();if(w!=null){w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);w.setGravity(Gravity.BOTTOM);w.setBackgroundDrawableResource(android.R.color.transparent);}
    }
    private void addRow(LinearLayout root,String name,String detail,boolean selected,float d,Runnable action){
        LinearLayout row=new LinearLayout(getContext());row.setOrientation(LinearLayout.VERTICAL);row.setPadding(px(d,14),px(d,12),px(d,14),px(d,12));
        GradientDrawable bg=new GradientDrawable();bg.setColor(selected?0xFF30283E:0xFF262131);bg.setCornerRadius(px(d,13));bg.setStroke(px(d,1),selected?0xFF9B6FC4:0x447B61A7);row.setBackground(bg);row.setClickable(true);row.setFocusable(true);row.setContentDescription(name+". "+detail);row.setOnClickListener(v->action.run());
        root.addView(row,lp(-1,-2,0,0,0,px(d,7)));row.addView(text(name,15,selected?0xFFD7B9FF:0xFFFFFFFF,true));TextView sub=text(detail,11,0xFFAAA4B4,false);row.addView(sub,lp(-1,-2,0,px(d,3),0,0));
    }
    private TextView text(String s,int z,int c,boolean b){TextView v=new TextView(getContext());v.setText(s);v.setTextSize(z);v.setTextColor(c);if(b)v.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return v;}
    private static LinearLayout.LayoutParams lp(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w,h);p.setMargins(l,t,r,b);return p;}
    private static int px(float d,int v){return(int)(d*v+.5f);}
}

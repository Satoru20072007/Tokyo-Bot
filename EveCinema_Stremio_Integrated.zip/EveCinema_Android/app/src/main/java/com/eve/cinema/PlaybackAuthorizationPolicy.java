package com.eve.cinema;

import android.content.Context;

import com.eve.cinema.providercore.ProviderDecision;
import com.eve.cinema.providercore.ProviderIds;

/**
 * بوابة السماح بمزودات التشغيل. مصدر الحقيقة الوحيد هو
 * {@link ProviderDecision#currentFor(String)} (ورقة قرار كل مصدر):
 * ACCEPTED/EXPERIMENTAL يعملان، DISABLED/REJECTED لا يُستدعيان أبداً.
 *
 * ⚠ كانت هذه الدالة تُرجع false ثابتاً لكل المصادر، فتتعطل كل شاشات
 * التفاصيل/الحلقات/المشغّل بلا أي طلب شبكة. أُعيدت لتتبع ورقة القرار.
 * لتعطيل مصدر: غيّر قراره في ProviderDecision فقط (مكان واحد).
 */
public final class PlaybackAuthorizationPolicy {

    private PlaybackAuthorizationPolicy() {}

    /** هل يوجد مصدر واحد على الأقل مسموح بمروره؟ */
    public static boolean hasAuthorizedSource() {
        return isProviderEnabled(ProviderIds.CINEMABOX)
                || isProviderEnabled(ProviderIds.MOVIEBOX);
    }

    /** An explicitly enabled Stremio stream add-on is also an authorized source. */
    public static boolean hasAuthorizedSource(Context context) {
        return hasAuthorizedSource()
                || com.eve.cinema.stremio.StremioSourceResolver.hasEnabledStreamAddon(
                        context, "movie", "tmdb:")
                || com.eve.cinema.stremio.StremioSourceResolver.hasEnabledStreamAddon(
                        context, "series", "tmdb:")
                || com.eve.cinema.stremio.StremioSourceResolver.hasEnabledStreamAddon(
                        context, "anime", "tmdb:");
    }

    public static boolean isProviderEnabled(String providerId) {
        return ProviderDecision.currentFor(providerId).allowsTraffic();
    }

    public static String disabledMessage() {
        return "لا يتوفر مصدر تشغيل مفعّل حالياً. راجع قرارات المصادر في ProviderDecision.";
    }
}

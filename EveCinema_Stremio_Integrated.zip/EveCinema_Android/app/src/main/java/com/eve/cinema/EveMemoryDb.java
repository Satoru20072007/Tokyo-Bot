package com.eve.cinema;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * EveMemoryDb — v5
 *
 * [L] mergeAndTrim() — يدمج حقول DNA مع حد أقصى للعناصر
 *     genreLikes لا تتراكم إلى ما لا نهاية — بحد أقصى 5 عناصر
 *     favDirectors بحد أقصى 5، mood_tags بحد أقصى 6، إلخ
 */
public class EveMemoryDb extends SQLiteOpenHelper {

    private static final String DB_NAME    = "eve_memory.db";
    private static final int    DB_VERSION = 4;

    private static final String T_MSG = "eve_messages";
    private static final String T_DNA = "eve_user_dna";

    public static final String C_ID        = "_id";
    public static final String C_USER_ID   = "user_id";
    public static final String C_ROLE      = "role";
    public static final String C_CONTENT   = "content";
    public static final String C_SESSION   = "session_id";
    public static final String C_TIMESTAMP = "timestamp";

    public static final String C_DNA_UID     = "user_id";
    public static final String C_GENRES_L    = "genre_likes";
    public static final String C_GENRES_D    = "genre_dislikes";
    public static final String C_DIRECTORS   = "fav_directors";
    public static final String C_ACTORS      = "fav_actors";
    public static final String C_MOOD_TAGS   = "mood_tags";
    public static final String C_WATCH_HIS   = "watch_history";
    public static final String C_SUMMARY     = "dna_summary";
    public static final String C_UPDATED     = "last_updated";
    public static final String C_EMO_PATTERN = "emotional_pattern";
    public static final String C_FAV_DECADE  = "fav_decade";

    private static final String CARD_SEP = "|||";

    private static EveMemoryDb sInstance;

    public static synchronized EveMemoryDb get(Context ctx) {
        if (sInstance == null)
            sInstance = new EveMemoryDb(ctx.getApplicationContext());
        return sInstance;
    }

    private EveMemoryDb(Context ctx) {
        super(ctx, DB_NAME, null, DB_VERSION);
    }

    @Override public void onCreate(SQLiteDatabase db)                      { createTables(db); }
    @Override public void onUpgrade(SQLiteDatabase db, int ov, int nv)    {
        createTables(db);
        safeAddColumn(db, T_DNA, C_EMO_PATTERN, "TEXT DEFAULT ''");
        safeAddColumn(db, T_DNA, C_FAV_DECADE,  "TEXT DEFAULT ''");
    }

    private void createTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + T_MSG + " ("
            + C_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + C_USER_ID + " TEXT NOT NULL, "
            + C_ROLE + " TEXT NOT NULL, "
            + C_CONTENT + " TEXT NOT NULL, "
            + C_SESSION + " TEXT, "
            + C_TIMESTAMP + " INTEGER NOT NULL DEFAULT (strftime('%s','now'))"
            + ")");
        // [FIX-PERF] INDEX على user_id — كل query يفلتر بـ user_id
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_msg_user ON " + T_MSG
            + " (" + C_USER_ID + ", " + C_TIMESTAMP + ")");
        db.execSQL("CREATE TABLE IF NOT EXISTS " + T_DNA + " ("
            + C_DNA_UID + " TEXT PRIMARY KEY, "
            + C_GENRES_L + " TEXT DEFAULT '', "
            + C_GENRES_D + " TEXT DEFAULT '', "
            + C_DIRECTORS + " TEXT DEFAULT '', "
            + C_ACTORS + " TEXT DEFAULT '', "
            + C_MOOD_TAGS + " TEXT DEFAULT '', "
            + C_WATCH_HIS + " TEXT DEFAULT '[]', "
            + C_SUMMARY + " TEXT DEFAULT '', "
            + C_UPDATED + " INTEGER DEFAULT 0, "
            + C_EMO_PATTERN + " TEXT DEFAULT '', "
            + C_FAV_DECADE + " TEXT DEFAULT ''"
            + ")");
    }

    private void safeAddColumn(SQLiteDatabase db, String table, String col, String def) {
        try { db.execSQL("ALTER TABLE " + table + " ADD COLUMN " + col + " " + def); }
        catch (Exception ignored) {}
    }

    // ═══════════════════════════════════════════════════════════════
    //  SAVE
    // ═══════════════════════════════════════════════════════════════

    public void saveMessage(String userId, String role, String content, String sessionId) {
        ContentValues cv = new ContentValues();
        cv.put(C_USER_ID,   userId);
        cv.put(C_ROLE,      role);
        cv.put(C_CONTENT,   content != null ? content : "");
        cv.put(C_SESSION,   sessionId);
        cv.put(C_TIMESTAMP, System.currentTimeMillis() / 1000L);
        getWritableDatabase().insert(T_MSG, null, cv);
    }

    public void saveMessageCombined(String userId, String text,
                                     List<JSONObject> cards, List<String> cardTypes,
                                     String sessionId) {
        try {
            JSONObject combined = new JSONObject();
            combined.put("text", text != null ? text : "");
            JSONArray cardsArr = new JSONArray();
            // [FIX-NULL] cards قد يكون null عند الاستدعاء من history restore
            if (cards != null) {
                for (int i = 0; i < cards.size(); i++) {
                    JSONObject entry = new JSONObject();
                    entry.put("mt",   (cardTypes != null && i < cardTypes.size()) ? cardTypes.get(i) : "movie");
                    entry.put("data", cards.get(i));
                    cardsArr.put(entry);
                }
            }
            combined.put("cards", cardsArr);
            ContentValues cv = new ContentValues();
            cv.put(C_USER_ID,   userId);
            cv.put(C_ROLE,      "combined");
            cv.put(C_CONTENT,   combined.toString());
            cv.put(C_SESSION,   sessionId);
            cv.put(C_TIMESTAMP, System.currentTimeMillis() / 1000L);
            getWritableDatabase().insert(T_MSG, null, cv);
        } catch (Exception e) {
            saveMessage(userId, "assistant", text, sessionId);
        }
    }

    public void saveCard(String userId, JSONObject cardData, String mediaType, String sessionId) {
        if (cardData == null) return;
        saveMessage(userId, "card",
            (mediaType != null ? mediaType : "movie") + CARD_SEP + cardData.toString(),
            sessionId);
    }

    // ═══════════════════════════════════════════════════════════════
    //  READ — AI context
    // ═══════════════════════════════════════════════════════════════

    public List<JSONObject> getHistory(String userId, int limit) {
        // [FIX] ORDER BY ASC مباشرةً + LIMIT بـ subquery لنأخذ آخر N رسالة بالترتيب الصحيح
        Cursor c = getReadableDatabase().rawQuery(
            "SELECT role, content FROM ("
            + "SELECT " + C_ROLE + " AS role, " + C_CONTENT + " AS content, "
            + C_TIMESTAMP + " FROM " + T_MSG
            + " WHERE " + C_USER_ID + "=?"
            + " AND " + C_ROLE + " IN ('user','assistant','combined')"
            + " ORDER BY " + C_TIMESTAMP + " DESC LIMIT ?"
            + ") ORDER BY " + C_TIMESTAMP + " ASC",
            new String[]{ userId, String.valueOf(limit) });
        List<JSONObject> result = new ArrayList<>();
        if (c.moveToFirst()) {
            do {
                try {
                    String role    = c.getString(0);
                    String content = c.getString(1);
                    JSONObject msg = new JSONObject();
                    if ("combined".equals(role)) {
                        String text = new JSONObject(content).optString("text", "");
                        if (text.isEmpty()) continue;
                        msg.put("role", "assistant");
                        msg.put("content", text);
                    } else {
                        msg.put("role", role);
                        msg.put("content", content);
                    }
                    result.add(msg);
                } catch (Exception ignored) {}
            } while (c.moveToNext());
        }
        c.close();
        return result;
    }

    // ═══════════════════════════════════════════════════════════════
    //  READ — UI display
    // ═══════════════════════════════════════════════════════════════

    public List<EveMessageModel> getDisplayMessages(String userId, int limit) {
        // [FIX] نفس نمط getHistory — آخر N رسالة بالترتيب الزمني الصحيح
        Cursor c = getReadableDatabase().rawQuery(
            "SELECT role, content FROM ("
            + "SELECT " + C_ROLE + " AS role, " + C_CONTENT + " AS content, "
            + C_TIMESTAMP + " FROM " + T_MSG
            + " WHERE " + C_USER_ID + "=?"
            + " ORDER BY " + C_TIMESTAMP + " DESC LIMIT ?"
            + ") ORDER BY " + C_TIMESTAMP + " ASC",
            new String[]{ userId, String.valueOf(limit) });
        List<EveMessageModel> result = new ArrayList<>();
        if (c.moveToFirst()) {
            do {
                EveMessageModel m = parseRow(c.getString(0), c.getString(1));
                if (m != null) result.add(m);
            } while (c.moveToNext());
        }
        c.close();
        return result;
    }

    public List<String> getRecentTitles(String userId, int limit) {
        List<String> titles = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(getDna(userId).watchHistory);
            int from = Math.max(0, arr.length() - limit);
            for (int i = from; i < arr.length(); i++) titles.add(arr.getString(i));
        } catch (Exception ignored) {}
        return titles;
    }

    private EveMessageModel parseRow(String role, String content) {
        switch (role) {
            case "user":      return new EveMessageModel(EveMessageModel.TYPE_USER, content);
            case "assistant": return new EveMessageModel(EveMessageModel.TYPE_EVE,  content);
            case "combined": {
                try {
                    JSONObject obj = new JSONObject(content);
                    String text = obj.optString("text", "");
                    JSONArray cardsArr = obj.optJSONArray("cards");
                    List<JSONObject> cards     = new ArrayList<>();
                    List<String>     cardTypes = new ArrayList<>();
                    if (cardsArr != null) {
                        for (int i = 0; i < cardsArr.length(); i++) {
                            JSONObject entry = cardsArr.optJSONObject(i);
                            if (entry != null) {
                                JSONObject data = entry.optJSONObject("data");
                                if (data != null) {
                                    cards.add(data);
                                    cardTypes.add(entry.optString("mt", "movie"));
                                }
                            }
                        }
                    }
                    return new EveMessageModel(text, cards, cardTypes);
                } catch (Exception e) { return null; }
            }
            case "card": {
                int sep = content.indexOf(CARD_SEP);
                if (sep < 0) return null;
                try {
                    return new EveMessageModel(
                        new JSONObject(content.substring(sep + CARD_SEP.length())),
                        content.substring(0, sep));
                } catch (Exception e) { return null; }
            }
            default: return null;
        }
    }

    public int getMessageCount(String userId) {
        Cursor c = getReadableDatabase().rawQuery(
            "SELECT COUNT(*) FROM " + T_MSG
            + " WHERE " + C_USER_ID + "=? AND " + C_ROLE + " NOT IN ('card')",
            new String[]{ userId });
        int count = 0;
        if (c.moveToFirst()) count = c.getInt(0);
        c.close();
        return count;
    }

    public boolean isFirstTime(String userId) { return getMessageCount(userId) == 0; }

    // ═══════════════════════════════════════════════════════════════
    //  USER DNA
    // ═══════════════════════════════════════════════════════════════

    public UserDna getDna(String userId) {
        Cursor c = getReadableDatabase().rawQuery(
            "SELECT " + C_GENRES_L + "," + C_GENRES_D + "," + C_DIRECTORS + ","
            + C_ACTORS + "," + C_MOOD_TAGS + "," + C_WATCH_HIS + ","
            + C_SUMMARY + "," + C_EMO_PATTERN + "," + C_FAV_DECADE
            + " FROM " + T_DNA + " WHERE " + C_DNA_UID + "=?",
            new String[]{ userId });
        UserDna dna = new UserDna(userId);
        if (c.moveToFirst()) {
            dna.genreLikes       = safe(c, 0);
            dna.genreDislikes    = safe(c, 1);
            dna.favDirectors     = safe(c, 2);
            dna.favActors        = safe(c, 3);
            dna.moodTags         = safe(c, 4);
            dna.watchHistory     = safeDef(c, 5, "[]");
            dna.summary          = safe(c, 6);
            dna.emotionalPattern = safe(c, 7);
            dna.favDecade        = safe(c, 8);
        }
        c.close();
        return dna;
    }

    public void updateDna(UserDna dna) {
        ContentValues cv = new ContentValues();
        cv.put(C_DNA_UID,     dna.userId);
        cv.put(C_GENRES_L,    dna.genreLikes);
        cv.put(C_GENRES_D,    dna.genreDislikes);
        cv.put(C_DIRECTORS,   dna.favDirectors);
        cv.put(C_ACTORS,      dna.favActors);
        cv.put(C_MOOD_TAGS,   dna.moodTags);
        cv.put(C_WATCH_HIS,   dna.watchHistory);
        cv.put(C_SUMMARY,     dna.summary);
        cv.put(C_EMO_PATTERN, dna.emotionalPattern);
        cv.put(C_FAV_DECADE,  dna.favDecade);
        cv.put(C_UPDATED,     System.currentTimeMillis() / 1000L);
        getWritableDatabase().insertWithOnConflict(T_DNA, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
    }

    public void addToWatchHistory(String userId, String title) {
        if (title == null || title.trim().isEmpty()) return;
        UserDna dna = getDna(userId);
        try {
            JSONArray arr = new JSONArray(dna.watchHistory);
            for (int i = 0; i < arr.length(); i++)
                if (arr.getString(i).equalsIgnoreCase(title)) return;
            if (arr.length() >= 60) {
                JSONArray trimmed = new JSONArray();
                for (int i = 1; i < arr.length(); i++) trimmed.put(arr.get(i));
                arr = trimmed;
            }
            arr.put(title);
            dna.watchHistory = arr.toString();
            updateDna(dna);
        } catch (Exception ignored) {}
    }

    // ─────────────────────────────────────────────────────────────────
    //  [L] mergeAndTrim — دمج حقول DNA مع حد أقصى للعناصر
    // ─────────────────────────────────────────────────────────────────
    /**
     * يدمج قيمة جديدة مع القيمة الموجودة، ويُبقي العناصر بحد أقصى maxItems.
     * يمنع تضخم حقول DNA إلى ما لا نهاية.
     */
    public String mergeAndTrim(String existing, String newVal, int maxItems) {
        if (existing == null || existing.trim().isEmpty())
            return trimItems(newVal, maxItems);
        if (newVal == null || newVal.trim().isEmpty())
            return existing.trim();

        // دمج العناصر الجديدة غير المكررة
        StringBuilder sb = new StringBuilder(existing.trim());
        for (String p : newVal.split("[,،]")) {
            String t = p.trim();
            if (t.isEmpty()) continue;
            boolean found = false;
            for (String ex : existing.split("[,،]")) {
                if (ex.trim().equalsIgnoreCase(t)) { found = true; break; }
            }
            if (!found) sb.append("، ").append(t);
        }
        // تطبيق الحد الأقصى
        return trimItems(sb.toString(), maxItems);
    }

    /**
     * يُبقي آخر maxItems عناصر من القائمة المفصولة بفاصلة.
     */
    private String trimItems(String csv, int maxItems) {
        if (csv == null || csv.trim().isEmpty()) return "";
        String[] parts = csv.split("[,،]");
        if (parts.length <= maxItems) return csv.trim();

        // نُبقي العناصر الأخيرة (الأحدث)
        StringBuilder sb = new StringBuilder();
        int from = parts.length - maxItems;
        for (int i = from; i < parts.length; i++) {
            String t = parts[i].trim();
            if (t.isEmpty()) continue;
            if (sb.length() > 0) sb.append("، ");
            sb.append(t);
        }
        return sb.toString();
    }

    private String safe(Cursor c, int col) {
        if (col >= c.getColumnCount() || c.isNull(col)) return "";
        String v = c.getString(col);
        return v != null ? v : "";
    }

    private String safeDef(Cursor c, int col, String def) {
        String v = safe(c, col);
        return v.isEmpty() ? def : v;
    }

    // ═══════════════════════════════════════════════════════════════
    //  UserDna
    // ═══════════════════════════════════════════════════════════════
    public static class UserDna {
        public String userId;
        public String genreLikes       = "";
        public String genreDislikes    = "";
        public String favDirectors     = "";
        public String favActors        = "";
        public String moodTags         = "";
        public String watchHistory     = "[]";
        public String summary          = "";
        public String emotionalPattern = "";
        public String favDecade        = "";

        public UserDna(String userId) { this.userId = userId; }

        public boolean isEmpty() {
            return genreLikes.isEmpty() && favDirectors.isEmpty()
                && summary.isEmpty() && emotionalPattern.isEmpty();
        }

        public int memoryScore() {
            int score = 0;
            if (!genreLikes.isEmpty())       score++;
            if (!genreDislikes.isEmpty())    score++;
            if (!favDirectors.isEmpty())     score++;
            if (!favActors.isEmpty())        score++;
            if (!moodTags.isEmpty())         score++;
            if (!summary.isEmpty())          score++;
            if (!emotionalPattern.isEmpty()) score++;
            if (!favDecade.isEmpty())        score++;
            try {
                if (new JSONArray(watchHistory).length() > 0) score += 2;
            } catch (Exception ignored) {}
            return score;
        }

        public String toPromptContext() {
            if (isEmpty()) return "";
            StringBuilder sb = new StringBuilder(
                "\n[ذاكرة إيف الخاصة بهذا المستخدم — استخدميها بشكل طبيعي دون الإشارة إليها:");
            if (!summary.isEmpty())
                sb.append("\nملخص ذوقه: ").append(summary);
            if (!emotionalPattern.isEmpty())
                sb.append("\nنمطه العاطفي: ").append(emotionalPattern);
            if (!genreLikes.isEmpty())
                sb.append("\nأنواع يحبها: ").append(genreLikes);
            if (!genreDislikes.isEmpty())
                sb.append("\nأنواع لا يطيقها: ").append(genreDislikes);
            if (!favDirectors.isEmpty())
                sb.append("\nمخرجوه المفضلون: ").append(favDirectors);
            if (!favActors.isEmpty())
                sb.append("\nممثلوه المفضلون: ").append(favActors);
            if (!moodTags.isEmpty())
                sb.append("\nنبضاته المزاجية: ").append(moodTags);
            if (!favDecade.isEmpty())
                sb.append("\nعقوده المفضلة: ").append(favDecade);
            try {
                JSONArray arr = new JSONArray(watchHistory);
                if (arr.length() > 0) {
                    sb.append("\nشاهد مؤخراً: ");
                    int show = Math.min(arr.length(), 7);
                    for (int i = arr.length() - show; i < arr.length(); i++) {
                        sb.append(arr.getString(i));
                        if (i < arr.length() - 1) sb.append("، ");
                    }
                }
            } catch (Exception ignored) {}
            sb.append("]");
            return sb.toString();
        }
    }
}

package com.eve.cinema;

import android.animation.ValueAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.AsyncListDiffer;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class EveChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    // ── Palette ────────────────────────────────────────────────────────
    private static final int C_VIOLET  = 0xFF9B6FC4;
    private static final int C_VIOLET2 = 0xFF7C4FA0;
    private static final int C_LITE    = 0xFFC4A0E8;
    private static final int C_TEXT    = 0xFFF2EEFF;
    private static final int C_STAR    = 0xFFF5C518;
    private static final String TMDB_IMG = "https://image.tmdb.org/t/p/w342";

    private final Context                          context;
    private final AsyncListDiffer<EveMessageModel> differ;
    private int animatedUpTo = 0;

    public EveChatAdapter(Context context) {
        this.context = context;
        this.differ  = new AsyncListDiffer<>(this, new EveMessageModel.DiffCallback());
        setHasStableIds(true);
    }

    public void submitList(List<EveMessageModel> list) { differ.submitList(list); }
    public void resetAnimationCounter() { animatedUpTo = 0; }

    @Override public int  getItemCount()          { return differ.getCurrentList().size(); }
    @Override public long getItemId(int pos)       { return differ.getCurrentList().get(pos).stableId; }
    @Override public int  getItemViewType(int pos) { return differ.getCurrentList().get(pos).type; }

    @NonNull @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int type) {
        switch (type) {
            case EveMessageModel.TYPE_USER:         return new UserVH(makeUserBubble());
            case EveMessageModel.TYPE_CARD:         return new CardVH(makeStandaloneCard());
            case EveMessageModel.TYPE_TYPING:       return new TypingVH(makeTypingView());
            case EveMessageModel.TYPE_EVE_COMBINED: return new CombinedVH(makeCombinedView());
            default:                                return new EveVH(makeEveBubble());
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int pos) {
        EveMessageModel m = differ.getCurrentList().get(pos);

        if      (holder instanceof UserVH)     ((UserVH)     holder).bind(m.content);
        else if (holder instanceof EveVH)      ((EveVH)      holder).bind(m.content);
        else if (holder instanceof CombinedVH) ((CombinedVH) holder).bind(m.content, m.cards, m.cardTypes);
        else if (holder instanceof CardVH)     ((CardVH)     holder).bind(m.cardData, m.mediaType);
        else if (holder instanceof TypingVH)   ((TypingVH)   holder).startDots();

        // Dynamic top margin between messages
        List<EveMessageModel> list = differ.getCurrentList();
        boolean senderChanged = pos > 0 && isFromDifferentSender(list.get(pos - 1), m);
        ViewGroup.MarginLayoutParams mlp =
            (ViewGroup.MarginLayoutParams) holder.itemView.getLayoutParams();
        if (mlp != null) {
            mlp.topMargin = senderChanged ? dp(16) : dp(4);
            holder.itemView.setLayoutParams(mlp);
        }

        // Fluid entrance animation — translateY + alpha, staggered for first 3
        if (pos >= animatedUpTo) {
            animatedUpTo = pos + 1;
            holder.itemView.setAlpha(0f);
            holder.itemView.setTranslationY(dp(20));
            holder.itemView.animate()
                .alpha(1f).translationY(0f).setDuration(300)
                .setStartDelay(Math.min(pos < 3 ? pos * 30L : 0L, 90L))
                .setInterpolator(new DecelerateInterpolator(2.2f)).start();
        }
    }

    @Override
    public void onViewRecycled(@NonNull RecyclerView.ViewHolder holder) {
        super.onViewRecycled(holder);
        if (holder instanceof TypingVH)   ((TypingVH)   holder).stopDots();
        if (holder instanceof CardVH)     clearPoster(((CardVH)     holder).poster);
        if (holder instanceof CombinedVH) clearGlideInContainer(((CombinedVH) holder).cardsBox);
    }

    private void clearPoster(ImageView iv) {
        if (iv != null) Glide.with(context).clear(iv);
    }

    private void clearGlideInContainer(LinearLayout box) {
        if (box == null) return;
        for (int i = 0; i < box.getChildCount(); i++) {
            ImageView iv = box.getChildAt(i).findViewWithTag("poster");
            if (iv != null) Glide.with(context).clear(iv);
        }
    }

    private boolean isFromDifferentSender(EveMessageModel a, EveMessageModel b) {
        return (a.type == EveMessageModel.TYPE_USER) != (b.type == EveMessageModel.TYPE_USER);
    }

    // ══════════════════════════════════════════════════════════════════
    //  USER BUBBLE — deep violet gradient, precision corners
    //
    //  Alignment: MATCH_PARENT root + Gravity.END + left padding 60dp
    //  Tail: BR = 6dp (bottom-right, sends right)
    // ══════════════════════════════════════════════════════════════════
    private View makeUserBubble() {
        FrameLayout root = new FrameLayout(context);
        root.setLayoutParams(new ViewGroup.MarginLayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        root.setPadding(dp(58), dp(2), dp(14), dp(2));

        TextView tv = new TextView(context);
        tv.setTag("txt");
        tv.setTextSize(14.5f);
        tv.setTextColor(0xFFF0EEFF);
        tv.setLineSpacing(dp(2), 1.38f);
        tv.setPadding(dp(16), dp(12), dp(16), dp(12));
        tv.setTextDirection(View.TEXT_DIRECTION_RTL);
        tv.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);

        int maxWidth = (int) (context.getResources().getDisplayMetrics().widthPixels * 0.76);
        tv.setMaxWidth(maxWidth);

        // Richer, deeper purple gradient — luxury feel
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadii(new float[]{
            dp(22), dp(22),   // TL
            dp(22), dp(22),   // TR
            dp(6),  dp(6),    // BR — tail
            dp(22), dp(22)    // BL
        });
        bg.setColors(new int[]{ 0xFF7040B8, 0xFF3E1870 });
        bg.setOrientation(GradientDrawable.Orientation.TL_BR);
        tv.setBackground(bg);

        tv.setLongClickable(true);
        tv.setOnLongClickListener(v -> { copyText(tv.getText().toString()); return true; });

        FrameLayout.LayoutParams tvLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT);
        tvLp.gravity = Gravity.END | Gravity.TOP;
        tv.setLayoutParams(tvLp);

        root.addView(tv);
        return root;
    }

    // ══════════════════════════════════════════════════════════════════
    //  EVE BUBBLE — architectural dark surface, left-to-right depth
    //
    //  Alignment: MATCH_PARENT root + Gravity.START + right padding 58dp
    //  Tail: BL = 6dp (bottom-left, receives from left)
    //  Surface: subtle LEFT_RIGHT gradient for visual depth
    // ══════════════════════════════════════════════════════════════════
    private View makeEveBubble() {
        FrameLayout root = new FrameLayout(context);
        root.setLayoutParams(new ViewGroup.MarginLayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        root.setPadding(dp(14), dp(2), dp(58), dp(2));

        TextView tv = new TextView(context);
        tv.setTag("txt");
        tv.setTextSize(14.5f);
        tv.setTextColor(0xFFE0DCFF);
        tv.setLineSpacing(dp(2), 1.48f);
        tv.setPadding(dp(16), dp(12), dp(16), dp(12));
        tv.setTextDirection(View.TEXT_DIRECTION_RTL);
        tv.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);

        int maxWidth = (int) (context.getResources().getDisplayMetrics().widthPixels * 0.76);
        tv.setMaxWidth(maxWidth);

        // Subtle LEFT_RIGHT gradient — left edge slightly more violet for depth
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadii(new float[]{
            dp(22), dp(22),   // TL
            dp(22), dp(22),   // TR
            dp(22), dp(22),   // BR
            dp(6),  dp(6)     // BL — tail
        });
        bg.setColors(new int[]{ 0xFF141430, 0xFF0D0D1E });
        bg.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
        bg.setStroke(1, 0xFF1E1E36);
        tv.setBackground(bg);

        tv.setLongClickable(true);
        tv.setOnLongClickListener(v -> { copyText(tv.getText().toString()); return true; });

        FrameLayout.LayoutParams tvLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT);
        tvLp.gravity = Gravity.START | Gravity.TOP;
        tv.setLayoutParams(tvLp);

        root.addView(tv);
        return root;
    }

    // ══════════════════════════════════════════════════════════════════
    //  COMBINED VIEW — Eve text + movie cards in one container
    //
    //  Same dark surface language as Eve bubble
    //  Tail: BL = 6dp
    // ══════════════════════════════════════════════════════════════════
    private View makeCombinedView() {
        FrameLayout root = new FrameLayout(context);
        root.setLayoutParams(new ViewGroup.MarginLayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        root.setPadding(dp(14), dp(2), dp(14), dp(2));

        int screenW  = context.getResources().getDisplayMetrics().widthPixels;
        int maxCardW = (int) (screenW * 0.88f);

        LinearLayout container = new LinearLayout(context);
        container.setOrientation(LinearLayout.VERTICAL);
        container.setTag("container");

        FrameLayout.LayoutParams containerLp = new FrameLayout.LayoutParams(
            maxCardW, FrameLayout.LayoutParams.WRAP_CONTENT);
        containerLp.gravity = Gravity.START | Gravity.TOP;
        container.setLayoutParams(containerLp);

        // Matches Eve bubble surface — consistent language
        GradientDrawable cBg = new GradientDrawable();
        cBg.setCornerRadii(new float[]{
            dp(20), dp(20),   // TL
            dp(20), dp(20),   // TR
            dp(20), dp(20),   // BR
            dp(6),  dp(6)     // BL — tail
        });
        cBg.setColors(new int[]{ 0xFF141430, 0xFF0D0D1E });
        cBg.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
        cBg.setStroke(1, 0xFF1E1E36);
        container.setBackground(cBg);
        container.setClipToOutline(true);
        container.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override public void getOutline(View v, android.graphics.Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(20));
            }
        });

        // Text portion
        TextView tv = new TextView(context);
        tv.setTag("txt");
        tv.setTextSize(14.5f);
        tv.setTextColor(0xFFE0DCFF);
        tv.setLineSpacing(dp(2), 1.48f);
        tv.setPadding(dp(18), dp(14), dp(18), dp(10));
        tv.setTextDirection(View.TEXT_DIRECTION_RTL);
        tv.setGravity(Gravity.RIGHT);
        tv.setLongClickable(true);
        tv.setOnLongClickListener(v -> { copyText(tv.getText().toString()); return true; });
        container.addView(tv, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));

        // Cards container
        LinearLayout cardsBox = new LinearLayout(context);
        cardsBox.setOrientation(LinearLayout.VERTICAL);
        cardsBox.setTag("cards_box");
        container.addView(cardsBox, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));

        root.addView(container);
        return root;
    }

    // ══════════════════════════════════════════════════════════════════
    //  TYPING VIEW — refined pulsing dots, premium spacing
    //
    //  Same dark surface language, BL=6dp tail
    //  Dots: 8dp, gradient violet, sinusoidal animation
    // ══════════════════════════════════════════════════════════════════
    private View makeTypingView() {
        FrameLayout root = new FrameLayout(context);
        root.setLayoutParams(new ViewGroup.MarginLayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        root.setPadding(dp(14), dp(2), dp(58), dp(2));

        LinearLayout pill = new LinearLayout(context);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(dp(20), dp(16), dp(20), dp(16));

        GradientDrawable pBg = new GradientDrawable();
        pBg.setCornerRadii(new float[]{
            dp(20), dp(20),
            dp(20), dp(20),
            dp(20), dp(20),
            dp(6),  dp(6)    // BL — tail
        });
        pBg.setColors(new int[]{ 0xFF141430, 0xFF0D0D1E });
        pBg.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
        pBg.setStroke(1, 0xFF1E1E36);
        pill.setBackground(pBg);

        // Three gradient dots — slightly larger, better spacing
        for (int i = 0; i < 3; i++) {
            View dot = new View(context);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(dp(8), dp(8));
            dlp.rightMargin = (i < 2) ? dp(7) : 0;
            dlp.gravity = Gravity.CENTER_VERTICAL;
            dot.setLayoutParams(dlp);
            GradientDrawable db = new GradientDrawable();
            db.setShape(GradientDrawable.OVAL);
            db.setColors(new int[]{ 0xFFC4A0E8, 0xFF8858B8 });
            db.setOrientation(GradientDrawable.Orientation.TL_BR);
            dot.setBackground(db);
            dot.setAlpha(0.20f);
            dot.setTag("d" + i);
            pill.addView(dot);
        }

        FrameLayout.LayoutParams pillLp = new FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT);
        pillLp.gravity = Gravity.START | Gravity.TOP;
        pill.setLayoutParams(pillLp);

        root.addView(pill);
        return root;
    }

    // ══════════════════════════════════════════════════════════════════
    //  STANDALONE CARD — full-width, premium cinema card
    // ══════════════════════════════════════════════════════════════════
    private View makeStandaloneCard() {
        FrameLayout root = new FrameLayout(context);
        root.setLayoutParams(new ViewGroup.MarginLayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        root.setPadding(dp(18), dp(6), dp(18), dp(6));

        LinearLayout card = buildCardContent(true);
        card.setTag("card");

        int screenW  = context.getResources().getDisplayMetrics().widthPixels;
        int maxCardW = (int) (screenW * 0.86f) - dp(36);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
            maxCardW, FrameLayout.LayoutParams.WRAP_CONTENT);
        lp.gravity    = Gravity.START;
        lp.leftMargin = dp(6);
        card.setLayoutParams(lp);

        root.addView(card);
        return root;
    }

    // ══════════════════════════════════════════════════════════════════
    //  buildCardContent — premium cinema card layout
    //
    //  Standalone: deeper background, elevation, clipped outline
    //  Embedded (inside combined): inherits container background
    //
    //  Poster: 84×128dp — taller, more cinematic 2:3 ratio
    //  Info: badge · title · meta · overview · watch button
    // ══════════════════════════════════════════════════════════════════
    private LinearLayout buildCardContent(boolean standalone) {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setClickable(true);
        card.setFocusable(true);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        if (standalone) {
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(18));
            bg.setColors(new int[]{ 0xFF0F0F24, 0xFF0A0A18 });
            bg.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
            bg.setStroke(1, 0xFF1E1E38);
            card.setBackground(bg);
            card.setElevation(dp(4));
            card.setClipToOutline(true);
            card.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override public void getOutline(View v, android.graphics.Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(18));
                }
            });
        }

        // Press spring animation — premium tactile feedback
        card.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.animate().scaleX(0.97f).scaleY(0.97f)
                        .setDuration(90).setInterpolator(new DecelerateInterpolator()).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.animate().scaleX(1f).scaleY(1f)
                        .setDuration(280).setInterpolator(new OvershootInterpolator(2.4f)).start();
                    break;
            }
            return false;
        });

        // ─── Poster frame ─────────────────────────────────────────────
        FrameLayout posterFrame = new FrameLayout(context);
        LinearLayout.LayoutParams pfLp = new LinearLayout.LayoutParams(dp(84), dp(128));
        pfLp.rightMargin = dp(14);
        posterFrame.setLayoutParams(pfLp);

        // Shimmer placeholder
        View shimmer = new View(context);
        shimmer.setLayoutParams(new FrameLayout.LayoutParams(dp(84), dp(128)));
        shimmer.setTag("shimmer");
        GradientDrawable sBg = new GradientDrawable();
        sBg.setCornerRadius(dp(12));
        sBg.setColors(new int[]{ 0xFF1A1A38, 0xFF222248 });
        sBg.setOrientation(GradientDrawable.Orientation.TL_BR);
        shimmer.setBackground(sBg);
        posterFrame.addView(shimmer);

        // Poster image
        ImageView poster = new ImageView(context);
        poster.setTag("poster");
        poster.setLayoutParams(new FrameLayout.LayoutParams(dp(84), dp(128)));
        poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        poster.setClipToOutline(true);
        poster.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override public void getOutline(View v, android.graphics.Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(12));
            }
        });
        posterFrame.addView(poster);

        // Bottom gradient overlay (poster fades into card bg)
        View overlay = new View(context);
        FrameLayout.LayoutParams ovLp = new FrameLayout.LayoutParams(dp(84), dp(44));
        ovLp.gravity = Gravity.BOTTOM;
        GradientDrawable oGd = new GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, new int[]{ 0x00000000, 0xC807070D });
        oGd.setCornerRadii(new float[]{ 0, 0, 0, 0, dp(12), dp(12), dp(12), dp(12) });
        overlay.setBackground(oGd);
        overlay.setLayoutParams(ovLp);
        posterFrame.addView(overlay);
        card.addView(posterFrame);

        // ─── Info column ──────────────────────────────────────────────
        LinearLayout info = new LinearLayout(context);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setGravity(Gravity.TOP | Gravity.START);
        info.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        info.setLayoutParams(new LinearLayout.LayoutParams(
            0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        // Type badge — minimal, uppercase letter-spacing
        TextView badge = new TextView(context);
        badge.setTag("badge");
        badge.setTextSize(8.5f);
        badge.setTextColor(C_LITE);
        badge.setTypeface(Typeface.DEFAULT_BOLD);
        badge.setLetterSpacing(0f);
        badge.setPadding(dp(9), dp(3), dp(9), dp(3));
        GradientDrawable bdBg = new GradientDrawable();
        bdBg.setCornerRadius(dp(20));
        bdBg.setColor(0x12C4A0E8);
        bdBg.setStroke(1, 0x35C4A0E8);
        badge.setBackground(bdBg);
        LinearLayout.LayoutParams bdLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        bdLp.bottomMargin = dp(8);
        badge.setLayoutParams(bdLp);
        info.addView(badge);

        // Title — larger, bolder hierarchy
        TextView title = new TextView(context);
        title.setTag("title");
        title.setTextSize(14f);
        title.setTextColor(0xFFEEEAFF);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setMaxLines(2);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setLineSpacing(0, 1.28f);
        title.setTextDirection(View.TEXT_DIRECTION_LTR);
        title.setGravity(Gravity.START);
        LinearLayout.LayoutParams tLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        tLp.bottomMargin = dp(6);
        title.setLayoutParams(tLp);
        info.addView(title);

        // Meta row (rating + year)
        LinearLayout meta = new LinearLayout(context);
        meta.setTag("meta");
        meta.setOrientation(LinearLayout.HORIZONTAL);
        meta.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        meta.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout.LayoutParams mLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        mLp.bottomMargin = dp(8);
        meta.setLayoutParams(mLp);
        info.addView(meta);

        // Overview — 2 lines max, more legible
        TextView ov = new TextView(context);
        ov.setTag("ov");
        ov.setTextSize(11f);
        ov.setTextColor(0xFF6060A0);
        ov.setMaxLines(2);
        ov.setEllipsize(android.text.TextUtils.TruncateAt.END);
        ov.setLineSpacing(0, 1.48f);
        ov.setTextDirection(View.TEXT_DIRECTION_LTR);
        ov.setGravity(Gravity.START);
        LinearLayout.LayoutParams ovInfoLp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT);
        ovInfoLp.bottomMargin = dp(12);
        ov.setLayoutParams(ovInfoLp);
        info.addView(ov);

        // Watch button — premium cinema gradient (vector play icon, no glyphs)
        LinearLayout watch = new LinearLayout(context);
        watch.setTag("watch");
        watch.setOrientation(LinearLayout.HORIZONTAL);
        watch.setGravity(Gravity.CENTER);
        watch.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable wBg = new GradientDrawable();
        wBg.setCornerRadius(dp(12));
        wBg.setColors(new int[]{ 0xFFB870F0, 0xFF7040B8, 0xFF4A1880 });
        wBg.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT);
        watch.setBackground(wBg);
        watch.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView watchTxt = new TextView(context);
        watchTxt.setTag("watch_txt");
        watchTxt.setTextSize(12f);
        watchTxt.setTextColor(0xFFF0EEFF);
        watchTxt.setTypeface(Typeface.DEFAULT_BOLD);
        watchTxt.setLetterSpacing(0f);
        watchTxt.setMaxLines(1);
        watch.addView(watchTxt);

        ImageView playIc = new ImageView(context);
        LinearLayout.LayoutParams piLp = new LinearLayout.LayoutParams(dp(13), dp(13));
        piLp.leftMargin = dp(7); // النص عربي (RTL): الأيقونة بعد النص = يساره في LTR
        playIc.setLayoutParams(piLp);
        playIc.setImageResource(R.drawable.ic_play_filled);
        playIc.setColorFilter(0xFFF0EEFF);
        watch.addView(playIc);

        info.addView(watch);

        card.addView(info);
        return card;
    }

    // ══════════════════════════════════════════════════════════════════
    //  bindCardData — populate card with TMDB data
    //  Cleaner meta row: rating pill + year, refined badge colors
    // ══════════════════════════════════════════════════════════════════
    private void bindCardData(LinearLayout card, final JSONObject item, final String mediaType) {
        final String title_en   = item.optString("title",          item.optString("name",  ""));
        final String title_orig = item.optString("original_title", item.optString("original_name", ""));
        final String display = !title_en.isEmpty()   ? title_en
                             : !title_orig.isEmpty() ? title_orig : "—";
        final String pp  = item.optString("poster_path",  "");
        final double rt  = item.optDouble("vote_average", 0);
        final String dr  = item.optString("release_date", item.optString("first_air_date", ""));
        final int    yr  = (dr.length() >= 4) ? safeInt(dr.substring(0, 4)) : 0;
        final String ot  = item.optString("overview", "");
        final int    id  = item.optInt("id", 0);

        TextView     badgeTV  = card.findViewWithTag("badge");
        TextView     titleTV  = card.findViewWithTag("title");
        LinearLayout meta     = card.findViewWithTag("meta");
        TextView     ovTV     = card.findViewWithTag("ov");
        View         watchRow = card.findViewWithTag("watch");
        TextView     watchTV  = card.findViewWithTag("watch_txt");
        ImageView    poster   = card.findViewWithTag("poster");
        View         shimmer  = card.findViewWithTag("shimmer");

        // Badge — premium color per type, refined border
        if (badgeTV != null) {
            String label; int bgColor, textColor, borderColor;
            if ("movie".equals(mediaType)) {
                label = "فيلم";
                bgColor = 0x10C4A0E8; textColor = 0xFFB898E8; borderColor = 0x30C4A0E8;
            } else if ("anime".equals(mediaType)) {
                label = "أنمي";
                bgColor = 0x10FF90B8; textColor = 0xFFFF88B0; borderColor = 0x30FF90B8;
            } else {
                label = "مسلسل";
                bgColor = 0x10A0D0FF; textColor = 0xFF90C8FF; borderColor = 0x30A0D0FF;
            }
            badgeTV.setText(label);
            badgeTV.setTextColor(textColor);
            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(20));
            bg.setColor(bgColor);
            bg.setStroke(1, borderColor);
            badgeTV.setBackground(bg);
        }

        if (titleTV != null) titleTV.setText(display);

        // Meta row: refined rating pill + year
        if (meta != null) {
            meta.removeAllViews();
            if (rt >= 0.5) {
                LinearLayout ratingBox = new LinearLayout(context);
                ratingBox.setOrientation(LinearLayout.HORIZONTAL);
                ratingBox.setGravity(Gravity.CENTER_VERTICAL);
                ratingBox.setPadding(dp(8), dp(3), dp(8), dp(3));
                GradientDrawable rb = new GradientDrawable();
                rb.setCornerRadius(dp(6));
                rb.setColor(0x18F5C518);
                rb.setStroke(1, 0x35F5C518);
                ratingBox.setBackground(rb);

                TextView starTV = new TextView(context);
                starTV.setText("★");
                starTV.setTextSize(9.5f);
                starTV.setTextColor(C_STAR);
                starTV.setTypeface(Typeface.DEFAULT_BOLD);
                LinearLayout.LayoutParams sLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
                sLp.rightMargin = dp(4);
                starTV.setLayoutParams(sLp);
                ratingBox.addView(starTV);

                TextView rtTV = new TextView(context);
                rtTV.setText(String.format(Locale.US, "%.1f", rt));
                rtTV.setTextSize(10f);
                rtTV.setTextColor(0xFFFAD888);
                rtTV.setTypeface(Typeface.DEFAULT_BOLD);
                ratingBox.addView(rtTV);

                LinearLayout.LayoutParams rbLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
                rbLp.rightMargin = dp(8);
                ratingBox.setLayoutParams(rbLp);
                meta.addView(ratingBox);
            }
            if (yr > 0) {
                TextView yrTV = new TextView(context);
                yrTV.setText(String.valueOf(yr));
                yrTV.setTextSize(10.5f);
                yrTV.setTextColor(0xFF3E3E68);
                yrTV.setLetterSpacing(0f);
                meta.addView(yrTV);
            }
        }

        if (ovTV != null) {
            ovTV.setVisibility(ot.isEmpty() ? View.GONE : View.VISIBLE);
            if (!ot.isEmpty()) ovTV.setText(ot);
        }

        if (watchTV != null) watchTV.setText("شاهد الآن");

        // Poster loading with Glide
        if (poster != null) {
            if (!pp.isEmpty()) {
                if (shimmer != null) shimmer.setVisibility(View.VISIBLE);
                Glide.with(context)
                    .load(TMDB_IMG + pp)
                    .centerCrop()
                    .transition(DrawableTransitionOptions.withCrossFade(300))
                    .listener(new com.bumptech.glide.request.RequestListener<android.graphics.drawable.Drawable>() {
                        @Override
                        public boolean onLoadFailed(com.bumptech.glide.load.engine.GlideException e,
                                Object model,
                                com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> t,
                                boolean isFirstResource) {
                            if (shimmer != null) shimmer.setVisibility(View.GONE);
                            poster.setImageDrawable(null);
                            poster.setBackgroundColor(0xFF161634);
                            return false;
                        }
                        @Override
                        public boolean onResourceReady(android.graphics.drawable.Drawable resource,
                                Object model,
                                com.bumptech.glide.request.target.Target<android.graphics.drawable.Drawable> t,
                                com.bumptech.glide.load.DataSource ds, boolean isFirstResource) {
                            if (shimmer != null) shimmer.setVisibility(View.GONE);
                            return false;
                        }
                    }).into(poster);
            } else {
                Glide.with(context).clear(poster);
                poster.setImageDrawable(null);
                poster.setBackgroundColor(0xFF141430);
                if (shimmer != null) {
                    GradientDrawable ph = new GradientDrawable();
                    ph.setCornerRadius(dp(12));
                    ph.setColor(0xFF121228);
                    ph.setStroke(1, 0xFF222240);
                    shimmer.setBackground(ph);
                    shimmer.setVisibility(View.VISIBLE);
                }
            }
        }

        // Card tap → DetailActivity with scale-up transition
        View.OnClickListener go = v -> {
            try {
                JSONObject nav = new JSONObject();
                nav.put("id",             id);
                nav.put("media_type",     mediaType);
                nav.put("title",          display);
                nav.put("name",           display);
                nav.put("original_title", title_orig);
                nav.put("original_name",  title_orig);
                nav.put("poster_path",    pp);
                nav.put("vote_average",   rt);
                nav.put("overview",       ot);

                Intent intent = new Intent(context, DetailActivity.class);
                intent.putExtra("item_json", nav.toString());
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                android.app.Activity activity = getActivity();
                if (activity != null) {
                    android.app.ActivityOptions opts =
                        android.app.ActivityOptions.makeScaleUpAnimation(
                            v, 0, 0, v.getWidth(), v.getHeight());
                    activity.startActivity(intent, opts.toBundle());
                } else {
                    context.startActivity(intent);
                }
            } catch (Exception ignored) {}
        };
        card.setOnClickListener(go);
        if (watchRow != null) watchRow.setOnClickListener(go);
    }

    private android.app.Activity getActivity() {
        android.content.Context ctx = context;
        while (ctx instanceof android.content.ContextWrapper) {
            if (ctx instanceof android.app.Activity) return (android.app.Activity) ctx;
            ctx = ((android.content.ContextWrapper) ctx).getBaseContext();
        }
        return null;
    }

    // ══════════════════════════════════════════════════════════════════
    //  VIEW HOLDERS
    // ══════════════════════════════════════════════════════════════════

    static class UserVH extends RecyclerView.ViewHolder {
        final TextView tv;
        UserVH(View v) { super(v); tv = v.findViewWithTag("txt"); }
        void bind(String t) { if (tv != null) tv.setText(t); }
    }

    static class EveVH extends RecyclerView.ViewHolder {
        final TextView tv;
        EveVH(View v) { super(v); tv = v.findViewWithTag("txt"); }
        void bind(String t) { if (tv != null) tv.setText(t); }
    }

    class CombinedVH extends RecyclerView.ViewHolder {
        final TextView     tv;
        final LinearLayout cardsBox;
        CombinedVH(View v) {
            super(v);
            tv       = v.findViewWithTag("txt");
            cardsBox = v.findViewWithTag("cards_box");
        }

        void bind(String text, List<JSONObject> cards, List<String> cardTypes) {
            if (tv != null) {
                if (text != null && !text.isEmpty()) {
                    tv.setText(text);
                    tv.setVisibility(View.VISIBLE);
                } else {
                    tv.setVisibility(View.GONE);
                }
            }
            if (cardsBox == null) return;
            cardsBox.removeAllViews();
            if (cards == null || cards.isEmpty()) return;
            for (int i = 0; i < cards.size(); i++) {
                JSONObject item = cards.get(i);
                if (item == null) continue;
                String mt = (cardTypes != null && i < cardTypes.size())
                    ? cardTypes.get(i) : "movie";

                // Hairline divider between cards
                View sep = new View(context);
                sep.setBackgroundColor(0x15C4A0E8);
                LinearLayout.LayoutParams sLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, 1);
                sLp.leftMargin  = dp(14);
                sLp.rightMargin = dp(14);
                sep.setLayoutParams(sLp);
                cardsBox.addView(sep);

                LinearLayout card = buildCardContent(false);
                bindCardData(card, item, mt);
                cardsBox.addView(card, new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════
    //  TYPING VIEW HOLDER — sinusoidal dot animation
    // ══════════════════════════════════════════════════════════════════

    static class TypingVH extends RecyclerView.ViewHolder {
        private final View    d0, d1, d2;
        private final Handler handler = new Handler(Looper.getMainLooper());
        private boolean running = false;

        TypingVH(View v) {
            super(v);
            d0 = v.findViewWithTag("d0");
            d1 = v.findViewWithTag("d1");
            d2 = v.findViewWithTag("d2");
        }

        void startDots() {
            if (running) return;
            running = true;
            animateDot(d0, 0L,   900L);
            animateDot(d1, 300L, 900L);
            animateDot(d2, 600L, 900L);
        }

        private void animateDot(View dot, long startDelay, long period) {
            if (dot == null) return;
            Runnable loop = new Runnable() {
                @Override public void run() {
                    if (!running) {
                        dot.animate().alpha(0.20f).scaleX(1f).scaleY(1f).setDuration(160).start();
                        return;
                    }
                    dot.animate().alpha(1f).scaleX(1.45f).scaleY(1.45f)
                        .setDuration((long)(period * 0.44))
                        .setInterpolator(new DecelerateInterpolator())
                        .withEndAction(() -> {
                            if (!running) return;
                            dot.animate().alpha(0.20f).scaleX(1f).scaleY(1f)
                                .setDuration((long)(period * 0.44))
                                .setInterpolator(new DecelerateInterpolator())
                                .withEndAction(() -> {
                                    if (running) handler.postDelayed(this, (long)(period * 0.12));
                                }).start();
                        }).start();
                }
            };
            handler.postDelayed(loop, startDelay);
        }

        void stopDots() {
            running = false;
            handler.removeCallbacksAndMessages(null);
        }
    }

    static class CardVH extends RecyclerView.ViewHolder {
        final LinearLayout card;
        final ImageView    poster;
        CardVH(View v) {
            super(v);
            card   = v.findViewWithTag("card");
            poster = card != null ? card.findViewWithTag("poster") : null;
        }
        void bind(JSONObject item, String mediaType) {
            // binding happens in CombinedVH/EveChatAdapter directly
        }
    }

    // Override for CardVH to work — needs adapter access for bindCardData
    class CardVHInner extends RecyclerView.ViewHolder {
        final LinearLayout card;
        final ImageView    poster;
        CardVHInner(View v) {
            super(v);
            card   = v.findViewWithTag("card");
            poster = card != null ? card.findViewWithTag("poster") : null;
        }
        void bind(JSONObject item, String mediaType) {
            if (card == null || item == null) return;
            bindCardData(card, item, mediaType);
        }
    }

    // ══════════════════════════════════════════════════════════════════
    //  Utils
    // ══════════════════════════════════════════════════════════════════

    private void copyText(String text) {
        if (text == null || text.trim().isEmpty()) return;
        ClipboardManager cm = (ClipboardManager)
            context.getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("eve", text));
            Toast.makeText(context, "تم نسخ النص", Toast.LENGTH_SHORT).show();
        }
    }

    private int dp(int v) {
        return (int) (v * context.getResources().getDisplayMetrics().density);
    }

    private static int safeInt(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; }
    }
}

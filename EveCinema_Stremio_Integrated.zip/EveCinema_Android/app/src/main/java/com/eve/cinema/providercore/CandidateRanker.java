package com.eve.cinema.providercore;

/**
 * CandidateRanker — ترتيب المرشحين على مراحل (خطة §12.2) مع درجة 0–100
 * اختيارية بعد اجتياز البوابات الصلبة (§12.3). الأوزان اقتراح تجريبي
 * يُعاير بقياسات حقيقية؛ أي شك في العربية/الهوية يرفض المرشح لا يعوَّض بدرجة.
 *
 * Pure Java — unit-tested on the JVM.
 */
public final class CandidateRanker {

    /** إشارات قياس حقيقية من الشبكة/المشغّل لهذا المرشح أو مضيفه. */
    public static final class Signals {
        public double transportStability = 0.5;  // 0..1 نجاحات حديثة للمضيف (30%)
        public double speedMargin;               // معدل مقاس / bitrate؛ <=0 غير مقاس (25%)
        public double ttfbMs = -1;               // زمن أول بايت (15%)
        public double codecSupported = 1;        // 0/1 بوابة تشغيل
        public boolean manifestOk = true;        // بوابة seek/manifest (10%)
        public boolean rangeOk = true;
        public double evidenceTrust = 1.0;       // موثوقية دليل النوع (5%)

        /** هامش السرعة المطلوب: 1.4×–1.7× (§12.2 بند 3). */
        public boolean speedGateOk() {
            return speedMargin <= 0 || speedMargin >= 1.4;
        }
    }

    public static final class Scored implements Comparable<Scored> {
        public final NormalizedCandidate candidate;
        public final double score; // 0..100

        Scored(NormalizedCandidate c, double s) {
            this.candidate = c;
            this.score = s;
        }

        @Override public int compareTo(Scored o) {
            return Double.compare(o.score, score); // تنازلي
        }
    }

    /** البوابات الصلبة: فشل أي منها = استبعاد، لا خصم درجة. */
    public static boolean passesHardGates(NormalizedCandidate c, Signals s) {
        if (c == null) return false;
        if (c.validationStatus() != ProviderResultState.VERIFIED_PLAYABLE) return false;
        if (c.playbackMode() == null
                || !c.evidence().isVerified(c.playbackMode())) return false;
        if (s != null) {
            if (s.codecSupported <= 0) return false;
            if (!s.speedGateOk()) return false;
        }
        return true;
    }

    /** درجة 0–100 بعد البوابات (الأوزان من §12.3). */
    public static double score(NormalizedCandidate c, Signals s) {
        if (!passesHardGates(c, s)) return 0;
        if (s == null) s = new Signals();

        double stability = clamp01(s.transportStability);
        double speed;
        if (s.speedMargin <= 0) speed = 0.5; // غير مقاس — حياد
        else speed = clamp01((s.speedMargin - 1.4) / (3.0 - 1.4)); // 1.4×→0، 3×→1

        double startup;
        if (s.ttfbMs < 0) startup = 0.5;
        else startup = clamp01(1.0 - (s.ttfbMs / 4000.0)); // 4 ثوانٍ TTFB → 0

        double quality = qualityScore(c.quality());
        double seek = ((s.manifestOk ? 0.6 : 0.0) + (s.rangeOk ? 0.4 : 0.0));
        double evidence = clamp01(s.evidenceTrust);

        double total = stability * 30 + speed * 25 + startup * 15
                + quality * 15 + seek * 10 + evidence * 5;
        return Math.max(0, Math.min(100, total));
    }

    /** جودة الصورة داخل القدرات: أعلى جودة لا تُختار إن كانت غير عملية — تحسمها بوابة السرعة قبل الدرجة. */
    private static double qualityScore(int q) {
        if (q <= 0) return 0.6;          // AUTO/غير معروف — حياد
        if (q >= 2160) return 1.0;
        if (q >= 1080) return 0.9;
        if (q >= 720) return 0.75;
        if (q >= 480) return 0.55;
        return 0.35;
    }

    private static double clamp01(double v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }

    /** ترتيب قائمة مع إشارات لكل مرشح (بنفس الترتيب) — المستبعدون يُحذفون. */
    public static java.util.List<Scored> rank(java.util.List<NormalizedCandidate> candidates,
                                              java.util.List<Signals> signals) {
        java.util.List<Scored> out = new java.util.ArrayList<>();
        for (int i = 0; i < candidates.size(); i++) {
            Signals s = signals != null && i < signals.size() ? signals.get(i) : null;
            NormalizedCandidate c = candidates.get(i);
            if (passesHardGates(c, s)) out.add(new Scored(c, score(c, s)));
        }
        java.util.Collections.sort(out);
        return out;
    }
}

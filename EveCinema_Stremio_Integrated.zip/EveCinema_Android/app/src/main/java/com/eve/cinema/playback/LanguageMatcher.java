package com.eve.cinema.playback;

import java.util.Locale;
import java.text.Normalizer;

/**
 * Normalises subtitle / audio language labels coming from providers and Media3
 * Formats. Arabic is matched by ISO codes (ar, ara, arb, ar-XX) and by names
 * ("Arabic", "العربية", "عربي"). Never matches Hindi, Armenian, etc.
 */
public final class LanguageMatcher {

    public static final String AR = "ar";
    public static final String EN = "en";

    private LanguageMatcher() {}

    public static boolean isArabic(String raw) {
        return AR.equals(normalize(raw));
    }

    public static boolean isEnglish(String raw) {
        return EN.equals(normalize(raw));
    }

    /** Returns "ar", "en", another lower-case primary code, or null when unknown. */
    public static String normalize(String raw) {
        if (raw == null) return null;
        String s = normalizeArabicMarks(raw.trim());
        if (s.isEmpty()) return null;
        String lower = s.toLowerCase(Locale.ROOT);

        if (lower.contains("عرب") || lower.contains("arabic")) return AR;
        if (lower.contains("إنجليز") || lower.contains("انجليز") || lower.contains("english"))
            return EN;

        String code = lower.replace('_', '-');
        int dash = code.indexOf('-');
        String primary = dash > 0 ? code.substring(0, dash) : code;
        switch (primary) {
            case "ar": case "ara": case "arb": return AR;
            case "en": case "eng": return EN;
            case "und": case "unknown": case "": return null;
            default:
                return primary.matches("[a-z]{2,3}") ? primary : null;
        }
    }

    /**
     * Arabic labels frequently arrive with harakat/tatweel, which otherwise split
     * substring checks such as "العربية". Remove only combining marks and tatweel;
     * preserve letters, digits, and punctuation used by ISO language tags.
     */
    private static String normalizeArabicMarks(String value) {
        String decomposed = Normalizer.normalize(value, Normalizer.Form.NFD);
        StringBuilder out = new StringBuilder(decomposed.length());
        for (int i = 0; i < decomposed.length(); i++) {
            char c = decomposed.charAt(i);
            int type = Character.getType(c);
            if (type == Character.NON_SPACING_MARK
                    || type == Character.COMBINING_SPACING_MARK
                    || type == Character.ENCLOSING_MARK
                    || c == '\u0640') {
                continue;
            }
            out.append(c);
        }
        return Normalizer.normalize(out.toString(), Normalizer.Form.NFC);
    }
}

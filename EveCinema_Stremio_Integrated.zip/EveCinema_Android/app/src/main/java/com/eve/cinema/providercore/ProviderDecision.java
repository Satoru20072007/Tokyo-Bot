package com.eve.cinema.providercore;

/**
 * ProviderDecision — ورقة قرار كل مصدر (خريطة الطرق الجانبية وقالب §22).
 *
 * القاعدة: بدون عقد واجهة موثّق أو إذن مكتوب، ثم ترخيص مراجَع، يكون الجواب
 * REJECTED ولا يدخل المصدر الطريق الرئيسي. الحالة تُفحص في ProviderRegistry
 * قبل أي استدعاء؛ REJECTED/DISABLED لا يعملان أبداً.
 *
 * Pure Java, no Android deps — unit-tested on the JVM.
 */
public enum ProviderDecision {
    /** اجتاز بوابة القبول كاملة ويعمل للمستخدمين. */
    ACCEPTED,
    /** يعمل ضمن مسار تجريبي مخفي من المسار الافتراضي حتى تكتمل أدلته. */
    EXPERIMENTAL,
    /** موجود في السجل لكنه مطفأ — لا يُستدعى إطلاقاً. */
    DISABLED,
    /** مرفوض بالبوابة (لا عقد/لا إذن/ترخيص مانع/يحتاج تحايل حماية). */
    REJECTED;

    public boolean allowsTraffic() {
        return this == ACCEPTED || this == EXPERIMENTAL;
    }

    /**
     * القرارات الحالية المتخذة من فحص الكود والبحث (خريطة الكنز 2026-10-17).
     * لا تُرقَّى أي قيمة هنا إلا بدليل اختبار جديد موثّق في سجل الجلسة.
     */
    public static ProviderDecision currentFor(String providerId) {
        if (providerId == null) return REJECTED;
        switch (providerId) {
            case ProviderIds.CINEMABOX:
                // يعمل داخل Eve اليوم؛ direct-from-phone محفوظ. يبقى مشروطاً
                // بتثبيت الحساب عبر CinemaBoxCredentials بعد المحطة 0.
                return ACCEPTED;
            case ProviderIds.MOVIEBOX:
                // مطفأ بقرار المالك (2026-10-20): صار Stremio هو «مصدر 1» والأساسي
                // للأنمي. لا يُستدعى MovieBox إطلاقاً ولا يظهر في المحدّد.
                // لإعادته: أعد القيمة إلى EXPERIMENTAL هنا فقط (مكان واحد).
                return DISABLED;
            case ProviderIds.VODU:
                // لا API عام ولا إذن مكتوب؛ شروط الاستخدام تمنع الوصول غير
                // المصرّح والهندسة العكسية. مفتاح الفتح: موافقة مكتوبة.
                return REJECTED;
            case ProviderIds.SINEMANA:
                // لا وثائق رسمية؛ المسارات من هندسة عكسية والنطاق غير مؤكد.
                // مفتاح الفتح: إذن أو عقد من الشركة.
                return REJECTED;
            default:
                // أي مصدر جديد يدخل مغلقاً حتى تُملأ ورقة قراره (§22).
                return REJECTED;
        }
    }
}

/*
 * Derived from MovieBox-Tui (Rust) — upstream dual-licensed MIT / Apache-2.0.
 * Upstream copyright retained. See NOTICE at the project root for the full
 * license texts and attribution scope.
 */
package com.eve.cinema.moviebox;

/*
 * Title selection for MovieBox search results. Adapted to MovieBox's search
 * model (subjectType 1/2, releaseDate strings) with the same scoring
 * philosophy as Eve's CinemaBoxBridge (exact > stripped > articles >
 * containment with length guard > word-overlap dice, year as a supporting
 * signal). Written fresh for this integration.
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import com.eve.cinema.moviebox.MovieBoxModels.SubjectItem;

/**
 * Picks the correct MovieBox subject for a TMDB title — never blindly the
 * first result.
 */
public final class MovieBoxTitleMatcher {

    private static final int MIN_SCORE = 55;

    private static final Set<String> STOPWORDS = new HashSet<>(Arrays.asList(
            "the", "and", "for", "with", "this", "that", "from", "into",
            "season", "part", "new", "ova", "ona", "special", "movie", "film"));

    private MovieBoxTitleMatcher() {}

    /** Result of a pick: the chosen subject plus the confidence score. */
    public static final class Pick {
        public final SubjectItem item;
        public final int score;
        public Pick(SubjectItem item, int score) { this.item = item; this.score = score; }
    }

    static String normalize(String s) {
        if (s == null) return "";
        String lower = s.toLowerCase(Locale.US);
        StringBuilder sb = new StringBuilder(lower.length());
        boolean lastSpace = true;
        for (int i = 0; i < lower.length(); i++) {
            char c = lower.charAt(i);
            boolean keep = Character.isLetterOrDigit(c);
            if (keep) {
                sb.append(c);
                lastSpace = false;
            } else if (!lastSpace) {
                sb.append(' ');
                lastSpace = true;
            }
        }
        return sb.toString().trim();
    }

    private static String stripArticle(String s) {
        if (s.startsWith("the ")) return s.substring(4);
        if (s.startsWith("a ")) return s.substring(2);
        if (s.startsWith("an ")) return s.substring(3);
        return s;
    }

    private static String[] significantWords(String norm) {
        if (norm.isEmpty()) return new String[0];
        List<String> out = new ArrayList<>();
        for (String w : norm.split(" ")) {
            if (w.length() < 3 || STOPWORDS.contains(w)) continue;
            out.add(w);
        }
        return out.toArray(new String[0]);
    }

    private static int countShared(String[] a, String[] b) {
        int n = 0;
        for (String wa : a) {
            for (String wb : b) {
                if (wa.equals(wb)) { n++; break; }
            }
        }
        return n;
    }

    /**
     * Scores one candidate. 0 = rejected outright (wrong media type or no
     * textual relation).
     */
    static int score(SubjectItem cand, String queryNorm, int year, boolean wantSeries) {
        return score(cand, cand.title, queryNorm, year, wantSeries);
    }

    static int score(SubjectItem cand, String candTitle, String queryNorm, int year,
                     boolean wantSeries) {
        // Media type is a hard requirement: a movie query must not resolve to
        // a series subject and vice versa.
        if (cand.isSeries != wantSeries) return 0;

        // Contradictory years = different installment/remake (e.g. Resident
        // Evil 2002 vs 2021). A title match never overrides a year conflict.
        int candYear = -1;
        if (!cand.year.isEmpty()) {
            try { candYear = Integer.parseInt(cand.year); }
            catch (NumberFormatException ignored) {}
        }
        if (com.eve.cinema.playback.MediaIdentity.yearHardRejects(year, candYear))
            return 0;

        String rNorm = normalize(candTitle);
        if (rNorm.isEmpty() || queryNorm.isEmpty()) return 0;

        // Short titles (F1): when stopword/length filtering reduces the query
        // to zero or one significant token ("From", "It", "Us", "Up"), ONLY
        // exact normalized equality (raw or article-stripped) is evidence.
        // Containment and Dice against look-alikes ("From Dusk Till Dawn",
        // "From Scratch") are noise, never a match.
        boolean shortTitle = significantWords(queryNorm).length <= 1;

        int score = 0;
        if (rNorm.equals(queryNorm)) {
            score = 100;
        } else if (stripArticle(rNorm).equals(stripArticle(queryNorm))) {
            score = 90;
        } else if (shortTitle) {
            score = 0;
        } else if (queryNorm.contains(rNorm) && rNorm.length() >= 4
                && rNorm.length() >= queryNorm.length() * 0.65) {
            score = 70;
        } else if (rNorm.contains(queryNorm) && queryNorm.length() >= 4
                && queryNorm.length() >= rNorm.length() * 0.65) {
            score = 70;
        } else {
            String[] qSig = significantWords(queryNorm);
            String[] rSig = significantWords(rNorm);
            if (qSig.length > 0 && rSig.length > 0) {
                int shared = countShared(qSig, rSig);
                if (shared >= 2) {
                    double dice = (2.0 * shared) / (double) (qSig.length + rSig.length);
                    double minCov = Math.min((double) shared / qSig.length,
                                             (double) shared / rSig.length);
                    if (dice >= 0.75 && minCov >= 0.40) score = 60;
                    else if (dice >= 0.60 && minCov >= 0.30) score = 50;
                } else if (shared == 1 && qSig.length == 1 && rSig.length == 1) {
                    score = 45;
                }
            }
        }
        if (score == 0) return 0;

        // Year as a supporting signal (candYear was parsed above for the hard gate).
        if (year > 0 && candYear > 0) {
            int diff = Math.abs(candYear - year);
            if (diff == 0) score += 10;
            else if (diff == 1) score += 3;
            else if (diff <= 3) score -= 8;
            else score -= 15;
        }
        return score;
    }

    /** Best candidate at or above the confidence threshold; null otherwise. */
    public static Pick pickBest(List<SubjectItem> candidates, String title,
                                String originalTitle, int year, boolean wantSeries) {
        Pick best = null;
        best = tryQuery(candidates, title, year, wantSeries, best);
        if (originalTitle != null && !originalTitle.isEmpty()
                && !originalTitle.equalsIgnoreCase(title == null ? "" : title)) {
            best = tryQuery(candidates, originalTitle, year, wantSeries, best);
        }
        return (best != null && best.score >= MIN_SCORE) ? best : null;
    }

    /** One acceptable MovieBox release for a title, with what its label claims. */
    public static final class ReleaseCandidate {
        public final SubjectItem item;
        public final int score;
        public final MovieBoxReleaseTag tag;
        ReleaseCandidate(SubjectItem item, int score, MovieBoxReleaseTag tag) {
            this.item = item; this.score = score; this.tag = tag;
        }
    }

    /**
     * Every release that passes the same title / media-type / year gates as
     * {@link #pickBest}, best first. Unlike pickBest it scores the title
     * WITHOUT release decorations ("[English]", "S1-S3"), so a language-labelled
     * release is a real candidate instead of a lucky 70-point containment match,
     * and orders candidates so the decision is explicit:
     *  1. releases whose label does not exclude {@code tmdbSeason} (a label that
     *     claims only other seasons is demoted, never trusted);
     *  2. title-match tier (exact/near-exact before partial);
     *  3. un-labelled (original) releases before language-labelled dubs;
     *  4. higher score, then the provider's own order.
     * The label is a ranking hint only — nothing here decides audio or subtitles.
     */
    public static List<ReleaseCandidate> rankReleases(List<SubjectItem> candidates, String title,
            String originalTitle, int year, boolean wantSeries, int tmdbSeason) {
        List<ReleaseCandidate> out = new ArrayList<>();
        if (candidates == null) return out;
        List<String> queries = new ArrayList<>();
        String t = normalize(title);
        if (!t.isEmpty()) queries.add(t);
        String o = normalize(originalTitle);
        if (!o.isEmpty() && !o.equals(t)) queries.add(o);

        java.util.Set<String> seen = new HashSet<>();
        for (SubjectItem cand : candidates) {
            if (cand == null || cand.subjectId == null || cand.subjectId.isEmpty()) continue;
            if (!seen.add(cand.subjectId)) continue;
            MovieBoxReleaseTag tag = MovieBoxReleaseTag.parse(cand.title);
            int best = 0;
            for (String q : queries) {
                best = Math.max(best, score(cand, cand.title, q, year, wantSeries));
                best = Math.max(best, score(cand, tag.baseTitle, q, year, wantSeries));
            }
            if (best >= MIN_SCORE) out.add(new ReleaseCandidate(cand, best, tag));
        }
        final int season = tmdbSeason;
        // Preserve the existing series ordering. For movies, prefer a plain
        // work before language variants; an Arabic-subtitle label is not a dub,
        // but it must not displace the original video when both match equally.
        java.util.Collections.sort(out, (a, b) -> {
            boolean ca = a.tag.coversSeason(season), cb = b.tag.coversSeason(season);
            if (ca != cb) return ca ? -1 : 1;
            int ta = a.score / 20, tb = b.score / 20;
            if (ta != tb) return ta > tb ? -1 : 1;
            int pa = wantSeries ? (a.tag.dubLabelled ? 1 : 0) : releasePreference(a.tag);
            int pb = wantSeries ? (b.tag.dubLabelled ? 1 : 0) : releasePreference(b.tag);
            if (pa != pb) return Integer.compare(pa, pb);
            if (a.tag.dubLabelled != b.tag.dubLabelled) return a.tag.dubLabelled ? 1 : -1;
            return Integer.compare(b.score, a.score);
        });
        return out;
    }

    /** 0 = plain/original, 1 = subtitle-labelled, 2 = dub/ambiguous/language-labelled. */
    private static int releasePreference(MovieBoxReleaseTag tag) {
        if (tag == null) return 2;
        if (tag.isArabicSubtitleHint()) return 1;
        if (tag.isArabicDubHint() || tag.markerKind == MovieBoxReleaseClassifier.Kind.ARABIC_AMBIGUOUS
                || tag.dubLabelled || tag.languageTag != null) return 2;
        return 0;
    }

    private static Pick tryQuery(List<SubjectItem> candidates, String query, int year,
                                 boolean wantSeries, Pick best) {
        String qNorm = normalize(query);
        if (qNorm.isEmpty()) return best;
        for (SubjectItem cand : candidates) {
            // F1/V3: also score the title WITHOUT provider decorations
            // ("[English]", " S01", "_1080P" …). The raw title alone defeats
            // exact matches for one-word titles like "From" — rankReleases
            // already scores the cleaned base; pickBest must not lag behind.
            MovieBoxReleaseTag tag = MovieBoxReleaseTag.parse(cand.title);
            int s = Math.max(score(cand, qNorm, year, wantSeries),
                             score(cand, tag.baseTitle, qNorm, year, wantSeries));
            if (s > 0 && (best == null || s > best.score)) best = new Pick(cand, s);
        }
        return best;
    }
}

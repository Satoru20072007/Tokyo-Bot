package com.eve.cinema;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.provider.Settings;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/**
 * UserSession — Cache محلي سريع للجلسة
 * ─────────────────────────────────────────────────────────────────────────────
 * Firebase هو المصدر الأساسي — هذا مجرد cache سريع.
 * الملف الشخصي يأتي دائماً من Google/Firebase.
 * لا يمكن تعديل الاسم أو الصورة يدوياً.
 * ─────────────────────────────────────────────────────────────────────────────
 */
public class UserSession {

    private static final String PREFS           = "eve_session";
    private static final String KEY_LOGGED_IN   = "logged_in";
    private static final String KEY_CODE        = "access_code";
    private static final String KEY_DEVICE_ID   = "device_id";
    private static final String KEY_USERNAME    = "username";
    private static final String KEY_EMAIL       = "email";
    private static final String KEY_AVATAR_URI  = "avatar_uri";
    private static final String KEY_AVATAR_IDX  = "avatar_index"; // -1 = Google photo
    private static final String KEY_TELEGRAM_ID = "telegram_id";
    private static final String KEY_CODE_STATUS = "code_status";
    private static final String KEY_LAST_VERIFY = "last_verify";

    public static final String STATUS_ACTIVE   = "active";
    public static final String STATUS_DISABLED = "disabled";
    public static final String STATUS_REVOKED  = "revoked";
    public static final String STATUS_UNKNOWN  = "unknown";

    private final SharedPreferences prefs;
    private final String            deviceId;

    public UserSession(Context ctx) {
        this.prefs    = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        this.deviceId = getOrCreateDeviceId(ctx);
    }

    // ── Device ID ─────────────────────────────────────────
    private String getOrCreateDeviceId(Context ctx) {
        String saved = prefs.getString(KEY_DEVICE_ID, null);
        if (saved != null && !saved.isEmpty()) return saved;

        String androidId = Settings.Secure.getString(
            ctx.getContentResolver(), Settings.Secure.ANDROID_ID);
        if (androidId == null || androidId.isEmpty())
            androidId = java.util.UUID.randomUUID().toString();

        String hash = sha256(androidId + "|" + Build.MODEL);
        prefs.edit().putString(KEY_DEVICE_ID, hash).apply();
        return hash;
    }

    public static String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return Integer.toHexString(input.hashCode()); }
    }

    public String getDeviceId() { return deviceId; }

    // ── Session state ─────────────────────────────────────
    public boolean isLoggedIn()       { return prefs.getBoolean(KEY_LOGGED_IN, false); }
    public boolean isCodeActiveLocally() {
        return STATUS_ACTIVE.equals(prefs.getString(KEY_CODE_STATUS, STATUS_UNKNOWN));
    }
    public String getCodeStatus()     { return prefs.getString(KEY_CODE_STATUS, STATUS_UNKNOWN); }
    public long   getLastVerifyTime() { return prefs.getLong(KEY_LAST_VERIFY, 0L); }

    // ── Login / Logout ────────────────────────────────────
    public void loginWithCode(String code) {
        if (code == null || code.trim().isEmpty()) return;
        prefs.edit()
            .putBoolean(KEY_LOGGED_IN, true)
            .putString(KEY_CODE, code.trim().toUpperCase())
            .putString(KEY_CODE_STATUS, STATUS_ACTIVE)
            .putLong(KEY_LAST_VERIFY, System.currentTimeMillis())
            .apply();
    }

    public void updateCodeStatus(String status) {
        SharedPreferences.Editor ed = prefs.edit()
            .putString(KEY_CODE_STATUS, status)
            .putLong(KEY_LAST_VERIFY, System.currentTimeMillis());
        if (!STATUS_ACTIVE.equals(status)) ed.putBoolean(KEY_LOGGED_IN, false);
        ed.apply();
    }

    public void markCodeInvalid(String reason) {
        prefs.edit()
            .putBoolean(KEY_LOGGED_IN, false)
            .putString(KEY_CODE_STATUS, reason != null ? reason : STATUS_DISABLED)
            .apply();
    }

    // ── Telegram ──────────────────────────────────────────
    public void saveTelegramId(long id) { prefs.edit().putLong(KEY_TELEGRAM_ID, id).apply(); }
    public long getTelegramId()          { return prefs.getLong(KEY_TELEGRAM_ID, 0L); }

    // ── Profile (Google cache — لا تعديل يدوي) ───────────

    /**
     * يحفظ الملف الشخصي القادم من Google/Firebase.
     * المصدر الوحيد المسموح به لتحديث الملف الشخصي.
     */
    public void saveGoogleProfile(String name, String email, String photoUrl) {
        prefs.edit()
            .putString(KEY_USERNAME,   name     != null ? name     : "مستخدم")
            .putString(KEY_EMAIL,      email    != null ? email    : "")
            .putString(KEY_AVATAR_URI, photoUrl != null ? photoUrl : "")
            .putInt(KEY_AVATAR_IDX, -1)   // -1 = Google photo
            .apply();
    }

    /** للتوافق مع الكود القديم فقط */
    public void saveProfile(String username, int avatarIndex, String avatarUri) {
        prefs.edit()
            .putString(KEY_USERNAME, username)
            .putInt(KEY_AVATAR_IDX, avatarIndex)
            .putString(KEY_AVATAR_URI, avatarUri != null ? avatarUri : "")
            .apply();
    }

    public void updateUsername(String username) {
        if (username == null) return;
        prefs.edit().putString(KEY_USERNAME, username).apply();
    }

    public void updateAvatar(int avatarIndex, String avatarUri) {
        prefs.edit()
            .putInt(KEY_AVATAR_IDX, avatarIndex)
            .putString(KEY_AVATAR_URI, avatarUri != null ? avatarUri : "")
            .apply();
    }

    public String  getUsername()    { return prefs.getString(KEY_USERNAME, "مستخدم"); }
    public String  getEmail()       { return prefs.getString(KEY_EMAIL, ""); }
    public int     getAvatarIndex() { return prefs.getInt(KEY_AVATAR_IDX, -1); }
    public String  getAvatarUri()   { return prefs.getString(KEY_AVATAR_URI, ""); }
    public String  getCode()        { return prefs.getString(KEY_CODE, ""); }
    public boolean hasProfile()     { return !prefs.getString(KEY_USERNAME, "").isEmpty(); }

    // ── Full logout ───────────────────────────────────────
    public void logout() {
        prefs.edit()
            .putBoolean(KEY_LOGGED_IN, false)
            .remove(KEY_CODE)
            .remove(KEY_CODE_STATUS)
            .remove(KEY_LAST_VERIFY)
            .remove(KEY_USERNAME)
            .remove(KEY_EMAIL)
            .remove(KEY_AVATAR_IDX)
            .remove(KEY_AVATAR_URI)
            .remove(KEY_TELEGRAM_ID)
            .apply();
    }
}

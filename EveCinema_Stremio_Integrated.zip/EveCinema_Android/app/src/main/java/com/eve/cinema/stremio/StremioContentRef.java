package com.eve.cinema.stremio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

/**
 * The title being searched, in every identity the app can honestly produce:
 * the TMDB id it already has, and the IMDb id ({@code tt…}) that stream add-ons such as Torrentio,
 * Comet or MediaFusion actually require. IDs are never invented and the title text is never used as
 * an id: when the IMDb id is unknown only the {@code tmdb:} form exists.
 */
public final class StremioContentRef {
    public static final String MOVIE = "movie";
    public static final String SERIES = "series";
    private static final Pattern IMDB = Pattern.compile("^tt\\d{6,10}$");
    private static final Pattern DIGITS = Pattern.compile("^\\d{1,12}$");
    /** Syntactically valid IMDb-style id used ONLY to ask a manifest "do you accept tt… ids?". */
    public static final String CAPABILITY_PROBE_IMDB = "tt0000001";

    public final String type;
    public final String tmdbId;
    /** null until resolved (or when TMDB has none). */
    public final String imdbId;
    /** 0 for movies. */
    public final int season;
    public final int episode;

    private StremioContentRef(String type, String tmdbId, String imdbId, int season, int episode) {
        this.type = type;
        this.tmdbId = tmdbId;
        this.imdbId = imdbId;
        this.season = season;
        this.episode = episode;
    }

    public static StremioContentRef movie(String tmdbId) {
        return new StremioContentRef(MOVIE, requireDigits(tmdbId), null, 0, 0);
    }

    public static StremioContentRef episode(String tmdbId, int season, int episode) {
        return episode(tmdbId, season, episode, SERIES);
    }

    /** An anime episode may use the Stremio `anime` type; add-ons that only declare `series` are fallback targets. */
    public static StremioContentRef episode(String tmdbId, int season, int episode, String type) {
        if (season < 0 || episode < 1) throw new IllegalArgumentException("Invalid episode");
        String kind = "anime".equals(type) ? "anime" : SERIES;
        return new StremioContentRef(kind, requireDigits(tmdbId), null, season, episode);
    }

    private static String requireDigits(String tmdbId) {
        String id = tmdbId == null ? "" : tmdbId.trim();
        if (!DIGITS.matcher(id).matches()) throw new IllegalArgumentException("Invalid TMDB id");
        return id;
    }

    public static boolean isImdbId(String value) { return value != null && IMDB.matcher(value).matches(); }

    /** Same title with the IMDb id attached (ignored unless it is a well-formed {@code tt…}). */
    public StremioContentRef withImdb(String imdb) {
        String clean = imdb == null ? null : imdb.trim();
        return new StremioContentRef(type, tmdbId, isImdbId(clean) ? clean : null, season, episode);
    }

    public boolean isEpisode() { return SERIES.equals(type) || "anime".equals(type); }
    public boolean isAnime() { return "anime".equals(type); }

    /** {@code tmdb:<id>} or {@code tmdb:<id>:<season>:<episode>}. */
    public String tmdbVideoId() {
        return isEpisode() ? "tmdb:" + tmdbId + ":" + season + ":" + episode : "tmdb:" + tmdbId;
    }

    /** {@code tt…} or {@code tt…:<season>:<episode>}; null when the IMDb id is unknown. */
    public String imdbVideoId() {
        if (imdbId == null) return null;
        return isEpisode() ? imdbId + ":" + season + ":" + episode : imdbId;
    }

    /** Candidate ids in preference order: IMDb first (what add-ons expect), then TMDB. */
    public List<String> candidateIds() {
        List<String> ids = new ArrayList<>(2);
        if (imdbId != null) ids.add(imdbVideoId());
        ids.add(tmdbVideoId());
        return Collections.unmodifiableList(ids);
    }

    /**
     * The single id to send to this add-on for this resource: the first candidate the manifest
     * declares support for, or null when it supports none (the add-on is then not queried at all).
     * Never both: no blind sequential double query.
     */
    public String idFor(StremioManifest manifest, String resource) {
        return idFor(manifest, resource, type);
    }

    /** Selects an id against the actual resource type declared by this add-on. */
    public String idFor(StremioManifest manifest, String resource, String resourceType) {
        for (String candidate : candidateIds()) {
            if (manifest.supports(resource, resourceType, candidate)) return candidate;
        }
        return null;
    }

    /**
     * Could this manifest serve this kind of title with SOME id scheme the app can produce
     * (IMDb once resolved, or TMDB)? Used before the IMDb id is known, e.g. to decide whether the
     * "watch via Stremio" entry should be offered.
     */
    public boolean couldBeServedBy(StremioManifest manifest, String resource) {
        String probe = isEpisode() ? CAPABILITY_PROBE_IMDB + ":" + Math.max(season, 1) + ":" + episode
                : CAPABILITY_PROBE_IMDB;
        if (manifest.supports(resource, type, probe) || manifest.supports(resource, type, tmdbVideoId())) return true;
        return isAnime() && (manifest.supports(resource, SERIES, probe)
                || manifest.supports(resource, SERIES, tmdbVideoId()));
    }
}
